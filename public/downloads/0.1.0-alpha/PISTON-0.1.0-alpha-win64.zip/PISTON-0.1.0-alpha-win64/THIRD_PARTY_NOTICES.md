# Third-Party Notices

PISTON bundles the third-party components below under `extern/`. Each is the property
of its respective authors and is licensed under the terms noted here. The canonical,
full verbatim license text for every component ships alongside it in
`extern/<component>/` (e.g. `extern/imgui/LICENSE.txt`); those files are authoritative.

This notices file is part of ULTRAPLAN P4-1. A configure-time check that every
`extern/` directory has a corresponding entry here is planned (P4-1 follow-up).

| Component | Used for | License | Upstream |
|-----------|----------|---------|----------|
| Dear ImGui | GUI | MIT | github.com/ocornut/imgui |
| ImPlot | GUI plots | MIT | github.com/epezent/implot |
| nlohmann/json | JSON I/O | MIT | github.com/nlohmann/json |
| GLFW | windowing/GL context | zlib/libpng | github.com/glfw/glfw |
| CLI11 | command-line parsing | BSD-3-Clause | github.com/CLIUtils/CLI11 |
| Catch2 | testing (not shipped in release binaries) | BSL-1.0 | github.com/catchorg/Catch2 |
| SQLite (amalgamation) | parts database | Public Domain | sqlite.org |

---

## MIT License — Dear ImGui, ImPlot, nlohmann/json

The following components are licensed under the MIT License, with these copyrights:

- Dear ImGui: Copyright (c) 2014-2026 Omar Cornut
- ImPlot:     Copyright (c) 2020 Evan Pezent
- nlohmann/json: Copyright (c) 2013-2026 Niels Lohmann

> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to deal
> in the Software without restriction, including without limitation the rights
> to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
> copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all
> copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
> OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
> SOFTWARE.

Verbatim: `extern/imgui/LICENSE.txt`, `extern/implot/LICENSE`, `extern/json/LICENSE.MIT`.

---

## zlib/libpng License — GLFW

Copyright (c) 2002-2006 Marcus Geelnard
Copyright (c) 2006-2019 Camilla Löwy

> This software is provided 'as-is', without any express or implied warranty. In no
> event will the authors be held liable for any damages arising from the use of this
> software.
>
> Permission is granted to anyone to use this software for any purpose, including
> commercial applications, and to alter it and redistribute it freely, subject to the
> following restrictions:
>
> 1. The origin of this software must not be misrepresented; you must not claim that you
>    wrote the original software. If you use this software in a product, an acknowledgment
>    in the product documentation would be appreciated but is not required.
> 2. Altered source versions must be plainly marked as such, and must not be
>    misrepresented as being the original software.
> 3. This notice may not be removed or altered from any source distribution.

Verbatim: `extern/glfw/LICENSE.md`.

---

## BSD-3-Clause — CLI11

CLI11 Copyright (c) 2017-2025 University of Cincinnati, developed by Henry Schreiner
under NSF AWARD 1414736. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the conditions of the BSD-3-Clause license are met (retain the
copyright notice and conditions; do not use the names of contributors to endorse
derived products without permission; provided "as is" without warranty).

Verbatim: `extern/CLI11/LICENSE`.

---

## Boost Software License 1.0 — Catch2

Catch2 is used for the test suite and is not linked into released PISTON binaries.
Licensed under the Boost Software License, Version 1.0.

Verbatim: `extern/Catch2/LICENSE.txt`.

---

## Public Domain — SQLite

The SQLite amalgamation (`extern/sqlite3/`) is in the public domain. No license is
required and no copyright is claimed by its authors. See https://sqlite.org/copyright.html
