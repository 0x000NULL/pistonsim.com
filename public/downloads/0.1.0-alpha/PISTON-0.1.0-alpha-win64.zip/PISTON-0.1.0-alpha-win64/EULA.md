# PISTON End-User Licence Agreement (binary releases)

Copyright (c) 2024-2026 PISTON Contributors. All rights reserved.

This agreement is between you and the PISTON copyright holders ("PISTON
Contributors") and governs the compiled software in the official PISTON release
package it ships inside.

## 1. What this licence covers

"The Software" means the compiled binaries and the bundled data files contained
in an official PISTON release package. This licence covers ONLY the Software.
The PISTON source code is not licensed by this agreement: it remains governed
exclusively by the repository LICENSE (proprietary, all rights reserved), and
nothing in this agreement grants any right to the source code.

## 2. Licence grant

Subject to this agreement, you are granted a non-exclusive, non-transferable,
royalty-free, revocable licence to install and run the Software on machines you
control, for any purpose, including commercial use.

## 3. Restrictions

You may NOT:

- redistribute, publish, re-host, sell, or otherwise make the Software or the
  release package available to third parties;
- modify the Software or create derivative works of it;
- reverse engineer, decompile, or disassemble the Software, except to the
  extent applicable law permits this notwithstanding this term;
- sublicense, rent, lease, or lend the Software, or provide it to others as a
  hosted or managed service;
- remove this licence, the copyright notices, or THIRD_PARTY_NOTICES.md from
  the package, or separate components from the package for use outside it.

## 4. Third-party components

The package includes third-party components that remain under their own
licences. THIRD_PARTY_NOTICES.md in this package is the authoritative list;
those licences apply to those components and are not restricted by section 3.

## 5. Versions

Each release package carries the licence text that governs it. A later release
may ship revised terms; those terms apply to that release only.

## 6. No warranty

The Software is provided AS IS, without warranty of any kind, express or
implied, including without limitation the implied warranties of
merchantability, fitness for a particular purpose, and non-infringement.
PISTON produces simulated estimates: its output is not measurement data,
engineering advice, or a substitute for a real dynamometer, and no accuracy of
results is warranted.

## 7. Limitation of liability

To the maximum extent permitted by applicable law, the PISTON Contributors are
not liable for any damages arising out of the use of, or inability to use, the
Software, including without limitation direct, indirect, incidental,
consequential, or special damages, even if advised of the possibility of such
damages.

## 8. Termination

This licence terminates automatically if you breach section 3. On termination
you must stop using the Software and delete your copies. Sections 4 through 9
survive termination.

## 9. General

If a provision of this agreement is unenforceable, the remainder stays in
effect. This agreement is the entire agreement concerning use of the Software
binaries. Trademarks are governed separately; see TRADEMARKS.md in the
repository's docs/legal/ directory.
