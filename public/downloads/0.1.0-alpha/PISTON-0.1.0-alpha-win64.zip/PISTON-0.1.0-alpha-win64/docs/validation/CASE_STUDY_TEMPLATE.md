# Validation Case Study — TEMPLATE

Copy this file to `docs/validation/case_studies/<engine>-<yyyy-mm-dd>.md` and fill every
field. One file = one independent predict-then-dyno data point, gathered per
[`PREDICT_THEN_DYNO_PROTOCOL.md`](PREDICT_THEN_DYNO_PROTOCOL.md). Leave a field blank only if
it genuinely does not apply, and say why — do not invent values. Report the result that came
out, corroborating or not.

> This is a blank template. It is intentionally unfilled; it is not itself a data point and
> must not be cited as one.

## Engine under test
- **Engine:** <make / family / displacement / configuration>
- **Notable build:** <stock | specific parts; link the build sheet if available>
- **Aspiration:** <NA | turbo | supercharged; boost target>
- **Fuel:** <octane / type>

## Prediction (locked before the pull)
- **Config file:** `<path/to/config.json>` (committed at <commit hash / PR link>)
- **Prediction file:** `<path/to/predict.csv>` (lock: <commit timestamp | SHA256 published on date>)
- **PISTON version:** <output of `piston version` — e.g. 0.x.y-alpha + build>
- **Correction standard used in prediction:** <e.g. SAE J1349>
- **Predicted peak power:** <value> @ <rpm>
- **Predicted peak torque:** <value> @ <rpm>

## Measurement
- **Dyno type:** <inertia | brake | hub | engine | chassis>
- **Shop / operator:** <who ran it> — **date:** <yyyy-mm-dd>
- **Correction standard on the dyno:** <must match the prediction, or note the mismatch>
- **Ambient:** <pressure> / <temperature> / <humidity>
- **Drivetrain-loss assumption (chassis only):** <stated assumption, or "n/a — engine dyno">
- **Measured peak power:** <value> @ <rpm>
- **Measured peak torque:** <value> @ <rpm>
- **Raw dyno sheet:** `<path or link>`

## Result
- **Peak power APE:** <|pred − meas| / meas × 100> %
- **Peak torque APE:** <…> %
- **Per-point RMSE (if full curve logged):** <value or "n/a">
- **Within the published fleet band?** <yes / no — compare against the peak MAPE in
  [`accuracy.generated.md`](accuracy.generated.md)>

## Notes & caveats
- <Anything that qualifies the comparison: partial throttle, knock-limited, different fuel,
  config numbers that were published-spec rather than measured, etc.>

## Disposition
- <Corroborates the accuracy claim | Disconfirms — opens a physics-sprint item:
  link to the relevant `docs/physics/` model and the discrepancy.>
