# Validation Data Guide

This guide explains how to add, structure, and use validation data in the PISTON engine simulation project.

## Overview

PISTON uses real-world dyno data to validate simulation accuracy. Validation data is stored as JSON files in the `data/validation/` directory and loaded using the `ValidationDataLoader` class.

## Directory Structure

```
data/validation/
├── naturally_aspirated/      # NA engines
│   └── ls3_stock_published.json
├── supercharged/             # Supercharged engines
│   └── lsa_stock_published.json
├── turbocharged/             # Turbocharged engines
│   └── 2jzgte_single_turbo_e85_community.json
├── _DYNO_DATA_TEMPLATE.json   # annotated template for new entries
└── _QUICK_FILL_TEMPLATE.json  # minimal fill-in-the-blanks template
```

## JSON Schema Format

### Complete Example

```json
{
  "metadata": {
    "source": "Manufacturer published specification (peak power/torque)",
    "date_collected": "2008-09-15",
    "dyno_operator": "General Motors (manufacturer rating)"
  },
  "engine": {
    "name": "LS3 6.2L V8 Stock",
    "manufacturer": "General Motors",
    "configuration": "V8",
    "displacement": 6.162,
    "bore": 103.25,
    "stroke": 92.0,
    "compression_ratio": 10.7,
    "forced_induction": {
      "type": "none",
      "model": "",
      "boost_psi": 0.0
    }
  },
  "dyno_type": "engine",
  "correction_standard": "SAE J1349",
  "conditions": {
    "temperature_f": 77.0,
    "pressure_inhg": 29.92,
    "humidity_percent": 30.0
  },
  "curves": {
    "rpm": [2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 5900, 6000, 6200, 6400, 6500, 6600],
    "power_hp": [133, 181, 228, 277, 320, 364, 400, 425, 430, 428, 425, 420, 415, 410],
    "torque_ftlb": [350, 380, 400, 415, 420, 426, 421, 406, 383, 375, 361, 345, 336, 327],
    "boost_psi": []
  },
  "peak_values": {
    "peak_power_hp": 430.0,
    "peak_power_rpm": 5900.0,
    "peak_torque_ftlb": 426.0,
    "peak_torque_rpm": 4500.0
  },
  "uncertainty": {
    "power_uncertainty_hp": 2.5,
    "torque_uncertainty_ftlb": 3.0,
    "rpm_uncertainty": 10.0
  },
  "sources": [
    "https://www.gmauthority.com/blog/gm/gm-engines/ls/ls3/",
    "GM Performance Parts Catalog 2008"
  ]
}
```

### Required Fields

> The example above is illustrative and flattens the structure for readability.
> `data/validation/schema.json` is canonical, and
> `ValidationDataLoader::validateSchema` is what actually enforces loading — where
> the three disagree, believe the loader.

#### Metadata
- `source`: What the figures are (e.g. a manufacturer's published specification).
  Describe the data, do not assert a certification the entry cannot evidence.
- `date_collected`: Date of dyno test (YYYY-MM-DD)
- `dyno_operator`: Who produced the underlying rating, or `Not recorded`

#### Dyno data
- `curve_provenance`: **Required.** How the rpm/torque/power curve came to exist.
  One of:
  - `measured_dyno_curve` — a real logged sweep, first-party. Use only if you can
    point at the run.
  - `published_measured_curve` — a real measured engine-dyno sweep published by a
    third party (manufacturer certification/catalog curve or equivalent primary
    source), digitized. Cite the publication in `sources`, and record the
    digitization method and read-off uncertainty in the entry's notes. This is not
    a blind point — see `PREDICT_THEN_DYNO_PROTOCOL.md`.
  - `reconstructed_from_published_peaks` — interpolated/estimated around published peaks
  - `published_peak_only` — only the peak values are meaningful

  There is no value for a synthetic curve: an invented reference is not validation
  data, and the loader rejects one.

  The optional `curves._data_quality` array refines this per point (e.g. `verified`
  vs `extrapolated`) and is reported alongside it when present.

  There is deliberately no free-text quality grade. A self-assigned score has no
  defined meaning and invites overclaiming; state the provenance and let the reader
  judge.

#### Engine Specifications
- `name`: Descriptive engine name
- `manufacturer`: Engine manufacturer
- `configuration`: Engine layout (e.g., "V8", "I6", "V6")
- `displacement`: Total displacement in liters
- `bore`: Bore diameter in mm
- `stroke`: Stroke length in mm
- `compression_ratio`: Static compression ratio

#### Forced Induction
- `type`: "none" (NA), "supercharger", or "turbocharger" (case-insensitive)
- `model`: Turbo/supercharger model (empty for NA)
- `boost_psi`: Peak boost pressure (0.0 for NA)

#### Test Conditions
- `dyno_type`: "engine" or "chassis"
- `correction_standard`: "SAE J1349", "DIN 70020", "JIS D 1001", or "STD" (the
  loader rejects underscore spellings like "SAE_J1349")
- `conditions.temperature_f`: Ambient temperature (°F)
- `conditions.pressure_inhg`: Barometric pressure (inHg)
- `conditions.humidity_percent`: Relative humidity (%)

#### Dyno Curves
- `curves.rpm`: Array of RPM points
- `curves.power_hp`: Array of power values (HP)
- `curves.torque_ftlb`: Array of torque values (lb-ft)
- `curves.boost_psi`: Array of boost values (empty for NA engines)

**Important**: All curve arrays must have the same length.

#### Peak Values
- `peak_values.peak_power_hp`: Maximum power output
- `peak_values.peak_power_rpm`: RPM at peak power
- `peak_values.peak_torque_ftlb`: Maximum torque output
- `peak_values.peak_torque_rpm`: RPM at peak torque

#### Uncertainty (Optional)
- `power_uncertainty_hp`: Power measurement uncertainty
- `torque_uncertainty_ftlb`: Torque measurement uncertainty
- `rpm_uncertainty`: RPM measurement uncertainty

#### Sources
- `sources`: Array of reference URLs or citations

## Adding New Validation Data

### Step 1: Gather Data

Collect the following information:
1. Complete dyno curve (power and torque vs RPM)
2. Engine specifications (bore, stroke, compression ratio)
3. Test conditions (temperature, pressure, humidity)
4. Peak values (peak power, peak torque, RPMs)
5. Data source and quality rating

### Step 2: Choose Correct Subdirectory

- **Naturally Aspirated**: `data/validation/naturally_aspirated/`
- **Supercharged**: `data/validation/supercharged/`
- **Turbocharged**: `data/validation/turbocharged/`

### Step 3: Create JSON File

Use the naming convention `{engine_code}_{modification}_{fuel}_{origin}.json`, where
`{origin}` matches the entry's `dyno_data.curve_provenance`:

| `{origin}` | Use when |
|---|---|
| `measured` | You have the logged sweep |
| `measured_published` | Digitized third-party measured sweep (`published_measured_curve`) |
| `published` | Manufacturer's published rating |
| `community` | Forum/enthusiast-reported figures |

Examples:
- `ls3_stock_published.json` — stock LS3, manufacturer rating
- `2jzgte_single_turbo_e85_community.json` — 2JZ-GTE, single turbo, E85, community-reported
- `coyote_cams_exhaust_measured.json` — Coyote 5.0L with cams + exhaust, your own dyno run

The suffix `_real` is deliberately not used: every entry is "real" in the sense that it
exists, and the distinction that matters is whether anything was measured.

**Pairing with an engine config.** `piston validate-dyno --batch` runs each entry against a
config in `data/engines/`. By default it takes the longest `_`-separated prefix of the file
name that names a config (`honda_f20c_jdm_measured_published` runs against `honda_f20c`).
When the name cannot find it, say so in the entry with a top-level `"engine_config":
"<config stem>"` (`lt4_stock_measured_published` names `chevy_lt4`). An entry that no config
can model declares `"engine_config": null` with an `"engine_config_reason"`; the batch reports
it as not runnable, with the reason, instead of counting it as a failure. A test holds every
shipped entry to one of these (PIS-0193).

### Step 4: Populate JSON

Copy `data/validation/_DYNO_DATA_TEMPLATE.json` (annotated) or
`data/validation/_QUICK_FILL_TEMPLATE.json` (minimal) and fill in all fields.
For a `published_measured_curve` entry, digitize the source chart with
`tools/digitize_dyno_chart.py` and record its invocation and reported
uncertainty in the entry's notes.

**Data Quality Guidelines**:
- Use at least 10 RPM data points across the engine's operating range
- Ensure data points are evenly distributed
- Include peak power and peak torque RPM points
- Verify all curve arrays have the same length
- Double-check units (HP, lb-ft, RPM, psi, °F, inHg)

### Step 5: Validate JSON

Run the validation data loader test to ensure your JSON is valid:

```bash
./build/bin/piston_tests "[validation][data][loader]" --reporter compact
```

Or load it directly in a test:

```cpp
#include "analysis/validation/ValidationDataLoader.h"

auto filepath = std::filesystem::path("data/validation/naturally_aspirated/your_file.json");
ValidationData data = ValidationDataLoader::loadFromFile(filepath);
```

The loader will throw exceptions if:
- Required fields are missing
- Curve arrays have different lengths
- Induction type is invalid
- File cannot be parsed as JSON

## Using Validation Data in Tests

### Loading Data

```cpp
#include "analysis/validation/ValidationDataLoader.h"

using namespace piston::analysis::validation;

// Load a specific file
auto filepath = std::filesystem::path("data/validation/naturally_aspirated/ls3_stock_published.json");
ValidationData data = ValidationDataLoader::loadFromFile(filepath);

// Find all validation files in a directory
auto files = ValidationDataLoader::findValidationFiles(
    std::filesystem::path("data/validation/naturally_aspirated")
);
```

### Accessing Data

```cpp
// Engine specifications
std::string engine_name = data.engine.name;
double displacement_L = data.engine.displacement;
double bore_mm = data.engine.bore;
double stroke_mm = data.engine.stroke;

// Forced induction
InductionType type = data.engine.forced_induction.type;
if (type == InductionType::TURBOCHARGER) {
    std::string turbo_model = data.engine.forced_induction.model;
}

// Test conditions
double temp_f = data.conditions.temperature_f;
double pressure_inhg = data.conditions.pressure_inhg;
double humidity_pct = data.conditions.humidity_percent;

// Dyno curves
const auto& rpm = data.curves.rpm;
const auto& power_hp = data.curves.power_hp;
const auto& torque_ftlb = data.curves.torque_ftlb;

// Peak values
double peak_power = data.peak_values.peak_power_hp;
double peak_power_rpm = data.peak_values.peak_power_rpm;
```

### Using with ValidationHarness

```cpp
#include "analysis/validation/ValidationHarness.h"
#include "dyno/DynoEngineAdapter.h"
#include "core/engine/EngineConfig.h"

using namespace piston::analysis::validation;

// Create validation harness with data file
auto filepath = std::filesystem::path("data/validation/naturally_aspirated/ls3_stock_published.json");
ValidationHarness harness(filepath);

// Load engine configuration
EngineConfig engineConfig = EngineConfig::fromFile("data/engines/ls3_stock.json");
auto adapter = std::make_shared<DynoEngineAdapter>(engineConfig, /*useDetailedCycle=*/true);

// Run validation
ValidationResult result = harness.runValidation(adapter);

// Export reports
harness.exportReportToConsole();
harness.exportReportToCSV("validation_report.csv");
harness.exportReportToJSON("validation_report.json");
```

### Calculating Accuracy Metrics

```cpp
#include "analysis/validation/AccuracyMetrics.h"

using namespace piston::analysis::validation;

// Calculate accuracy metrics
ValidationResult accuracy = AccuracyMetrics::calculate(
    measured_rpm, measured_power, measured_torque,
    simulated_rpm, simulated_power, simulated_torque
);

// Access metrics
double power_rmse = accuracy.rmse_power;           // HP
double power_rmse_pct = accuracy.rmse_power_percent; // %
double torque_rmse = accuracy.rmse_torque;         // lb-ft
double mean_error = accuracy.mean_error_power;     // HP
std::string grade = accuracy.accuracy_grade;        // "Excellent", "Good", "Acceptable", "Poor"
bool meets_target = accuracy.meets_target_accuracy; // <10% RMSE for both power and torque
```

## Data Quality Standards

### Excellent Quality (Use for primary validation)
- Manufacturer-published data (corrected to SAE J1349 or equivalent standard)
- Professional dyno with calibration records
- Multiple runs averaged
- Full environmental correction
- Known uncertainty values

### Good Quality (Use for secondary validation)
- Reputable dyno shop (Dynojet, Mustang, etc.)
- Single run or limited averaging
- Standard environmental correction
- Consistent with published specifications

### Acceptable Quality (Use with caution)
- Forum posts with dyno sheets
- Unknown dyno calibration
- May have outliers or inconsistencies
- Should be cross-referenced with other sources

### Poor Quality (Do not use)
- Missing environmental data
- Unrealistic values (beyond physical limits)
- Inconsistent with known specifications
- No source attribution

## Validation Accuracy Targets

Based on `AccuracyMetrics` grading system:

| Grade      | RMSE Power | RMSE Torque | Target Phase |
|------------|------------|-------------|--------------|
| Excellent  | <5%        | <5%         | Phase 4+     |
| Good       | <10%       | <10%        | Phase 3 MVP  |
| Acceptable | <15%       | <15%        | Phase 2      |
| Poor       | ≥15%       | ≥15%        | Phase 1      |

**Current Project Target**: <10% RMSE for both power and torque (Phase 3 MVP)

## Common Issues and Solutions

### Issue: "Required field 'X' is missing"
**Solution**: Add the missing field to your JSON file. All required fields must be present.

### Issue: "Curve arrays have different sizes"
**Solution**: Ensure `rpm`, `power_hp`, and `torque_ftlb` arrays have the same number of elements.

### Issue: "Invalid induction type"
**Solution**: Use only "none", "supercharger", or "turbocharger" (case-insensitive).

### Issue: "Cannot parse JSON file"
**Solution**: Validate your JSON syntax using a JSON validator (e.g., jsonlint.com).

### Issue: High RMSE in validation tests
**Solution**:
1. Verify environmental conditions match between real and simulated data
2. Check correction standard is applied correctly
3. Ensure engine configuration matches validation data specifications
4. Review data quality - may need better source

## Best Practices

1. **Always cite sources**: Include URLs or references in the `sources` array
2. **Use SI-adjacent units**: The schema uses imperial units (HP, lb-ft, °F, inHg) for consistency with dyno industry standards
3. **Include uncertainty**: If measurement uncertainty is known, include it
4. **Multiple data points**: Use at least 10 RPM points across the engine's range
5. **Cross-reference**: Verify dyno data against manufacturer specifications when available
6. **Document modifications**: If engine is modified, note all changes in the filename and `name` field
7. **Environmental correction**: Always note the correction standard used (SAE J1349, DIN 70020, or None)

## Further Reading

- API reference for `AccuracyMetrics` and `ValidationHarness`: build the `docs` target
  (Doxygen) and open the generated HTML. There is no hand-written API markdown.
- [Validation Data Sources](validation_data_sources.md)
- [SAE J1349 Standard](https://www.sae.org/standards/content/j1349_201208/) - Correction factors for engine power
- [Dyno Testing Best Practices](https://www.dynojet.com/best-practices) - Industry standards

## Contributing

When contributing validation data:
1. Ensure data quality meets "Good" or "Excellent" standards
2. Include complete metadata and sources
3. Test your JSON file with ValidationDataLoader
4. Submit a pull request with the new file and updated documentation
5. Consider adding a corresponding test case in `tests/validation/`

---

**Last Updated**: Phase 1, Month 3 (Validation Infrastructure Complete)
**Maintainer**: PISTON Project
