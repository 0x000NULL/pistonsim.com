# PISTON Phase 1 Validation Results (Historical)

> **Superseded.** This document described an early **Phase 1 simplified Otto cycle** experiment and
> is kept only for historical context. It does **not** describe the current model.
>
> **Date.** The earliest record of it is the repository's initial commit, `063e9b7` on 2025-10-30.
> The original text was stamped "October 29, 2024", a year before the repository existed; no record
> supports that date (the day-before-the-initial-commit a year later suggests a mistyped year, but
> that is inference, not evidence), so it is not repeated here (PIS-0185).
>
> The production simulation path is now the **detailed cycle (Wiebe + Woschni + integrated VE)**, not
> the simplified Otto cycle, and the figures below no longer reflect current accuracy.
>
> For the authoritative, reproducible accuracy report, see
> [`accuracy.generated.md`](accuracy.generated.md). CI regenerates it and enforces its
> threshold on every push, but does not commit the result, so check its commit stamp before
> quoting it. That report carries its own scope section: peak power/torque only, not curve
> shape, and nothing in it is certified.

---

## Historical context (recorded no later than 2025-10-30)

The original Phase 1 effort validated a **simplified Otto cycle** model against a single reference
engine (a naturally aspirated GM LS3 6.2L V8, using GM published factory specifications). At that time
the model did **not** implement the Wiebe combustion function, Woschni heat transfer, friction
modeling, or RPM-varying volumetric efficiency, and it relied on a flat correction factor to
compensate for those missing losses.

All numeric results, targets, and "Phase 2 roadmap" items from that experiment have been removed to
avoid confusion with current behavior. Those models (Wiebe, Woschni, integrated VE) are now part of
the production path; see [`accuracy.generated.md`](accuracy.generated.md) for current numbers and the
`physics/` references for the implemented equations.

---

**Status**: Historical — superseded by [`accuracy.generated.md`](accuracy.generated.md)
