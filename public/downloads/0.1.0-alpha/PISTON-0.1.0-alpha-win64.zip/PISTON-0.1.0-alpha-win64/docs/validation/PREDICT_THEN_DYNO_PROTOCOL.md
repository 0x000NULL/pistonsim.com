# Predict-Then-Dyno Validation Protocol

This is the instrument for ULTRAPLAN Phase 5 / M3: producing **independent, blind
predict-then-dyno data points** that either corroborate or challenge PISTON's published
fleet accuracy (see [`accuracy.generated.md`](accuracy.generated.md) for the current figure).

The protocol exists because credibility is the whole product. The harness MAPE is computed
against *published* peaks the model authors could in principle have seen. A predict-then-dyno
point is stronger evidence precisely because **the prediction is locked before the
measurement exists** — there is no opportunity to tune to the answer. Three such points are
the M3 gate; they are also the input to every downstream milestone (M4–M6).

> A data point gathered any other way (prediction adjusted after seeing the dyno, or a config
> reverse-fit to a known result) is **not** a validation point and must not be published as
> one. That is the fabricated-validation failure mode this project was remediated to end.

## What counts as one valid data point

All five must hold, or the point is discarded (not silently weakened):

1. **Real hardware.** A physical engine on a real dyno — not another simulator, not a
   manufacturer brochure number.
2. **Blind prediction.** The PISTON prediction is recorded and timestamped **before** the
   dyno pull is run (see "Locking the prediction" below).
3. **Reproducible config.** The exact engine-config JSON used for the prediction is committed,
   with each non-default number sourced (measured, build-sheet, or published spec — labeled).
4. **Stated conditions.** Dyno type (inertia/brake/hub/engine), correction standard, ambient
   pressure/temperature/humidity, fuel, and operator are recorded.
5. **Same metric, both sides.** Error is computed with the same definitions the harness uses
   (peak power & torque absolute-percent error; per-point RMSE when a full curve is logged),
   under one consistent correction standard (default **SAE J1349**).

## Procedure

### 1. Build the config (before the pull)
- Start from a sibling in `data/engines/` and edit, or author a new JSON.
- Fill geometry, valvetrain, combustion, and (if forced) induction from the **actual build
  sheet** for the specific engine being tested. Where a number is a published spec rather than
  a measurement, label it as such in the config notes — honesty about provenance is the point.
- Validate it: `piston validate -c <config.json> --verbose` (must pass).

### 2. Generate the prediction
- Curve: `piston simulate -c <config.json> --rpm-start <a> --rpm-end <b> -o predict.csv`
- If comparing build options, `piston optimize` ranks combinations — but the **point being
  validated is one specific config**, predicted before the pull.
- Apply the **same correction standard** you will read on the dyno
  (`--correction SAE_J1349` by default) and record the ambient conditions you expect at the
  dyno via `--ambient-pressure/--ambient-temp/--humidity`.
- Record predicted peak power, peak torque, and the RPMs at which they occur.

### 3. Lock the prediction (this is what makes it independent)
Pick one and keep the evidence with the data point:
- **Preferred:** commit `predict.csv` + the config to the repo (or open a PR) **before** the
  dyno session. The commit timestamp is the lock.
- Or: hash the prediction file (`certutil -hashfile predict.csv SHA256` on Windows /
  `sha256sum` elsewhere) and publish/send the hash before the pull; reveal the file after.

No prediction may be edited after this step. If the config was wrong, that is itself a result
(record it) — do not silently re-predict.

### 4. Run the dyno
- Perform the pull(s) under the stated, recorded conditions; keep the raw dyno sheet/CSV.
- Note anything that breaks the comparison's assumptions (different correction, partial
  throttle, knock-limited, drivetrain losses on a chassis dyno) — these are recorded, not
  hidden, and may reclassify the point as "engine vs chassis" rather than discarding it.

### 5. Compute and record the error
- Peak APE = `|predicted − measured| / measured × 100` for power and for torque.
- If a full measured curve exists, also compute per-point RMSE over the shared RPM band.
- A chassis-dyno (wheel) number is **not** directly comparable to PISTON's crank prediction
  without a drivetrain-loss assumption — state the assumption or mark the point engine-dyno-only.

### 6. Publish honestly
Fill in one [`CASE_STUDY_TEMPLATE.md`](CASE_STUDY_TEMPLATE.md) per point. Report the number
that came out — corroborating *and* disconfirming points are both publishable and both build
credibility. A disconfirming point becomes a physics-sprint input (see `docs/physics/`).

## The M3 gate
M3 (shop SaaS pilot) opens when **three independent points** collected this way exist, at
least one of them gathered by someone other than the model author. They are the seed corpus
for the case studies that gate M4–M6. Nothing here can be produced by the simulator alone —
it requires real engines, real dynos, and real operators, which is exactly why a point
gathered this way is worth more than any number the model can quote about itself.
