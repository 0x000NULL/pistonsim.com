# Validation Data Sources

This document lists potential sources for high-quality engine dyno data to use in PISTON validation.

## Manufacturer Data (Highest Quality)

### SAE Standards and Certifications

**SAE J2723** - Net Power Rating for Naturally Aspirated Spark Ignition Engines
- Official manufacturer-certified power ratings
- Full environmental correction per SAE J1349
- Published specifications for most modern engines
- Access: SAE International website or manufacturer technical documents

**SAE J1349** - Engine Power Test Code - Spark Ignition and Compression Ignition
- Standard environmental correction factors
- Widely used in North America
- Reference: https://www.sae.org/standards/content/j1349_201208/

**DIN 70020** - German standard for engine power measurement
- Used primarily in Europe
- Similar to SAE J1349 but with different correction factors
- Reference: https://www.din.de/

### Manufacturer Technical Documents

#### General Motors (GM)
- **LS Engine Family**: Extensive SAE-certified data
  - LS1, LS2, LS3, LS7, LS9, LSA, etc.
  - Available through GM Performance Parts catalogs
  - Access: https://www.gmperformancemotor.com/

#### Ford Motor Company
- **Coyote Series**: 5.0L, 5.2L variants
- **EcoBoost Series**: Turbocharged data
- Access: Ford Performance Parts catalogs

#### Chrysler/Stellantis
- **HEMI Series**: 5.7L, 6.1L, 6.2L, 6.4L
- Access: Mopar Performance Parts catalogs

#### European Manufacturers
- BMW S-Series engines
- Mercedes-AMG engines
- Porsche flat-six engines
- Access: Official technical documentation (often in German)

#### Japanese Manufacturers
- Toyota/Lexus (2JZ, 1UZ, etc.)
- Nissan (VQ, RB, SR series)
- Honda (K-series, B-series)
- Access: Service manuals, OEM technical documents

## Professional Dyno Facilities (High Quality)

### Major Dyno Manufacturers

#### Dynojet Research
- Industry-standard chassis and engine dynos
- Website: https://www.dynojet.com/
- Data sources:
  - Dynojet database (user-submitted)
  - Professional shops using Dynojet equipment

#### Mustang Advanced Engineering
- Professional-grade dynos
- Website: https://www.mustangae.com/
- Common in OEM testing and performance shops

#### SuperFlow
- Engine and chassis dynos
- Website: https://www.superflow.com/
- Used by many professional engine builders

### Reputable Dyno Shops

#### United States
- **AMS Performance** (Chicago, IL) - Import performance
- **Hennessey Performance** (Texas) - High-performance builds
- **Lingenfelter Performance** (Michigan) - GM performance
- **Texas Speed & Performance** (Texas) - LS/LT engines
- **Evolution Performance** (California) - BMW/European
- **Church Automotive Testing** (California) - Professional testing

#### United Kingdom
- **EcuTek** - Tuning and dyno testing
- **Regal Autosport** - Professional dyno facility
- **AET Motorsport** - Engine development

#### Australia
- **Croydon Racing Developments** - Professional dyno and tuning
- **Kudos Motorsports** - High-performance testing

### Racing Organizations

#### NASCAR
- Official engine specifications published
- Access: NASCAR rule books (technical specifications)

#### Formula 1
- Limited public data (proprietary)
- Historical data available through technical publications

#### NHRA (Drag Racing)
- Some published specifications for pro stock engines
- Access: NHRA rule books

## Academic and Research Sources

### University Research Programs

#### MIT - Sloan Automotive Lab
- Engine combustion research
- Published papers with validation data
- Access: MIT research publications

#### University of Wisconsin - Engine Research Center
- Extensive engine testing facilities
- Published research with dyno data
- Access: Academic journals, research papers

#### Ricardo plc (UK)
- Automotive engineering consultancy
- Published case studies and white papers
- Access: Ricardo publications

### SAE Technical Papers

**SAE International Technical Papers**
- Thousands of papers with engine performance data
- Search: https://www.sae.org/publications/technical-papers/
- Topics: combustion, emissions, performance, modeling
- Cost: Individual papers or institutional access

**Key Paper Series:**
- Engine power measurement and correction factors
- Validation of engine simulation models
- Performance testing methodologies

## Online Communities and Forums (Use with Caution)

### High-Quality Forums with Dyno Data

#### GM LS Engines
- **LS1Tech** (https://www.ls1tech.com/)
  - Extensive LS dyno database
  - User-submitted dyno sheets
  - Quality varies - verify with multiple sources

#### Ford Performance
- **Mustang6G** (https://www.mustang6g.com/) - Coyote engines
- **FordMuscleForums** - Various Ford engines

#### Import Performance
- **NAGTROC** (https://www.nagtroc.org/) - Nissan GT-R
- **Supraforums** (https://www.supraforums.com/) - Toyota Supra/2JZ
- **S2Ki** (https://www.s2ki.com/) - Honda S2000/F20C

#### European Performance
- **M3Post** - BMW M engines
- **Rennlist** (https://rennlist.com/) - Porsche engines
- **MBWorld** - Mercedes-AMG engines

### Quality Guidelines for Forum Data

**✅ Look For:**
- Full dyno sheet with operator signature
- Environmental conditions noted
- Correction standard applied (SAE, DIN, uncorrected)
- Multiple runs shown
- Known dyno facility
- Consistent with manufacturer specs

**❌ Avoid:**
- Single screenshot with no context
- Unrealistic claims
- Missing environmental data
- Unknown dyno calibration
- Inconsistent with known specifications

## Publications and Magazines

### Performance Publications

#### Engine Builder Magazine
- Professional engine building and testing
- Occasional dyno data in articles
- Website: https://www.enginebuildermag.com/

#### Hot Rod Magazine (MotorTrend)
- Engine builds with dyno results
- Database of tested engines
- Website: https://www.hotrod.com/

#### Engine Technology International
- Professional publication with technical data
- Website: https://www.enginetechnologyinternational.com/

#### Race Engine Technology (RET)
- High-level technical journal
- Professional race engine data
- Website: https://www.racecar-engineering.com/

## Data Quality Verification

### Cross-Referencing

When collecting validation data, always verify with multiple sources:

1. **Check manufacturer specifications** - Does the data match published specs?
2. **Compare with similar builds** - Are the numbers realistic for the configuration?
3. **Verify environmental correction** - Is the correction standard noted and reasonable?
4. **Check for outliers** - Any data points that seem unrealistic?

### Red Flags

**Avoid data with these characteristics:**
- Power claims significantly higher than manufacturer specs (without modifications)
- Missing environmental conditions
- "Uncorrected" data without raw numbers
- Unknown dyno type or calibration
- Inconsistent curve shape (unrealistic torque curve)
- No source attribution

### Realistic Expectations

**Typical NA engine losses** (engine to wheels):
- Manual transmission: 12-15%
- Automatic transmission: 18-22%
- AWD: 20-25%

**Example**: If chassis dyno shows 350 whp (wheel HP) on a manual FWD car, engine power is likely ~400 HP at the crank.

## Building a Data Collection Strategy

### Phase 1: Core Validation Set (Current)
**Target**: 15-20 stock NA engines across different families
- GM LS series (LS1, LS3, LS7)
- Ford modular (Coyote 5.0L, 5.2L)
- Import performance (2JZ, RB26, K-series)
- European (BMW S-series, Mercedes-AMG)

**Priority**: Manufacturer-published specifications (corrected to SAE J1349 or equivalent)

### Phase 2: Forced Induction
**Target**: 10-15 supercharged and turbocharged engines
- Factory forced induction (LSA, GT500, GT-R)
- Common aftermarket setups
- Range of boost levels (5-25 psi)

**Priority**: Professional dyno shops with known calibration

### Phase 3: Modified Engines
**Target**: 20+ modified engines with known parts
- Cams + exhaust (bolt-ons)
- Head and cam packages
- Stroker kits
- Different compression ratios

**Priority**: Builds with complete parts lists and multiple dyno runs

### Phase 4: Extreme Builds
**Target**: 10+ high-performance builds
- Race engines
- High-boost turbo
- Nitrous oxide
- Exotic fuels (E85, methanol)

**Priority**: Professional builders with documented testing

## Legal and Ethical Considerations

### Copyright and Fair Use

- **Manufacturer data**: Generally public domain for published specifications
- **Dyno sheets**: May be copyrighted - obtain permission when possible
- **Academic papers**: Follow journal copyright policies
- **Forum posts**: Respect original poster's intellectual property

### Attribution

Always provide proper attribution:
- Source website or publication
- Date of data collection
- Dyno facility name (if known)
- Original tester or poster (if available)

### Data Privacy

- Avoid including personal information (phone numbers, addresses)
- Redact VIN numbers if present
- Don't share customer information without consent

## Recommended Data Collection Workflow

1. **Identify target engine** - Choose from priority list
2. **Search multiple sources** - Manufacturer data, forums, publications
3. **Verify consistency** - Cross-reference multiple sources
4. **Document sources** - Save URLs, take screenshots, note dates
5. **Use add_validation_data.py** - Interactive script to create JSON file
6. **Validate** - Run ValidationDataLoader tests
7. **Create test case** - Add to tests/validation/
8. **Document** - Update validation_data_guide.md with new engine

## Contributing

If you find high-quality validation data:
1. Verify the data meets "Good" or "Excellent" quality standards
2. Use the `add_validation_data.py` script to create a JSON file
3. Include complete source attribution
4. Submit a pull request with:
   - New validation JSON file
   - Updated documentation
   - Test case (if appropriate)

## Further Reading

- [Validation Data Guide](validation_data_guide.md) - JSON format and usage
- API reference for `AccuracyMetrics`: build the `docs` target (Doxygen).
- SAE J1349 Standard (SAE International)
- SAE J2723 Standard (SAE International)
- "Engine Testing: The Design, Building, Modification and Use of Powertrain Test Facilities" by A.J. Martyr and M.A. Plint

---

**Last Updated**: Phase 1, Month 3 (Validation Infrastructure Complete)
**Maintainer**: PISTON Project

**Note**: This is a living document. As new sources are discovered and validated, this list will be updated. Contributions are welcome!
