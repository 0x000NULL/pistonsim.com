# Physics Model Explanations

This guide explains the scientific principles and mathematical models that PISTON uses to simulate engine performance. Understanding these models will help you interpret results and make informed decisions about engine modifications.

## Fundamental Principles

### Thermodynamic Cycle Modeling

PISTON simulates the **Otto cycle** with real-world corrections for:
- Heat transfer losses
- Incomplete combustion
- Pumping work
- Friction losses
- Gas property variations

The simulation tracks energy flow through each process:
1. **Intake**: Work done bringing air/fuel into cylinder
2. **Compression**: Work done compressing the charge
3. **Combustion**: Heat added from fuel burning
4. **Expansion**: Work extracted from hot gases
5. **Exhaust**: Work done expelling burned gases

### Conservation Laws

**Mass Conservation:**
- Mass flow into cylinder = Mass flow out + Accumulated mass
- Applied at each valve, accounting for compressible flow effects
- Critical for calculating volumetric efficiency

**Energy Conservation:**
- Energy in (fuel chemical energy) = Work out + Heat losses + Internal energy change
- First Law of Thermodynamics applied to each process
- Accounts for all energy transfers

**Momentum Conservation:**
- Force = Mass × Acceleration for all moving components
- Applied to piston/rod/crank assembly
- Critical for calculating loads and vibrations

## Combustion Modeling

### Wiebe Function Heat Release

The **Wiebe function** models realistic heat release during combustion, rather than assuming instantaneous burning:

```
dxb/dθ = (m+1) × (θ/Δθ)^m × exp(-a×(θ/Δθ)^(m+1))
```

Where:
- **xb** = Mass fraction burned
- **θ** = Crank angle from ignition start
- **Δθ** = Total burn duration (degrees)
- **m** = Wiebe form factor (shape parameter)
- **a** = Wiebe efficiency factor (typically 5.0)

**Physical Meaning:**
- **m = 2**: Normal turbulent flame propagation
- **m = 1**: Fast burning (high turbulence, rich mixture)
- **m = 3**: Slow burning (lean mixture, low turbulence)

**Typical Values:**
- **Gasoline engines**: m = 2.0-2.5, Δθ = 40-60°
- **High-performance engines**: Faster burning (shorter Δθ)
- **Lean-burn engines**: Slower burning (higher m, longer Δθ)

### Two-Zone Combustion Model

PISTON uses a **two-zone model** that divides the combustion chamber into:

1. **Unburned Zone**: Fresh air/fuel mixture ahead of flame front
2. **Burned Zone**: Hot combustion products behind flame front

**Zone Properties Calculated:**
- Temperature in each zone
- Pressure (same in both zones)
- Mass in each zone
- Species concentrations
- Heat transfer from each zone

**Advantages over Single-Zone:**
- More realistic temperature predictions
- Better heat transfer modeling
- Accounts for flame propagation physics
- Enables knock prediction (future enhancement)

**Governing Equations:**

*Mass Conservation:*
```
dmb/dt = ṁb (mass burning rate from Wiebe function)
dmu/dt = -ṁb (unburned mass decreases)
```

*Energy Conservation:*
```
dU/dt = Q̇fuel - Q̇wall - P×dV/dt
```

*Ideal Gas Law (each zone):*
```
P×V = m×R×T
```

### Fuel Properties and Chemistry

**Lower Heating Value (LHV):**
- Energy released per unit mass of fuel
- Accounts for water vapor not condensing
- Typical values: 43-45 MJ/kg for gasoline

**Stoichiometric Air/Fuel Ratio:**
- Theoretical minimum air needed for complete combustion
- Gasoline: ~14.7:1 by mass
- E85: ~9.8:1 by mass
- Affects flame speed and combustion efficiency

**Octane Rating Effects:**
- Higher octane allows higher compression ratios
- Affects ignition timing optimization
- Influences burn rate characteristics
- Critical for knock-limited engines

## Gas Properties and Thermodynamics

### Real Gas Effects

While PISTON primarily uses ideal gas assumptions, it includes corrections for:

**Temperature-Dependent Specific Heats:**
- Cp and Cv increase with temperature
- Affects compression and expansion calculations
- Important at high compression ratios

**Combustion Product Properties:**
- Burned gases have different properties than air
- Higher molecular weight
- Different specific heat ratios
- Affects expansion work extraction

### Heat Transfer Modeling

**Woschni Correlation:**

The Woschni heat transfer correlation calculates convective heat transfer to cylinder walls:

```
h = 3.26 × B^(-0.2) × P^0.8 × T^(-0.55) × w^0.8
```

Where:
- **h** = Heat transfer coefficient (W/m²·K)
- **B** = Cylinder bore (m)  
- **P** = Cylinder pressure (bar)
- **T** = Gas temperature (K)
- **w** = Characteristic velocity (m/s)

**Characteristic Velocity:**
```
w = C₁×Ūp + C₂×(Vd×Ti)/(Pi×Vi) × (P - Pm)
```

Where:
- **Ūp** = Mean piston speed = 2×stroke×RPM/60
- **C₁, C₂** = Woschni constants (2.28, 0.00324 for combustion)
- **Vd** = Displaced volume
- **Ti, Pi, Vi** = Intake conditions
- **Pm** = Motored pressure at same crank angle

**Physical Significance:**
- Higher RPM → Higher heat transfer (more turbulence)
- Higher pressure → Higher heat transfer (density effect)
- Combustion creates additional turbulence (C₂ term)
- Heat transfer reduces thermal efficiency

### Wall Temperature Modeling

**Temperature Distribution:**
- Piston crown: 300-400°C (hottest)
- Cylinder head: 200-300°C
- Cylinder walls: 150-200°C (coolant temperature + margin)

**Effects on Performance:**
- Higher wall temperatures reduce heat transfer losses
- But increase knock tendency
- Affect air density and volumetric efficiency
- Critical for thermal stress analysis

## Mechanical System Physics

### Slider-Crank Kinematics

The connecting rod and crankshaft convert reciprocating motion to rotary motion. PISTON uses exact kinematics (not approximations):

**Piston Position:**
```
x(θ) = r(1 - cos θ) + l(1 - √(1 - (r/l)² sin² θ))
```

**Piston Velocity:**
```
v(θ) = rω sin θ (1 + (r/l) cos θ / √(1 - (r/l)² sin² θ))
```

**Piston Acceleration:**
```
a(θ) = rω² cos θ (1 + r/l + (r/l)² sin² θ / (1 - (r/l)² sin² θ)^1.5)
```

Where:
- **r** = Crank radius (stroke/2)
- **l** = Connecting rod length  
- **θ** = Crank angle
- **ω** = Angular velocity (2π×RPM/60)

**Rod Ratio Effects (r/l):**
- Higher ratio (shorter rod): Higher side forces, more friction
- Lower ratio (longer rod): Smoother motion, better torque curve
- Typical values: 0.25-0.35 for automotive engines

### Force Analysis

**Forces on Piston:**
1. **Gas Force**: Fg = P × π × (bore/2)²
2. **Inertia Force**: Fi = -ma (opposes acceleration)
3. **Total Force**: Ftotal = Fg + Fi

**Force Components:**
- **Rod Force**: Along connecting rod centerline
- **Side Force**: Perpendicular to cylinder (piston thrust)
- **Crank Force**: Tangential and radial components

**Torque Calculation:**
```
T = (Ftotal × sin(θ + β) × r) / cos β
```

Where β is rod angle from vertical.

### Chen-Flynn Friction Model

PISTON uses the advanced **Chen-Flynn model** for accurate friction predictions:

**Total Friction Mean Effective Pressure:**
```
FMEP = FMEP_piston + FMEP_valvetrain + FMEP_bearings + FMEP_accessories
```

**Piston Assembly Friction:**
Based on detailed ring-liner contact mechanics:
```
FMEP_piston = C₁ + C₂×Ūp + C₃×IMEP
```

Where coefficients depend on:
- Ring tension and design
- Liner surface finish
- Oil viscosity and temperature
- Piston skirt contact pressure

**Typical Coefficient Values:**
- **Gasoline engines**: C₁=0.97, C₂=0.15, C₃=0.05
- **Diesel engines**: C₁=1.40, C₂=0.17, C₃=0.09
- **Racing engines**: Lower C₁ (tighter tolerances), higher C₂ (RPM effects)

**Physical Basis:**
- **C₁**: Constant friction (sealing loads, accessories)
- **C₂**: Speed-dependent (hydrodynamic losses, windage)
- **C₃**: Load-dependent (ring tension effects)

## Flow and Breathing Physics

### Valve Flow Modeling

**Compressible Orifice Flow:**
For subsonic flow (P₂/P₁ > 0.528):
```
ṁ = Cd × Aeff × ρ₁ × √(2(P₁-P₂)/ρ₁)
```

For sonic flow (choked, P₂/P₁ ≤ 0.528):
```
ṁ = Cd × Aeff × ρ* × c*
```

Where:
- **ρ*** = Sonic density = ρ₁ × (2/(γ+1))^(1/(γ-1))
- **c*** = Sonic velocity = √(γRT*)
- **T*** = Sonic temperature = T₁ × 2/(γ+1)

**Discharge Coefficient (Cd):**
Varies with valve lift and flow direction:
- Low lift: Cd = 0.3-0.5 (flow separation)
- Mid lift: Cd = 0.6-0.7 (attached flow)
- High lift: Cd = 0.4-0.6 (curtain area limitation)

### Intake System Dynamics

**Helmholtz Resonance:**
Intake runners act as organ pipes, creating resonance effects:

```
f = c / (4 × Leff)
```

Where:
- **f** = Resonant frequency (Hz)
- **c** = Speed of sound (~343 m/s at 20°C)
- **Leff** = Effective runner length (physical + end corrections)

**Tuned RPM:**
```
RPM_tuned = (f × 60 × 2) / (cylinders / 2)
```

**VE Boost from Resonance:**
- Peak boost: 10-15% at tuned RPM
- Boost width: ±500 RPM around peak
- Effect decreases with throttle restriction

### Exhaust System Effects

**Back Pressure Impact:**
Higher back pressure reduces volumetric efficiency:
```
VE_reduction = 0.15 × (P_exhaust / P_atmospheric)
```

Typical values:
- Stock exhaust: 0.2-0.5 bar back pressure
- Performance exhaust: 0.1-0.3 bar back pressure
- Each 0.1 bar costs ~1.5% VE

**Scavenging Effects:**
Properly timed exhaust pulses create low-pressure zones that help cylinder emptying:

**Optimal Primary Length:**
```
L_optimal = (c × Δt) / 4
```

Where Δt is time between exhaust events for same cylinder.

**Scavenging Benefit:**
- Can improve VE by 3-8% when properly tuned
- Most effective during valve overlap period
- RPM-dependent (resonance effect)

## Volumetric Efficiency Modeling

### Physics-Based VE Strategy

PISTON calculates VE from first principles rather than using lookup tables:

```
VE_total = VE_baseline × VE_resonance × VE_ram × VE_backpressure
```

**Baseline VE (Geometric):**
Based on valve flow area, port restrictions, and heat transfer:
```
VE_baseline = (Aeff / Abore) × Cd × Tintake/Tcylinder
```

**Resonance Multiplier:**
Gaussian-shaped boost around tuned RPM:
```
VE_resonance = 1 + boost × exp(-((RPM - RPM_tuned)/width)²)
```

**Ram Effect:**
Dynamic pressure from flow velocity:
```
P_dynamic = 0.5 × ρ × v²
VE_ram = 1 + P_dynamic / P_static
```

### Empirical VE Strategy

For comparison, PISTON also includes empirical models based on measured data:

**Polynomial Fit:**
```
VE(RPM) = a₀ + a₁×RPM + a₂×RPM² + a₃×RPM³
```

**Advantages:**
- Can match measured data exactly
- Accounts for all effects (known and unknown)
- Fast calculation

**Disadvantages:**
- No predictive capability for modifications
- Requires extensive measurement data
- Doesn't provide physical insight

## Environmental Corrections

### Air Density Effects

**Standard Conditions:**
- SAE J1349: 99 kPa, 25°C, dry air
- DIN 70020: 99 kPa, 20°C, 65% relative humidity

**Density Calculation:**
```
ρ = P / (R × T) × (1 - 0.378 × e / P)
```

Where:
- **P** = Absolute pressure (Pa)
- **R** = Gas constant for dry air (287 J/kg·K)
- **T** = Absolute temperature (K)
- **e** = Water vapor pressure (Pa)

**Power Correction:**
```
Power_corrected = Power_measured × √(ρ_std / ρ_actual)
```

### Altitude Effects

**Pressure vs. Altitude:**
```
P(h) = P₀ × exp(-Mgh/(RT))
```

Where:
- **h** = Altitude above sea level (m)
- **M** = Molar mass of air (0.0289644 kg/mol)
- **g** = Gravitational acceleration (9.80665 m/s²)
- **R** = Universal gas constant (8.31432 J/mol·K)

**Practical Formula:**
```
P(h) ≈ P₀ × (1 - 2.25577×10⁻⁵ × h)^5.25588
```

**Power Loss:**
Naturally aspirated engines lose approximately 3% power per 1000 feet of altitude.

## Advanced Topics

### Knock Modeling (Future Enhancement)

**Arrhenius Kinetics:**
```
dα/dt = A × exp(-E/(RT)) × P^n × (1-α)^m
```

Where:
- **α** = Reaction progress
- **A** = Pre-exponential factor
- **E** = Activation energy
- **n, m** = Pressure and concentration exponents

**Integration:**
Knock occurs when ∫dα/dt dt reaches critical value (~1.0).

### Turbocharger Modeling (Future Enhancement)

**Compressor Map Interpolation:**
- Pressure ratio vs. corrected mass flow
- Efficiency contours
- Surge and choke limits
- Speed lines

**Turbine Modeling:**
- Expansion ratio vs. corrected mass flow
- Turbine efficiency
- Wastegate control
- Heat transfer effects

### Multi-Cylinder Dynamics (Future Enhancement)

**Firing Order Effects:**
- Intake manifold pressure pulsations
- Exhaust system tuning
- Torsional vibrations
- Balance shaft requirements

## Model Validation and Accuracy

### Validation Approach

PISTON's models are validated against:
1. **Textbook examples** (thermodynamic cycles)
2. **Published research data** (heat transfer, friction)
3. **Real dyno data** (complete engine tests)
4. **Component bench tests** (flow bench, friction tests)

### Known Limitations

**Model Simplifications:**
- Quasi-steady flow (real flow is highly unsteady)
- Perfect mixing assumptions
- Simplified combustion chamber geometry
- No cycle-to-cycle variations

**Input Uncertainties:**
- Component tolerances not modeled
- Wear effects not included
- Assembly variations ignored
- Environmental fluctuations

**Computational Trade-offs:**
- 1D gas dynamics (not 3D CFD)
- Simplified heat transfer
- Average properties used
- Time step limitations

### Continuous Improvement

PISTON's physics models are continuously refined based on:
- User feedback and validation data
- Latest research publications
- Computational advances
- Expanded experimental databases

Understanding these physics models helps you make the most of PISTON's simulation capabilities and interpret results with appropriate engineering judgment.