# PISTON User Guide

**Status**: Alpha (0.1.0-alpha)

*Note: The GUI (`piston-gui`) ships but is incomplete; this user guide is being expanded alongside it.*

---

## Current Project Status

PISTON is currently at the **Alpha - Enhanced Core (unvalidated)** stage (version 0.1.0-alpha). Both the headless CLI (`piston`) and the GUI (`piston-gui`) are usable today; the GUI is still incomplete and the simulation results are unvalidated.

### For Early Adopters

If you're interested in following the project's development:

1. **Watch the Repository**: Stay updated on progress
2. **Review Documentation**: Check out the architecture and physics documentation
3. **Join Discussions**: Participate in issue discussions and feature planning

### Expected Timeline

- **Phase 1 (Months 1-3)**: Basic engine simulation and CLI interface
- **Phase 2 (Months 4-6)**: GUI implementation with real-time visualization
- **Phase 3 (Months 7-9)**: MVP release with full user documentation

---

## Available Walkthroughs

The user-guide pages that exist today and the order they are meant to be read in:

- **[Quickstart](quickstart.md)** — the three-step "load → run → read" loop, in five minutes.
- **[Getting Started](getting_started.md)** — the longer CLI-first tutorial that builds on the quickstart and ends with two CSVs on disk.
- **[Engine Configuration](engine_configuration.md)** — section 2 below: a CLI-first, JSON-first walkthrough of every field in the shipped engine configurations, what physics it drives, and how to change it safely.
- **[Parts Selection](parts_selection.md)** — section 3 below: a CLI-first walkthrough of the SQLite parts catalog, the compatibility checker, and the bridge from a parts pick to a runnable JSON engine configuration.
- **[Simulation Workflow](simulation_workflow.md)** — recommended day-to-day workflow and the per-stroke walk through the simulator.
- **[Interpreting Results](interpreting_results.md)** — section 5 below: a CLI-first deep-dive on reading the sweep CSV column-by-column, what curve shape to expect, how to spot a bad run, and how to compare two engines.
- **[Physics Models](physics_models.md)** — what each model does and the assumptions behind it.
- **[Dyno Simulation](dyno_simulation.md)** — inertia and brake dyno modes in detail.
- **[Troubleshooting](troubleshooting.md)** — section 7 below: a CLI-first, symptom-indexed reference for the failure modes you can hit on the current build, with cross-links to the pages that own each underlying topic.

## Planned User Guide Structure

The complete user guide will include the following sections:

### 1. Getting Started
- Installation guide
- First-time setup
- Quick start tutorial
- System requirements

### 2. Engine Configuration
- **[engine_configuration.md](engine_configuration.md)** — full walkthrough of every top-level JSON section (geometry, valvetrain, fuel, combustion, knock, intake_manifold, egr, forced_induction, vcr, thermal, mechanical, operating_limits) across the three walkthrough configs (`configs/engines/ls3_egr.json`, `configs/engines/2jz_gte_egr.json`, `data/engines/kr20ddet.json`), with cross-links to the physics docs and a worked example.

### 3. Parts Selection
- **[parts_selection.md](parts_selection.md)** — CLI-first walkthrough of the SQLite parts catalog (engine_blocks, cylinder_heads, pistons, connecting_rods, crankshafts, camshafts, turbochargers, intake_manifolds), the `CompatibilityChecker` rules and tolerances, `sqlite3` browsing recipes for use today (the `piston parts` subcommands are still TODO stubs), the parts-to-JSON bridge that ends at a runnable configuration, and how to add custom parts via SQL or `PartsDatabase::importFromJson`.

### 4. Running Simulations
- Dyno configuration
- Running a dyno pull
- Environmental conditions
- Save and load configurations

### 5. Interpreting Results
- **[interpreting_results.md](interpreting_results.md)** — CLI-first deep-dive on reading a PISTON sweep CSV column-by-column (`rpm`, `torque_nm`, `power_kw`, `bmep_bar`, `ve_percent`, `bsfc_g_per_kwh`, environmental-correction trailing columns), the curve shapes to expect, peak-metric extraction, an LS3-vs-2JZ-GTE comparison worked example, common failure modes, and what the CSV cannot tell you.
- Reading power and torque curves
- Understanding BSFC (Brake Specific Fuel Consumption)
- Peak power vs. peak torque
- Comparing configurations

### 6. Advanced Features (Phase 4+)
- Forced induction setup
- ECU tuning
- Failure prediction
- Cost analysis

### 7. Troubleshooting
- **[troubleshooting.md](troubleshooting.md)** — symptom-indexed reference for the failure modes you can hit on the current build (build & launch problems, configuration loading, sweep/simulation failures, implausible results, CSV export, parts database, GUI gaps, performance), grounded in the real CLI error strings from `src/cli/Commands.cpp` and cross-linked back to the pages that own each topic.
- Common errors and solutions
- Configuration validation
- Performance optimization
- Getting help

---

## For Developers

If you're a developer looking to contribute or understand the codebase:

### Development Documentation

Located in `docs/development/`:
- **[building.md](../development/building.md)** - Complete build instructions
- **[contributing.md](../development/contributing.md)** - Contribution guidelines
- **[testing.md](../development/testing.md)** - Testing framework and practices

### Architecture Documentation

Located in project root:
- **[architecture.md](../../architecture.md)** - System architecture and design
- **[architecture.md](../../architecture.md)** - System design and directory layout
- **[docs/product/brief.md](../product/brief.md)** - What PISTON is for

### Physics Documentation

Located in `docs/physics/`:
- **[references.md](../physics/references.md)** - Physics models and equations

### Project Instructions

Located in project root:
- **[CLAUDE.md](../../CLAUDE.md)** - AI-assisted development guide

---

## Current Capabilities (Phase 0)

While the full engine simulation is not yet complete, the following foundation is operational:

### Core Utilities
- ✅ Unit conversion system (SI ↔ Imperial)
- ✅ Mathematical utilities (interpolation, integration)
- ✅ Configuration system (JSON-based)
- ✅ Version information

### Testing Infrastructure
- ✅ Extensive unit + integration test suite (current counts/pass-rate are reported by CI; run `ctest --test-dir build --output-on-failure`)
- ✅ Reproducible accuracy harness (`docs/validation/accuracy.generated.md`)
- ✅ Validation framework

### Build System
- ✅ Cross-platform CMake configuration
- ✅ Automated testing
- ✅ API documentation generation (Doxygen)

---

## Example Configurations

The canonical example engine configurations ship in `configs/engines/`:

- **ls3_egr.json** - GM LS3 V8 with EGR
- **2jz_gte_egr.json** - Toyota 2JZ-GTE with EGR
- **kr20ddet.json** - KR20DDET

These demonstrate the configuration file format. Many more example engines live under `data/engines/`.

---

## Placeholder Validation Data

Placeholder validation data is available in `data/validation/`:

- **naturally_aspirated/** - NA engine dyno data (placeholder)
- **turbocharged/** - Turbo engine data (placeholder)
- **supercharged/** - Supercharged data (placeholder)

**Note**: These are synthetic placeholder files. Real dyno data will be collected in Phase 1 for validation.

---

## Quick Reference: Phase Roadmap

| Phase | Duration | Key Deliverables | Status |
|-------|----------|------------------|--------|
| **Phase 0** | 4 weeks | Foundation, testing infrastructure | ✅ Complete |
| **Phase 1** | 3 months | Basic NA engine simulation, CLI | 🔄 Starting |
| **Phase 2** | 3 months | Enhanced accuracy, GUI | ⏳ Planned |
| **Phase 3** | 3 months | MVP polish, cost calculator | ⏳ Planned |
| **Phase 4** | 6 months | Forced induction, advanced features | ⏳ Planned |

---

## Stay Updated

- **GitHub Repository**: see repository
- **Issue Tracker**: Report bugs or request features
- **Discussions**: Join design and feature discussions

---

## Contact

Contact: see repository

---

*Last Updated: Phase 0 Complete - Phase 1 Starting*
*This document will be expanded as the project progresses*
