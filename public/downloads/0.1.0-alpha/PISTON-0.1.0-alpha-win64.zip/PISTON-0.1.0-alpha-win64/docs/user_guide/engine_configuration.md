# Engine Configuration

This page is **section 2** of the [PISTON User Guide](README.md), sitting between [`quickstart.md`](quickstart.md) (the three-step "load → run → read" loop) and [`getting_started.md`](getting_started.md) (the longer end-to-end CLI tutorial). Where those two pages teach you how to *run* the simulator, this page teaches you how to *author* the JSON configuration files that drive it.

It is a CLI-first walkthrough. The GUI configuration panel referenced in [`quickstart.md`](quickstart.md) is still in progress — until it ships, every parameter described below is edited as raw JSON in your text editor of choice and consumed by `piston` via `--config`. When the panel arrives, the field names below will map one-to-one onto its controls, so the work you do here is forward-compatible.

## Who this is for

You are comfortable editing JSON by hand, you have a built `piston` per [`docs/development/building.md`](../development/building.md), and you already know which CLI flags drive a sweep (per [`getting_started.md`](getting_started.md)). You want to know what every top-level key in the bundled engine configurations *means*, what a sensible value looks like, and which knob to turn when you want a specific change in the curve.

If you just need a working sweep, start with [`quickstart.md`](quickstart.md). If you have never read a PISTON CSV, start with [`getting_started.md`](getting_started.md). If you have done both and you want to start authoring your own engines, you are in the right place.

## Prerequisites

- A built `piston` at `build/bin/piston` (Linux/macOS) or `build\bin\piston.exe` (Windows). Build instructions live in [`docs/development/building.md`](../development/building.md).
- The three engine configurations that ship with the repository, located at:
  - [`configs/engines/ls3_egr.json`](../../configs/engines/ls3_egr.json) — GM LS3 6.2 L V8, naturally aspirated.
  - [`configs/engines/2jz_gte_egr.json`](../../configs/engines/2jz_gte_egr.json) — Toyota 2JZ-GTE 3.0 L I6, twin-turbo.
  - [`data/engines/kr20ddet.json`](../../data/engines/kr20ddet.json) — Nissan KR20DDET 2.0 L I4, single-turbo, variable compression.
- A text editor that handles JSON. Anything with brace-matching and JSON syntax highlighting will do.
- A terminal in the repository root. Every command in this page uses repo-root–relative paths.

`data/examples/` holds the curated example library behind the GUI's **File → Load Example** menu: five validator-clean configs (LS3, SBC 350, K20A, 2JZ-GTE, VW 1.8T), each carrying `display_name`/`description`/`engine_type` metadata for the menu. They are full, loadable configurations and good starting points to copy. Treat the three walkthrough configs listed above as canon for the config format.

## How to use this walkthrough

The most reliable way to learn the format is to copy a known-good config to a working file, change one section at a time, and re-run the sweep after each change. The LS3 is the simplest of the three (no turbo, no VCR, no compressor map), so it makes the best starting point:

```
cp configs/engines/ls3_egr.json my_engine.json
./build/bin/piston run \
    --config my_engine.json \
    --output baseline.csv \
    --format csv
```

After each edit, re-run with a different output filename and compare the CSVs:

```
./build/bin/piston run \
    --config my_engine.json \
    --output after_edit.csv \
    --format csv
```

The columns the sweep writes (`rpm`, `torque_nm`, `power_kw`, `bmep_bar`, `ve_percent`, `bsfc_g_per_kwh`, plus environmental-correction trailing columns) are documented in [`quickstart.md` § Exporting CSV](quickstart.md#exporting-csv). Watching those columns move while you change one JSON field at a time is the fastest way to internalize what each setting actually does.

A general rule: if a column moves the way the physics says it should, your edit makes sense. If a column moves the wrong way or by an implausible amount, the edit is either wrong or pushing past one of the assumptions in [`docs/physics/limitations.md`](../physics/limitations.md).

## The walkthrough

The remainder of this page steps through every top-level key found across the three walkthrough configs. Each section follows the same template:

- **What it represents.** The physical thing the section models.
- **Fields and units.** Every key, with its expected units.
- **Typical ranges.** A sanity-check band drawn from the shipped configs and the physics docs.
- **What changing it does.** Which CSV column the field pushes around, and which direction.
- **Where to read more.** A pointer into [`physics_models.md`](physics_models.md) or the deeper docs under [`docs/physics/`](../physics/).

Sections marked **(optional)** appear only on some shipped configs. Treat optional sections as opt-in feature flags: omit the key entirely and the simulator falls back to a baseline behavior; include it and you take responsibility for the values inside.

A note on what is *required* vs. *parsed but not yet wired*: the shipped JSON files contain a few descriptive fields (`notes`, `build_details`, `performance_targets`) that are not simulation inputs at all, plus some fields whose handling in the C++ loader is still in progress. Where a field is parsed but its physical effect has not been validated end-to-end, this page calls it out explicitly. The authoritative answer to "does the loader actually require this?" lives in the C++ loader source, not in the example configs — see the [Validation against the JSON Schema](#validation-against-the-json-schema) section below.

---

### `engine` / top-level identity (metadata)

**What it represents.** Human-readable identification. Carried through the run for reporting; does not feed any physics model.

**Fields and units.**

| Field | Type | Notes |
|---|---|---|
| `name` | string | Engine display name. Also printed by the CLI on startup. |
| `manufacturer` | string | OEM name. |
| `family` | string | Engine family (e.g. "GM Gen IV Small Block"). |
| `notes` | string | Free-form description. |

These fields sit at the file root. An `"engine": { … }` wrapper around them is **rejected** at load: it used to be accepted and silently ignored, which is why the LS3 configs reported themselves as "Unnamed Engine" (the loader now suggests the unwrapped key, e.g. `name` for `engine.name`).

**Typical ranges.** N/A — strings.

**What changing it does.** Nothing the simulator computes. Use it to keep your library organized.

**Where to read more.** Nothing physics-side. If you want the engine name to surface in plotting tools downstream, this is the only place to set it.

---

### `geometry`

**What it represents.** The fixed mechanical layout of the cylinder and crank — what the slider-crank kinematics and Otto-cycle volume curve are computed against.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `cylinders` | integer | Cylinder count. |
| `bore_mm` | mm | Cylinder bore diameter. |
| `stroke_mm` | mm | Crank stroke. |
| `compression_ratio` | dimensionless | Static geometric compression ratio. Overridden mid-sweep if [`vcr`](#vcr-optional) is enabled. |
| `connecting_rod_length_mm` | mm | Center-to-center rod length. |
| `pin_offset_mm` | mm | Wrist-pin offset from cylinder centerline. `0.0` for symmetric geometries. |
| `firing_order` | array of integers | Cylinder firing sequence; length must equal `cylinders`. |
| `layout` | `single`, `inline`, `v` or `flat` | Cylinder arrangement (`vee` and `boxer` accepted). Absent means inline; it is never inferred from the engine's name. Required when a `cylinder_balance` block is present, which lays out its per-cylinder variation by bank. Every shipped config states it. |
| `displacement_L` | L | Optional stated figure. Displacement is always computed from bore, stroke and cylinder count, and that computed value is what every output reports. If present, it must agree with the geometry to within 1% (enough for published rounding, e.g. "6.2" for 6.162 L), or the config fails validation. |

**Typical ranges.** Across the shipped configs: bore 84–103 mm, stroke 86–93 mm, rod 142–159 mm, compression ratio 8.5 (turbocharged 2JZ) to 14.0 (high-CR setting on the VC-Turbo). Cylinders 4–8.

**What changing it does.**

- **`bore_mm` and `stroke_mm`** scale displacement directly. Power scales roughly with displacement at fixed BMEP, so larger bore/stroke moves the whole power curve up.
- **`compression_ratio`** raises peak cylinder pressure and indicated efficiency, which lifts both peak power and BSFC. Pushing CR up on a non-knock-resistant fuel will trip the [`knock`](#knock) model if `knock.enabled` is true.
- **`connecting_rod_length_mm`** changes the rod-to-stroke ratio (often called the rod ratio, *r/l*). Longer rods produce more symmetric piston motion, slightly reducing secondary forces; the practical effect on the dyno curve is small.
- **`pin_offset_mm`** shifts piston-thrust direction. Very small effect on cycle output; mostly relevant for piston-side-load and friction modeling.
- **`firing_order`** does not change steady-state power, but it does affect crank torque smoothness — important downstream when the project models inertia dynamics.
- **`layout`** does not change steady-state power on any shipped config: it reaches a reported number only through a `cylinder_balance` block's bank-wise variation, and every shipped config that models cylinder imbalance gives explicit per-cylinder multipliers instead. It also sets the layout the cranktrain-dynamics analysis uses.

**Where to read more.** [`docs/physics/crank_slider_kinematics.md`](../physics/crank_slider_kinematics.md) for the kinematic equations and the rod-ratio derivation; [`docs/physics/otto_cycle_assumptions.md`](../physics/otto_cycle_assumptions.md) for how the volume curve feeds the cycle; [`physics_models.md` § Slider-Crank Kinematics](physics_models.md) for the user-facing summary.

---

### `valvetrain`

**What it represents.** The breathing window — when intake and exhaust valves open and close, how big they are, and how many of them are present per cylinder. Drives the volumetric-efficiency curve and, in particular, where peak VE sits in the rev range.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `intake_valve_diameter_mm` | mm | Per-valve intake head diameter. |
| `exhaust_valve_diameter_mm` | mm | Per-valve exhaust head diameter. |
| `intake_valves_per_cylinder` | integer | Usually 1 (2-valve heads) or 2 (4-valve heads). |
| `exhaust_valves_per_cylinder` | integer | Usually 1 or 2. |
| `intake_cam_duration_deg` | crank degrees | Total intake-valve open duration. |
| `exhaust_cam_duration_deg` | crank degrees | Total exhaust-valve open duration. |
| `lobe_separation_angle_deg` | crank degrees | Cam-lobe separation angle (LSA). Larger LSA = less overlap. |
| `intake_centerline_deg` | crank degrees | Where peak intake-valve lift falls relative to TDC. |
| `head_type` | string | One of `performance_2v`, `performance_4v`, etc. Used by the breathing model to select a flow archetype. |

**Optional measured-data fields.** All optional; without them, lift is synthesised from
valve diameter (`0.28 ×` intake, `0.26 ×` exhaust) and flow comes from the `head_type`
archetype. Precedence per side: lift profile > scalar lift > synthesis; an explicit
`intake_cd_table`/`exhaust_cd_table` > `head_flow` > archetype. A malformed table is
ignored with a warning — it never fails the load.

| Field | Units / shape | Notes |
|---|---|---|
| `intake_valve_lift_mm` / `exhaust_valve_lift_mm` | mm | Peak lift **at the valve** (rocker ratio already applied). Range 4–25 when present. On a VTEC engine the scalar is the **high-cam (engaged) lift** — the same convention as the duration keys — and the simulated low lobe is a fixed fraction of it (0.75 intake / 0.78 exhaust); a separate low-cam figure cannot currently be expressed. |
| `intake_lift_profile` / `exhaust_lift_profile` | `[[angle_deg, lift_mm], …]` | Full lobe shape. Angles are **lobe-relative** (0 = peak lift, negative before it), strictly ascending, within ±180°; the profile is positioned by `intake_centerline_deg` and any VVT phasing. At least 5 points. |
| `head_flow` | object | Flow-bench data: `{"test_pressure_inH2O": 28.0, "intake": [[lift_mm, cfm], …], "exhaust": […]}`. CFM is per cylinder's port(s) at the stated depression (default 28" H₂O). |

**Typical ranges.** Across the shipped configs: intake valves 33.5–55 mm, exhaust valves 28–49 mm; cam durations 204–240° intake / 211–236° exhaust; LSA 112–116°; intake centerline 108–115°.

**What changing it does.**

- **Larger valve diameters** raise peak VE and push the VE peak slightly higher in the rev range. The CSV column to watch is `ve_percent` at high RPM.
- **Longer cam duration** trades low-RPM torque for high-RPM power. The torque hump in `torque_nm` will flatten and shift right. Past a certain point, low-RPM idle quality and BSFC suffer (this simulator does not model idle quality, so the trade looks free if you are not careful).
- **Tighter LSA** (smaller number) increases overlap, which scavenges harder at high RPM but hurts low-load running. Wider LSA is the more conservative choice.
- **Intake centerline** moves the breathing peak earlier or later in the cycle. Subtle; tune it after duration and LSA.
- **`head_type`** flips between flow archetypes. Changing this is a coarse adjustment — typically you pick it once based on the head you are modeling.
- **Measured lift or head flow** (the optional fields above) replaces the synthesised
  assumptions with your numbers: a higher-lift cam or a better-flowing head raises peak VE
  (the correlation's usual 0.98 cap opens to 1.02 on this branch) and moves the VE peak and
  the breathing limit up the rev range; milder measurements move everything down. See
  [`../physics/volumetric_efficiency.md`](../physics/volumetric_efficiency.md) § Measured
  valvetrain data for the mechanism and its documented stand-ins.

**Where to read more.** [`physics_models.md` § Valve Flow Modeling](physics_models.md) for the discharge-coefficient model, and [`docs/GAS_DYNAMICS_AND_VE_MODELING.md`](../GAS_DYNAMICS_AND_VE_MODELING.md) for the full VE pipeline.

---

### `fuel`

**What it represents.** The thermochemical properties of the fuel — how much energy releases per unit mass, what air/fuel ratio is stoichiometric, and what density is used to convert volume to mass.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `type` | string | `"gasoline"`, `"gasoline91"`, etc. Currently used as a label. |
| `density_kg_per_L` | kg/L | Mass density at standard conditions. |
| `stoichiometric_ratio` | dimensionless | Mass A/F ratio for complete combustion (≈14.7 for gasoline). |
| `lower_heating_value_J_per_kg` | J/kg | Energy released per unit mass, lower-heating-value basis. |

**Typical ranges.** Gasoline: density 0.73–0.745 kg/L, stoichiometric 14.7, LHV ≈ 43.5–44.0 MJ/kg. Use the same units the example files use — J/kg, not MJ/kg.

**What changing it does.**

- **`lower_heating_value_J_per_kg`** scales the energy released per cycle, which lifts both `power_kw` and `bsfc_g_per_kwh` (BSFC moves because mass flow per unit work changes).
- **`stoichiometric_ratio`** changes the mass of air needed per mass of fuel. Combined with VE, this sets fuel mass flow at WOT.
- **`density_kg_per_L`** rarely matters at the steady-state level the simulator runs at; it shows up downstream when fuel-mass-flow is converted into volumetric flow for an injector model.
- **`type`** does not currently swap any model — it is a tag.

**Where to read more.** [`physics_models.md` § Fuel Properties and Chemistry](physics_models.md) for how fuel feeds the combustion model.

---

### `combustion`

**What it represents.** How heat releases inside the cylinder during the burn. This is the heart of the cycle — the Wiebe function and its parameters live here, along with chamber geometry, charge motion, and ignition timing.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `efficiency` | dimensionless 0–1 | Combustion completeness factor. ≈0.9 for street tunes, up to ≈0.96 for very efficient designs. |
| `model` | string | Currently `"predictive"` for the Wiebe-driven model. |
| `wiebe_efficiency` | dimensionless | Wiebe `a` constant (sometimes written as the burn-completeness coefficient). |
| `wiebe_form_factor` | dimensionless | Wiebe `m` exponent. Higher `m` skews the heat-release curve. |
| `burn_duration_deg` | crank degrees | 10–90 % burn duration. |
| `chamber.shape` | string | `"bathtub"`, `"pentroof"`, etc. Used as a flow/squish archetype. |
| `chamber.spark_offset_x_mm` | mm | Spark plug offset from cylinder centerline. |
| `chamber.spark_depth_mm` | mm | Spark plug protrusion into the chamber. |
| `tumble_ratio` | dimensionless | Bulk in-cylinder tumble; higher → faster burn. |
| `swirl_ratio` | dimensionless | Bulk in-cylinder swirl; complements tumble. |
| `spark_energy_mJ` | mJ | Ignition energy. |
| `ignition_timing_btdc` | crank degrees | Spark advance before TDC. |

**Typical ranges.** Across the shipped configs: `efficiency` 0.9–0.96, `wiebe_efficiency` 4.8–5.0, `wiebe_form_factor` 2.0–2.3, `burn_duration_deg` 45–55°, `tumble_ratio` 0.9–1.8, `swirl_ratio` 0.2–0.5, `spark_energy_mJ` 40–45, `ignition_timing_btdc` 20–24°.

`wiebe_efficiency` and `wiebe_form_factor` appear in `2jz_gte_egr.json` and `kr20ddet.json` but **not** in `ls3_egr.json`. When omitted, the simulator falls back to its built-in Wiebe defaults; specify them when you want explicit control over the burn shape.

**What changing it does.**

- **`burn_duration_deg`** is the most physically intuitive knob. Shorter burn → closer to ideal Otto behavior → higher peak pressure, higher efficiency, higher knock risk. Longer burn → smoother but lossier.
- **`ignition_timing_btdc`** advances or retards the burn. There is an optimum (MBT — minimum advance for best torque); past it, advancing further hurts. The dyno-tuning intuition that "more advance = more power" only holds up to MBT.
- **`tumble_ratio` / `swirl_ratio`** speed up the burn for a given duration; effectively they shorten the *effective* burn duration without changing the parameter explicitly. Helpful when modeling EGR — diluted charges burn slower, and tumble compensates.
- **`efficiency`** is a lumped fudge factor for combustion completeness. Treat it as a calibration knob, not a physics parameter — start at the value in the example file and only move it when matching a real dyno trace.
- **`chamber.*`** fields are mostly archetype selectors; their effect at the cycle level is bundled into the burn-shape and squish behavior.

**Where to read more.** [`physics_models.md` § Combustion Modeling](physics_models.md) for the Wiebe equation, and [`docs/GAS_DYNAMICS_AND_VE_MODELING.md`](../GAS_DYNAMICS_AND_VE_MODELING.md) for the gas-side context. The Otto-cycle assumptions baked into the burn live in [`docs/physics/otto_cycle_assumptions.md`](../physics/otto_cycle_assumptions.md).

---

### `knock`

**What it represents.** A simple knock-onset model that tracks induction time against pressure/temperature history and trips when the integrated knock criterion exceeds 1.0. When knock would occur, the model effectively limits peak pressure.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `enabled` | boolean | Master switch for the knock model. |
| `fuel_ron` | RON | Research Octane Number of the fuel. |
| `induction_time_multiplier` | dimensionless | Scales the empirical induction-time correlation; 1.0 is the unmodified correlation. |

**Typical ranges.** `fuel_ron` 91–100 for pump gasoline; 100+ for race fuels. `induction_time_multiplier` defaults to 1.0; only move it when calibrating against a known-knock-prone or knock-resistant build.

**What changing it does.**

- **`enabled: false`** turns the knock model off entirely. The cycle will then happily run a 14:1 compression ratio on 87 RON without complaint — useful as a sanity check, dangerous as a default.
- **`fuel_ron`** is the main lever. Lowering RON brings the knock margin closer; raising it gives more headroom for compression and timing.
- **`induction_time_multiplier`** is a calibration knob. Start at 1.0.

**Where to read more.** [`physics_models.md` § Knock Modeling](physics_models.md) for the induction-time integration and the octane discussion.

---

### `intake_manifold`

**What it represents.** The geometry of the runners and plenum that feed each cylinder. Drives the Helmholtz / quarter-wave resonance behavior that gives the VE curve its tuned peak.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `runner_length_mm` | mm | Effective intake-runner length from plenum to valve. |
| `runner_diameter_mm` | mm | Runner cross-section. |
| `plenum_volume_L` | L | Plenum volume that feeds the runners. |
| `num_runners` | integer | Usually equal to cylinder count. |
| `manifold_type` | string | Currently `"plenum"`; reserved for future archetypes (single-plane, dual-plane, IR). |

**Typical ranges.** Across the shipped configs: runner length 280–300 mm, runner diameter 44–55 mm, plenum 4.0–5.5 L.

**What changing it does.**

- **`runner_length_mm`** sets the resonance RPM. Longer runners tune for lower RPM (low-end torque); shorter runners tune for higher RPM (top-end). Watch `ve_percent` shift left or right in the rev range as you change this.
- **`runner_diameter_mm`** trades flow for velocity. Smaller runners increase velocity and tuning effect at low RPM but choke at high RPM; bigger runners do the opposite.
- **`plenum_volume_L`** affects how steady the pressure feeding each runner is. Too small and you get cylinder-to-cylinder cross-talk; too large and the resonance effect weakens.

**Where to read more.** [`physics_models.md` § Intake System Dynamics](physics_models.md) for the Helmholtz-tuning model; [`docs/GAS_DYNAMICS_AND_VE_MODELING.md`](../GAS_DYNAMICS_AND_VE_MODELING.md) for the full VE pipeline including the manifold contribution.

---

### `egr`

**What it represents.** Exhaust-gas recirculation — diluting the intake charge with cooled exhaust to reduce peak combustion temperature (and therefore NOx).

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `enabled` | boolean | Master switch. |
| `fixed_rate` | mass fraction 0–1 | EGR mass fraction at steady state. |
| `max_rate` | mass fraction 0–1 | Cap on EGR rate (used by transient/load-aware logic). |
| `cooled` | boolean | Whether the EGR is routed through a cooler before mixing. |
| `cooler_efficiency` | dimensionless 0–1 | Cooler heat-exchange effectiveness. |

**Typical ranges.** `fixed_rate` 0.08–0.10 (8–10 %), `max_rate` 0.12–0.15, `cooler_efficiency` 0.80–0.85.

**What changing it does.**

- **`fixed_rate`** dilutes the charge. Peak combustion temperature drops (NOx benefit, modeled as a cycle-temperature reduction), peak power drops slightly, BSFC rises slightly. Burn duration effectively lengthens because diluted charges burn slower — compensate with the [`combustion.tumble_ratio`](#combustion) knob if you want to keep burn duration constant.
- **`cooled` / `cooler_efficiency`** govern how much heat the EGR loses before mixing. Cooled EGR returns more of the dilution benefit (lower charge temperature) at less of a power cost.

**Where to read more.** [`physics_models.md` § Combustion Modeling](physics_models.md) (EGR-aware burn) and [`docs/physics/limitations.md`](../physics/limitations.md) for the assumptions baked into the dilution model.

---

### `forced_induction` (optional)

**What it represents.** A turbocharger or twin-turbo system, plus an intercooler. Present in `2jz_gte_egr.json`; absent on the LS3 (NA) and the KR20DDET (the KR20DDET is turbocharged in real life but does not ship with a `forced_induction` block in its example config — the canonical turbo example to copy is the 2JZ).

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `type` | string | `"turbo"`, `"twin_turbo"`, `"supercharger"`, etc. |
| `turbo.num_turbos` | integer | Number of turbos in parallel/sequential. |
| `turbo.compressor_map` | string path | Path to a CSV compressor map, **relative to the working directory**. The file must exist at run time. |
| `turbo.a_r_ratio` | dimensionless | Turbine-housing A/R. |
| `turbo.turbine_wheel_diameter_mm` | mm | Turbine wheel diameter. |
| `turbo.turbine_trim` | dimensionless | Trim ratio. |
| `turbo.turbine_peak_efficiency` | 0–1 | Peak isentropic efficiency. |
| `turbo.turbine_optimal_velocity_ratio` | dimensionless | U/Cs at peak efficiency. |
| `turbo.turbine_discharge_coefficient` | dimensionless | Effective flow coefficient. |
| `turbo.rotor_inertia_kgm2` | kg·m² | Rotating inertia of the wheel/shaft. |
| `turbo.max_speed_rpm` | rpm | Mechanical speed limit. |
| `turbo.max_pressure_ratio` | dimensionless | Compressor pressure-ratio cap. |
| `turbo.nominal_speed_rpm` | rpm | Initial / nominal speed used at idle. |
| `turbo.wastegate_spring_psi` | psi | Wastegate cracking pressure. |
| `turbo.wastegate_area_mm2` | mm² | Effective wastegate flow area. |
| `turbo.bearing_friction_viscous` | (model units) | Viscous bearing-friction coefficient. |
| `turbo.bearing_friction_windage` | (model units) | Windage friction coefficient. |
| `intercooler.type` | string | `"air_to_air"`, `"air_to_water"`. |
| `intercooler.effectiveness` | 0–1 | Heat-exchanger effectiveness. |
| `intercooler.pressure_drop_coeff` | (model units) | Pressure drop across the intercooler. |

**Typical ranges (from the 2JZ example).** A/R 0.63, max speed 180 000 rpm, max pressure ratio 2.5, wastegate spring 7 psi, intercooler effectiveness 0.72.

**What changing it does.**

- **`turbo.compressor_map`** is the most important file in this section. It defines the compressor's flow/PR/efficiency surface. A wrong or missing map is the most common reason a turbo config produces nonsense output.
- **`turbo.max_pressure_ratio` and `turbo.wastegate_spring_psi`** set the boost ceiling. Raising the wastegate spring lifts the steady-state boost, which lifts cylinder pressure and (within knock margin) lifts peak power. **If the config has an `ecu.boost` block, its `target_map` is the boost target instead and the spring has no effect**, as on a real engine whose boost controller holds the target. Edit the map to change boost on such an engine (the 2JZ-GTE, N54 and K20C1 ship one). Below the target, boost is limited by how much exhaust energy the turbine gets, so at low speed it can sit well under either value.
- **Intercooler `effectiveness`** trades pressure drop for charge cooling. Higher effectiveness → cooler charge → more density → more power, up to the knock limit.

Forced induction expects `ve_percent` to climb well above 100 % across the boost band — frequently 130–180 %. That is not a bug; see [`getting_started.md` § Step 5](getting_started.md) for the explanation.

**Where to read more.** [`physics_models.md`](physics_models.md) for the compressor-map interpolation and the wastegate model; [`docs/physics/limitations.md`](../physics/limitations.md) for the steady-state assumptions (no transient turbo lag, no surge modeling, etc.).

---

### `vcr` (optional)

**What it represents.** Variable compression ratio. Present in `kr20ddet.json` as the canonical example. When enabled, the actuator overrides the static `geometry.compression_ratio` mid-sweep based on the load map.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `enabled` | boolean | Master switch. When `false`, the static `geometry.compression_ratio` is used. |
| `min_cr` | dimensionless | Lowest CR the actuator can reach. |
| `max_cr` | dimensionless | Highest CR the actuator can reach. |
| `strategy` | string | `"load_map"`, etc. Selects how target CR is chosen at each operating point. |
| `actuator_speed_cr_per_sec` | CR/s | How fast CR can change. |
| `mechanism` | string | Mechanical archetype, e.g. `"multi_link"`. |
| `min_stroke_mm` | mm | Stroke at min CR (mechanism-dependent). |
| `max_stroke_mm` | mm | Stroke at max CR. |
| `load_map.low_load_cr` | dimensionless | CR at low load. |
| `load_map.high_load_cr` | dimensionless | CR at high load. |
| `load_map.transition_load` | 0–1 | Load fraction where CR transitions. |

**Typical ranges (from KR20DDET).** `min_cr` 8.0, `max_cr` 14.0, `transition_load` 0.45.

**What changing it does.**

- **`load_map.high_load_cr`** is the boost-friendly setting (lower CR for knock margin under load). Raising it gives more peak efficiency at the cost of knock margin.
- **`load_map.low_load_cr`** is the cruising setting (higher CR for efficiency at part-throttle). Lowering it gives back some efficiency.
- **`transition_load`** decides where the actuator switches. Move it down to bias toward the low-CR setting earlier.

VCR overrides `geometry.compression_ratio` for any operating point where the strategy says it should. If you want a fixed CR, set `vcr.enabled: false` and let `geometry.compression_ratio` take over.

**Where to read more.** [`physics_models.md` § Combustion Modeling](physics_models.md) and [`docs/physics/otto_cycle_assumptions.md`](../physics/otto_cycle_assumptions.md) for the cycle-side effect of CR.

---

### `thermal` (optional)

**What it represents.** Steady-state wall, coolant, and oil temperatures. Feed the Woschni heat-transfer correlation that subtracts heat from the cycle each step.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `wall_temperature_K` | K | Combustion-chamber wall temperature. |
| `coolant_temperature_K` | K | Coolant temperature. |
| `oil_temperature_K` | K | Oil-film temperature. |

**Typical ranges.** Across the shipped configs: wall 450–460 K, coolant 363 K (≈90 °C), oil 373–378 K (≈100–105 °C).

**What changing it does.** Higher wall temperature reduces heat loss from the cycle (less heat going into the walls), nudging both peak pressure and indicated efficiency up. The effect is small but cumulative; this section matters most when matching a real dyno trace at a specific operating temperature.

**Where to read more.** [`physics_models.md`](physics_models.md) for the Woschni correlation.

---

### `mechanical` (optional)

**What it represents.** The reciprocating and friction inputs to the friction model. Present in `2jz_gte_egr.json` and `kr20ddet.json`; the LS3 example uses defaults.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `piston_mass_kg` | kg | Piston-assembly mass. |
| `connecting_rod_mass_kg` | kg | Rod mass. |
| `reciprocating_mass_fraction` | 0–1 | Fraction of rod treated as reciprocating (rest is rotating). Usually ≈0.667. |
| `fmep_coefficient` | dimensionless | Calibration multiplier on the Chen–Flynn FMEP estimate. |
| `mechanical.friction_class` | - | Optional. Selects a cited per-class Chen-Flynn friction set derived from the Sandoval-Heywood correlation (`gasoline_pushrod_2v`, `gasoline_dohc_4v`, `gasoline_sohc_2v`, `side_valve`). Absent: the legacy tuned default. See `docs/physics/chen_flynn_friction_model.md` section 9.1 -- including why no shipped config sets this yet. |

**Typical ranges.** Piston 0.30–0.52 kg, rod 0.55–0.73 kg. Across the shipped configs `fmep_coefficient` runs 0.85–1.15, and 28 of 32 set it; those that do not take a default of 0.97.

**What changing it does.**

- **`fmep_coefficient`** is the main practical knob. It scales the friction model directly; a lower coefficient gives back power on paper, a higher coefficient takes it. Use it to match a real dyno's friction characteristic.
- **`piston_mass_kg` / `connecting_rod_mass_kg`** feed inertia and side-load calculations rather than steady-state friction; their effect on a steady-state sweep is small.

**Where to read more.** [`docs/physics/chen_flynn_friction_model.md`](../physics/chen_flynn_friction_model.md) for the friction correlation; [`docs/physics/force_analysis.md`](../physics/force_analysis.md) for how the masses feed into side loads.

---

### `operating_limits`

**What it represents.** The sweep envelope and the safety caps the simulator respects.

**Fields and units.**

| Field | Units | Notes |
|---|---|---|
| `idle_rpm` | rpm | Lower bound of the sweep. |
| `redline_rpm` | rpm | The engine's rev limit, and the **default sweep end** for `run`, `simulate`, `report` and `optimize` when `--rpm-end` is not given. An explicit `--rpm-end` is honoured verbatim by `simulate`/`report`/`optimize` (no clamp); `run`'s physical pull always stops here. |
| `max_intake_pressure_kPa` | kPa | Maximum allowed intake pressure (relevant under boost). |
| `max_cylinder_pressure_bar` | bar | Maximum allowed peak cylinder pressure. |
| `max_coolant_temp_C` | °C | Coolant-temperature envelope. |

**Typical ranges.** Across the 32 shipped configs: redline 3200–9000 rpm; `max_cylinder_pressure_bar` 90–180, present on 28 of them and defaulted to 150 on the rest. `max_coolant_temp_C` appears on exactly one config, so treat it as optional rather than typical.

**What changing it does.**

- **`redline_rpm`** is the most user-visible, but it is only enforced on `piston run`: the inertia-dyno pull ends once the engine passes its redline, so an `--rpm-end` above it gives a shorter CSV than expected (the "sweep stops early" symptom called out in [`getting_started.md`](getting_started.md)). `simulate`, `report` and `optimize` evaluate whatever range you ask for, **including past the rev limit**, where the numbers are not meaningful: there is no valve-float or choked-port rolloff in the VE model, so torque stays nearly flat and "peak power" lands wherever you stopped. Keep `--rpm-end` at or below `redline_rpm` on those three commands.
- **`max_*` caps** are guardrails. Raising them lets the simulator extrapolate further into territory the underlying models may not have been validated against — see [`docs/physics/limitations.md`](../physics/limitations.md) before doing so.

**Where to read more.** [`getting_started.md` § Common issues](getting_started.md#common-issues) for the user-visible clamp behavior; [`docs/physics/limitations.md`](../physics/limitations.md) for the validity envelope.

---

### `performance_targets`, `build_details` (metadata only)

These sections are descriptive only — they capture stock OEM ratings, internals, intercooler notes, and so on. The simulator does not read them. They are useful for keeping a configuration self-documenting (and for future tooling that may surface them in a comparison view), but a config that omits them runs identically.

A particularly important consequence: do **not** treat `performance_targets.peak_power_hp` as a target the simulator will hit. It is documentation, not a constraint.

---

## Worked example: make the LS3 breathe better

Two edits, one knob each, applied to a copy of `ls3_egr.json`. The point is not the exact number on the CSV — it is the *direction* of the change.

### Knob 1: lengthen the intake runners

The shipped LS3 manifold has `runner_length_mm: 300`. Lengthen it to 380:

```json
"intake_manifold": {
  "runner_length_mm": 380,
  "runner_diameter_mm": 55,
  "plenum_volume_L": 5.5,
  "num_runners": 8,
  "manifold_type": "plenum"
}
```

Run the sweep before and after:

```
./build/bin/piston run --config my_engine.json --output before.csv --format csv
# … edit runner_length_mm …
./build/bin/piston run --config my_engine.json --output after.csv --format csv
```

Expected qualitative change: the **VE peak shifts to a lower RPM**. Long runners tune for lower-RPM resonance, so `ve_percent` climbs earlier in the rev range and the torque hump in `torque_nm` shifts left. Peak power may move down slightly because top-end breathing is now slightly worse.

This is the single most reliable way to tune for low-end torque vs. top-end power without changing displacement.

### Knob 2: raise compression ratio (and check the knock margin)

The shipped LS3 has `compression_ratio: 10.7` and runs on 95 RON. Bump CR to 11.5:

```json
"geometry": {
  "cylinders": 8,
  "bore_mm": 103.25,
  "stroke_mm": 92.0,
  "compression_ratio": 11.5,
  "connecting_rod_length_mm": 158.75,
  "pin_offset_mm": 0.0,
  "firing_order": [1, 8, 7, 2, 6, 5, 4, 3]
}
```

Make sure `knock.enabled: true` and `fuel_ron: 95.0` are set (they are, in the shipped file). Run the sweep again.

Expected qualitative change: BMEP and peak power **rise** across the rev range as long as the knock model does not trip. If the knock criterion exceeds 1.0 at any operating point, the cycle effectively limits peak pressure there — you will see peak `power_kw` flatten or back off above a particular RPM/load. Lower the fuel RON to 91 and the knock margin shrinks; raise it to 100 and you can go higher on CR before knock bites.

The lesson: **CR and fuel RON are coupled.** Treat the pair as a single design choice, not two independent knobs.

---

## Validation against the JSON Schema

A JSON Schema lives at [`data/validation/schema.json`](../../data/validation/schema.json). One important caveat up front: that schema is the **validation-entry** contract — it covers the real-world dyno-data files under `data/validation/{naturally_aspirated,supercharged,turbocharged}/`, not the engine-configuration files under `configs/engines/`. The two file shapes are different and should not be confused.

There is no JSON Schema file for the engine-configuration format; the loader carries the list of keys it accepts (see the next section), and the three walkthrough configs are the canonical worked examples. When in doubt:

1. Start from a copy of one of the three walkthrough configs.
2. Change one section at a time and re-run.
3. If the loader fails, the error message names the offending key; check the file for typos and missing required keys before assuming the field is unsupported.

### Keys the loader accepts

Every key in an engine config is one of three kinds, and anything else fails the load:

- **Simulated** — a key some part of the simulator reads. This is every key described in the walkthrough above.
- **Metadata** — never simulated, by design: `name`, `manufacturer`, `family`, `notes` (allowed on any section), `description`, `display_name` and `engine_type` (the example library's menu fields), and everything under `build_details`, `performance_targets` and `validation`.
- **Recorded, not simulated** — real engine facts that shipped configs carry and **nothing in the simulation uses**. Changing one has no effect on any result:

  | Key | Why it has no effect |
  |---|---|
  | `intake_manifold.num_runners` | The runner model is per cylinder already |
  | `operating_limits.max_coolant_temp_C` | There is no cooling-system model |
  | `operating_limits.max_intake_pressure_kPa` | Boost limits come from `forced_induction` and `ecu.boost` |
  | `forced_induction.intercooler.type` | Only `effectiveness` and `pressure_drop_coeff` are simulated |
  | `vvt.intake.type`, `vvt.exhaust.type` | Only the phasing range and crossover are simulated |
  | `egr.cooled`, `egr.cooler_efficiency` | Recirculated exhaust carries no temperature in the cycle, so there is nothing for a cooler to cool. `egr.fixed_rate` is simulated (see [`limitations.md`](../physics/limitations.md)) |

---

## Common pitfalls

A short list of mistakes that have shown up most often when authoring a configuration from scratch:

- **A forgotten field that defaults to garbage.** If you delete a required key from a copy of the example, the loader may fall back to a default that is non-physical for your engine. Symptom: the CSV looks plausible but is consistently 10–20 % off in one column. Fix: diff your file against the example you started from.
- **Unit mismatches.** Bore and stroke are **mm**, not m. Pressures are **kPa** for intake and **bar** for cylinder. Heating value is **J/kg**, not MJ/kg. The example files are the source of truth — match their unit suffix on every field you edit.
- **A `forced_induction.turbo.compressor_map` path that does not exist.** The path is relative to the working directory at run time, not relative to the JSON file. If you `cd`'d into a different directory before invoking `piston`, the relative path will not resolve. Fix: use an absolute path, or always run from the repo root.
- **An explicit `--rpm-end` past `redline_rpm`.** Sweeps default to the redline, so this only arises when you pass the flag. On `piston run` the pull still ends at the redline and you get a shorter CSV than expected. On `simulate`, `report` and `optimize` the flag is honoured verbatim — you get rows above the rev limit that look plausible and are not. Lower `--rpm-end`, or raise `operating_limits.redline_rpm` if the engine really does rev that high.
- **Pushing past simulator assumptions.** Extreme compression ratios, very high boost, very high RPM, very low coolant temperature — all push past the assumptions the underlying models were validated against. The simulator will produce *a* number, but it may not be a number you should publish. Read [`docs/physics/limitations.md`](../physics/limitations.md) before drawing strong conclusions.
- **Treating `performance_targets` as a target.** It is metadata, not a constraint — the simulator does not steer toward it.
- **A key the simulator does not know.** A misspelt key, or a real key under the wrong section, is a load error naming the key and, where one is close, the key you probably meant. It used to be ignored silently, so the engine simulated as if the key were absent. See [Keys the loader accepts](#keys-the-loader-accepts).

---

## Next steps

- **[Parts Selection](parts_selection.md)** — the alternate route to a configuration: pick parts from the SQLite catalog, derive the geometry side from the pick, and end at the same JSON shape this page authors by hand.
- **[Simulation Workflow](simulation_workflow.md)** — what the simulator does with the configuration once it has loaded it; the per-stroke walk through each cycle.
- **[Physics Models](physics_models.md)** — the canonical reference for every model named on this page.
- **[Dyno Simulation](dyno_simulation.md)** — inertia and brake dyno modes in detail; relevant if you want to compare a configuration against a real dyno trace.
- **[Known Limitations](../physics/limitations.md)** — the cross-cutting index of simulation simplifications and unsupported configurations. Read this before publishing any number from PISTON as a quantitative claim.

When the GUI configuration panel ships, every section above will map onto a control in the panel — but the JSON files and their semantics will not change, so any configuration you author here will keep loading.
