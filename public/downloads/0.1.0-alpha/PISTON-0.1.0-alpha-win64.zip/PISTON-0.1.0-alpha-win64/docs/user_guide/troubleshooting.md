# Troubleshooting

This page is **section 7** of the [PISTON User Guide](README.md), sitting after [`interpreting_results.md`](interpreting_results.md) at the end of the user-guide reading order. Where every other page in the guide assumes things are working, this page is the one to land on when something is *not* — the build will not run, the configuration will not load, the sweep stops early, or the numbers come out implausible.

It does not re-derive the underlying concepts. Each section names a symptom you can see in your terminal, walks the diagnosis in two or three steps, and cross-links back to the page that already owns the topic.

## Who this is for

You have already produced (or tried to produce) a sweep using the workflow in [`quickstart.md`](quickstart.md) or [`getting_started.md`](getting_started.md), and something went wrong. You have a terminal open, you can re-run the failing command, and you want a fast path from the symptom you can see to the page that explains the fix.

If you have not yet built PISTON or run a sweep, start at [`quickstart.md`](quickstart.md) and come back here when something breaks.

## How to use this page

The section headings below name **symptoms** — `piston: command not found`, `Could not open configuration file`, "the sweep stops early," etc. Scan the headings for the symptom that matches what you saw in the terminal, follow the diagnosis steps in order (cheapest first), then act.

Two ground rules before you start:

- **Quote real terminal output where possible.** The CLI's error strings are short and consistent — copy the exact text into a search of this page or the issue tracker rather than paraphrasing.
- **Defer to the canonical pages.** Where the underlying topic already has a page (`engine_configuration.md` for JSON fields, `interpreting_results.md` for what the CSV columns mean, `physics/limitations.md` for accuracy bands, `development/building.md` for the build), this page sends you there rather than restating it.

---

## Build & launch problems

### `piston: command not found` (or "no such file or directory")

**Symptom.** The shell reports that it cannot find the binary you just tried to run.

**Diagnosis.**

1. The binary did not build, or it built somewhere other than `build/bin/`. Look for `build/bin/piston` (Linux/macOS) or `build\bin\piston.exe` (Windows).
2. You are invoking it from outside the repository root. The CLI does not need to be on your `$PATH`; pass the relative or absolute path explicitly, e.g. `./build/bin/piston --version`.
3. The build itself failed silently. Re-run `cmake --build build` and read the output — a partial build may produce some binaries but not `piston`.

**Fix.** Re-build from the instructions in [`docs/development/building.md`](../development/building.md), confirm the build exits cleanly, and look in `build/bin/` for the executable.

### Wrong path on Windows

**Symptom.** The commands in [`quickstart.md`](quickstart.md) and [`getting_started.md`](getting_started.md) (`./build/bin/piston ...`) fail on Windows.

**Diagnosis.** The user-guide pages are written in Linux/macOS shell spelling. On Windows you need backslashes and the `.exe` suffix: `build\bin\piston.exe`.

**Fix.** Translate the slash and suffix. Everything else — flag names, JSON paths, CSV column names — is the same.

### Slow runs, occasional NaN, or numerically wrong output (Debug vs Release build)

**Symptom.** A sweep that should take a few seconds takes minutes, or one or more rows in the CSV contain `nan`.

**Diagnosis.** You are running a Debug build. Debug builds are slow and occasionally short-circuit numerical paths in performance-critical code, giving nonsense or `nan` output. This is the single most common cause of "my numbers look wrong" and is called out at the top of [`getting_started.md` § Common issues](getting_started.md#common-issues) and [`interpreting_results.md` § Sanity checks](interpreting_results.md#sanity-checks-when-results-are-wrong).

**Fix.** With the supported Ninja generator, the build type is fixed at configure time: reconfigure with `cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=Release` and rebuild. The full guidance is in [`docs/development/building.md`](../development/building.md).

---

## Configuration loading problems

### `Could not open configuration file`

**Symptom.** The CLI exits early reporting that it could not open the file you passed via `--config`.

**Diagnosis.** The `--config` path is **relative to your current shell directory**, not to the binary. If you `cd`'d somewhere other than the repo root, a path like `configs/engines/ls3_egr.json` will not resolve. The `--config` option is also marked `required` and `ExistingFile` in [`src/cli/CLI.cpp`](../../src/cli/CLI.cpp), so the file is opened up-front before the simulation starts.

**Fix.** Either `cd` into the repo root before running the command, or pass an absolute path to the configuration file. This is the same advice given in [`getting_started.md` § Common issues](getting_started.md#common-issues).

### JSON parse error on the configuration file

**Symptom.** The CLI prints `Error: ...` followed by a JSON parser message — `expected '"' in object`, `unexpected character ','`, etc. — and exits with code 1. The catch in [`src/cli/Commands.cpp`](../../src/cli/Commands.cpp) at line 158 wraps any exception from `EngineConfig::fromFile` into this `Error:` line.

**Diagnosis.** The configuration file is not valid JSON. The most common causes are:

- A trailing comma after the last element of an object or array.
- A missing or stray quotation mark around a string value or field name.
- A comment in the file (JSON does not support `//` or `/* */`).

**Fix.** Run the file through a JSON linter (`python -m json.tool < your.json`, `jq . your.json`, or your editor's JSON-mode validation) to find the exact line. Then fix the syntax. The shape of every section is documented in [`engine_configuration.md`](engine_configuration.md); compare against a shipped config in [`configs/engines/`](../../configs/engines/) when in doubt.

### Missing required fields in the configuration

**Symptom.** The CLI loads the file but errors out partway through with a message about a missing field — geometry, valvetrain, fuel, etc.

**Diagnosis.** The shipped configs in `configs/engines/` are the source of truth for the required JSON shape. A custom configuration that omits a required section or field will fail at load time.

**Fix.** Diff your file against the closest shipped config and add the missing section. Every top-level JSON section is documented in [`engine_configuration.md`](engine_configuration.md).

### Wrong engine loaded (the file printed is not the file you meant)

**Symptom.** The CLI printed a different engine name than you expected on startup. The `run` command logs `Engine: <name>` from `Commands.cpp:50`; the `simulate` command logs the same string in its success line at `Commands.cpp:196`.

**Diagnosis.** The `--config` path resolved to a different file than you intended — typically because of a relative-path collision (you ran from the wrong directory) or because two engine configs in different directories share a partial name and shell completion picked the wrong one.

**Fix.** Read the engine name the CLI printed on startup and confirm it matches the file you passed. If it does not, check your shell's working directory and the resolved path of `--config`.

---

## Sweep / simulation problems

### Sweep ends at the redline (or lower than requested)

**Symptom.** The highest `rpm` in the output is the engine's redline rather than the value you expected, or (`piston run` only) lower than the `--rpm-end` you passed.

**Diagnosis.** With no `--rpm-end`, every sweep defaults to `operating_limits.redline_rpm` from the configuration — the default used to be a fixed 7000, so an old script relying on that will now sweep a different band. An explicit `--rpm-end` is honoured as given on `simulate`, `report` and `optimize`; `piston run`'s physical pull always stops at the redline, so its CSV can end below an `--rpm-end` passed above it. See [`getting_started.md` § Common issues](getting_started.md#common-issues) and [`interpreting_results.md` § `rpm`](interpreting_results.md#rpm).

**Fix.** Pass `--rpm-end` explicitly for a different band, or raise `operating_limits.redline_rpm` in the JSON — and accept that the simulator will let you ask physically unreasonable questions if you push the redline past what the engine can actually survive (see [`engine_configuration.md`](engine_configuration.md) for the field).

### `Simulation failed: <message>` or `Error: <message>`

**Symptom.** The CLI exits with a red `Simulation failed: ...` line (from [`src/cli/Commands.cpp`](../../src/cli/Commands.cpp) line 280 in `simulate`) or `Error: ...` (from `Commands.cpp` line 159 in `run`). Both wrap the exception's `e.what()` text.

**Diagnosis.** Some part of the simulator threw a C++ exception during the sweep. The trailing text after the colon is the underlying message — that is the diagnostic signal.

**Fix.** Copy the exact `Simulation failed:` or `Error:` line, including the trailing message, into a bug report (see [§ When to file an issue](#when-to-file-an-issue) below). Before filing, also try narrowing the sweep band with `--rpm-start` and `--rpm-end` — a failure at one specific RPM is much easier to diagnose than "it broke."

### No progress / sweep appears to hang

**Symptom.** The CLI prints the configuration banner and then nothing happens for minutes.

**Diagnosis.** The sweep is either (a) running on a Debug build and is genuinely that slow, or (b) stuck inside a sub-model on a particular RPM step. The `simulate` subcommand prints one line per RPM as it goes, so use it to localize a hang.

**Fix.**

1. Confirm you are on a Release build per [§ Slow runs, occasional NaN](#slow-runs-occasional-nan-or-numerically-wrong-output-debug-vs-release-build).
2. Ctrl-C and re-run `simulate` (not `run`) on a smaller `--rpm-start..--rpm-end` band to find the RPM where it stops printing. That RPM goes in the bug report.

### Seeing more diagnostic output

**Symptom.** You want to see what the simulator set up — which VE strategy, whether the ECU / turbocharger / supercharger initialized, and with what parameters — and a normal run prints none of it.

**Diagnosis.** Setup diagnostics go through the structured logger at **debug** level, which is below the default. Only warnings (for example a physics-init failure that silently degrades the model) print by default, to stderr.

**Fix.** Set the `PISTON_LOG_LEVEL` environment variable to `debug` for one run (`debug`, `info`, `warn` and `error` are accepted; the default is `info`). The level is read once, when the first message is logged, so set it before launching:

```powershell
$env:PISTON_LOG_LEVEL = "debug"; .\build\bin\piston.exe simulate -c data\engines\ls3_stock.json
```

```bash
PISTON_LOG_LEVEL=debug ./build/bin/piston simulate -c data/engines/ls3_stock.json
```

---

## Implausible results

The general rule is: when the run *completes* but the numbers look wrong, the failure mode catalogue lives in [`interpreting_results.md` § Sanity checks](interpreting_results.md#sanity-checks-when-results-are-wrong) — it has per-column bands, the curve shapes to expect, and the three top offenders walked through in detail. This page does not restate any of that.

The three top offenders cribbed from [`getting_started.md` § Common issues](getting_started.md#common-issues), in order:

1. **Debug build.** See [§ Slow runs, occasional NaN](#slow-runs-occasional-nan-or-numerically-wrong-output-debug-vs-release-build).
2. **Wrong configuration loaded.** See [§ Wrong engine loaded](#wrong-engine-loaded-the-file-printed-is-not-the-file-you-meant).
3. **Configuration pushed past the validated envelope.** Some configurations sit outside what the simulator was validated against; the simulator does not always warn before extrapolating. See [`docs/physics/limitations.md`](../physics/limitations.md) for the cross-cutting list of what is and is not in scope.

A reminder on accuracy bands: measured peak-power error is published per engine in [`docs/validation/accuracy.generated.md`](../validation/accuracy.generated.md) for the reference fleet. Per [`docs/physics/limitations.md` § Accuracy expectations](../physics/limitations.md#accuracy-expectations), an engine outside that fleet is **unvalidated — estimate only**. Do not read tighter accuracy claims into the numbers on those engines; this page deliberately does not restate the per-column bands so that [`interpreting_results.md`](interpreting_results.md) and [`limitations.md`](../physics/limitations.md) remain the single sources of truth.

---

## CSV output problems

### `Export failed`

**Symptom.** The CLI prints `Export failed` (from [`src/cli/Commands.cpp`](../../src/cli/Commands.cpp) line 151) and exits with code 1, even though the simulation itself completed.

**Diagnosis.** `DynoResults::exportToCSV` (or `exportToJSON`) returned false. The most common causes are:

- The destination directory does not exist. The CLI creates the file but not its parent directory.
- The destination is not writable (permissions, read-only filesystem, file open in another program).
- The `--output` path resolved somewhere other than where you expected — check the path the CLI echoes in the `Exporting results to:` line just above.

**Fix.** Confirm the parent directory of `--output` exists, confirm you can write to it, and re-run. `--format csv` is the safe explicit form; CSV is also the default, but writing it out makes the command unambiguous in scripts.

### Wrong columns / unexpected column names

**Symptom.** The CSV looks different from what [`quickstart.md` § Exporting CSV](quickstart.md#exporting-csv) and [`interpreting_results.md`](interpreting_results.md) describe.

**Diagnosis.** The CSV column contract is documented in [`quickstart.md` § Exporting CSV](quickstart.md#exporting-csv). If your build emits something different, you are likely on a different cut of the binary than the docs target.

**Fix.** Read the column list in [`quickstart.md`](quickstart.md#exporting-csv) and [`interpreting_results.md`](interpreting_results.md). For column-by-column meaning and units, [`interpreting_results.md`](interpreting_results.md) is the canonical reference.

---

## Parts database problems

### `Parts database not found at ...` from a `parts` subcommand

**Symptom.** You ran `piston parts list` (or `search`/`show`/`compatible`) and the CLI printed `Parts database not found at <path>` and exited with an error.

**Diagnosis.** The subcommands resolve `piston.db` the same way the GUI does: the database the build wrote beside `bin/` first, then `data/database/` (the working directory's, then relative to the executable), taking the first whose schema is current. From a source tree the database is a build product, so a fresh clone has not built it yet; from a package it ships pre-seeded, so this error usually means the `data/` tree was separated from `bin/`. The same message names an empty file or a database with an older schema version when that is what was found.

**Fix.** From source, build it: `cmake --build build --target piston_seed_db`. From a package, keep the unzipped layout intact (`bin/` and `data/` siblings). A stale `data/database/piston.db` left over from an earlier build can simply be deleted.

### `no such table: <name>` from `sqlite3`

**Symptom.** `sqlite3 data/database/piston.db "SELECT ... FROM engine_blocks;"` reports `no such table`.

**Diagnosis.** The schema step of the database initializer did not run, or it ran against a different file. Per [`parts_selection.md` § Building the database](parts_selection.md#building-the-database), the canonical on-disk location is `data/database/piston.db`.

**Fix.** Re-run the initializer:

```
cd data/database
./init_database.sh piston.db          # Linux/macOS
init_database.bat piston.db           # Windows
```

Read the script's output for any errors. The script runs `schema.sql` first, then the seed `*_data.sql` files; a failure in `schema.sql` is the usual cause of `no such table`.

### Missing `piston.db`

**Symptom.** The parts browser is empty, or the file `data/database/piston.db` does not exist.

**Diagnosis.** Two cases:

- **Installed from a release package:** the package ships a seeded `data/database/piston.db` and the GUI finds it relative to the executable — this should not happen; check the file survived extraction.
- **Building from source:** the repository does not track a pre-built database (it is gitignored); the schema and seed data ship as plain SQL. The build seeds `<build-dir>/piston.db` automatically, but the canonical repo location `data/database/piston.db` is built by you. See [`parts_selection.md` § Building the database](parts_selection.md#building-the-database).

**Fix.** From source: build the database with `init_database.sh` / `init_database.bat` from `data/database/`, or with the C++ initializer at `build/bin/init_database`.

### Wrong working directory for the database

**Symptom.** The CLI or a script that opens `data/database/piston.db` cannot find it, even though the file exists.

**Diagnosis.** On the CLI side the path is relative to the *current working directory*, so launching from elsewhere breaks it. (The GUI is different: it probes the executable's directory and its parent for `data/` as well as the CWD, so a packaged install works from any launch location.)

**Fix.** Run the CLI from the repo root, or pass an absolute path.

---

## Performance problems

### Sweep takes minutes instead of seconds

**Symptom.** A full LS3 sweep takes minutes rather than the few seconds [`getting_started.md` § Step 3](getting_started.md) describes.

**Diagnosis.** Almost always a Debug build. See [§ Slow runs, occasional NaN](#slow-runs-occasional-nan-or-numerically-wrong-output-debug-vs-release-build).

**Fix.** Re-build Release. As a secondary lever, narrow the sweep band with `--rpm-start` and `--rpm-end` — `simulate` with a tight band is the fastest iteration loop while you debug a configuration.

### Iterating on a configuration is slow

**Symptom.** You are tweaking a JSON field, re-running, and waiting longer than you want between iterations.

**Diagnosis.** The default `run` sweep covers idle to redline. While you are pinning down a single behavior (peak torque RPM, VE peak, BSFC minimum), you do not need the full sweep.

**Fix.** Use `simulate` with `--rpm-start` and `--rpm-end` set to a narrow band around the RPM you care about. The streaming output lets you watch each row come in. Switch back to `run` once the behavior is locked.

---

## When to file an issue

When the diagnosis steps above do not resolve the problem and you are about to file an issue against the project, attach the following so a maintainer can reproduce:

- **PISTON version.** Output of `piston --version` (or `piston version --verbose`).
- **Build mode.** Release or Debug, and the exact `cmake --build` command you ran.
- **Engine config name printed on startup.** The `Engine: <name>` line from `run`, or the `<name> - <N>cyl <displacement>L` line from `simulate`. This confirms which file the CLI loaded.
- **Exact `--config` and `--output` arguments.** Including the full path you passed.
- **Exact terminal output** of the failing command, including any `Simulation failed:` / `Error:` / `Export failed` line and the trailing `e.what()` text.
- **OS and shell.** Linux/macOS/Windows, plus the shell (on Windows: MSYS2 MINGW64, PowerShell, or cmd).

The issue tracker URL is in [`docs/user_guide/README.md` § Contact](README.md#contact). Pasting the items above into the issue body up front saves a back-and-forth round trip.

---

## Next steps

- **[Interpreting Results](interpreting_results.md)** — section 5; for "the run completed but the numbers look weird," this is the page with the per-column sanity-check bands and the three failure-mode walkthroughs.
- **[Engine Configuration](engine_configuration.md)** — section 2; for "I want to change a value and not break the file," every JSON field's role and unit conventions live here.
- **[Known Limitations](../physics/limitations.md)** — the cross-cutting index of what the simulator does and does not model. Read this when a result feels off but you are not sure whether it is a bug or a documented simplification.
- **[Building PISTON](../development/building.md)** — the full build matrix for any "I cannot get a working binary" symptom that this page did not cover.
