# Parts Selection

This page is **section 3** of the [PISTON User Guide](README.md), sitting between [`engine_configuration.md`](engine_configuration.md) (which authors a runnable JSON file by editing JSON directly) and [`simulation_workflow.md`](simulation_workflow.md) (which feeds that file into the simulator). Where section 2 teaches you how to *write* a configuration, this page teaches you how to *assemble* one — pick parts from the SQLite catalog, derive geometry from those parts, hand the result to the simulator.

It is a CLI-first walkthrough: `piston parts` lists and searches the catalog, and `piston parts apply` writes a picked build into an engine config. The GUI parts panel does the same interactively.

---

## Honest status: what is wired up, and what is not

Before anything else, what works *today* on `path2`:

- The schema in [`data/database/schema.sql`](../../data/database/schema.sql), the bundled seed data under [`data/database/`](../../data/database/), and the initializer in [`tools/init_database.cpp`](../../tools/init_database.cpp) are real and produce a usable `piston.db`.
- The C++ surface in [`src/database/PartsDatabase.h`](../../src/database/PartsDatabase.h) — `getEngineBlocks`, `getCylinderHeads`, `searchParts`, `getCompatibleCylinderHeads`, the insert/update/delete CRUD methods, and `importFromJson` / `exportToJson` (a whole-catalog JSON export that re-imports part for part) — is implemented and exercised by the unit tests.
- The parts-taking compatibility checker in [`src/database/PartsDatabase.h`](../../src/database/PartsDatabase.h) (the `AssemblyCompatibilityChecker` class — renamed from `CompatibilityChecker` when the name collision with the config-taking checker was resolved) — `checkCompatibility(block, head)`, `checkRodRatio(rod, crank)`, `checkDeckHeightStack(...)`, `checkBearingCompatibility(...)`, `checkPinCompatibility(...)`, `checkFullAssembly(...)`, and `calculateCompressionRatio(...)` — is implemented with the constants documented below.

The user-facing surfaces now work:

- **The CLI subcommands are implemented**: `piston parts list -t <type>` (with `-m`/`--model` filters), `piston parts search -q <text>`, `piston parts show -i <id> -t <type>` (`--type` is required — part IDs are per-table), and `piston parts compatible -b <block-id>`. Types are `blocks`, `heads`, `pistons`, `rods`, `cranks`, `cams`, `turbos`, `intakes` and `superchargers`. They query the same database this page documents; from a source build they find the seeded `piston.db` the build writes beside `bin/`.
- **`piston parts apply` writes a build into a config**: `piston parts apply -c data/engines/ls3_stock.json --cam 12 --supercharger 3 -o my_build.json` applies the given part ids (any of `--block --head --piston --rod --crank --cam --turbo --supercharger --intake`) through the same transaction as the GUI, prints every key it changes and every assumption it made, and writes the result only if the whole build validates. `--dry-run` prints the changes and writes nothing. Simulate the output like any config.
- **The GUI panel applies builds to the loaded config**: assemble parts (one per category), press *Apply to Config*, review the preview of every key change, and apply. A camshaft swap visibly moves the simulated curve. Favourites and saved build profiles persist between sessions, in `parts_user.json` in your per-user PISTON config folder.
- **Superchargers reach the simulation.** Applying a roots or twin-screw unit writes its displacement and a drive ratio (`--sc-drive-ratio`, else the midpoint of the part's pulley range, and the tool says which). Boost is capped at the model's default bypass target, because the catalog carries no boost rating; set `forced_induction.supercharger.bypass_target_psi` for your build. A centrifugal unit follows the model's generic speed-squared boost curve, since the catalog has no compressor maps for them. A build with both a turbo and a supercharger is refused: compound charging is not modelled.

The `sqlite3` recipes below remain useful for ad-hoc queries the CLI does not wrap (custom joins, bulk edits, seeding your own parts), and the C++ `PartsDatabase` API in [`PartsDatabase.h`](../../src/database/PartsDatabase.h) is the surface both front ends sit on.

---

## Who this is for

You are comfortable with SQL and SQLite, you have a built `piston` per [`docs/development/building.md`](../development/building.md), and you want to understand the data model well enough either to query it directly today or to be ready when the CLI/GUI surface ships. You have probably already read [`engine_configuration.md`](engine_configuration.md) and noticed that authoring a JSON config from scratch is a lot of fields — the parts database is the *other* route, where the geometry-side fields fall out of a parts pick rather than being typed by hand.

If you have never run a sweep, start with [`quickstart.md`](quickstart.md). If you want to author a config without touching the database, [`engine_configuration.md`](engine_configuration.md) is the right page. If you want to know what the simulator does *with* the configuration, [`simulation_workflow.md`](simulation_workflow.md) is next.

## Prerequisites

- A built `piston` at `build/bin/piston` (Linux/macOS) or `build\bin\piston.exe` (Windows). Build instructions in [`docs/development/building.md`](../development/building.md).
- The `sqlite3` command-line tool installed and on your `$PATH`. Ubuntu/Debian: `sudo apt-get install sqlite3`. macOS: `brew install sqlite3`. Windows: download from `sqlite.org`.
- A `piston.db` file built from the bundled schema and seed data (instructions below).
- Familiarity with the JSON format documented in [`engine_configuration.md`](engine_configuration.md). The bridge subsection ties parts back to JSON fields, and you will follow that bridge more easily if you have skimmed the engine-configuration page first.

## Building the database

**Installed from a release package?** Skip this section: the package ships a freshly
seeded `data/database/piston.db`, built by `init_database` at package time, and the GUI
finds it relative to the executable however you launch it.

**Building from source:** the repository ships the schema and seed data as plain SQL
files, and the build seeds `<build-dir>/piston.db` from them automatically (the
`piston_seed_db` target). The CLI and the GUI look there first, then in
`data/database/piston.db`, and use the first one whose schema version is current; a
database older than the build (or an empty file) is reported with the reason rather than
used, and a missing one is never created. You only need a copy at `data/database/piston.db`
to inspect it with `sqlite3` or use it outside the build. There are two ways to make one:

**With the provided shell/batch scripts** (Linux/macOS uses bash, Windows uses cmd):

```
cd data/database
./init_database.sh piston.db          # Linux/macOS
init_database.bat piston.db           # Windows
```

The scripts run `sqlite3` against [`schema.sql`](../../data/database/schema.sql) followed by [`sample_data.sql`](../../data/database/sample_data.sql), [`manufacturers_extended.sql`](../../data/database/manufacturers_extended.sql), and the seven `*_data.sql` part files, then print row counts per table.

**With the C++ initializer** (good when you want the same surface the C++ code uses):

```
./build/bin/init_database --db data/database/piston.db --schema data/database/schema.sql
```

See [`tools/init_database.cpp`](../../tools/init_database.cpp) for the supported flags.

A copy at `data/database/piston.db` is not regenerated by the build, so rebuild it after the schema changes; the applications ignore it, with a message naming its schema version, once it falls behind.

After the build succeeds, sanity-check the contents:

```
sqlite3 data/database/piston.db "SELECT COUNT(*) FROM engine_blocks;"
sqlite3 data/database/piston.db "SELECT COUNT(*) FROM cylinder_heads;"
```

You should see double-digit row counts for each part table. If you get `no such table`, the schema step failed — re-run the script and read the error.

---

## The parts catalog: tables and what each models

Each subsection follows the same template used in [`engine_configuration.md`](engine_configuration.md):

- **What it represents.** The physical part the table models.
- **Key columns.** Names from [`schema.sql`](../../data/database/schema.sql), with units.
- **Typical ranges.** Sanity-check bands drawn from the bundled seed data.
- **What it maps to in the engine config.** Which JSON field in [`engine_configuration.md`](engine_configuration.md) the column populates.
- **Where to read more.** Pointers into the schema and the physics docs.

Two cross-cutting tables sit beneath the parts:

- **`manufacturers`** — `id`, `name`, `country`, `website`, `notes`. Every part table has a `manufacturer_id` foreign key into this table. `name` is `UNIQUE`, so manufacturer references are stable.
- **`materials`** — `id`, `name`, `type` (one of `metal`, `alloy`, `composite`, `ceramic`), `density` (kg/m³), `tensile_strength` (MPa), `yield_strength` (MPa), `thermal_conductivity` (W/m·K), `specific_heat` (J/kg·K), `thermal_expansion` (µm/m·K), `melting_point` (K). Most part tables have an optional `material_id` foreign key. Used by the strength and thermal-side calculations rather than the cycle simulator directly.

When you insert a custom part by SQL, you insert manufacturer and material rows first (or `SELECT` an existing `id`), then insert the part with the right foreign keys. See [§ Custom parts](#custom-parts).

### `engine_blocks`

**What it represents.** The cylinder block — bore, stroke, deck height, the bolt-pattern that the head has to match, and the main-bearing geometry that the crankshaft has to match. The closest analogue to the `geometry` JSON section.

**Key columns.**

| Column | Units | Notes |
|---|---|---|
| `model` | string | OEM / aftermarket model, e.g. `LS1`, `K20A2`, `2JZ-GTE`. |
| `part_number` | string | Optional unique part number. |
| `bore` | mm | Nominal bore diameter. Compatibility with cylinder heads is checked against this within ±0.5 mm. |
| `stroke` | mm | Crank stroke this block was designed around. (The actual stroke comes from `crankshafts.stroke`.) |
| `deck_height` | mm | Crank centerline to deck surface. Drives the deck-clearance stack check. |
| `bore_spacing` | mm | Center-to-center distance between cylinders. Compatibility with cylinder heads is checked against `cylinder_heads.compatible_spacing` within ±1.0 mm. |
| `cylinder_count` | integer | 1–16. |
| `configuration` | string | One of `inline`, `V`, `flat`, `W`, `rotary`. |
| `bank_angle` | degrees | For `V` and `W` configurations. |
| `max_bore` | mm | Maximum safe bore after machining. |
| `min_deck_height` | mm | Minimum deck height after decking. |
| `main_bearing_count` | integer | Must match `crankshafts.main_bearing_count`. |
| `main_bearing_diameter` | mm | Must match `crankshafts.main_journal_diameter` within ±0.05 mm. |
| `main_bearing_width` | mm | Optional. |
| `weight` | kg | |
| `material_id` | FK → `materials` | |

**Typical ranges (from the bundled seed data).** Bore 84–104 mm, stroke 86–93 mm, deck height 220–235 mm, bore spacing 92–112 mm, cylinder count 4–8, main-bearing diameter 50–65 mm.

**What it maps to in the engine config.**

- `bore` → `geometry.bore_mm`.
- `cylinder_count` → `geometry.cylinders`.
- `configuration` and `bank_angle` are not directly consumed by the cycle simulator — they are descriptive — but they constrain which crank configurations will fit physically.
- `deck_height` is **not** a JSON field; it is consumed by `CompatibilityChecker::checkDeckHeightStack` to verify the rotating assembly fits, and by `calculateCompressionRatio` to derive the clearance volume that ends up as `geometry.compression_ratio`.

**Where to read more.** [`schema.sql`](../../data/database/schema.sql) lines 82–129 for the column definitions and indexes; [`engine_configuration.md` § geometry](engine_configuration.md) for the JSON destination.

### `cylinder_heads`

**What it represents.** The head — combustion chamber volume, valve geometry, valve count, port flow data. Compatibility with a block is enforced by `compatible_spacing` (must match `engine_blocks.bore_spacing` within ±1.0 mm).

**Key columns.**

| Column | Units | Notes |
|---|---|---|
| `model` | string | |
| `compatible_spacing` | mm | Block bore-spacing this head fits. |
| `bolt_pattern` | string | Description; not currently parsed. |
| `combustion_chamber_cc` | cc | Chamber volume. Feeds `calculateCompressionRatio`. |
| `valve_angle` | degrees | Included angle from vertical. |
| `quench_area_percent` | 0–100 | Squish-pad fraction of bore. |
| `intake_valve_count` | integer | Per cylinder; usually 1 (2-valve heads) or 2 (4-valve heads). |
| `intake_valve_diameter` | mm | Per-valve head diameter. |
| `intake_valve_stem_diameter` | mm | Optional. |
| `intake_port_volume` | cc | Optional. |
| `intake_runner_cross_section` | cm² | Optional. |
| `exhaust_valve_count` | integer | Per cylinder. |
| `exhaust_valve_diameter` | mm | |
| `exhaust_valve_stem_diameter` | mm | Optional. |
| `valve_configuration` | string | Description (`DOHC`, `OHV`, `SOHC`, etc.). |
| `valves_per_cylinder` | integer | Total valves per cylinder. |
| `chamber_type` | string | Archetype tag (`cathedral`, `heart`, `pent_roof`, `hemi`, `wedge`). |
| `max_lift` | mm | Maximum supported valve lift. |
| `compatible_bore` | mm | Bore this head was designed around. |
| `flow_data_json` | TEXT (JSON) | Bench flow curve. Structure: `{"intake": [[lift_mm, cfm], …], "exhaust": [[lift_mm, cfm], …]}`. The schema's `json_valid` `CHECK` rejects malformed JSON. |
| `weight` | kg | |
| `material_id` | FK → `materials` | |

**Typical ranges (from the bundled seed data).** Chamber volume 30–75 cc, intake valves 30–60 mm, exhaust valves 25–50 mm, intake valves per cylinder 1–2.

**What it maps to in the engine config.**

- `intake_valve_diameter` → `valvetrain.intake_valve_diameter_mm`.
- `exhaust_valve_diameter` → `valvetrain.exhaust_valve_diameter_mm`.
- `intake_valve_count` → `valvetrain.intake_valves_per_cylinder`.
- `exhaust_valve_count` → `valvetrain.exhaust_valves_per_cylinder`.
- `chamber_type` → maps to `combustion.chamber.shape` (the simulator uses this only as a flow archetype).
- `combustion_chamber_cc` is the *clearance volume at TDC* that feeds `calculateCompressionRatio`. It is not a direct JSON field — its job is to derive `geometry.compression_ratio`.
- `flow_data_json` is the head's measured breathing. Applying a head that has it writes `valvetrain.head_flow`, which the simulator reduces to the valve discharge coefficient it breathes through (28 inH2O is assumed; the catalogue does not record the test depression). **Only one catalogued head carries flow data.** Applying any other head changes valve sizes and count only; `parts apply` and the GUI's build preview both say so, and a flow curve left in the config by an earlier head swap is removed rather than carried over as the new head's breathing.

**Where to read more.** [`schema.sql`](../../data/database/schema.sql) lines 137–201; [`engine_configuration.md` § valvetrain](engine_configuration.md) for the JSON destination; [`docs/GAS_DYNAMICS_AND_VE_MODELING.md`](../GAS_DYNAMICS_AND_VE_MODELING.md) for the breathing pipeline.

### `pistons`

**What it represents.** The piston assembly — bore size, compression height (pin centerline to crown), pin diameter, dish/dome volume, and the valve-relief pockets that show up in the valve-to-piston clearance check.

**Key columns.**

| Column | Units | Notes |
|---|---|---|
| `model` | string | |
| `bore_size` | mm | Actual piston diameter. Compatibility with the block's bore is checked within ±0.5 mm. |
| `compression_height` | mm | Pin centerline to crown. The single most important field for the deck-clearance stack. |
| `pin_diameter` | mm | Wrist-pin diameter. Must match `connecting_rods.small_end_diameter` within ±0.05 mm. |
| `pin_length` | mm | Optional. |
| `dish_dome_cc` | cc | Positive = dish, negative = dome. Feeds `calculateCompressionRatio`. |
| `dome_height` | mm | Crown-above-deck height for dome pistons. |
| `valve_relief_intake_depth` | mm | Optional; consumed by the V2P clearance estimator. |
| `valve_relief_intake_diameter` | mm | Optional. |
| `valve_relief_exhaust_depth` | mm | Optional. |
| `valve_relief_exhaust_diameter` | mm | Optional. |
| `weight` | grams | |
| `material_id` | FK → `materials` | Often `2618 forged` or `4032 forged`. |
| `coating` / `skirt_coating` | string | Free-form descriptors. |
| `max_rpm` | integer | Manufacturer rating; informational only. |
| `max_boost` | psi | Manufacturer rating; informational only. |

**Typical ranges (from the bundled seed data).** Bore 84–104 mm, compression height 28–38 mm, pin diameter 20–24 mm, dish/dome ±3 to ±20 cc, weight 280–550 g.

**What it maps to in the engine config.**

- `weight` → feeds `mechanical.piston_mass_kg` (note the unit conversion — schema is grams, JSON is kg).
- `compression_height` and `dish_dome_cc` are inputs to `calculateCompressionRatio`. They derive `geometry.compression_ratio`; they are not themselves JSON fields.
- `bore_size` is *paired with* `engine_blocks.bore` — the simulator only sees one bore (the JSON `geometry.bore_mm`), but the parts side enforces piston-block compatibility before you author the JSON.

**Where to read more.** [`schema.sql`](../../data/database/schema.sql) lines 208–264; [`engine_configuration.md` § mechanical](engine_configuration.md) for the JSON destination of `weight`; [`engine_configuration.md` § geometry](engine_configuration.md) for the role of `compression_ratio`.

### `connecting_rods`

**What it represents.** The connecting rod — center-to-center length, big-end and small-end bearing geometry, beam type, weight. Length is the dominant dimension because it sets the rod ratio.

**Key columns.**

| Column | Units | Notes |
|---|---|---|
| `model` | string | |
| `center_to_center_length` | mm | Rod length. Maps to `geometry.connecting_rod_length_mm`. |
| `big_end_diameter` | mm | Big-end bearing bore. Must match `crankshafts.rod_journal_diameter` within ±0.05 mm. |
| `big_end_width` | mm | Optional. |
| `small_end_diameter` | mm | Wrist-pin bore. Must match `pistons.pin_diameter` within ±0.05 mm. |
| `small_end_width` | mm | Optional. |
| `beam_type` | string | One of `I-beam`, `H-beam`, `A-beam`, `billet` (or short forms `I`, `H`, `A`). |
| `beam_width` | mm | At narrowest point. |
| `beam_thickness` | mm | |
| `bolt_type` / `rod_bolts` | string | Free-form descriptor. |
| `bolt_diameter` | mm | |
| `weight` | grams | |
| `material_id` | FK → `materials` | Often `4340 forged`. |
| `max_rpm_rating` / `max_horsepower_rating` | integer | Manufacturer ratings; informational. |
| `tensile_strength_rating` | MPa | |

**Typical ranges (from the bundled seed data).** Length 140–170 mm, big-end diameter 48–55 mm, small-end diameter 20–24 mm, weight 550–900 g.

**What it maps to in the engine config.**

- `center_to_center_length` → `geometry.connecting_rod_length_mm`.
- `weight` → feeds `mechanical.connecting_rod_mass_kg` (g → kg).
- `big_end_diameter` and `small_end_diameter` do not appear in the JSON — they are compatibility-only.

**Where to read more.** [`schema.sql`](../../data/database/schema.sql) lines 271–323; [`engine_configuration.md` § geometry](engine_configuration.md) for the rod-length destination; [`docs/physics/crank_slider_kinematics.md`](../physics/crank_slider_kinematics.md) for what rod length does to piston motion.

### `crankshafts`

**What it represents.** The crank — stroke, journal diameters, balance configuration, firing order. Stroke is the dominant dimension because it sets displacement.

**Key columns.**

| Column | Units | Notes |
|---|---|---|
| `model` | string | |
| `stroke` | mm | Crank stroke. Maps to `geometry.stroke_mm`. |
| `main_journal_diameter` | mm | Must match `engine_blocks.main_bearing_diameter` within ±0.05 mm. |
| `main_journal_width` | mm | Optional. |
| `rod_journal_diameter` | mm | Must match `connecting_rods.big_end_diameter` within ±0.05 mm. |
| `rod_journal_width` | mm | Optional. |
| `cylinder_count` | integer | Must match the block's `cylinder_count`. |
| `main_bearing_count` | integer | Must match the block's `main_bearing_count`. |
| `firing_order` | string | E.g. `1-8-7-2-6-5-4-3`. |
| `counterweight_config` | string | Description. |
| `balance_factor` | % | Typically 50–100. |
| `internal_balance` / `external_balance` | boolean | Mutually exclusive in practice. |
| `bobweight` | grams | For external balance. |
| `weight` | kg | |
| `material_id` | FK → `materials` | |
| `heat_treatment` | string | E.g. `nitrided`, `induction hardened`. |
| `max_rpm_rating` / `max_horsepower_rating` | integer | Informational. |

**Typical ranges (from the bundled seed data).** Stroke 70–110 mm, main journal 50–70 mm, rod journal 47–60 mm, cylinder count 4–8.

**What it maps to in the engine config.**

- `stroke` → `geometry.stroke_mm`.
- `firing_order` → `geometry.firing_order` (parsed from the dash-separated string into an integer array).
- `cylinder_count` is consistency-checked against the block's `cylinder_count` and the JSON's `geometry.cylinders` — all three should agree.

**Where to read more.** [`schema.sql`](../../data/database/schema.sql) lines 330–384; [`engine_configuration.md` § geometry](engine_configuration.md) for the JSON destination.

### `camshafts`

**What it represents.** The cam — duration (at 0.050" lift), lift, lobe-separation angle, intake centerline, and an optional per-degree lift curve in JSON. Drives the breathing window.

**Key columns.**

| Column | Units | Notes |
|---|---|---|
| `model` | string | |
| `intake_duration_050` | crank degrees | Intake duration at 0.050" lift. |
| `exhaust_duration_050` | crank degrees | Exhaust duration at 0.050" lift. |
| `intake_duration_seat` | crank degrees | Optional advertised duration at the seat. |
| `exhaust_duration_seat` | crank degrees | Optional. |
| `intake_lift` | mm | Max intake valve lift (at the valve). |
| `exhaust_lift` | mm | Max exhaust valve lift. |
| `intake_lobe_lift` | mm | Optional; lobe-side lift (use rocker ratio to convert to valve lift). |
| `exhaust_lobe_lift` | mm | Optional. |
| `lsa` | crank degrees | Lobe separation angle. |
| `intake_centerline` | crank degrees ATDC | Where peak intake lift falls. |
| `exhaust_centerline` | crank degrees BTDC | |
| `overlap` | crank degrees | Optional; derived as `(intake_dur + exhaust_dur)/2 − lsa` if absent. |
| `advance_built_in` | crank degrees | Default 0. |
| `profile_type` | string | One of `hydraulic_flat`, `hydraulic_roller`, `mechanical_flat`, `mechanical_roller`, `direct_acting`, `overhead_cam`, `solid_roller`, `dohc`, `dohc_vtec`, `dohc_ivtec`, `dohc_mivec`, `dohc_tivct`. |
| `base_circle_diameter` | mm | Optional. |
| `lift_curve_data_json` | TEXT (JSON) | Optional per-degree lift curve. Structure: `{"intake": [[angle_deg, lift_mm], …], "exhaust": [[angle_deg, lift_mm], …]}` from −360 to +360 degrees. |
| `rocker_ratio` | dimensionless | E.g. 1.5, 1.6, 1.7. |
| `valve_spring_requirement` | string | E.g. "180 lb seat, 450 lb open". |
| `material_id` | FK → `materials` | |
| `max_rpm_safe` | integer | Valvetrain-dynamics-limited RPM. |

**Typical ranges (from the bundled seed data).** Intake duration 200–260°, exhaust duration 200–270°, lift 9–14 mm, LSA 108–116°, intake centerline 104–116°.

**What it maps to in the engine config.**

- `intake_duration_050` → `valvetrain.intake_cam_duration_deg`.
- `exhaust_duration_050` → `valvetrain.exhaust_cam_duration_deg`.
- `lsa` → `valvetrain.lobe_separation_angle_deg`.
- `intake_centerline` → `valvetrain.intake_centerline_deg`.
- `profile_type` informs `valvetrain.head_type` indirectly (via the head archetype the cam belongs to); it is not a 1:1 mapping.

**Where to read more.** [`schema.sql`](../../data/database/schema.sql) lines 392–470; [`engine_configuration.md` § valvetrain](engine_configuration.md) for the JSON destination; [`physics_models.md`](physics_models.md) for what duration and LSA do to the curve.

### `turbochargers`

**What it represents.** A turbocharger — compressor and turbine wheel geometry, optional compressor and turbine map JSON, bearing type, max boost. The closest analogue to the `forced_induction.turbo` JSON section.

**Key columns.**

| Column | Units | Notes |
|---|---|---|
| `model` | string | |
| `compressor_inducer` | mm | Inlet diameter. |
| `compressor_exducer` | mm | Outlet diameter. |
| `compressor_trim` | integer | E.g. 60, 62, 67. |
| `compressor_housing_ar` | dimensionless | Compressor A/R. |
| `turbine_inducer` | mm | |
| `turbine_exducer` | mm | |
| `turbine_trim` | integer | |
| `turbine_housing_ar` | dimensionless | Turbine A/R; maps to `forced_induction.turbo.a_r_ratio`. |
| `compressor_map_data_json` | TEXT (JSON) | Optional compressor surface — corrected speed lines, pressure ratios, corrected flow, efficiency grid, surge and choke lines. |
| `turbine_map_data_json` | TEXT (JSON) | Optional turbine map — expansion ratios, corrected flow, efficiency grid. |
| `bearing_type` | string | One of `journal`, `ball_bearing`, `ceramic_ball`, `ball`. |
| `oil_cooled` / `water_cooled` | boolean | |
| `max_rpm` | integer | Mechanical speed limit; maps to `forced_induction.turbo.max_speed_rpm`. |
| `max_boost` | psi | |
| `max_flow` | lb/min | |
| `weight` | kg | |

**Typical ranges (from the bundled seed data).** Compressor inducer 50–85 mm, exducer 65–110 mm, turbine A/R 0.6–1.2, max RPM 100 000–200 000.

**What it maps to in the engine config.**

- `turbine_housing_ar` → `forced_induction.turbo.a_r_ratio`.
- `turbine_inducer` → `forced_induction.turbo.turbine_wheel_diameter_mm`.
- `turbine_trim` → `forced_induction.turbo.turbine_trim`.
- `max_rpm` → `forced_induction.turbo.max_speed_rpm`.
- `compressor_map_data_json` is the on-disk source of truth for what `forced_induction.turbo.compressor_map` points at — when the parts-to-config bridge writes a JSON file, the compressor map is exported to a CSV alongside it and the path is referenced by the JSON.

**Where to read more.** [`schema.sql`](../../data/database/schema.sql) lines 477–540; [`engine_configuration.md` § forced_induction (optional)](engine_configuration.md) for the JSON destination.

### `intake_manifolds`

**What it represents.** The runners and plenum — runner length, runner diameter, plenum volume, throttle-body geometry. Drives the resonance behavior in the VE curve.

**Key columns.**

| Column | Units | Notes |
|---|---|---|
| `model` | string | |
| `configuration` | string | One of `single_plane`, `dual_plane`, `tunnel_ram`, `itb`, `log_style`, `sheet_metal`. |
| `runner_length` | mm | Plenum-to-port. Maps to `intake_manifold.runner_length_mm`. |
| `runner_diameter` | mm | Average. Maps to `intake_manifold.runner_diameter_mm`. |
| `runner_cross_section` | cm² | |
| `runner_taper` | string | Free-form descriptor. |
| `plenum_volume` | L | Maps to `intake_manifold.plenum_volume_L`. |
| `plenum_shape` | string | Description. |
| `throttle_body_size` | mm | Effective diameter. |
| `throttle_body_count` | integer | Default 1. |
| `injector_bung_size` | string | E.g. `14mm x 1.5`. |
| `injector_location` | string | One of `port`, `throttle_body`, `direct`. |
| `weight` | kg | |
| `material_id` | FK → `materials` | |

**Typical ranges (from the bundled seed data).** Runner length 200–400 mm, runner diameter 35–60 mm, plenum 3–8 L.

**What it maps to in the engine config.**

- `runner_length` → `intake_manifold.runner_length_mm`.
- `runner_diameter` → `intake_manifold.runner_diameter_mm`.
- `plenum_volume` → `intake_manifold.plenum_volume_L`.
- `configuration` informs `intake_manifold.manifold_type` (currently only `"plenum"` is wired through end-to-end on the simulator side; see [`engine_configuration.md` § intake_manifold](engine_configuration.md)).

**Where to read more.** [`schema.sql`](../../data/database/schema.sql) lines 553–603; [`engine_configuration.md` § intake_manifold](engine_configuration.md); [`docs/GAS_DYNAMICS_AND_VE_MODELING.md`](../GAS_DYNAMICS_AND_VE_MODELING.md) for the manifold's role in the VE pipeline.

### Other tables

A handful of additional tables live in the schema that you will see in `sqlite3 .tables` output but that are less central to the parts-to-config bridge:

- **`fuels`** ([`schema.sql`](../../data/database/schema.sql) lines 610–641) — a small library of fuels with octane numbers, ethanol content, lower heating value, density, stoichiometric AFR, and laminar flame speed. Maps roughly onto the `fuel` JSON section in [`engine_configuration.md`](engine_configuration.md), with the caveat that the schema stores LHV in MJ/kg while the JSON stores it in J/kg — convert before writing the file.
- **`superchargers`** (seeded via [`superchargers_data.sql`](../../data/database/superchargers_data.sql)) — fifteen roots, twin-screw and centrifugal units. Listed by `piston parts list -t superchargers`, and applied to a config as described above.
- **`compatibility_rules`** ([`schema.sql`](../../data/database/schema.sql) lines 649–680) — a metadata table for human-readable compatibility rules. The actual checks live in C++ in `CompatibilityChecker`; this table is descriptive rather than executable today.
- **`saved_configurations`** ([`schema.sql`](../../data/database/schema.sql) lines 687–729) — a place to persist a parts pick (block, head, piston, rod, crank, cam, turbo, manifold, fuel) plus a `custom_params_json` blob. Useful when you want a parts pick to round-trip through the database; not yet wired into the CLI.

---

## Browsing the database with sqlite3

`piston parts list` / `search` / `show` cover the common cases; for anything they do not wrap (custom joins, bulk edits, your own inserts), query `sqlite3` directly. The recipes below are intentionally short — none of them is more than what you would type at a SQL prompt.

**Open the database.**

```
sqlite3 data/database/piston.db
```

At the SQLite prompt, `.tables` lists every table; `.schema engine_blocks` prints the column layout; `.mode column` and `.headers on` make output readable.

**List manufacturers.**

```sql
SELECT name, country FROM manufacturers ORDER BY name;
```

**Find blocks by displacement (rough; uses the schema's `displacement_liters` view).**

```sql
SELECT manufacturer_name, model, bore, stroke, cylinder_count,
       printf('%.2f', displacement_liters) AS L
FROM v_engine_blocks_full
WHERE displacement_liters BETWEEN 5.5 AND 6.5
ORDER BY displacement_liters;
```

The `v_engine_blocks_full` view is defined in [`schema.sql`](../../data/database/schema.sql) at line 812 — it joins `engine_blocks` against `manufacturers` and `materials` and computes displacement in liters from bore × stroke × cylinder count.

**Find heads matching a block's bore spacing.**

```sql
SELECT ch.model, ch.compatible_spacing, ch.combustion_chamber_cc,
       ch.intake_valve_diameter, ch.exhaust_valve_diameter
FROM cylinder_heads ch
WHERE ABS(ch.compatible_spacing - 111.76) <= 1.0
ORDER BY ch.intake_valve_diameter DESC;
```

(`111.76` is the LS-family bore spacing; substitute your block's value. The 1.0 mm tolerance matches `CompatibilityChecker::SPACING_TOLERANCE_MM`.)

**Find pistons matching a block's bore.**

```sql
SELECT model, bore_size, compression_height, pin_diameter, dish_dome_cc, weight
FROM pistons
WHERE ABS(bore_size - 99.0) <= 0.5
ORDER BY compression_height;
```

(0.5 mm tolerance matches `CompatibilityChecker::BORE_TOLERANCE_MM`.)

**Find rods within a length range.**

```sql
SELECT model, center_to_center_length, big_end_diameter, small_end_diameter, weight, beam_type
FROM connecting_rods
WHERE center_to_center_length BETWEEN 145.0 AND 165.0
ORDER BY center_to_center_length;
```

**Find cams by duration window.**

```sql
SELECT model, intake_duration_050, exhaust_duration_050, lsa,
       intake_lift, exhaust_lift, profile_type
FROM camshafts
WHERE intake_duration_050 BETWEEN 220 AND 240
ORDER BY intake_duration_050;
```

**Cross-table compatibility scan (block + head + piston).** Find any combination that matches a target bore and spacing within tolerance:

```sql
SELECT eb.model AS block, ch.model AS head, p.model AS piston
FROM engine_blocks eb
JOIN cylinder_heads ch ON ABS(ch.compatible_spacing - eb.bore_spacing) <= 1.0
JOIN pistons p ON ABS(p.bore_size - eb.bore) <= 0.5
WHERE eb.bore BETWEEN 99.0 AND 104.0
LIMIT 20;
```

This is the kind of three-way join `piston parts compatible -b <block-id>` encapsulates — use the subcommand for the common case, the SQL when you want different columns.

The shipped subcommands sit exactly where this page said they would: `parts list` on `PartsDatabase::getEngineBlocks(filter)` and its siblings, `parts search` on `PartsDatabase::searchParts(query)`, `parts show` on the per-table `get*(int id)` getters, and `parts compatible` on `PartsDatabase::getCompatibleCylinderHeads(block)`.

---

## Compatibility checking

`CompatibilityChecker` enforces a small set of mechanical rules that have to hold before a parts pick will produce a runnable engine. Every rule is a static method on the class declared in [`PartsDatabase.h`](../../src/database/PartsDatabase.h) and the constants are private to the class — they live next to the methods at the bottom of the header (lines 253–270) and are reproduced here verbatim:

```
BORE_TOLERANCE_MM         = 0.5    // mm — block bore vs piston bore_size
SPACING_TOLERANCE_MM      = 1.0    // mm — block bore_spacing vs head compatible_spacing
ROD_RATIO_MIN_IDEAL       = 1.5    // rod_length / (stroke / 2)
ROD_RATIO_MAX_IDEAL       = 2.0
ROD_RATIO_MIN_ACCEPTABLE  = 1.3    // outside ideal but tolerated
ROD_RATIO_MAX_ACCEPTABLE  = 2.5
DECK_CLEARANCE_MIN        = 1.0    // mm — minimum safe deck clearance at TDC
DECK_CLEARANCE_IDEAL      = 2.0    // mm
PISTON_PROTRUSION_MAX     = 1.5    // mm — piston above deck
BEARING_TOLERANCE_MM      = 0.05   // mm — main bearings, rod bearings, wrist pins
```

Each method takes the relevant parts and returns a `CompatibilityResult` (a `bool compatible` plus `issues` and `warnings` string vectors).

### `checkCompatibility(block, head)`

Verifies the head bolts on the block:

- **Bore match.** `|head.compatible_bore − block.bore|` must be ≤ `BORE_TOLERANCE_MM` (0.5 mm). A larger gap is an error.
- **Spacing match.** `|head.compatible_spacing − block.bore_spacing|` must be ≤ `SPACING_TOLERANCE_MM` (1.0 mm). A larger gap is an error.

The bolt pattern column is descriptive only; this check is geometric.

### `checkRodRatio(rod, crank)`

Computes `rod_length / (stroke / 2)` and classifies it:

- 1.5 ≤ ratio ≤ 2.0 — ideal, no message.
- 1.3 ≤ ratio < 1.5 or 2.0 < ratio ≤ 2.5 — acceptable but warned (high side loads / unusual kinematics).
- ratio < 1.3 or ratio > 2.5 — error (mechanically unreasonable).

Rod ratio also feeds the kinematics ([`docs/physics/crank_slider_kinematics.md`](../physics/crank_slider_kinematics.md)) — longer rods produce more symmetric piston motion and slightly less side load. The ideal band exists because most production engines sit inside it; the acceptable band catches purpose-built cases (very short rods on narrow-deck blocks, etc.).

### `checkDeckHeightStack(block, crank, rod, piston)`

Verifies the rotating assembly fits in the block:

```
required_height = (crank.stroke / 2) + rod.center_to_center_length + piston.compression_height
deck_clearance  = block.deck_height − required_height
```

Then:

- `deck_clearance > DECK_CLEARANCE_IDEAL` (2.0 mm) — fine, no message.
- `DECK_CLEARANCE_MIN ≤ deck_clearance ≤ DECK_CLEARANCE_IDEAL` (1.0–2.0 mm) — tight, warned.
- `0 < deck_clearance < DECK_CLEARANCE_MIN` (< 1.0 mm) — too tight, error.
- `−PISTON_PROTRUSION_MAX ≤ deck_clearance ≤ 0` (piston protrudes 0–1.5 mm above deck) — warned (head gasket / chamber needs to accept the protrusion).
- `deck_clearance < −PISTON_PROTRUSION_MAX` (> 1.5 mm protrusion) — interference, error.

The same arithmetic is the bridge to compression ratio — see `calculateCompressionRatio` below.

### `checkBearingCompatibility(block, crank)` and `checkBearingCompatibility(rod, crank)`

Two overloads:

- **Block ↔ crank.** `|block.main_bearing_diameter − crank.main_journal_diameter|` ≤ `BEARING_TOLERANCE_MM` (0.05 mm), and `block.main_bearing_count == crank.main_bearing_count`.
- **Rod ↔ crank.** `|rod.big_end_diameter − crank.rod_journal_diameter|` ≤ `BEARING_TOLERANCE_MM` (0.05 mm).

Mismatches are errors — bearing shells are not adjustable.

### `checkPinCompatibility(piston, rod)`

`|piston.pin_diameter − rod.small_end_diameter|` ≤ `BEARING_TOLERANCE_MM` (0.05 mm). Mismatches are errors — wrist pins are not adjustable either.

### `checkFullAssembly(block, head, crank, rod, piston)`

The single-call gate before producing a config. Runs all of:

- `checkCompatibility(block, head)`
- `checkRodRatio(rod, crank)`
- `checkDeckHeightStack(block, crank, rod, piston)`
- `checkBearingCompatibility(block, crank)`
- `checkBearingCompatibility(rod, crank)`
- `checkPinCompatibility(piston, rod)`

Aggregates every issue and warning into one `CompatibilityResult`. If `result.isCompatible()` returns `true` (compatible *and* no errors), you have a parts pick that fits — the next step is computing `geometry.compression_ratio` and writing the JSON.

### `calculateCompressionRatio(block, head, pistonCompression, gasketThickness)`

The bridge from parts geometry to the `geometry.compression_ratio` field in the JSON. Given a block (which contributes deck height and bore), a head (which contributes `combustion_chamber_cc`), the piston's compression height, and the head-gasket thickness:

```
swept_volume   = π/4 · bore² · stroke               (mm³, then converted to cc)
deck_clearance = block.deck_height
                 − (crank.stroke / 2 + rod.center_to_center_length
                    + piston.compression_height)    (mm)
clearance_volume = head.combustion_chamber_cc
                 + π/4 · bore² · gasketThickness    (cc, gasket ring volume)
                 + π/4 · bore² · deck_clearance     (cc, deck annulus)
                 − piston.dish_dome_cc              (subtract for dome, add for dish)
compression_ratio = (swept_volume + clearance_volume) / clearance_volume
```

The result is the `geometry.compression_ratio` value you write into the JSON. **This is the most important method in the bridge between the parts catalog and the simulator** — every other JSON geometry field is a column copy, but compression ratio is a derived quantity, and getting it wrong moves the whole power curve.

The simulator does not recompute CR from parts at run time — it consumes whatever scalar lives in `geometry.compression_ratio`. That means the parts-to-CR derivation happens once, off-line, and the JSON file becomes the source of truth from then on.

---

## From parts to a runnable engine configuration

This is the bridge subsection. The end goal is a JSON file in the shape documented in [`engine_configuration.md`](engine_configuration.md). The parts database fills the geometry-side fields and a few `valvetrain` and `mechanical` fields; everything else (the burn shape, EGR, knock, operating limits, thermal, friction calibration) you author by hand.

### Worked example: an LS3-shaped pick

Suppose you query the database and pick:

- **Block**: `LS3` — bore 103.25 mm, stroke 92.0 mm, deck height 234.95 mm, bore spacing 111.76 mm, 8 cylinders, V-config, 5 mains, main-journal 65.0 mm.
- **Head**: a compatible head with 68 cc chambers, intake valves 55.0 mm × 1, exhaust valves 40.5 mm × 1, valve config DOHC=N (`OHV`), chamber type `cathedral`, compatible spacing 111.76 mm.
- **Crank**: stroke 92.0 mm, main-journal 65.0 mm, rod-journal 53.34 mm, 8 cylinders, 5 mains, firing order `1-8-7-2-6-5-4-3`.
- **Rod**: length 158.75 mm, big-end 53.34 mm, small-end 22.0 mm, weight 620 g.
- **Piston**: bore 103.25 mm, compression height 28.6 mm, pin diameter 22.0 mm, dish/dome +6 cc, weight 425 g.
- **Cam**: intake duration 204°, exhaust duration 211°, LSA 116°, intake centerline 110°, intake lift 13.0 mm, exhaust lift 13.0 mm.
- **Intake manifold**: runner length 300 mm, runner diameter 55 mm, plenum 5.5 L, configuration `single_plane`.
- **Turbocharger**: none (NA).

Run `CompatibilityChecker::checkFullAssembly` against this set. Assuming it returns compatible, fill in the JSON:

```json
"geometry": {
  "cylinders": 8,
  "bore_mm": 103.25,
  "stroke_mm": 92.0,
  "compression_ratio": 10.7,
  "connecting_rod_length_mm": 158.75,
  "pin_offset_mm": 0.0,
  "firing_order": [1, 8, 7, 2, 6, 5, 4, 3]
},
"valvetrain": {
  "intake_valve_diameter_mm": 55.0,
  "exhaust_valve_diameter_mm": 40.5,
  "intake_valves_per_cylinder": 1,
  "exhaust_valves_per_cylinder": 1,
  "intake_cam_duration_deg": 204,
  "exhaust_cam_duration_deg": 211,
  "lobe_separation_angle_deg": 116,
  "intake_centerline_deg": 110,
  "head_type": "performance_2v"
},
"intake_manifold": {
  "runner_length_mm": 300,
  "runner_diameter_mm": 55,
  "plenum_volume_L": 5.5,
  "num_runners": 8,
  "manifold_type": "plenum"
},
"mechanical": {
  "piston_mass_kg": 0.425,
  "connecting_rod_mass_kg": 0.620,
  "reciprocating_mass_fraction": 0.667,
  "fmep_coefficient": 1.0
}
```

`compression_ratio: 10.7` is the output of `calculateCompressionRatio` against the block + head + piston above with a typical 1.0 mm head-gasket thickness. The other geometry fields are direct column copies (with the firing-order string parsed into an integer array).

### What the parts database does **not** cover

Everything *thermodynamic* still has to be authored by hand. The parts catalog is silent on:

- `combustion.*` — Wiebe coefficients, burn duration, chamber spark offsets, tumble/swirl, ignition timing, spark energy, combustion efficiency. The chamber's *volume* feeds CR; the chamber's *behavior* is a separate calibration.
- `fuel.*` — fuel type, density, stoichiometric ratio, lower heating value. The `fuels` table is forward-compatible but does not yet populate the JSON section automatically.
- `egr.*` — EGR rate, cooling, cooler effectiveness.
- `knock.*` — knock model on/off, fuel RON, induction-time multiplier.
- `vcr.*` — VCR enable, min/max CR, load map.
- `thermal.*` — wall, coolant, oil temperatures.
- `mechanical.fmep_coefficient` — friction calibration factor (the masses come from the parts; this scalar does not).
- `operating_limits.*` — idle RPM, redline RPM, max intake/cylinder pressure, max coolant temp.
- `forced_induction.intercooler.*` — intercooler type, effectiveness, pressure drop. The turbocharger geometry is in the parts table; the intercooler is not a part in the schema.

For each of these, copy the values from a shipped config in [`configs/engines/`](../../configs/engines/) and tune them as documented in [`engine_configuration.md`](engine_configuration.md). The shipped configs are the source of truth for sensible defaults.

### "Two routes, one simulator"

The point of this page and section 2 is that they end at the same place: a JSON file the simulator can load. [`engine_configuration.md`](engine_configuration.md) walks you through editing each section by hand. This page walks you through deriving the geometry side from a parts pick. Once you have the JSON on disk, the run path is identical:

```
./build/bin/piston run \
    --config my_engine.json \
    --output sweep.csv \
    --format csv
```

…and the CSV reads the same way per [`interpreting_results.md`](interpreting_results.md).

---

## Custom parts

Two ways to add a part: SQL or JSON.

### Insert via SQL

The `manufacturer_id` and `material_id` columns are foreign keys, so the safe pattern is to insert (or look up) the manufacturer and material first:

```sql
INSERT OR IGNORE INTO manufacturers (name, country)
VALUES ('Custom Builders Inc', 'USA');

INSERT OR IGNORE INTO materials (name, type, density, tensile_strength)
VALUES ('Custom 4340 Forged', 'alloy', 7850, 1100);

INSERT INTO engine_blocks
    (manufacturer_id, model, part_number, bore, stroke, deck_height,
     bore_spacing, cylinder_count, configuration, main_bearing_count,
     main_bearing_diameter, weight, material_id, notes)
SELECT m.id, 'CB-V8-427', 'CB-427-001', 104.78, 92.0, 234.95,
       111.76, 8, 'V', 5, 65.0, 95.0, mat.id,
       'Custom 427ci LS-pattern block'
FROM manufacturers m, materials mat
WHERE m.name = 'Custom Builders Inc' AND mat.name = 'Custom 4340 Forged';
```

The `INSERT OR IGNORE` guards against the manufacturer or material already existing; the `SELECT` joins them by name to pick up the right `id`. Most of the bundled `*_data.sql` files use exactly this pattern — read [`engine_blocks_data.sql`](../../data/database/engine_blocks_data.sql) for more examples.

### Insert via the C++ API

Equivalent to the SQL above, against the high-level interface:

```cpp
piston::database::Database db("data/database/piston.db");
piston::database::PartsDatabase parts(db);

piston::database::EngineBlock block;
block.setManufacturer("Custom Builders Inc");
block.setModel("CB-V8-427");
block.setBore(104.78);
block.setStroke(92.0);
block.setDeckHeight(234.95);
block.setBoreSpacing(111.76);
block.setCylinderCount(8);
// … etc.
int newId = parts.insertEngineBlock(block);
```

`insertEngineBlock` enforces the schema's `CHECK` constraints — non-positive prices, out-of-range cylinder counts, malformed JSON in `flow_data_json` etc. all surface as `DatabaseException` rather than silently corrupting the catalog.

### Bulk import via JSON

`PartsDatabase::importFromJson(filepath)` parses a JSON file laid out as an array of part objects and inserts each one. The export side, `PartsDatabase::exportToJson(filepath, optional<PartCategory>)`, produces the same shape. Use this when you have a parts spreadsheet exported as JSON or when you want to ship a parts pack as a single file.

### Custom flow / lift / map curves

Three columns store curve data as JSON inside the row:

- **`cylinder_heads.flow_data_json`** — `{"intake": [[lift_mm, cfm], …], "exhaust": [[lift_mm, cfm], …]}`. A custom head's flow-bench data goes here.
- **`camshafts.lift_curve_data_json`** — `{"intake": [[angle_deg, lift_mm], …], "exhaust": [[angle_deg, lift_mm], …]}` from −360 to +360 degrees. A custom cam's per-degree lift profile goes here.
- **`turbochargers.compressor_map_data_json`** and **`turbine_map_data_json`** — a compressor or turbine surface (corrected speed lines, pressure ratios, corrected flow, efficiency grid, surge / choke lines for compressors).

The schema's `CHECK(json_valid(...))` constraint will reject malformed JSON at insert time. SQLite's `json_valid` returns 1 for any well-formed JSON — it does not validate the *shape* against the structure documented in the schema comments, so a syntactically valid but semantically wrong JSON object will still insert and surface only when something downstream tries to consume it.

---

## Common pitfalls

A short list of mistakes that have shown up most often when building a configuration from a parts pick:

- **Missing `manufacturer_id` or `material_id` foreign keys when inserting.** The `manufacturers` and `materials` tables exist for normalization — every part references them by `id`, not by name. If you `INSERT INTO engine_blocks (...) VALUES (...)` and pass a literal manufacturer name in the model column, the row will load but the `manufacturer_id` will be `NULL` and the `v_engine_blocks_full` view will return an empty `manufacturer_name`. Insert (or `SELECT`) the manufacturer row first, then reference its `id`.
- **Bore tolerance vs. bore-spacing tolerance confusion.** Bore tolerance is 0.5 mm (block ↔ piston, block ↔ head bore); spacing tolerance is 1.0 mm (block ↔ head bolt-pattern centers). The two are enforced by separate constants in the checker (`BORE_TOLERANCE_MM` vs. `SPACING_TOLERANCE_MM`) and a near-miss on one is not a near-miss on the other.
- **Treating `combustion_chamber_cc` as the simulator's full combustion configuration.** The chamber volume feeds `calculateCompressionRatio` — that is its only job. The simulator's `combustion` JSON section (Wiebe coefficients, burn duration, tumble, ignition timing) is independent of the head's chamber volume and has to be authored by hand.
- **Assuming `getCompatibleCylinderHeads` returns thermodynamically compatible heads.** It returns *mechanically* compatible heads — same bore-spacing within tolerance, bore that fits the block. It does not filter for chamber volume, valve area, or flow characteristics — those are tuning concerns, not compatibility concerns.
- **Forgetting to convert grams → kilograms when copying piston / rod weights into the JSON.** The schema stores piston and rod weights in **grams**; the JSON stores `mechanical.piston_mass_kg` and `mechanical.connecting_rod_mass_kg` in **kilograms**. A 425 g piston goes into the JSON as `0.425`, not `425`.
- **Forgetting to convert MJ/kg → J/kg on fuel LHV.** The schema's `fuels.lower_heating_value` is in MJ/kg; the JSON's `fuel.lower_heating_value_J_per_kg` is in J/kg. A 44 MJ/kg gasoline is `44e6` (or `44000000`) in the JSON.
- **Re-running `init_database.sh` over an existing `piston.db` and losing custom rows.** The script prompts before overwriting, but the prompt is easy to miss in scripted environments. Custom parts inserted into the live database are not in the seed `*_data.sql` files; if you re-initialize, they are gone. Either keep a backup of `piston.db`, or maintain your custom inserts as an additional `*_data.sql` file you can re-run.
- **Treating `saved_configurations.custom_params_json` as a substitute for the engine-config JSON.** It is a per-row blob meant for round-tripping the parts pick plus a few tuning scalars; it is not the file that `piston run --config` reads. The latter is the JSON authored per [`engine_configuration.md`](engine_configuration.md).

---

## Next steps

- **[Engine Configuration](engine_configuration.md)** — section 2; what every JSON field does once your parts pick has been translated into a configuration. The fields the parts database does *not* fill (combustion, knock, EGR, thermal, operating limits) are documented there.
- **[Simulation Workflow](simulation_workflow.md)** — section 4; what the simulator does with the configuration once it has loaded it.
- **[Interpreting Results](interpreting_results.md)** — section 5; how to read the sweep CSV that comes out the other side.
- **[Known Limitations](../physics/limitations.md)** — the cross-cutting index of simulation simplifications. Read this before publishing any number derived from a parts pick as a quantitative claim.
- **The schema itself** — [`data/database/schema.sql`](../../data/database/schema.sql) is the source of truth for column names, units, and `CHECK` constraints. When the data model evolves, this page will go stale before the schema does, so when in doubt re-read the schema.

The `piston parts` subcommands and the GUI panel now cover the common workflows on this page; the schema, the compatibility constants, and the parts-to-JSON mapping are unchanged underneath them, so the SQL recipes keep working for everything the wrappers do not reach.
