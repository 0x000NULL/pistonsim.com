# PISTON Quickstart

This quickstart walks a new user through the three-step loop you will use most often: load a configuration, run a simulation, and read the results. It targets the current Alpha build (0.1.0-alpha) of PISTON and covers both the GUI (`piston-gui`) and the headless CLI (`piston`).

## Prerequisites

- A built copy of PISTON. See [docs/development/building.md](../development/building.md) for full instructions; the short version is `cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=Release && cmake --build build`.
- The two front-end binaries land in `build/bin/`:
  - Windows: `build\bin\piston-gui.exe` and `build\bin\piston.exe`
  - Linux / macOS: `build/bin/piston-gui` and `build/bin/piston`
- At least one engine configuration file. The curated example library ships under `data/examples/` (LS3, Small Block 350, K20A, 2JZ-GTE, VW 1.8T) — prefer those for first-time use. Three variant configs also ship under `configs/engines/`:
  - `configs/engines/2jz_gte_egr.json`
  - `data/engines/kr20ddet.json`
  - `configs/engines/ls3_egr.json`

## First-time launch

Start the GUI:

- Windows: `build\bin\piston-gui.exe`
- Linux / macOS: `./build/bin/piston-gui`

You will land on a workspace with the engine-configuration panel, the Results panel, the live dashboard (RPM/HP/torque gauges) and, when the parts database loaded, the parts-selection panel; the windows are dockable and you can rearrange them freely. If you prefer to script everything from a terminal, run `piston --help` instead — every workflow below has a CLI equivalent.


## Loading an example

Open **File → Load Example** and pick one of the five bundled engines — each entry shows the engine type, and hovering shows a one-line description. The engine-configuration panel populates with the loaded engine and its editable fields in a single click: geometry and ignition timing, cam timing (durations, lobe separation, intake centerline), operating limits (idle, redline), the fuel (each choice rewrites density, stoichiometry, heating value and the knock model's octane together), and, on a turbocharged or supercharged engine, its boost, pressure-ratio and intercooler settings. An edit the configuration rules reject is reverted and the reason shown; **Save As...** in the panel writes the edited engine to a new file. **File → New** starts an editable, runnable "Untitled engine" from a bundled template, recorded in its notes, for you to reshape. Cylinder count and firing order stay fixed by the starting configuration, and a turbo is added by applying one from the parts panel rather than typed in.

To load any other configuration from disk:

- GUI: **File → Open Config...** and pick a JSON file (for example from `configs/engines/`).
- CLI: pass the file with `--config`, e.g.
  ```
  piston run --config configs/engines/2jz_gte_egr.json --output run.csv
  ```

If the current configuration has unsaved edits, loading asks before discarding them.


## Running a simulation

Once a configuration is loaded, open **Simulation → Run Simulation** (Ctrl+R) — the RUN SIMULATION button in the engine-configuration panel goes to the same place. A dialog collects the sweep parameters; the RPM band defaults to the loaded engine's redline, and the environmental conditions and correction standard are editable there too. Confirm to start the run. While it runs, a progress overlay tracks the sweep and the dashboard gauges show live RPM, power and torque; the Results panel draws the full curves when the run completes.

The CLI equivalent is the `simulate` (or `run`) subcommand:

```
piston simulate --config data/examples/ls3_stock.json
```

With no `--rpm-end`, the sweep ends at the engine's `redline_rpm` (and the CLI says so); pass `--rpm-start`/`--rpm-end` to pick a different band. Expect a few seconds of runtime for a full sweep on a modern desktop. The CLI prints one line per RPM — torque in N·m and ft-lb, and power in HP — so you can watch the sweep proceed.

## Interpreting power/torque curves

The Results panel draws two plots against RPM, stacked vertically:

- **Torque Curve** (lb-ft) — the rotational force the engine produces. Peak torque marks the RPM where the engine breathes and burns most efficiently.
- **Power Curve** (HP) — the rate of doing work. Peak power sits higher in the rev range than peak torque because power = torque × RPM.

Because the two quantities are related by `HP = torque × RPM / 5252`, the curves would cross at exactly **5252 RPM** if drawn in HP and lb-ft on one shared axis — a unit-conversion artifact, not a physical event, but a useful sanity check when comparing the two plots' values at that RPM.

Hovering a plot shows a crosshair readout of the cursor's coordinates in data space; peak power and peak torque are called out in the metrics column beside the plots, and the toolbar checkboxes toggle raw and corrected curves.

For a column-by-column deeper read of the sweep CSV, expected curve shapes, and the most common failure modes, see [interpreting_results.md](interpreting_results.md).


## Exporting CSV

To hand the results off to a spreadsheet, plotting tool, or another script:

- GUI: **File → Export Results** (Ctrl+E), or the Results panel's **File** menu, which also offers JSON and a single CSV of every comparison run. Each asks where to save (suggesting `dyno_results_<timestamp>.csv`), then reports the path it wrote or why it could not. The entries are disabled until a run has produced results.
- CLI:
  ```
  piston run --config configs/engines/2jz_gte_egr.json --output run.csv --format csv
  ```

The exported file is a time series — one row per simulation timestep, not per RPM — with the columns `Time(s)`, `RPM`, `Omega(rad/s)`, `Alpha(rad/s²)`, `Torque(N·m)`, `Power(W)`, `CorrectedTorque(N·m)`, `CorrectedPower(W)`, followed by any simulation warnings as trailing `# Warnings:` comment lines. The same exporter backs the GUI and the CLI.

## Comparing part combinations (`optimize`)

To answer "which combination of changes makes the most power?", `optimize` sweeps one or
more configuration keys across a grid, runs the full detailed-cycle dyno on every
combination, and ranks them:

```
piston optimize --config data/engines/ls3_stock.json \
  --vary geometry.compression_ratio=10.5,11.0,11.5 \
  --vary combustion.ignition_timing_btdc=20,24,28 \
  --objective peak-hp --rpm-start 2000 --rpm-end 6500 --top 10 --output grid.csv
```

- `--vary key=v1,v2,...` — one axis per flag (repeatable); the search is the Cartesian
  product of all axes. Any numeric config key works.
- `--objective` — what to rank by: `peak-hp`, `peak-tq`, `avg-hp`, or `hp-at-rpm`
  (with `--target-rpm`).
- `--top N` limits the printed table; `--output` writes the full ranked grid as CSV.

Each row reports peak HP and the RPM it occurs at, peak torque and its RPM, and average HP
across the band, with the best combination called out at the end.

## Exporting a printable report (`report`)

To produce a self-contained one-pager you can hand to a customer or save as a PDF (print to
PDF from a browser):

```
piston report --config data/engines/ls3_stock.json --output ls3.html --rpm-start 2000 --rpm-end 6500
```

The HTML file is standalone (inline styles and chart — no external assets) and includes the
engine specification, the simulation conditions, peak power and torque, an SVG power/torque
chart, the full curve table, and an honest accuracy/limitations note (PISTON is a simulated
estimate, not a substitute for a real dyno; for measured fleet peak error see
`docs/validation/accuracy.generated.md`).

## Next steps

- [Getting Started](getting_started.md) — a longer walkthrough of the GUI and configuration panel.
- [Simulation Workflow](simulation_workflow.md) — recommended day-to-day workflow and tips.
- [Physics Models](physics_models.md) — what each model does and the assumptions behind it.
- [Dyno Simulation](dyno_simulation.md) — inertia and brake dyno modes in detail.
