# Dyno Simulation User Guide

## Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [Configuration](#configuration)
4. [Running Simulations](#running-simulations)
5. [Interpreting Results](#interpreting-results)
6. [Examples](#examples)
7. [Advanced Topics](#advanced-topics)
8. [Troubleshooting](#troubleshooting)

---

## Overview

The PISTON dyno simulation module provides a physics-based inertia dynamometer simulation for testing engine performance. The simulation calculates torque and power output by modeling the acceleration of a rotating drum with known moment of inertia.

### Key Features

- **Realistic Inertia Dyno Physics**: Based on τ = I × α (torque from moment of inertia and angular acceleration)
- **Dual Simulation Modes**:
  - **TIME_BASED**: Realistic time-stepped simulation with acceleration
  - **STATIC**: Direct calculation at specific RPM points for validation
- **Environmental Correction**: SAE J1349 and DIN 70020 correction standards
- **Loss Modeling**: Optional friction and windage loss modeling
- **Data Export**: CSV and JSON export formats
- **Validation**: Tested against real dyno data (LS3 6.2L V8)

### Physics Background

An inertia dynamometer measures engine torque by accelerating a drum of known inertia:

```
τ_engine = I × α + τ_loss
```

Where:
- `τ_engine` = Engine torque [N·m]
- `I` = Drum moment of inertia [kg·m²]
- `α` = Angular acceleration [rad/s²]
- `τ_loss` = Friction and windage losses [N·m]

Power is calculated as:

```
P = τ × ω
```

Where:
- `P` = Power [W]
- `ω` = Angular velocity [rad/s]

---

## Quick Start

### Minimal Example

```cpp
#include "dyno/InertiaDyno.h"
#include "dyno/DynoEngineAdapter.h"
#include "core/engine/EngineConfig.h"

using namespace piston::dyno;
using namespace piston::core::engine;
using namespace piston::utils::units;

int main() {
    // 1. Load engine configuration
    EngineConfig engineConfig = EngineConfig::fromFile("data/engines/ls3_stock.json");
    auto adapter = std::make_shared<DynoEngineAdapter>(engineConfig, /*useDetailedCycle=*/true);

    // 2. Configure dyno
    DynoConfig dynoConfig;
    dynoConfig.setDrumProperties(DrumProperties(150.0, meters(0.5)));  // 150 kg, 0.5 m radius
    dynoConfig.setSimulationMode(SimulationMode::TIME_BASED);
    dynoConfig.setEnvironmentalConditions(
        kilopascals(101.3),  // Pressure
        celsius(25.0),       // Temperature
        0.0                  // Relative humidity
    );
    dynoConfig.setCorrectionStandard("SAE J1349");

    // 3. Create dyno and set engine
    InertiaDyno dyno(dynoConfig);
    dyno.setEngineSource(adapter);

    // 4. Run dyno pull
    DynoResults results = dyno.runPull();

    // 5. Calculate and display results
    results.calculatePeakMetrics();
    std::cout << results.generateSummaryReport() << std::endl;

    // 6. Export results
    results.exportToCSV("dyno_results.csv");
    results.exportToJSON("dyno_results.json");

    return 0;
}
```

---

## Configuration

### Drum Properties

The drum (or roller) properties determine the moment of inertia used in torque calculations.

```cpp
// Method 1: Calculate inertia from mass and radius (solid cylinder)
DrumProperties drum1(150.0, meters(0.5));  // I = 0.5 × m × r²

// Method 2: Set inertia directly (for hollow cylinders or calibrated values)
DrumProperties drum2(150.0, meters(0.5));
drum2.setMomentOfInertia(25.0);  // kg·m²
```

**Common Drum Sizes**:
- **Small dyno**: 50 kg, 0.3 m radius, I ≈ 2.25 kg·m²
- **Medium dyno**: 100 kg, 0.4 m radius, I ≈ 8.0 kg·m²
- **Large dyno**: 150 kg, 0.5 m radius, I ≈ 18.75 kg·m²

### Data Acquisition Configuration

Configure sampling rate and RPM range for data collection.

```cpp
DataAcquisitionConfig daq;
daq.samplingRate = 100.0;       // 100 Hz (10 ms intervals)
daq.startRPM = 2000.0;          // Start recording at 2000 RPM
daq.endRPM = 6500.0;            // Stop recording at 6500 RPM
daq.minRecordingRPM = 1500.0;   // Filter out data below 1500 RPM

dynoConfig.setDAQConfig(daq);
```

**Sampling Rate Guidelines**:
- **100 Hz**: Standard for most applications
- **1000 Hz**: High-resolution data capture
- **50 Hz**: Acceptable for steady-state testing

### Environmental Conditions

Atmospheric conditions affect engine performance. The dyno applies correction factors to normalize results to standard conditions.

```cpp
dynoConfig.setEnvironmentalConditions(
    kilopascals(95.0),  // Barometric pressure (Denver: ~95 kPa, sea level: 101.3 kPa)
    celsius(35.0),      // Dry bulb temperature
    0.6                 // Relative humidity (0.0 to 1.0)
);
```

**Correction Standards**:

```cpp
// SAE J1349 (North America standard)
dynoConfig.setCorrectionStandard("SAE J1349");

// DIN 70020 (European standard)
dynoConfig.setCorrectionStandard("DIN 70020");

// No correction (raw data only)
dynoConfig.setCorrectionStandard("None");
```

**SAE J1349 Formula**:
```
CF = (99/P_kPa) × √(T_K/298) × (1 - 0.18×P_v_kPa)
```

**DIN 70020 Formula**:
```
CF = (1013/P_mbar) × √(T_K/293)
```

### Simulation Mode

Choose between time-based simulation (realistic) or static calculation (fast validation).

```cpp
// Time-based: Realistic acceleration simulation
dynoConfig.setSimulationMode(SimulationMode::TIME_BASED);

// Static: Direct calculation at specific RPM points
dynoConfig.setSimulationMode(SimulationMode::STATIC);
```

**When to use TIME_BASED**:
- Simulating actual dyno pulls
- Analyzing transient behavior
- Generating realistic power curves

**When to use STATIC**:
- Validating against dyno sheets
- Quick comparison at specific RPM points
- Debugging engine models

### Loss Modeling (Optional)

Model friction and windage losses in the dyno system.

```cpp
// Loss model: τ_loss = a + b×ω + c×ω²
LossModelConfig lossModel(
    5.0,    // a: Constant friction [N·m]
    0.01,   // b: Linear term [N·m·s/rad]
    0.001   // c: Quadratic term [N·m·s²/rad²]
);

dynoConfig.setLossModel(lossModel);
```

**Typical Loss Values**:
- **Small dyno**: a = 2 N·m, b = 0.005, c = 0.0005
- **Large dyno**: a = 10 N·m, b = 0.02, c = 0.002

---

## Running Simulations

### Time-Based Dyno Pull

Simulates a realistic dyno pull with acceleration from start to end RPM.

```cpp
InertiaDyno dyno(dynoConfig);
dyno.setEngineSource(adapter);

// WOT (wide open throttle) pull
DynoResults results = dyno.runPull();

// Custom throttle profile
auto throttleProfile = [](double time) -> double {
    if (time < 1.0) return 0.5;  // Half throttle for 1 second
    return 1.0;                   // Then WOT
};
DynoResults results2 = dyno.runPullWithThrottle(throttleProfile);
```

**Expected Pull Duration**:
- Small engine (4-cyl, 2.0L): 5-8 seconds
- Large engine (V8, 6.2L): 3-5 seconds
- Turbocharged: 4-7 seconds (depends on boost)

### Static Calculation

Calculate power/torque at specific RPM points without time integration.

```cpp
// Define RPM points
std::vector<double> rpmPoints = {2000, 3000, 4000, 5000, 6000, 7000};

// Run static calculation
dynoConfig.setSimulationMode(SimulationMode::STATIC);
InertiaDyno dyno(dynoConfig);
dyno.setEngineSource(adapter);

DynoResults results = dyno.runStaticCalculation(rpmPoints, 1.0);  // 1.0 = WOT
```

**Use Cases**:
- Comparing against published dyno sheets
- Quick validation during development
- Generating torque curves for documentation

---

## Interpreting Results

### Peak Metrics

After running a simulation, calculate peak performance metrics:

```cpp
results.calculatePeakMetrics();
const PeakMetrics& peaks = results.getPeakMetrics();

std::cout << "Peak Power: " << toHorsepower(peaks.peakPower) << " HP @ "
          << peaks.peakPowerRPM << " RPM" << std::endl;
std::cout << "Peak Torque: " << toPoundFeet(peaks.peakTorque) << " lb-ft @ "
          << peaks.peakTorqueRPM << " RPM" << std::endl;

// Corrected values (SAE/DIN)
std::cout << "Corrected Peak Power: " << toHorsepower(peaks.peakCorrectedPower)
          << " HP @ " << peaks.peakCorrectedPowerRPM << " RPM" << std::endl;
std::cout << "Corrected Peak Torque: " << toPoundFeet(peaks.peakCorrectedTorque)
          << " lb-ft @ " << peaks.peakCorrectedTorqueRPM << " RPM" << std::endl;
```

### Data Points

Access individual data points for plotting or analysis:

```cpp
const auto& dataPoints = results.getDataPoints();

for (const auto& point : dataPoints) {
    std::cout << "Time: " << point.time << " s, "
              << "RPM: " << point.rpm << ", "
              << "Torque: " << toNewtonMeters(point.torque) << " N·m, "
              << "Power: " << toKilowatts(point.power) << " kW" << std::endl;
}
```

### Summary Report

Generate a formatted summary report:

```cpp
std::string report = results.generateSummaryReport();
std::cout << report << std::endl;
```

Example output:
```
===== Dyno Results Summary =====
Test: LS3 Dyno Pull
Date: 2024-01-15
Time: 14:30:00
Engine: LS3 6.2L V8

----- Performance -----
Peak Power:       430.5 HP @ 5900 RPM
Peak Torque:      424.2 lb-ft @ 4600 RPM

----- Environmental Correction (SAE J1349) -----
Corrected Power:  445.2 HP @ 5900 RPM
Corrected Torque: 438.9 lb-ft @ 4600 RPM
Correction Factor: 1.034

----- Environmental Conditions -----
Pressure:    95.0 kPa
Temperature: 35.0 °C
Humidity:    60.0%

----- Test Details -----
Duration:    4.52 s
Data Points: 452
RPM Range:   2000 - 6500 RPM
===============================
```

### Exporting Results

Export data for analysis in external tools:

```cpp
// CSV format (time-series data)
results.exportToCSV("dyno_results.csv");

// JSON format (includes metadata and peak metrics)
results.exportToJSON("dyno_results.json");
```

**CSV Columns**:
```
Time(s), RPM, Omega(rad/s), Alpha(rad/s²), Torque(N·m), Power(W), CorrectedTorque(N·m), CorrectedPower(W)
```

**JSON Structure**:
```json
{
  "metadata": { ... },
  "environmentalConditions": { ... },
  "peakMetrics": { ... },
  "dataPoints": [ ... ]
}
```

---

## Examples

### Example 1: LS3 Stock Configuration

Test a stock GM LS3 6.2L V8 engine:

```cpp
// Load LS3 configuration
EngineConfig engineConfig = EngineConfig::fromFile("data/engines/ls3_stock.json");
auto adapter = std::make_shared<DynoEngineAdapter>(engineConfig, /*useDetailedCycle=*/true);

// Configure dyno (large drum for V8)
DynoConfig dynoConfig;
dynoConfig.setDrumProperties(DrumProperties(150.0, meters(0.5)));

DataAcquisitionConfig daq;
daq.samplingRate = 100.0;
daq.startRPM = 2000.0;
daq.endRPM = 6600.0;  // LS3 redline
dynoConfig.setDAQConfig(daq);

dynoConfig.setSimulationMode(SimulationMode::TIME_BASED);
dynoConfig.setEnvironmentalConditions(kilopascals(101.3), celsius(25.0), 0.0);
dynoConfig.setCorrectionStandard("SAE J1349");

// Run pull
InertiaDyno dyno(dynoConfig);
dyno.setEngineSource(adapter);
DynoResults results = dyno.runPull();

// Display results
results.calculatePeakMetrics();
std::cout << results.generateSummaryReport() << std::endl;
```

**Expected Results** (with current OttoCycle limitations):
- Peak Power: ~813 HP (overestimated due to no friction modeling)
- Peak Torque: ~465 lb-ft (flat curve due to RPM-independent OttoCycle)
- Actual LS3: 430 HP @ 5900 RPM, 424 lb-ft @ 4600 RPM

### Example 2: Custom Engine Configuration

Test a custom engine configuration:

```cpp
Config cfg;

// Basic info
cfg.set("engine.name", "Custom 4-Cylinder");
cfg.set("engine.manufacturer", "DIY Motors");

// Geometry (2.0L square engine)
cfg.set("geometry.cylinders", 4);
cfg.set("geometry.bore_mm", 86.0);
cfg.set("geometry.stroke_mm", 86.0);
cfg.set("geometry.compression_ratio", 10.5);
cfg.set("geometry.connecting_rod_length_mm", 143.0);
cfg.set("geometry.firing_order", std::vector<int>{1, 3, 4, 2});

// Valvetrain
cfg.set("valvetrain.intake_valve_diameter_mm", 33.0);
cfg.set("valvetrain.exhaust_valve_diameter_mm", 29.0);
cfg.set("valvetrain.intake_cam_duration_deg", 220.0);  // Aggressive cam
cfg.set("valvetrain.lobe_separation_angle_deg", 110.0);

// Fuel properties
cfg.set("fuel.type", "gasoline91");
cfg.set("fuel.density_kg_per_L", 0.73);
cfg.set("fuel.stoichiometric_ratio", 14.7);
cfg.set("fuel.lower_heating_value_J_per_kg", 43500000.0);

// Operating limits
cfg.set("operating_limits.idle_rpm", 900.0);
cfg.set("operating_limits.redline_rpm", 7500.0);

EngineConfig engineConfig(cfg);
auto adapter = std::make_shared<DynoEngineAdapter>(engineConfig, /*useDetailedCycle=*/true);

// Run dyno test (small drum for 4-cylinder)
DynoConfig dynoConfig;
dynoConfig.setDrumProperties(DrumProperties(50.0, meters(0.3)));
// ... configure and run as above
```

### Example 3: Validation Against Real Dyno Data

Compare simulation against real dyno sheet:

```cpp
// Real dyno data
struct RealDynoPoint {
    double rpm;
    double torque_lbft;
    double power_hp;
};

std::vector<RealDynoPoint> realData = {
    {2000, 350.0, 133.0},
    {3000, 400.0, 228.0},
    {4600, 424.0, 372.0},  // Peak torque
    {5900, 400.0, 450.0},  // Peak power
    {6400, 370.0, 451.0}
};

// Run static simulation at same RPM points
std::vector<double> rpmPoints;
for (const auto& point : realData) {
    rpmPoints.push_back(point.rpm);
}

dynoConfig.setSimulationMode(SimulationMode::STATIC);
InertiaDyno dyno(dynoConfig);
dyno.setEngineSource(adapter);
DynoResults results = dyno.runStaticCalculation(rpmPoints, 1.0);

// Calculate RMSE
double calculateRMSE(const std::vector<double>& predicted,
                     const std::vector<double>& actual) {
    double sum = 0.0;
    for (size_t i = 0; i < predicted.size(); ++i) {
        double error = predicted[i] - actual[i];
        sum += error * error;
    }
    return std::sqrt(sum / predicted.size());
}

std::vector<double> predictedTorque, actualTorque;
const auto& simPoints = results.getDataPoints();

for (size_t i = 0; i < realData.size(); ++i) {
    predictedTorque.push_back(toPoundFeet(simPoints[i].torque));
    actualTorque.push_back(realData[i].torque_lbft);
}

double rmse = calculateRMSE(predictedTorque, actualTorque);
std::cout << "Torque RMSE: " << rmse << " lb-ft" << std::endl;
```

---

## Advanced Topics

### Custom Engine Sources

Implement the `IEngineSource` interface to test custom engine models:

```cpp
class CustomEngine : public IEngineSource {
public:
    Torque getTorqueAtRPM(double rpm, double throttle = 1.0) override {
        // Your custom torque calculation
        double torque_Nm = calculateTorque(rpm, throttle);
        return newtonMeters(torque_Nm);
    }

    double getMaxRPM() const override { return 8000.0; }
    double getMinRPM() const override { return 1000.0; }

private:
    double calculateTorque(double rpm, double throttle) {
        // Implement your torque curve
        // Example: Simple quadratic torque curve
        double peakTorque = 200.0;  // N·m
        double peakRPM = 5000.0;

        double normalized = (rpm - peakRPM) / peakRPM;
        double torque = peakTorque * (1.0 - 0.5 * normalized * normalized);

        return std::max(0.0, torque * throttle);
    }
};

// Use custom engine
auto customEngine = std::make_shared<CustomEngine>();
dyno.setEngineSource(customEngine);
```

### Progressive Throttle Profiles

Simulate part-throttle operation:

```cpp
// Linear ramp from 50% to 100% throttle
auto rampThrottle = [](double time) -> double {
    return 0.5 + 0.5 * std::min(1.0, time / 3.0);  // Ramp over 3 seconds
};

// Step throttle (50% for 2s, then WOT)
auto stepThrottle = [](double time) -> double {
    return (time < 2.0) ? 0.5 : 1.0;
};

// Sinusoidal throttle (for transient testing)
auto sineThrottle = [](double time) -> double {
    return 0.5 + 0.5 * std::sin(2.0 * M_PI * time / 5.0);  // 5 second period
};

DynoResults results = dyno.runPullWithThrottle(rampThrottle);
```

### Altitude and Weather Compensation

Simulate dyno testing at different altitudes:

```cpp
// Denver, CO (high altitude)
dynoConfig.setEnvironmentalConditions(
    kilopascals(84.0),   // ~1600 m elevation
    celsius(20.0),
    0.3
);

// Sea level, hot day
dynoConfig.setEnvironmentalConditions(
    kilopascals(101.3),
    celsius(40.0),
    0.8  // High humidity
);

// Compare results
DynoResults denverResults = dyno.runPull();
dynoConfig.setEnvironmentalConditions(kilopascals(101.3), celsius(40.0), 0.8);
DynoResults seaLevelResults = dyno.runPull();
```

### Batch Testing

Test multiple configurations in a loop:

```cpp
std::vector<std::string> engineFiles = {
    "data/engines/ls3_stock.json",
    "data/engines/ls7_stock.json",
    "data/engines/coyote_stock.json"
};

for (const auto& file : engineFiles) {
    EngineConfig config = EngineConfig::fromFile(file);
    auto adapter = std::make_shared<DynoEngineAdapter>(config, /*useDetailedCycle=*/true);

    dyno.setEngineSource(adapter);
    DynoResults results = dyno.runPull();
    results.calculatePeakMetrics();

    std::string outputFile = file + "_results.csv";
    results.exportToCSV(outputFile);
}
```

---

## Troubleshooting

### Issue: Dyno is not ready to run

**Error**: `std::runtime_error: Dyno is not ready to run`

**Cause**: Missing configuration or engine source.

**Solution**:
```cpp
if (!dyno.isReady()) {
    std::cerr << "Dyno not ready. Check configuration." << std::endl;

    // Verify drum properties
    if (!dynoConfig.getDrumProperties().isValid()) {
        std::cerr << "Invalid drum properties" << std::endl;
    }

    // Verify engine is set
    dyno.setEngineSource(adapter);
}
```

### Issue: Results are empty

**Symptom**: `results.isEmpty()` returns true after running simulation.

**Possible Causes**:
1. RPM range doesn't intersect with engine operating range
2. `minRecordingRPM` is too high
3. `startRPM` > `endRPM`

**Solution**:
```cpp
DataAcquisitionConfig daq = dynoConfig.getDAQConfig();

// Ensure valid RPM range
if (daq.startRPM >= daq.endRPM) {
    std::cerr << "Invalid RPM range" << std::endl;
}

// Lower minRecordingRPM
daq.minRecordingRPM = 0.0;
dynoConfig.setDAQConfig(daq);
```

### Issue: Simulation takes too long

**Symptom**: Time-based simulation takes > 30 seconds.

**Possible Causes**:
1. Sampling rate too high
2. Large RPM range with low torque
3. Heavy drum (high inertia)

**Solution**:
```cpp
// Reduce sampling rate
DataAcquisitionConfig daq = dynoConfig.getDAQConfig();
daq.samplingRate = 50.0;  // Was 1000 Hz, now 50 Hz
dynoConfig.setDAQConfig(daq);

// Or use STATIC mode for faster results
dynoConfig.setSimulationMode(SimulationMode::STATIC);
```

### Issue: Power values are much higher than published figures

**Symptom**: Simulated power overshoots the engine's published rating by a large margin.

**Cause**: The adapter was constructed with `useDetailedCycle=false` — the analytical
Otto baseline, which overpredicts and exists only as a deterministic reference for
unit tests and dev comparison. The constructor requires the flag precisely so this
choice is visible at the call site.

**Solution**: Construct on the production path:

```cpp
auto adapter = std::make_shared<DynoEngineAdapter>(engineConfig, /*useDetailedCycle=*/true);
```

The detailed cycle includes RPM-dependent thermodynamics, Wiebe combustion, Woschni
heat transfer, the VE model, and Chen-Flynn friction — do not apply manual friction
corrections on top of it. The published error bands per engine class are in
`docs/physics/limitations.md`.

### Issue: Environmental correction seems wrong

**Symptom**: Corrected values are very different from raw values.

**Check**: Verify environmental conditions are realistic:

```cpp
const auto& env = results.getEnvironmentalConditions();

std::cout << "Pressure: " << toKilopascals(env.pressure) << " kPa" << std::endl;
std::cout << "Temperature: " << toCelsius(env.temperature) << " °C" << std::endl;
std::cout << "Humidity: " << env.relativeHumidity * 100.0 << "%" << std::endl;
std::cout << "Correction Factor: " << env.correctionFactor << std::endl;

// Typical correction factors:
// - Sea level, 25°C, 0% RH: CF ≈ 1.00
// - Denver (1600m), 20°C, 30% RH: CF ≈ 1.15-1.20
// - Hot day (40°C), 80% RH: CF ≈ 0.90-0.95
```

### Issue: Compilation errors with units

**Error**: Cannot convert between unit types.

**Solution**: Use explicit unit conversion functions:

```cpp
// Correct
double torque_Nm = toNewtonMeters(point.torque);
double power_kW = toKilowatts(point.power);

// Incorrect (won't compile)
double torque_Nm = point.torque;  // Error: Torque is a typed unit
```

---

## Summary

The PISTON dyno simulation provides a flexible, physics-based tool for testing engine performance. Key takeaways:

1. **Start simple**: Use default configurations and work your way up to advanced features
2. **Validate early**: Compare against real dyno data to verify your engine model
3. **Understand limitations**: Current OttoCycle has known limitations (flat torque, no friction)
4. **Export data**: Use CSV/JSON export for detailed analysis in external tools
5. **Environmental correction**: Always apply SAE J1349 or DIN 70020 for meaningful comparisons

For more information, see:
- API documentation: `docs/api/`
- Physics background: `docs/physics/thermodynamics.md`
- Example configurations: `data/engines/`
- Validation tests: `tests/validation/`

---

**Last Updated**: Phase 1, Week 14 (Dyno Module Complete)
**Version**: 0.1.0
**Contact**: See `README.md` for project information
