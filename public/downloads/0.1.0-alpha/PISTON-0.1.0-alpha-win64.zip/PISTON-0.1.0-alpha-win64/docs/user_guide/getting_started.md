# Getting Started with PISTON

This is a longer companion to [Quickstart](quickstart.md). Where the quickstart hands you the three-step loop in five minutes, this tutorial walks the same path more slowly: it explains *why* each step exists, picks one configuration to follow end-to-end, and shows you how to read the resulting curves and tweak them. By the end you will have a CSV from a real engine sweep on disk and enough vocabulary to keep going on your own.

## Who this tutorial is for

You are comfortable on a command line, you have already (or are about to) build PISTON from source, and you would rather spend ten minutes learning what each output column means than five minutes copying commands. If you only need the commands, the quickstart is a better fit. If you have never touched a four-stroke engine cycle before, read this page top-to-bottom — it links out to the deeper physics docs at the points where they become relevant.

A note on tooling: PISTON ships two front-end binaries today, `piston` and `piston-gui`. The CLI is feature-complete enough to drive every workflow in this tutorial, and this page sticks to it — the deeper diagnostics below are CLI-shaped. The GUI covers the core loop ([quickstart.md](quickstart.md) describes it as shipped: load an example or config, run a sweep, read the curves, export); it remains unvalidated against real hardware like everything else in the alpha.

## What you'll build

By the time you reach the bottom of this page you will have:

1. A working `piston` binary on your machine.
2. A CSV of an LS3 dyno sweep from idle to redline on disk.
3. An annotated reading of that CSV — peak power, peak torque, the VE curve, and what each column means.
4. A second sweep on a turbocharged engine (the 2JZ-GTE) so you can see how curve shape differs between naturally aspirated and forced-induction setups.
5. A pointer into the configuration JSON that explains how the numbers you see in the CSV trace back to the engine's geometry, head, cam, and combustion settings.

That is enough to start running your own experiments — comparing cams, sweeping compression ratios, or validating a build against a real dyno trace.

## Prerequisites

- **A copy of PISTON.** Two ways to get one:
  - **Download a release** (Windows): the portable ZIP on the GitHub Releases page — unzip anywhere, binaries in `bin\`, configs and data bundled. The README's Download section covers the unsigned-binary SmartScreen warning and checksum verification.
  - **Build from source:** follow [docs/development/building.md](../development/building.md); the short version is `cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=Release && cmake --build build`. The build drops binaries into `build/bin/`.
- **The engine configurations that ship with the repo.** Three are provided under `configs/engines/`:
  - [`configs/engines/ls3_egr.json`](../../configs/engines/ls3_egr.json) — GM LS3 6.2 L V8, naturally aspirated, with 10 % cooled EGR.
  - [`configs/engines/2jz_gte_egr.json`](../../configs/engines/2jz_gte_egr.json) — Toyota 2JZ-GTE 3.0 L inline-6, twin-turbo, with 8 % cooled EGR.
  - [`data/engines/kr20ddet.json`](../../data/engines/kr20ddet.json) — Nissan KR20DDET 2.0 L inline-4, single-turbo, variable compression ratio (8:1–14:1).
- **A terminal in the repository root.** All paths in this tutorial are written relative to the repo root, so `cd` there before you start.

If your build succeeded, you should see the CLI binary at `build/bin/piston` (Linux/macOS) or `build\bin\piston.exe` (Windows). The remainder of this tutorial uses the Linux/macOS spelling — translate to `\` and `.exe` on Windows.

## Step 1: Verify your build

Before pointing the binary at a configuration, confirm it runs:

```
./build/bin/piston --version
./build/bin/piston --help
```

`--version` prints the version string the build was tagged with and exits. `--help` lists the top-level subcommands and the global flags they share. If either command errors out, your build is incomplete or the binary is on the wrong path — go back to [building.md](../development/building.md) and re-check the build output.

The two subcommands you will use in this tutorial are:

- `piston simulate` — sweeps RPM and prints one summary line per RPM to stdout. Good for a quick sanity check.
- `piston run` — same sweep, but writes results to a file (CSV by default). Use this when you want to keep the numbers.

If `--help` shows a different subcommand name on your build (the surface evolves), substitute it everywhere below; the flags are the same.

Two more commands are useful once you have the basics:

- `piston wizard` builds a new engine configuration interactively. You pick an engine class, it starts from a bundled engine of that class, and it asks for bore, stroke, rod length, compression ratio, the boost target on the supercharged class, fuel octane and rev limits; pressing Enter keeps each value shown. It saves the result only if it passes the same checks as `piston validate` and simulates across its rev range, then offers to run it. (The turbocharged class does not ask for a boost target: the simulated curve does not currently respond to the wastegate setting, so the answer would be ignored.) Because the published power figures and parts list of the starting engine no longer describe your edit, they are not copied into the new file.
- `piston export -i results.json -o results.csv` converts a `run` result between JSON and CSV, taking the output format from the `-o` extension (or `-f csv|json`). JSON to CSV gives exactly the CSV `run` writes. A CSV does not record the test conditions or correction standard, so converting CSV to JSON leaves those fields `null` rather than guessing them.

## Step 2: Pick a configuration

The repository ships three engines on purpose — each shows off a different corner of the simulator:

| File | Engine | Why it's interesting |
|---|---|---|
| `configs/engines/ls3_egr.json` | GM LS3, 6.2 L V8 NA | Big naturally aspirated pushrod V8. Smooth torque curve, well-validated archetype, no boost variables to interpret. |
| `configs/engines/2jz_gte_egr.json` | Toyota 2JZ-GTE, 3.0 L I6 twin-turbo | Forced induction with a published compressor map. Shows what a turbo torque plateau looks like vs. an NA torque hump. |
| `data/engines/kr20ddet.json` | Nissan KR20DDET, 2.0 L I4 VC-Turbo | Variable compression ratio (8:1 at high load, 14:1 at low load). Useful once you want to see the simulator switch CR mid-sweep. |

For your **first** run, use `ls3_egr.json`. It is the simplest of the three: no turbo, no VCR, a healthy NA torque curve, and the configuration file is short enough to skim later in this tutorial. Once you have an LS3 sweep on disk and have read it, come back and run the 2JZ-GTE for contrast. Save the KR20DDET for after you are comfortable with both.

## Step 3: Run the sweep

Run a full RPM sweep on the LS3 and write the result to a CSV:

```
./build/bin/piston run \
    --config configs/engines/ls3_egr.json \
    --output ls3_sweep.csv \
    --format csv
```

Notes on the invocation:

- The `--config` path is **relative to the directory you ran the command from**. If you `cd`'d to the repo root, the path above resolves; otherwise prefix it with the absolute path to the file.
- `--output` is the destination CSV. It will be created (or overwritten) in the current directory.
- `--format csv` is explicit; CSV is also the default, but writing it out makes the command unambiguous in scripts.

If you want to scope the sweep to a specific RPM band — for example, to skip idle and only look at the meat of the curve — add `--rpm-start` and `--rpm-end`:

```
./build/bin/piston simulate \
    --config configs/engines/ls3_egr.json \
    --rpm-start 2000 \
    --rpm-end 6500
```

Note that `simulate` here is the streaming variant: it prints one summary line per RPM to your terminal as the sweep progresses. Use it as a "watch the engine spin up" check; use `run` when you actually want a file.

By default `simulate` reports steady-state torque at each RPM (`--mode static`). `--mode time` instead runs the same time-based inertia-dyno pull as `piston run` and prints it at the same RPM steps; the two agree closely on a slow pull, and the pull always stops at the engine's redline.

A modern desktop CPU runs the full LS3 sweep in a few seconds. If it takes minutes, you are likely running an unoptimized debug build — rebuild with `--config Release`.

## Step 4: Read the results

Open `ls3_sweep.csv` in a spreadsheet, a text editor, or your scripting tool of choice. The CSV has one row per RPM and the columns documented in [quickstart.md § Exporting CSV](quickstart.md#exporting-csv):

| Column | Units | What it means |
|---|---|---|
| `rpm` | rev/min | Crank speed for this row. |
| `torque_nm` | N·m | Brake torque at the crank. Multiply by `0.7376` to convert to lb-ft. |
| `power_kw` | kW | Brake power at the crank. Multiply by `1.341` to convert to HP. |
| `bmep_bar` | bar | Brake mean effective pressure — torque normalized by displacement. A platform-independent way to compare engines. |
| `ve_percent` | % | Volumetric efficiency. How completely each cylinder fills with fresh charge. |
| `bsfc_g_per_kwh` | g/kWh | Brake-specific fuel consumption. Lower is better; a modern gasoline minimum is around 220 g/kWh. |

Trailing columns carry the SAE J1349 environmental-correction metadata — the temperature, pressure, and humidity used to normalize the run. See [`docs/physics/limitations.md`](../physics/limitations.md) for the corrections applied and their assumptions.

### What to expect for an LS3

A stock-tune LS3 produces somewhere around **400–450 HP** at peak power and **400–450 lb-ft** at peak torque, with peak torque arriving roughly 1500–2500 RPM below peak power. The exact number depends on the configuration's current state — the `combustion.efficiency`, `ignition_timing_btdc`, and intake-runner geometry in `ls3_egr.json` all push the answer up or down by tens of horsepower. **Treat the numbers as a sanity-check range, not a target.** If your sweep shows 50 HP or 1000 HP, something is wrong; if it shows 380 or 470, you are within the expected band.

The shape of the curve is the more reliable signal. For an NA V8 you should see:

- **Torque** rising smoothly from low RPM, peaking somewhere between 4000 and 5000 RPM, and falling off as the engine starts to choke on its own breathing at high RPM.
- **Power** continuing to climb past peak torque (because power = torque × RPM), peaking 1000–2000 RPM higher, and then falling once the torque drop-off outpaces the RPM gain.
- **VE** in the 85–105 % band across the meat of the curve — naturally aspirated engines with good intake design routinely break 100 % at the runner-tuned RPM.
- **BSFC** lowest near peak torque (best efficiency) and rising at both ends of the rev range.

If your VE column is reading 60 % or your BSFC is bottoming out at 150 g/kWh, double-check that you ran against the right config and that the build is a Release build — debug builds occasionally short-circuit numerical paths and give nonsense output.

For a deeper read of how each of these numbers is computed, see [physics_models.md](physics_models.md) (combustion and Otto cycle) and [simulation_workflow.md](simulation_workflow.md) (the per-stroke flow). The cross-cutting list of assumptions baked into the baseline cycle lives in [`docs/physics/limitations.md`](../physics/limitations.md).

For a column-by-column deep-dive on the CSV — sanity-check bands per column, curve shapes, peak-metric extraction, and the most common failure modes — see [interpreting_results.md](interpreting_results.md).

## Step 5: Compare a second engine

Now do the same sweep on the 2JZ-GTE so you have two CSVs side-by-side:

```
./build/bin/piston run \
    --config configs/engines/2jz_gte_egr.json \
    --output 2jz_sweep.csv \
    --format csv
```

Plot both `power_kw` and `torque_nm` against `rpm` for each engine in your spreadsheet. Three differences should jump out:

1. **Torque shape.** The LS3 has a clear hump — torque rises, peaks, falls. The 2JZ-GTE shows a much flatter **plateau**: once the turbos light, torque holds roughly constant across a wide RPM band before tailing off. That plateau is the signature of forced induction — boost compensates for the breathing falloff that limits an NA engine.
2. **VE > 100 %.** The 2JZ-GTE will sit well above 100 % VE through the boost band — frequently 130–180 %. That is not a bug. VE measures fresh charge mass against atmospheric-density displacement, and forced induction puts more than atmospheric pressure into the cylinder. NA engines top out near 105 % even with perfect runner tuning.
3. **BSFC penalty.** The 2JZ-GTE's BSFC will sit higher than the LS3's at peak power, even though the LS3 displaces twice as much. Turbos are efficient at making power but trade some fuel efficiency to do it — the lower compression ratio (8.5:1 vs. 10.7:1) is the main driver.

Save both CSVs. They are useful baselines for the experiments in [simulation_workflow.md](simulation_workflow.md).

## Step 6: Inspect the configuration file

Open [`configs/engines/ls3_egr.json`](../../configs/engines/ls3_egr.json) in your editor. Each top-level section maps to a piece of the simulator:

- **`geometry`** — bore, stroke, compression ratio, rod length, firing order. These feed the crank-slider kinematics ([`docs/physics/crank_slider_kinematics.md`](../physics/crank_slider_kinematics.md)) and the Otto-cycle volume curve ([`docs/physics/otto_cycle_assumptions.md`](../physics/otto_cycle_assumptions.md)). Changing `compression_ratio` will move the whole power curve up or down.
- **`valvetrain`** — valve diameters, cam duration, lobe separation angle, intake centerline. These set the breathing window. Bigger valves and longer duration push peak power up the RPM range at the cost of low-RPM torque.
- **`combustion`** — Wiebe form factors, burn duration, chamber shape, spark timing, EGR-aware tumble/swirl ratios. This is where flame-propagation behavior is parameterized; see [physics_models.md § Combustion Modeling](physics_models.md#combustion-modeling).
- **`fuel`** — type, lower heating value, stoichiometric ratio. Changing fuel changes the energy released per unit mass of charge, which moves both power and BSFC.
- **`intake_manifold`** — runner length, runner diameter, plenum volume. Drives the resonance/Helmholtz tuning that gives the VE curve its characteristic peak.
- **`egr`** — fixed/maximum EGR rate and cooler effectiveness. Reduces NOx at the cost of a small power hit and a meaningful BSFC change.
- **`operating_limits`** — idle RPM, redline RPM, max intake pressure, max coolant temp. Sweeps default to ending at `redline_rpm` when `--rpm-end` is not given; an explicit `--rpm-end` is honoured as given. Raise the redline if the engine really revs higher (and accept that the simulator will let you ask physically unreasonable questions if you do).

For a guided tour of how each section feeds the simulation pipeline, read [simulation_workflow.md](simulation_workflow.md) next. For the physics behind each model, [physics_models.md](physics_models.md) is the canonical reference.

A final note before you start editing: every model in PISTON has limits, and exceeding them silently produces wrong numbers rather than an error. Before drawing strong conclusions from a swept-parameter study, check [`docs/physics/limitations.md`](../physics/limitations.md) for the assumptions baked into the baseline cycle (ideal gas, adiabatic walls in the Otto baseline, empirical Chen–Flynn friction, no transient turbo lag, etc.).

## Common issues

- **`piston: command not found` or "no such file or directory."** Your build did not produce the binary at `build/bin/`. Re-read [building.md](../development/building.md), confirm `cmake --build build --config Release` exited cleanly, and look in `build/bin/` and `build/bin/Release/` for the executable.
- **"Could not open configuration file."** The `--config` path is relative to your current shell directory, not to the binary. `cd` into the repo root first, or pass an absolute path.
- **Numbers look wildly wrong (10× too high, 10× too low, or NaN).** First, confirm you are running a Release build — debug builds occasionally give nonsense for performance-critical paths. Second, check that the configuration loaded the engine you think it did (the CLI prints the engine name on startup). Third, see [`docs/physics/limitations.md`](../physics/limitations.md): some configurations push past the validated envelope, and the simulator does not always warn before extrapolating.
- **The sweep ends at the redline.** With no `--rpm-end`, every sweep defaults to `operating_limits.redline_rpm`. An explicit `--rpm-end` is honoured as given on `simulate`, `report` and `optimize`; `piston run`'s physical pull always stops at the redline regardless.

For a longer, symptom-indexed walk through these and other failure modes — JSON parse errors, `Export failed`, `Simulation failed:` exceptions, the parts-CLI TODO stubs, and the build/launch shape of each — see [troubleshooting.md](troubleshooting.md).

## Next steps

You have a sweep on disk, you have read the curves, and you know which knobs in the JSON push them around. From here, the natural reading order is:

- **[Parts Selection](parts_selection.md)** — the parts-database route to a configuration: browse the SQLite catalog, run the compatibility checker, and derive the JSON geometry section from a parts pick instead of editing it by hand.
- **[Simulation Workflow](simulation_workflow.md)** — the per-stroke walk through the simulator, plus the recommended day-to-day workflow for parameter studies.
- **[Physics Models](physics_models.md)** — what each model does (Wiebe combustion, Otto cycle, Chen–Flynn friction, SAE J1349 correction) and the assumptions it carries.
- **[Dyno Simulation](dyno_simulation.md)** — inertia and brake dyno modes in detail; relevant if you want to compare PISTON output against a real dyno trace.
- **[Known Limitations](../physics/limitations.md)** — the cross-cutting index of simulation simplifications and unsupported configurations. Read this before publishing any number from PISTON as a quantitative claim.

When the GUI ships the panels referenced in [quickstart.md](quickstart.md), the workflow above moves into the result viewer — but the configuration files and the CSV format stay the same, so any work you do here will keep paying off.
