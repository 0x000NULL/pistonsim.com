# Simulation Workflow Guide

This guide explains the step-by-step process PISTON uses to simulate engine performance, helping you understand what happens behind the scenes and how to optimize your configurations for accurate results.

## Simulation Overview

PISTON uses a **physics-based approach** that models the actual thermodynamic processes occurring inside your engine. Unlike simple lookup tables or empirical formulas, PISTON calculates:

1. **Intake Process**: Air/fuel mixture entering cylinders
2. **Compression**: Heating and pressurizing the charge
3. **Combustion**: Heat release and pressure rise
4. **Expansion**: Power extraction from hot gases
5. **Exhaust**: Expelling burned gases
6. **Mechanical Losses**: Friction, pumping, and accessory loads

## The Four-Stroke Cycle Simulation

### Intake Stroke (0-180° crankshaft rotation)

**What PISTON calculates:**
- **Valve Timing**: When intake valves open/close based on cam profile
- **Mass Flow Rate**: Air entering through intake valves using compressible flow equations
- **Volumetric Efficiency**: How much air actually enters vs. theoretical maximum
- **Manifold Dynamics**: Pressure waves and runner tuning effects
- **Throttle Restriction**: Mass flow limitation from throttle position

**Physics Models Used:**
- **Orifice Flow**: ṁ = Cd × A × ρ × √(2ΔP/ρ) for valve flow
- **Helmholtz Resonance**: Runner tuning effects on VE
- **Gas Dynamics**: Pressure wave propagation in intake system

**Key Factors:**
- Intake valve size and timing
- Port flow characteristics
- Intake manifold design
- Atmospheric conditions
- Engine RPM (affects flow velocity)

### Compression Stroke (180-360°)

**What PISTON calculates:**
- **Pressure Rise**: Using ideal gas law with temperature compensation
- **Heat Transfer**: Energy loss to cylinder walls (Woschni correlation)
- **Piston Motion**: Exact position, velocity, acceleration from slider-crank kinematics
- **Compression Work**: Energy required to compress the charge

**Physics Models Used:**
- **Ideal Gas Law**: PV = nRT (corrected for real gas effects)
- **Isentropic Relations**: P₂/P₁ = (V₁/V₂)^γ for compression
- **Heat Transfer**: Q = hA(T_gas - T_wall) using Woschni correlation
- **Geometry**: Exact piston motion from connecting rod kinematics

**Key Factors:**
- Compression ratio (bore, stroke, combustion chamber volume)
- Heat transfer coefficient (RPM dependent)
- Gas properties (specific heats, molecular weight)
- Piston crown and combustion chamber shape

### Combustion (Power Stroke 360-540°)

**What PISTON calculates:**
- **Heat Release Rate**: Using Wiebe function for realistic burn profile
- **Pressure Rise**: From chemical energy release
- **Temperature Distribution**: Two-zone model (burned vs. unburned gas)
- **Flame Propagation**: Burn rate based on mixture motion and composition

**Physics Models Used:**
- **Wiebe Function**: dxb/dθ = (m+1)(θ/Δθ)^m × exp(-a(θ/Δθ)^(m+1))
- **Two-Zone Model**: Separate burned and unburned gas zones
- **Chemical Energy**: Heat of combustion from fuel properties
- **Flame Speed**: Based on mixture strength and turbulence

**Key Factors:**
- Ignition timing
- Burn duration (cam timing, mixture motion, combustion chamber shape)
- Air/fuel ratio
- Fuel octane rating and properties
- Combustion chamber turbulence

### Exhaust Stroke (540-720°)

**What PISTON calculates:**
- **Blowdown Process**: High-pressure gas escaping when exhaust valve opens
- **Pumping Work**: Energy required to push exhaust gases out
- **Scavenging Effects**: Exhaust pulses helping empty cylinders
- **Back Pressure**: Restriction from exhaust system

**Physics Models Used:**
- **Compressible Flow**: Choked flow through exhaust valves
- **Exhaust System**: Primary tube length effects, collector design
- **Wave Dynamics**: Exhaust pulse timing and reflection
- **Pumping Mean Effective Pressure**: PMEP calculation

**Key Factors:**
- Exhaust valve timing and size
- Header primary tube length
- Exhaust back pressure
- Valve overlap duration
- Exhaust gas temperature

## Mechanical System Simulation

### Connecting Rod and Crankshaft Forces

**Slider-Crank Kinematics:**
- Piston position: x = r(1 - cos θ) + l(1 - √(1 - (r/l sin θ)²))
- Piston velocity: v = rω(sin θ + r sin 2θ/(2l√(1-(r sin θ/l)²)))
- Piston acceleration: a = rω²(cos θ + r cos 2θ/l + r³ sin² θ cos 2θ/(l³(1-(r sin θ/l)²)^1.5))

**Force Analysis:**
- Gas force on piston crown
- Inertia forces from reciprocating mass
- Rod angle and side thrust forces
- Crankshaft torque calculation

### Friction Modeling (Chen-Flynn Model)

PISTON uses the advanced Chen-Flynn friction model, which accounts for:

**Piston Assembly Friction:**
- Ring tension and contact pressure
- Oil film thickness effects
- Piston skirt friction
- Temperature dependencies

**Valvetrain Friction:**
- Cam follower friction
- Valve spring work
- Rocker arm losses

**Bearing Friction:**
- Main bearings (journal bearing theory)
- Rod bearings
- Oil viscosity effects

**Accessories:**
- Water pump
- Alternator
- Power steering
- Air conditioning

## Breathing System Integration

### Intake System Modeling

**Throttle Body:**
- Butterfly valve flow restriction
- Discharge coefficient vs. angle
- Sonic choking at high pressure ratios
- Manifold pressure calculation

**Intake Manifold:**
- Plenum volume effects
- Runner length tuning (Helmholtz resonance)
- Runner taper and cross-sectional area
- Distribution between cylinders

**Port Flow:**
- Discharge coefficient from flow bench data
- Valve lift-dependent flow characteristics
- Swirl and tumble generation
- Port velocity effects

### Exhaust System Modeling

**Primary Tubes:**
- Length optimization for scavenging
- Diameter effects on velocity
- Heat transfer and temperature drop
- Friction pressure losses

**Collectors:**
- Merge losses at tube junctions
- Pulse merging effects
- Back pressure generation
- Collector volume optimization

**Scavenging Effects:**
- Negative pressure wave reflection
- Optimal timing for valve overlap
- Multi-cylinder pulse interaction
- RPM-dependent tuning

## Environmental and Operating Conditions

### Atmospheric Corrections

PISTON applies standard corrections for fair comparison:

**SAE J1349 (Standard):**
- Reference: 99 kPa, 25°C, 0% humidity
- Correction factor accounts for air density
- Most common in North America

**DIN 70020 (European):**
- Reference: 99 kPa, 20°C, 65% humidity
- Slightly different from SAE
- Common in European markets

**Calculation:**
CF = √(99/P) × √(T+273)/298) × (1-0.18×H)
Where P=pressure (kPa), T=temperature (°C), H=humidity (fraction)

### Altitude Effects

**Air Density Changes:**
- Density decreases ~12% per 1000m altitude
- Naturally aspirated engines lose ~3% power per 1000 feet
- Turbocharged engines less affected due to boost compensation

**Temperature Effects:**
- Colder air is denser (more power)
- Hotter air reduces density and increases knock tendency
- Intake air temperature critical for accurate simulation

## Simulation Modes

### Static Mode (Point Calculation)

- Calculates performance at specific RPM points
- Fastest computation method
- Assumes steady-state conditions
- Good for power curve generation

**Use When:**
- Creating dyno curves
- Comparing different configurations
- Initial performance estimates
- Parameter sensitivity studies

### Time-Based Mode (Dynamic Simulation)

- Calculates full engine dynamics over time
- Includes transient effects
- Models real acceleration/deceleration
- More computationally intensive

**Use When:**
- Analyzing engine response
- Studying transient behavior
- Validating against time-based dyno data
- Investigating cycle-to-cycle variations

## Accuracy and Validation

### Expected Accuracy Levels

**Phase 1 Target**: <20% RMSE (proof of concept)
**Phase 2 Target**: <15% RMSE (enhanced prototype)  
**Phase 3 Target**: <10% RMSE for 80% of configurations (MVP)
**Long-term Goal**: <7% RMSE (professional grade)

### Sources of Error

**Model Limitations:**
- Simplified combustion model (real engines have complex flame propagation)
- Quasi-steady flow assumptions (real flow is highly unsteady)
- Perfect gas assumptions (real gases have property variations)
- Manufacturing tolerances not modeled

**Input Uncertainties:**
- Component specifications may not match database
- Port flow data interpolation errors
- Cam timing measurement accuracy
- Compression ratio assumptions

**Environmental Factors:**
- Fuel quality variations
- Temperature stratification
- Humidity effects on combustion
- Barometric pressure changes

### Improving Accuracy

**Better Component Data:**
- Flow bench test your cylinder heads
- Measure actual compression ratio
- Verify cam timing with degree wheel
- Use actual fuel properties

**Environmental Measurements:**
- Record ambient temperature, pressure, humidity
- Account for altitude effects
- Consider fuel temperature and density
- Measure intake air temperature

**Calibration:**
- Compare with known dyno results
- Adjust model parameters if systematic errors exist
- Validate against multiple engine configurations
- Use statistical analysis to identify trends

## Troubleshooting Common Issues

### Unrealistic Power Numbers

**Too High:**
- Check compression ratio (may be unrealistic)
- Verify volumetric efficiency isn't over 100% (for NA engines)
- Ensure friction model is enabled
- Check fuel energy content

**Too Low:**
- Verify all components are compatible
- Check for flow restrictions (heads, intake, exhaust)
- Ensure cam timing is realistic
- Verify no input errors in displacement, etc.

### Strange Curve Shapes

**Flat Power Curve:**
- May indicate breathing restriction
- Check valve lift and timing
- Verify intake/exhaust flow balance
- Look for resonance tuning issues

**Power Drop at High RPM:**
- Valvetrain friction increasing
- Breathing becoming restricted
- Combustion efficiency decreasing
- Check valve float limits

### Convergence Problems

**Simulation Won't Complete:**
- Reduce RPM step size
- Check for invalid input parameters
- Verify component compatibility
- Try different initial conditions

**Oscillating Results:**
- Numerical stability issue
- Reduce time step (for time-based mode)
- Check for unrealistic parameter values
- Verify model equations are properly conditioned

## Advanced Features

### Multi-Configuration Comparison

- Compare different builds side-by-side
- Overlay multiple dyno curves
- Export comparison reports

### Sensitivity Analysis

- Vary one parameter while holding others constant
- Identify most critical design factors
- Optimize component selection
- Understand parameter interactions

## Best Practices

### Configuration Setup

1. **Start Simple**: Begin with known, validated configurations
2. **One Change at a Time**: Modify single components to understand effects
3. **Verify Compatibility**: Ensure all parts work together physically
4. **Document Assumptions**: Note any estimated or assumed values
5. **Cross-Check Results**: Compare with similar known builds

### Result Interpretation

1. **Look at Curve Shape**: Smooth curves indicate good component matching
2. **Check Physical Reasonableness**: Results should make engineering sense
3. **Compare to Similar Engines**: Validate against comparable builds
4. **Consider Manufacturing Tolerances**: Real engines vary from nominal specs
5. **Account for Unknowns**: Some factors (like mixture motion) are estimated

### Validation Process

1. **Use Known Good Data**: Start with validated reference engines
2. **Document Differences**: Note any deviations from expected results
3. **Systematic Testing**: Vary parameters methodically
4. **Statistical Analysis**: Look for patterns in errors
5. **Iterative Improvement**: Refine models based on validation results

This workflow ensures you get the most accurate and useful results from PISTON's advanced engine simulation capabilities.