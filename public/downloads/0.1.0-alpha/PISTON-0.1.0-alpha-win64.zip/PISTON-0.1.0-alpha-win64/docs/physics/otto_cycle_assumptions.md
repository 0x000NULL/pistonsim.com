# Otto Cycle Model - Assumptions and Limitations

**Document Version:** 1.0
**Last Updated:** Phase 1 Implementation
**Model Status:** Simplified thermodynamic model for validation baseline

---

## Executive Summary

The Otto Cycle implementation in PISTON is a **simplified thermodynamic model** designed for Phase 1 validation and proof-of-concept. It provides a baseline for testing infrastructure and establishing validation methodology before implementing more sophisticated models (Wiebe combustion, Woschni heat transfer) in Phase 2.

**Key Characteristics:**
- ✅ Thermodynamically consistent (follows first law and ideal gas law)
- ✅ Computationally fast (suitable for 1000 Hz simulation loop)
- ✅ Predictable and testable (deterministic results)
- ❌ Simplified combustion (instantaneous vs. finite burn duration)
- ❌ No heat transfer (adiabatic assumption vs. reality)
- ❌ Indicated power only (no friction losses modeled)

---

## Fundamental Assumptions

### 1. Ideal Gas Behavior

**Assumption:** Air behaves as an ideal gas with constant properties.

**Mathematical Form:**
```
PV = mRT
```

**Constants Used:**
- Gas constant: `R = 287.05 J/(kg·K)` for air
- Specific heat ratio: `γ = 1.4` (constant)
- Specific heats: `cp = 1005 J/(kg·K)`, `cv = 718 J/(kg·K)` (constant)

**Reality:**
- Specific heats vary with temperature (increase at high temperatures)
- γ changes from ~1.4 at intake to ~1.3 at peak combustion temperatures
- Dissociation occurs at very high temperatures (>2500K)

**Impact on Accuracy:**
- Underestimates peak pressure by 5-10% (real γ lower at high temps)
- Affects thermal efficiency calculation by 1-2%

**Improvement Path (Phase 2+):**
- Implement temperature-dependent specific heats: `cp(T)`, `cv(T)`
- Use real gas properties or polynomial fits from JANAF tables
- Model dissociation for high compression ratios (CR > 12:1)

---

### 2. Isentropic Compression and Expansion

**Assumption:** Compression and expansion are isentropic (adiabatic + reversible).

**Mathematical Form:**
```
P₂/P₁ = (V₁/V₂)^γ
T₂/T₁ = (V₁/V₂)^(γ-1)
```

**Reality:**
- Heat transfer occurs during compression/expansion (not adiabatic)
- Irreversibilities from turbulence, friction (not reversible)
- Woschni correlation shows ~10-30% heat loss during expansion

**Impact on Accuracy:**
- Overestimates expansion work by 10-15% (no heat loss)
- Overestimates exhaust gas temperature
- Affects IMEP calculation

**Improvement Path (Phase 2):**
- Implement Woschni heat transfer correlation
- Model heat flux: `q = hA(T_gas - T_wall)`
- Account for cylinder wall temperature (~400K) vs. gas peak (>2000K)

---

### 3. Instantaneous Combustion at TDC

**Assumption:** Heat addition occurs instantaneously at top dead center (constant volume).

**Mathematical Form:**
```
Q_added = m_fuel × LHV × η_combustion
T_after = T_before + Q/(m × cv)
P_after = P_before × (T_after / T_before)  [at constant volume]
```

**Combustion Efficiency:**
- Currently: `η_combustion = 0.95` (fixed)
- Reality: Varies with AFR, turbulence, residual gas fraction

**Reality:**
- Combustion takes 40-60° crank angle (10-90% mass fraction burned)
- Burn rate follows Wiebe function, not instantaneous
- Peak pressure occurs 10-15° after TDC (not at TDC)
- Slower combustion → lower peak pressure → lower thermal efficiency

**Impact on Accuracy:**
- Overestimates peak pressure by 15-20%
- Peak pressure occurs at wrong crank angle (0° vs. 12° ATDC)
- Affects power/torque calculation significantly

**Improvement Path (Phase 2 - CRITICAL):**
- Implement Wiebe function: `x_b = 1 - exp(-a(θ/θ_d)^(m+1))`
- Parameters: `a = 5`, `m = 2` (typical for gasoline)
- Burn duration: 50-60° crank angle
- Model flame development and propagation phases

---

### 4. Perfect Gas Exchange (No Residual Gas)

**Assumption:** Complete scavenging of exhaust gas, fresh charge only.

**Mathematical Form:**
```
m_fresh = ρ_intake × V_swept × VE
(No residual mass carried over from previous cycle)
```

**Reality:**
- Residual gas fraction: 5-15% of total mass
- Residual gas dilutes fresh charge
- Reduces peak temperature and pressure
- Affects combustion speed and stability

**Impact on Accuracy:**
- Overestimates charge mass by 5-15%
- Overestimates power output proportionally
- Ignores EGR effects (important for emissions)

**Improvement Path (Phase 3+):**
- Model residual gas fraction: `f_residual = P_exhaust / P_intake × V_clearance / V_total`
- Account for charge dilution in combustion
- Important for overlap timing effects

---

### 5. Constant-Pressure Intake and Exhaust

**Assumption:** Intake and exhaust occur at constant pressure.

**Mathematical Form:**
```
P_intake = P_ambient (typically 101325 Pa)
P_exhaust = P_ambient
```

**Reality:**
- Intake manifold has vacuum (-20 to -60 kPa at part throttle)
- Exhaust backpressure (+5 to +30 kPa depending on system)
- Valve timing creates dynamic pressure waves
- Ram effect at high RPM can increase intake pressure

**Impact on Accuracy:**
- Ignores pumping losses (negative work during gas exchange)
- Overestimates volumetric efficiency
- Critical for part-throttle operation modeling

**Improvement Path (Phase 2+):**
- Model intake manifold pressure vs. throttle position
- Account for exhaust backpressure
- Calculate pumping mean effective pressure (PMEP)
- BMEP = IMEP - FMEP - PMEP

---

### 6. No Heat Transfer to Cylinder Walls

**Assumption:** Adiabatic cylinder walls (no heat loss).

**Reality:**
- Cylinder walls at ~400K, gas reaches >2000K
- Heat flux proportional to temperature difference
- Woschni correlation: `h ∝ P^0.8 × T^(-0.55) × v^0.8`
- Typical heat loss: 20-30% of fuel energy

**Impact on Accuracy:**
- Overestimates expansion work
- Overestimates thermal efficiency by 10-15%
- Major contributor to error in power prediction

**Improvement Path (Phase 2 - CRITICAL):**
- Implement Woschni heat transfer coefficient
- Model cylinder wall temperature distribution
- Account for coolant temperature effects
- This is the single most important improvement for Phase 2

---

### 7. Single-Cylinder Model (No Multi-Cylinder Effects)

**Assumption:** Each cylinder operates independently.

**Current Implementation:**
- Total power = Per-cylinder power × Number of cylinders

**Reality:**
- Intake manifold dynamics couple cylinders
- Exhaust pulse interactions
- Torsional vibration in crankshaft
- Overlap between cylinders affects scavenging

**Impact on Accuracy:**
- Reasonable for total power/torque calculation
- Misses cylinder-to-cylinder variations
- Ignores intake runner tuning effects

**Improvement Path (Phase 3+):**
- Model intake plenum and runner dynamics
- Couple cylinders through manifold pressure
- Account for firing order effects on scavenging

---

### 8. Indicated Power Only (No Friction)

**Assumption:** Calculated power is indicated power (pressure-volume work).

**Mathematical Form:**
```
IMEP = W_indicated / V_swept
P_indicated = IMEP × V_d × (RPM / 120) × n_cylinders  [for 4-stroke]
```

**Reality:**
- Brake power (at crankshaft) = Indicated power - Friction losses
- Friction includes: piston rings, bearings, valvetrain, oil pump, accessories
- Friction mean effective pressure (FMEP): 0.5-2.5 bar typical

**Impact on Accuracy:**
- Overestimates actual engine output by 15-25%
- Critical for comparison to dyno measurements (which measure brake power)

**Improvement Path (Phase 1 validation - immediate need):**
- Apply simplified friction factor: `Brake power = Indicated power × 0.85`
- Phase 2: Implement Chen-Flynn friction model
- FMEP = C1 + C2 × S_p + C3 × S_p^2 + C4 × P_peak

---

### 9. No Valve Timing Effects

**Assumption:** Valves open/close instantaneously at ideal timing.

**Current Implementation:**
- Intake: 0-180° (simplified)
- Compression: 180-360°
- Power/expansion: 360-540°
- Exhaust: 540-720°

**Reality:**
- Cam profiles create gradual valve opening (lift curve)
- Overlap period (both intake and exhaust open)
- Variable valve timing (VVT) changes events dynamically
- Valve float at high RPM

**Impact on Accuracy:**
- Simplified VE model compensates partially
- Misses dynamic effects at high RPM
- Cannot model cam swap effects accurately

**Improvement Path (Phase 2):**
- Integrate actual cam profile data (lift vs. angle)
- Model valve flow area vs. lift
- Account for overlap effects on residual gas

---

### 10. Simplified Volumetric Efficiency

**Assumption:** Air mass intake is estimated, not calculated from first principles.

**Current Implementation:**
```
m_air = ρ_intake × V_swept × VE_assumed
VE_assumed = 0.85 (fixed)
```

**Reality:**
- VE varies with RPM (wave dynamics, valve timing)
- VE varies with throttle position
- Peak VE at resonant RPM (runner tuning)
- Typical VE: 70-95% depending on design

**Impact on Accuracy:**
- Major source of error in air mass calculation
- Affects fuel mass, combustion energy, power output
- Cannot predict VE curve shape vs. RPM

**Improvement Path (Phase 2):**
- Model intake runner dynamics (1D gas dynamics)
- Calculate flow restriction through valves
- Account for ram effect, resonance
- Generate VE vs. RPM curve from first principles

---

## Limitations Summary

### What This Model **CAN** Do:

✅ **Calculate thermodynamic efficiency** accurately for given compression ratio
✅ **Demonstrate pressure-volume cycle** and verify thermodynamic laws
✅ **Provide baseline** for validation infrastructure
✅ **Test at boundary conditions** (various CR, bore/stroke, RPM)
✅ **Validate software architecture** before adding complexity
✅ **Estimate relative performance** (comparing similar engines)

### What This Model **CANNOT** Do:

❌ **Predict absolute power/torque** with <10% accuracy (Phase 1 target: <20%)
❌ **Model cam timing effects** (cannot predict cam swap results)
❌ **Account for intake/exhaust tuning** (runner length, header design)
❌ **Simulate part-throttle operation** accurately (no pumping losses)
❌ **Predict knock tendency** (no temperature/pressure history)
❌ **Model forced induction** (Phase 1 is NA only)
❌ **Estimate emissions** (no combustion chemistry)

---

## Expected Accuracy vs. Real Dyno Data

### Phase 1 Targets

**Best Case Scenario:**
- Well-documented stock NA engine (LS3, K20, etc.)
- Simple geometry (no exotic valve timing)
- Full-load operation (WOT)
- **Expected error: 15-25%** (indicated power)
- **After friction correction: <20%** (brake power)

**Worst Case Scenario:**
- Complex engine (VVT, high overlap cams)
- Part-load operation
- High compression ratio (>12:1)
- **Expected error: 30-40%**

**Primary Error Sources (ranked):**
1. **Heat transfer neglected** (~30% contribution to error)
2. **Instantaneous combustion** (~25% contribution)
3. **No friction model** (~20% contribution)
4. **Simplified VE** (~15% contribution)
5. **Ideal gas assumptions** (~10% contribution)

### Validation Strategy

**Acceptance Criteria:**
- **Phase 1:** RMSE < 20% for stock NA engines
- **Phase 2:** RMSE < 15% after Wiebe + Woschni
- **Phase 3:** RMSE < 10% (MVP target)
- **Phase 5:** RMSE < 7% (professional-grade target)

---

## Documented Test Cases

### Theoretical Validation (Textbook Examples)

All theoretical validation tests pass with <0.01% error:

1. **Thermal efficiency** matches Otto cycle formula: `η = 1 - 1/CR^(γ-1)`
2. **Isentropic relations** hold during compression/expansion
3. **Ideal gas law** (PV = mRT) consistent throughout cycle
4. **Displacement calculations** match standard formulas
5. **Boundary conditions** (CR 6:1 to 15:1, RPM 1000-7000) valid

**Test Results:** 58/58 assertions pass

**Reference:** `tests/core/engine/thermodynamics/test_OttoCycle.cpp`

### Real-World Validation (Dyno Data)

**Status:** Phase 1 in progress

**Validation Data Available:**
- LS3 stock (placeholder - needs real data)
- Target: 430 HP @ 5900 RPM, 424 lb-ft @ 4600 RPM

**Validation Test:** `tests/validation/test_OttoCycleValidation.cpp` (to be created)

---

## Phase 2 Improvement Roadmap

### Critical Improvements (Required for <15% accuracy)

1. **Wiebe Combustion Function** (Highest Priority)
   - Replace instantaneous combustion
   - Model burn duration: 50-60° crank angle
   - Expected improvement: 10-15% reduction in error

2. **Woschni Heat Transfer** (Highest Priority)
   - Add heat loss during expansion
   - Model temperature-dependent heat flux
   - Expected improvement: 10-12% reduction in error

3. **Friction Model Integration** (High Priority)
   - Chen-Flynn FMEP model
   - Convert indicated to brake power
   - Expected improvement: 5-10% reduction in error

### Secondary Improvements (Phase 3+)

4. **Volumetric Efficiency Model**
   - 1D gas dynamics or simplified wave model
   - Generate VE vs. RPM curve
   - Expected improvement: 3-5% reduction in error

5. **Residual Gas Fraction**
   - Model incomplete scavenging
   - Important for high overlap cams

6. **Pumping Losses**
   - Model intake manifold vacuum
   - Critical for part-throttle accuracy

---

## References

### Primary Sources

1. **Heywood, J. B. (1988).** *Internal Combustion Engine Fundamentals*. McGraw-Hill.
   - Chapter 5: Ideal Models of Engine Cycles
   - Chapter 9: Combustion in Spark-Ignition Engines

2. **Ferguson, C. R., & Kirkpatrick, A. T. (2015).** *Internal Combustion Engines: Applied Thermosciences* (3rd ed.).
   - Chapter 4: Thermodynamic Analysis of Ideal Models
   - Chapter 7: Burn Rate and Flamefront Analysis

3. **Stone, R. (2012).** *Introduction to Internal Combustion Engines* (4th ed.).
   - Chapter 2: Thermodynamic Principles
   - Chapter 3: Combustion and Fuels

### Validation Methodology

4. **SAE J1349** - Engine Power Test Code - Spark Ignition and Compression Ignition
5. **SAE J1995** - Engine Power Test Code - Gross Power Rating
6. **GT-POWER** documentation (Gamma Technologies) - Industry standard for comparison

---

## Appendix: Code Location Reference

### Implementation Files

- **Header:** `src/core/engine/thermodynamics/OttoCycle.h`
- **Implementation:** `src/core/engine/thermodynamics/OttoCycle.cpp`
- **Supporting Classes:**
  - `GasState.h` - Thermodynamic state (P, T, ρ, m, V)
  - `GasProperties.h` - Ideal gas calculations
  - `EngineGeometry.h` - Volume calculations
  - `CycleState.h` - Four-stroke phase enumeration

### Test Files

- **Unit Tests:** `tests/core/engine/thermodynamics/test_OttoCycle.cpp`
- **Validation Tests:** `tests/validation/test_ValidationHarness.cpp`
- **End-to-End:** `tests/validation/test_OttoCycleValidation.cpp` (Phase 1)

### Documentation

- **Architecture:** `architecture.md` - System design overview
- **Backlog:** `TODO.md` - open work, by permanent item id
- **This Document:** `docs/physics/otto_cycle_assumptions.md`

---

**This document will be updated as the model evolves through Phases 2-5.**

*Last Updated: Phase 1*
*Next Review: After Phase 2 Implementation (Wiebe + Woschni)*
