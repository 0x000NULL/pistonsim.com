# PISTON Thermodynamic Models — Reference

This page is the developer-oriented entry point to PISTON's in-cylinder thermodynamics. It maps each implemented model to its governing equations and to the source headers where those equations live, and points at the existing companion docs rather than re-deriving content already documented there.

## Scope and how to read this page

PISTON ships several layers of in-cylinder thermodynamics:

- The **production path** is the **detailed cycle** (`DetailedCycleSimulation`): Wiebe combustion + Woschni heat transfer + variable gamma + integrated VE. This is what `piston simulate`/`run` execute (the `DynoEngineAdapter` default is now `useDetailedCycle=true`, ULTRAPLAN P2-1) and what the reproducible accuracy report covers — see [`../validation/accuracy.generated.md`](../validation/accuracy.generated.md), which `tools/validate_all.cpp` generates and CI gates on every push. Companion assumptions: [`otto_cycle_assumptions.md`](otto_cycle_assumptions.md).
- The **analytical Otto cycle** (`src/core/engine/thermodynamics/OttoCycle.h`, selected by passing `useDetailedCycle=false`) is retained ONLY as a labeled dev-only comparison; it overpredicts and is never a user default (decision D3).
- The **two-zone burned/unburned solver** (`TwoZoneSolver`) is implemented but **not enabled even in the production detailed path** (`DetailedCycleSimulation::useTwoZone` defaults `false`): it is implemented-not-validated, and enabling it would require re-validating the accuracy bands. The NASA-polynomial mixture properties and the knock integral are likewise opt-in and not part of the validated configuration.

This document is a reference, not a tutorial. For the user-facing view (which model PISTON picks at runtime, what knobs are exposed in the JSON), see [`../user_guide/physics_models.md`](../user_guide/physics_models.md). For the textbook citations behind each correlation, see [`references.md`](references.md).

ASCII math is used throughout (`γ`, `θ`, `Δθ`, `^`, `·`) to match the style already used in the sibling physics docs.

---

## 1. Otto-cycle baseline

The analytical Otto cycle in `OttoCycle.h` divides each four-stroke cycle into four 180° crank-angle windows:

| Stroke | Crank angle | Method | Behavior |
| --- | --- | --- | --- |
| Intake | 0–180° | `intakeStroke` | Constant-pressure fill at intake-manifold conditions |
| Compression | 180–360° | `compressionStroke` | Isentropic compression to TDC |
| Power | 360–540° | `powerStroke` | Constant-volume heat addition at TDC, then isentropic expansion |
| Exhaust | 540–720° | `exhaustStroke` | Constant-pressure blowdown |

### Governing equations

Ideal-gas state:

```
P · V = m · R · T
```

Isentropic compression / expansion (no heat transfer, reversible):

```
P₂ / P₁ = (V₁ / V₂)^γ
T₂ / T₁ = (V₁ / V₂)^(γ − 1)
```

Constant-volume heat addition at TDC (instantaneous combustion; replaces a finite burn):

```
Q     = m_fuel · LHV · η_combustion
T₂    = T₁ + Q / (m · cv)
P₂    = P₁ · (T₂ / T₁)
```

These are implemented in `OttoCycle::compressionStroke`, `OttoCycle::powerStroke`, and `OttoCycle::applyCombustion`.

### Constants used

The analytical Otto path uses the following hard-wired constants, matching the values stored in `OttoCycle`'s member variables:

| Symbol | Value | Meaning |
| --- | --- | --- |
| `R` | 287.05 J/(kg·K) | Specific gas constant for air |
| `γ` | 1.4 | Specific heat ratio (constant) |
| `cp` | 1005 J/(kg·K) | Specific heat at constant pressure |
| `cv` | 718 J/(kg·K) | Specific heat at constant volume |
| `η_combustion` | 0.95 | Combustion completeness |

Real-gas / temperature-dependent specific heats are *not* used on this path — see §6 for the optional `NASAPolynomials` / `MixtureProperties` machinery.

### Cycle-level outputs

From the integrated P–V loop, the analytical Otto path produces:

```
η_thermal = 1 − 1 / CR^(γ − 1)            // calculateThermalEfficiency
W_net     = ∮ P dV                        // calculateNetWork (trapezoidal, 1° step)
IMEP      = W_net / V_swept               // calculateIMEP
T_ind     = IMEP · V_d / (4π)             // calculateIndicatedTorque (4-stroke)
P_ind     = T_ind · ω = T_ind · 2π · RPM / 60   // calculateIndicatedPower
```

`calculateBrakeTorque` / `calculateBrakePower` then subtract Chen–Flynn FMEP (see [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md)) and PMEP.

For the full assumption list (ideal-gas behavior, perfect scavenging, single-zone treatment, indicated-power-only framing, etc.) see [`otto_cycle_assumptions.md`](otto_cycle_assumptions.md). The simplifications are not duplicated here.

---

## 2. Wiebe function — finite-duration burn

The Wiebe function replaces the Otto baseline's instantaneous constant-volume combustion with a progressive burn that releases heat over a finite crank-angle window. The implementation is in `WiebeFunction.h` (the analytical primitive) and `WiebeBurnRate.h` (per-step burn-rate consumer), integrated into the production detailed path in `DetailedCycleSimulation.h`.

### Mass fraction burned

```
x_b(θ) = 1 − exp( −a · ((θ − θ_s) / Δθ)^(m + 1) )
```

where:

| Symbol | Meaning |
| --- | --- |
| `θ` | Current crank angle (deg) |
| `θ_s` | Start of combustion (deg; ignition timing, BTDC negative) |
| `Δθ` | Burn duration (10–90 % MFB, deg) |
| `a` | Efficiency parameter (controls completeness; `a = 5` → 99.3 % at `θ_s + Δθ`) |
| `m` | Form parameter (controls early-vs-late skew of the burn) |

### Burn rate and heat-release rate

Differentiating the mass-fraction-burned expression gives the burn rate:

```
dx_b/dθ = (a · (m + 1) / Δθ) · x^m · exp(−a · x^(m + 1))
                                        with x = (θ − θ_s) / Δθ
```

Multiplying by total chemical energy gives the heat-release rate that downstream pressure / temperature integrators consume:

```
dQ/dθ = (dx_b/dθ) · Q_total      where Q_total = m_fuel · LHV
```

Both are implemented inline in `WiebeFunction::burnRate` and `WiebeFunction::heatReleaseRate`.

### Default parameters

The factory functions in `WiebeFunction.h` carry these defaults:

| Fuel | `a` | `m` | `Δθ` | Source |
| --- | --- | --- | --- | --- |
| Gasoline | 5.0 | 2.0 | 55° | `forGasoline()` |
| E85 | 5.0 | 1.8 | 48° | `forE85()` |

Per-engine-family overrides can be loaded from `data/combustion/wiebe_calibration.json` via `WiebeFunction::loadCalibration("SBC", ...)`; on miss this returns the gasoline defaults and emits a one-time `std::cerr` warning per unknown family.

### Burn-period decomposition

`WiebeFunction` exposes the conventional three-period decomposition:

- `flameDevelopmentPeriod()`  — 0 → 10 % MFB
- `rapidBurnPeriod()` — 10 → 90 % MFB (this is the calibration's `Δθ` by definition)
- `flameTerminationPeriod()` — 90 → 100 % MFB

### Charge-motion (swirl / tumble) scaling

`WiebeFunction::burnDurationWithChargeMotion` applies a first-order linearization of turbulent flame speed around a calibration point:

```
f_motion = 1 + k_s · (SR − SR_ref) + k_t · (TR − TR_ref)
Δθ_eff   = Δθ_ref / f_motion
```

`f_motion` is clamped to `[0.5, 2.0]` (`CHARGE_MOTION_MIN_FACTOR` / `CHARGE_MOTION_MAX_FACTOR`); inputs outside `[0, 10]` for `SR` / `TR` are rejected.

---

## 3. Two-zone combustion model

The two-zone model in `TwoZoneSolver.h` (with state in `TwoZoneState.h`, calculator helpers in `TwoZoneCalculator.h`, and thermodynamic primitives in `TwoZoneThermo.h`) replaces the single-zone treatment with a burned / unburned partition that shares pressure but tracks distinct zone temperatures. It is what enables knock prediction, since knock is driven by end-gas (unburned-zone) thermodynamic history.

### Governing equations

Mass burn rate (Wiebe-driven):

```
dx_b/dθ = (a · (m + 1) / Δθ) · x^m · exp(−a · x^(m + 1))
```

Energy release into the burned zone:

```
dQ_in/dθ = m_fuel · LHV · dx_b/dθ
```

Cylinder pressure with two coexisting zones (uniform pressure, distinct temperatures, additive volumes):

```
P = (m_b · R_b · T_b + m_u · R_u · T_u) / V_total
```

Wall heat loss per zone (Woschni — see §4):

```
Q_wall = h_c · A_wall · (T_gas − T_wall)
```

Each zone's specific heats follow from its `R` and `γ`:

```
cv = R / (γ − 1)
cp = γ · R / (γ − 1)
```

### Default constants (gasoline)

The table that stood here was attributed to a `TwoZoneCombustionConfig`, which does not
exist in this codebase, and half its rows matched no constant in it. Corrected against the
source, naming the symbol each value actually lives on:

| Value | Where it lives | Meaning |
| --- | --- | --- |
| 288 J/(kg·K) | `TwoZoneCalculator`, default argument | Gas constant, products |
| 287 J/(kg·K) | `TwoZoneCalculator`, default argument | Gas constant, fresh charge |
| 43.4 MJ/kg | `FuelProperties::gasoline87()` | Lower heating value (89 and 91 differ) |
| 14.7 | `FuelProperties::gasoline87()` | Stoichiometric A/F |
| 50° | `DetailedCycleConfig::burnDuration` | Burn duration |
| 20° BTDC | `DetailedCycleConfig::sparkAdvance` | Nominal spark advance |
| 0.94 | `DetailedCycleConfig::combustionEfficiency` | Fraction of fuel energy released |

`sparkAdvance` is the *nominal* value only. On the production path the knock-limited-spark-
advance search overrides it at almost every operating point, so the timing a simulation
actually runs is a result rather than a setting.

There is no configurable `γ_burned` or `γ_unburned`. What the code does instead is in
[§5, Specific-heat ratio](#specific-heat-ratio).

---

## 4. Heat-transfer simplifications — Woschni

Woschni's correlation is implemented in `HeatTransfer.h` (single-zone form) and `EnhancedHeatTransfer.h` (per-surface form, Hohenberg / Annand alternatives). It is *not* called by the analytical Otto baseline; it is invoked by `DetailedCycleSimulation` and by `TwoZoneSolver`. The validated Phase 1 Otto path is **adiabatic**.

### Heat-transfer coefficient

```
h = C1 · B^(−0.2) · P^0.8 · T^(−0.55) · w^0.8
```

| Symbol | Meaning | Value / unit |
| --- | --- | --- |
| `C1` | Calibration constant | 70 in source (Woschni's original is 130; PISTON's value is reduced empirically — see the comment block in `HeatTransfer.h` on calibration vs. peak-pressure / work matching) |
| `B` | Bore | m |
| `P` | Instantaneous cylinder pressure | Pa |
| `T` | Instantaneous gas temperature | K |
| `w` | Characteristic velocity | m/s |

### Characteristic velocity

```
w = C2 · S_p + C3 · (V_d · T_r) / (P_r · V_r) · (P − P_m)
```

with the source constants:

| Symbol | Value | Meaning |
| --- | --- | --- |
| `C2` | 2.28 | Mean piston speed coefficient (gas exchange & compression) |
| `C3` | 0.00324 | Pressure coefficient (combustion term) |
| `S_p` | `2 · N · stroke` | Mean piston speed |
| `(V_d, T_r, P_r, V_r)` | — | Displacement and IVC reference state |
| `P − P_m` | — | Instantaneous minus motored pressure |

`C3` is suppressed (set to 0) outside combustion and expansion; the `useCombustionTerm` flag on `woschniCoefficient` controls this.

### Heat flux

```
Q̇ = h · A · (T_gas − T_wall)
```

`HeatTransfer::calculateTotalHeatTransfer` sums head, piston, and liner contributions; the liner area varies with piston position via `A_liner = π · B · s(θ)`.

### Wall-temperature ranges

Typical steady-state wall temperatures from the source-comment guidance and the `EnhancedHeatTransfer` defaults:

| Surface | Range | `EnhancedHeatTransfer` default |
| --- | --- | --- |
| Cylinder head | 450–550 K | 550 K |
| Piston crown | 500–650 K | 600 K |
| Cylinder liner | 400–450 K | 475 K |

### Important caveat

The validated Phase 1 Otto baseline is **adiabatic** — no Woschni term is applied. Woschni is only active when the detailed cycle path is selected (see §7). [`limitations.md`](limitations.md) is the cross-cutting summary; this section just documents what the implemented correlation looks like when it *is* used.

---

## 5. Real-gas / mixture properties

`NASAPolynomials.h`, `MixtureProperties.h`, and `UnburnedGasProperties.h` provide temperature-dependent specific heats and a dissociation-aware mixture state, for callers that want to escape the constant-`γ` assumption.

**Almost nothing calls them.** This section used to say they are "consumed by `DetailedCycleSimulation` and by parts of the two-zone path". In fact `NASAPolynomials` and `MixtureProperties` are not referenced by `DetailedCycleSimulation` at all, and `UnburnedGasProperties` is constructed only inside the `useTwoZone` branch — which defaults **false**, and which no shipped engine configuration enables. What the production cycle actually uses for `γ` is the two-point linear fit below.

The analytical Otto baseline does not use them either — its `cp`, `cv`, and `γ` are constants. This is the dominant single source of peak-pressure error at high compression ratios; see [`otto_cycle_assumptions.md`](otto_cycle_assumptions.md) §1 for the magnitude.

### Specific-heat ratio

`DetailedCycleSimulation::gammaOfT` is a **two-point linear fit**, not a correlation taken
from a source:

```
γ(T) = 1.4 − 5e-5 (T − 300),   clamped to [1.2, 1.4]
```

**Provenance.** The anchors are air near 300 K (γ about 1.40) and combustion products near
2500 K (γ about 1.29); the straight line between them is the whole model. It is not a fit to
tabulated data, it carries no species dependence, and it does not distinguish fresh charge
from products.

**Validity range.** Reasonable through compression and early expansion. It is weakest exactly
where the cycle is most sensitive: near peak temperature the real γ of burned gas falls below
1.25 through dissociation, and the lower clamp at 1.2 pins it there instead of following it
down. Gated by `enableVariableGamma`, which defaults **true** — this is the shipped path.

Two further fixed values sit alongside it:

- **Burned-zone offset.** The two-zone branch uses `gammaOfT(T_b) − 0.05`, clamped to
  `[1.15, 1.35]`. The 0.05 is a magic offset with no stated basis, and it appears twice, once
  in compression and once in expansion. It is dormant in shipped configurations: `useTwoZone`
  defaults **false** and no engine JSON enables it.
- **Knock-integral γ.** The unburned-gas temperature driving the Livengood–Wu integral is
  computed as `T_u = T_ivc (P / P_ivc)^((γ−1)/γ)` with γ **hard-coded at 1.35**, not with
  `gammaOfT`. Unlike the two-zone branch, this one is live: it selects knock-limited timing at
  every production operating point.

Replacing the linear fit with a `cp(T)` polynomial for the burned zone would move the golden
values and the fleet figure, and is deliberately not attempted here — see `TODO.md` section 16.

### What the two-zone model unlocks

- A separate **unburned-zone temperature** `T_u`, which drives the Livengood–Wu / Douaud–Eyzat knock integral in `KnockModel.h` / `KnockPredictor.h`. The single-zone Otto baseline does not produce a meaningful unburned-zone temperature, which is why baseline knock is heuristic (CR + octane only) — see [`limitations.md`](limitations.md).
- A more accurate **peak pressure** and **peak temperature** during combustion, because heat is released over `Δθ` rather than added at constant volume.
- A separation of the **mixture-properties** assumption from the **kinematic** integration: the burned and unburned sides each get their own `R` and `γ`.

---

## 6. Detailed cycle path

`OttoCycle::OttoCycle(config, useDetailedCycle = true)` swaps the analytical Otto path for a `DetailedCycleSimulation` (`DetailedCycleSimulation.h`), which composes the more sophisticated thermodynamics at crank-degree resolution:

- Wiebe-function progressive heat release (§2)
- Woschni / Hohenberg / Annand wall heat transfer (§4)
- Variable-`γ` via the linear `gammaOfT` fit, not the NASA-polynomial mixture model (§5)
- Incomplete-combustion modeling
- Optional two-zone solver for knock (§3)

This is the path that activates the more sophisticated thermodynamics. The same `OttoCycle` public interface still produces `calculateNetWork` / `calculateIMEP` / `calculateIndicatedTorque` / `getCycleResult` outputs, but they now come from the integrated detailed simulation rather than the analytical isentropic-plus-constant-volume formulas of §1.

---

## 7. Cross-references and further reading

- [`otto_cycle_assumptions.md`](otto_cycle_assumptions.md) — full assumption list for the validated Otto baseline (ideal-gas behavior, isentropy, perfect scavenging, etc.).
- [`limitations.md`](limitations.md) — cross-cutting modeling caveats; the canonical place to check whether a given correlation is or isn't on the validated path.
- [`references.md`](references.md) — Heywood (1988), Stone (2012), Ferguson & Kirkpatrick (2015), Wiebe (1956), Woschni SAE 670931, plus the rest of the citation list.
- [`../user_guide/physics_models.md`](../user_guide/physics_models.md) — user-facing rather than developer-facing view of which models PISTON runs and how to select them.
