# Crank-Slider Mechanism Kinematics

**Technical Reference for Engine Simulation**

## Document Information

- **Project**: PISTON Engine Simulation System
- **Module**: Mechanical Simulation (Phase 1, Weeks 9-10)
- **Target Accuracy**: <7% error (final target)
- **Author**: Technical Documentation
- **Last Updated**: 2025-10-29

---

## Table of Contents

1. [Introduction](#introduction)
2. [Coordinate System and Conventions](#coordinate-system-and-conventions)
3. [Geometric Parameters](#geometric-parameters)
4. [Fundamental Kinematic Equations](#fundamental-kinematic-equations)
5. [Exact Solutions](#exact-solutions)
6. [Approximate Solutions](#approximate-solutions)
7. [Velocity and Acceleration](#velocity-and-acceleration)
8. [Force Analysis](#force-analysis)
9. [Implementation Considerations](#implementation-considerations)
10. [Numerical Stability](#numerical-stability)
11. [Performance Optimizations](#performance-optimizations)
12. [Validation and Testing](#validation-and-testing)
13. [References](#references)

---

## Introduction

The **crank-slider mechanism** (also called **slider-crank mechanism**) is the fundamental kinematic linkage in reciprocating internal combustion engines. It converts the reciprocating linear motion of the piston into rotary motion of the crankshaft (and vice versa during the power stroke).

### Physical Components

1. **Crank**: Rotating element with radius `r` (= stroke/2)
2. **Connecting Rod**: Link of length `l` connecting crank pin to piston pin
3. **Piston**: Reciprocating element constrained to linear motion

### Importance for Engine Simulation

Accurate kinematics are essential for:
- **Piston position**: Determines instantaneous cylinder volume → compression ratio → pressure
- **Piston velocity**: Affects mean piston speed (friction, heat transfer correlations)
- **Piston acceleration**: Determines inertia forces on connecting rod and bearings
- **Force transmission**: Gas force → piston → connecting rod → crankshaft torque

**Error Propagation**: A 1% error in piston position can cause >5% error in instantaneous cylinder pressure during compression, directly impacting simulation accuracy.

---

## Coordinate System and Conventions

### Standard Engine Coordinate System

```
        TDC (θ = 0° or 360°)
            ↑
            │ y-axis (piston motion direction)
            │
            │        Piston
            │      ┌────────┐
            │      │        │
            │      │   •    │ ← Piston pin
            │      └────────┘
            │          │
            │          │ Connecting rod (length l)
            │          │
            │          │
            │          • ← Crank pin
            │        ╱  ╲
            │      ╱      ╲
            │    ╱          ╲
            │  ╱              ╲
            •─────────────────── x-axis
       Crank center
       (main bearing)
```

### Angular Convention

**Two common conventions exist in engine literature:**

#### Convention 1: TDC = 0° (Used in this document)
- **Top Dead Center (TDC)**: θ = 0° (compression/power)
- **90° ATDC**: θ = 90° (power/exhaust)
- **Bottom Dead Center (BDC)**: θ = 180°
- **270° ATDC**: θ = 270° (intake/compression)
- **Rotation Direction**: Clockwise when viewing from front of engine

**Advantages**:
- Intuitive for thermodynamic cycle (TDC is natural zero point)
- Aligns with cam timing specifications (degrees BTDC/ATDC)
- Used in Heywood, Stone, and most engine textbooks

#### Convention 2: BDC = 0° (Less common)
- Used in some mechanical engineering texts
- We **do not use this convention**

### Sign Conventions

- **θ (crank angle)**: Measured from TDC, positive in direction of rotation
- **x(θ)**: Piston position, **zero at TDC**, positive downward (toward BDC)
- **v(θ)**: Piston velocity, positive during expansion (downward)
- **a(θ)**: Piston acceleration, positive downward
- **β(θ)**: Connecting rod angle from vertical, positive when crank pin is on exhaust side

---

## Geometric Parameters

### Primary Parameters

| Parameter | Symbol | Units | Description |
|-----------|--------|-------|-------------|
| **Stroke** | `S` | mm | Distance piston travels from TDC to BDC |
| **Crank Radius** | `r` | mm | Distance from crankshaft center to crank pin (r = S/2) |
| **Connecting Rod Length** | `l` | mm | Center-to-center distance (big end to small end) |
| **Bore** | `B` | mm | Cylinder diameter |
| **Crank Angle** | `θ` | degrees or radians | Angle from TDC |

### Derived Parameters

| Parameter | Symbol | Formula | Typical Range |
|-----------|--------|---------|---------------|
| **Rod Ratio** | `λ` | λ = l/r = 2l/S | 1.5 - 2.2 (automotive) <br> 3.0 - 4.0 (racing) |
| **Rod Angle** | `β` | β = arcsin(sin(θ)/λ) | -30° to +30° (typical) |
| **Piston Pin Offset** | `e` | Usually 0 mm | 0 - 2 mm (if used) |

### Typical Values (Automotive Engines)

| Engine Type | Stroke (mm) | Rod Length (mm) | Rod Ratio λ |
|-------------|-------------|-----------------|-------------|
| **Small Block Chevy (350)** | 88.4 | 165.1 | 3.74 |
| **LS3 (6.2L)** | 92.0 | 158.0 | 3.43 |
| **Honda B18C (1.8L)** | 87.2 | 137.9 | 3.16 |
| **Formula 1 (V10 era)** | 39.7 | 102.0 | 5.14 |
| **Harley-Davidson** | 101.6 | 177.8 | 3.50 |

**Note**: Higher rod ratios (λ > 3.5) reduce side loading on cylinder walls and allow small-angle approximations.

---

## Fundamental Kinematic Equations

### Geometric Constraint

The crank-slider mechanism is constrained by geometry. At any crank angle θ, the piston position `x` must satisfy:

```
Constraint: The sum of projections equals piston position
x(θ) = r(1 - cos θ) + l(1 - cos β)
```

Where β (rod angle) is related to θ by:

```
sin β = (r/l) sin θ = sin(θ) / λ
```

This constraint is **exact** and forms the basis for all kinematic calculations.

### Visual Representation

```
TDC (x = 0)
    │
    │  ← x(θ) →  ┌─── Piston
    │            │
    ↓            ↓
    •────────────────•  ← Current position
    │            ╱  │
    │          ╱    │ l (rod length)
    │        ╱      │
    │      ╱        │
    │    ╱β (rod angle)
    │  ╱            │
    •───────────────┘  ← Crank pin
      ╲    θ       ╱
        ╲        ╱
          ╲    ╱
            ╲╱
    Crank center (O)
```

### Geometric Relationships

From the triangle formed by crankshaft center, crank pin, and piston pin:

**Horizontal components**:
```
r sin θ = l sin β
```

**Vertical components**:
```
x = r(1 - cos θ) + l(1 - cos β)
```

---

## Exact Solutions

### Piston Position (Exact Formula)

The **exact** piston position as a function of crank angle:

```
x(θ) = r[(1 - cos θ) + λ(1 - √(1 - (sin θ / λ)²))]
```

Where:
- `r` = crank radius (mm)
- `θ` = crank angle from TDC (radians)
- `λ` = rod ratio = l/r

**Derivation**:
```
1. From sin β = sin θ / λ
2. cos β = √(1 - sin² β) = √(1 - sin² θ / λ²)
3. Substitute into x = r(1 - cos θ) + l(1 - cos β)
4. Factor out r: x = r[(1 - cos θ) + λ(1 - cos β)]
5. Result: x(θ) = r[(1 - cos θ) + λ(1 - √(1 - (sin θ / λ)²))]
```

**Alternative form** (using rod length directly):
```
x(θ) = r(1 - cos θ) + l[1 - √(1 - (r sin θ / l)²)]
```

### Rod Angle (Exact Formula)

```
β(θ) = arcsin(sin θ / λ)
```

Where:
- `β` = connecting rod angle from cylinder axis (radians)
- `θ` = crank angle from TDC (radians)
- `λ` = rod ratio

**Range**: For automotive engines (λ = 1.5 to 4.0), β typically ranges from -20° to +20°.

### Implementation (C++)

```cpp
// Exact piston position calculation
double calculatePistonPosition(double crankAngle, double crankRadius, double rodLength) {
    const double theta = crankAngle;  // radians
    const double r = crankRadius;
    const double l = rodLength;
    const double lambda = l / r;

    // sin(θ)/λ
    const double sinThetaOverLambda = std::sin(theta) / lambda;

    // Ensure numerical stability: |sin(θ)/λ| ≤ 1
    // (Should always be true if λ > 1, but guard against floating point error)
    const double clampedSin = std::clamp(sinThetaOverLambda, -1.0, 1.0);

    // √(1 - (sin θ / λ)²)
    const double sqrtTerm = std::sqrt(1.0 - clampedSin * clampedSin);

    // x = r[(1 - cos θ) + λ(1 - √(...))]
    return r * ((1.0 - std::cos(theta)) + lambda * (1.0 - sqrtTerm));
}

// Exact rod angle calculation
double calculateRodAngle(double crankAngle, double rodRatio) {
    const double theta = crankAngle;  // radians
    const double lambda = rodRatio;

    const double sinBeta = std::sin(theta) / lambda;
    const double clampedSin = std::clamp(sinBeta, -1.0, 1.0);

    return std::asin(clampedSin);
}
```

---

## Approximate Solutions

### When to Use Approximations

For high rod ratios (λ > 3.0), **small angle approximations** can simplify calculations:
- **Advantage**: Faster computation, simpler formulas
- **Disadvantage**: Introduces error (typically <1% for λ > 3.5)

**Recommendation for PISTON**: Use exact formulas. Modern CPUs compute sqrt and trig functions efficiently, and exact formulas eliminate a potential error source.

### Small Angle Approximation

For small β (rod angle), we can use:
```
sin β ≈ β  (for |β| < 0.3 rad ≈ 17°)
cos β ≈ 1 - β²/2
```

### Approximate Piston Position

**First-order approximation** (classical engine literature):
```
x(θ) ≈ r[(1 - cos θ) + (sin² θ)/(2λ)]
```

**Second-order approximation** (more accurate):
```
x(θ) ≈ r[(1 - cos θ) + (sin² θ)/(2λ) - (sin⁴ θ)/(8λ³)]
```

### Error Analysis

For λ = 3.0 (typical automotive engine):

| Position | Exact (mm) | 1st Order (mm) | 2nd Order (mm) | 1st Error (%) | 2nd Error (%) |
|----------|------------|----------------|----------------|---------------|---------------|
| TDC (0°) | 0.000 | 0.000 | 0.000 | 0.00% | 0.00% |
| 45° | 19.73 | 19.78 | 19.73 | 0.25% | 0.00% |
| 90° (BDC) | 88.40 | 88.67 | 88.41 | 0.31% | 0.01% |
| 135° | 157.07 | 157.33 | 157.08 | 0.17% | 0.01% |
| 180° | 176.80 | 176.80 | 176.80 | 0.00% | 0.00% |

**Conclusion**: Second-order approximation is very accurate (<0.01% error), but exact formula is preferred for <7% target accuracy.

---

## Velocity and Acceleration

### Piston Velocity

Piston velocity is the first derivative of position with respect to **time**:

```
v = dx/dt = (dx/dθ) × (dθ/dt) = (dx/dθ) × ω
```

Where:
- `ω` = angular velocity of crankshaft (rad/s)
- `ω = 2πN / 60` where N is RPM

**Derivation of dx/dθ**:

Starting from exact position:
```
x(θ) = r[(1 - cos θ) + λ(1 - √(1 - (sin θ / λ)²))]
```

Taking derivative with respect to θ:
```
dx/dθ = r[sin θ + λ × d/dθ(√(1 - sin² θ / λ²))]
```

Using chain rule:
```
d/dθ(√(1 - sin² θ / λ²)) = -sin θ cos θ / (λ² √(1 - sin² θ / λ²))
```

Simplifying:
```
dx/dθ = r[sin θ + (sin θ cos θ) / √(1 - sin² θ / λ²)]
```

Using cos β = √(1 - sin² θ / λ²):
```
dx/dθ = r sin θ [1 + cos θ / (λ cos β)]
```

**Final velocity formula**:
```
v(θ) = rω sin θ [1 + cos θ / (λ cos β)]
```

Where:
- `cos β = √(1 - sin² θ / λ²)`

**Alternative form**:
```
v(θ) = rω sin θ [1 + (λ² - sin² θ)^(-1/2) cos θ]
```

### Piston Acceleration

Piston acceleration is the second derivative:

```
a = dv/dt = d²x/dt² = (d²x/dθ²) × ω² + (dx/dθ) × (dω/dt)
```

For **constant RPM** (steady-state dyno testing), dω/dt = 0:

```
a(θ) = ω² (d²x/dθ²)
```

**Exact formula** (from second derivative):

```
a(θ) = rω² [cos θ + (cos 2θ + sin⁴ θ / λ²) / (λ (1 - sin² θ / λ²)^(3/2))]
```

Two earlier statements of this equation were wrong and are corrected here: this document
placed λ in the numerator rather than the denominator, and the implementation dropped the
`sin⁴ θ / λ²` term. Both are exact at TDC and BDC, where `sin θ = 0`; the implementation was
wrong by 9.1% at 90° for an LS3 rod ratio. Verified against a central finite difference of
the exact position.

**Approximate formula** (first-order):

```
a(θ) ≈ rω² [cos θ + (cos 2θ) / λ]
```

This approximation is accurate to ~1% for λ > 2.5.

### Mean Piston Speed

**Mean piston speed** is used in friction and heat transfer correlations (e.g., Woschni):

```
S̄_p = 2 × Stroke × N / 60

Where:
- S̄_p = mean piston speed (m/s)
- Stroke in meters
- N = engine speed (RPM)
```

**Example**: For LS3 (92 mm stroke) at 6000 RPM:
```
S̄_p = 2 × 0.092 m × 6000 / 60 = 18.4 m/s
```

**Typical values**:
- Automotive (NA): 15-20 m/s at peak power
- Racing (F1): 25-30 m/s
- Diesel: 10-15 m/s

### Implementation (C++)

```cpp
struct KinematicResults {
    double position;      // m
    double velocity;      // m/s
    double acceleration;  // m/s²
    double rodAngle;      // rad
};

KinematicResults calculateKinematics(double crankAngle,
                                     double crankRadius,
                                     double rodLength,
                                     double rpm) {
    const double theta = crankAngle;  // rad
    const double r = crankRadius;
    const double l = rodLength;
    const double lambda = l / r;
    const double omega = rpm * 2.0 * piston::utils::math::PI / 60.0;  // rad/s

    KinematicResults result;

    // Sin and cos of crank angle
    const double sinTheta = std::sin(theta);
    const double cosTheta = std::cos(theta);

    // Rod angle: sin(β) = sin(θ)/λ
    const double sinBeta = sinTheta / lambda;
    const double sinBetaClamped = std::clamp(sinBeta, -1.0, 1.0);
    const double cosBeta = std::sqrt(1.0 - sinBetaClamped * sinBetaClamped);
    result.rodAngle = std::asin(sinBetaClamped);

    // Position: x = r[(1 - cos θ) + λ(1 - cos β)]
    result.position = r * ((1.0 - cosTheta) + lambda * (1.0 - cosBeta));

    // Velocity: v = rω sin θ [1 + cos θ / (λ cos β)]
    result.velocity = r * omega * sinTheta * (1.0 + cosTheta / (lambda * cosBeta));

    // Acceleration (exact formula)
    const double cosBeta3 = cosBeta * cosBeta * cosBeta;
    const double cos2Theta = std::cos(2.0 * theta);
    const double sinSq = sinTheta * sinTheta;
    result.acceleration = r * omega * omega *
                         (cosTheta +
                          (cos2Theta + sinSq * sinSq / (lambda * lambda)) /
                              (lambda * cosBeta3));

    return result;
}
```

---

## Force Analysis

### Forces in the Crank-Slider Mechanism

```
    Gas Pressure
         ↓
    ┌────────┐
    │ Piston │  F_gas (from cylinder pressure)
    └────────┘
         ↓
    ┌────────┐
    │ Piston │  F_inertia = -m_piston × a
    │  Pin   │
    └────────┘
         ↓
         │
    Connecting Rod
    (Tension/Compression)
         │
         ↓
    ┌────────┐
    │ Crank  │  Torque = F_rod × r × sin(θ + β)
    │  Pin   │
    └────────┘
```

### Piston Force (Gas + Inertia)

**Total force on piston**:
```
F_piston = F_gas + F_inertia

Where:
- F_gas = P_cylinder × A_piston (positive downward)
- F_inertia = -m_piston × a (opposes acceleration)
- A_piston = π × (bore/2)²
```

**Net force** (positive downward):
```
F_net = (P_cylinder - P_crankcase) × A_piston - m_piston × a
```

**Note**: Crankcase pressure is typically atmospheric (100 kPa), but can be lower with PCV system.

### Connecting Rod Force

The connecting rod transmits piston force to the crankshaft. It acts along the rod axis at angle β:

**Force magnitude**:
```
F_rod = F_piston / cos β

Where:
- β = rod angle from vertical (radians)
- cos β = √(1 - sin² θ / λ²)
```

**Components**:
- **Axial force** (along rod): F_rod
- **Side force** (on cylinder wall): F_side = F_piston × tan β
- **Tangential force** (drives crank): F_tangential = F_rod × sin(θ + β)

### Crankshaft Torque

**Instantaneous torque** from one cylinder:

```
τ(θ) = F_rod × r × sin(θ + β)

Where:
- F_rod = connecting rod force (N)
- r = crank radius (m)
- θ = crank angle (rad)
- β = rod angle (rad)
```

**Expanded form**:
```
τ(θ) = [P_cylinder × A_piston - m_piston × a] × r × sin(θ + β) / cos β
```

**Multi-cylinder engine**:
```
τ_total(θ) = Σ τ_i(θ + θ_offset_i)

Where:
- i = cylinder index
- θ_offset_i = firing order offset (e.g., 0°, 90°, 270°, 180° for inline-4)
```

### Implementation (C++)

```cpp
// Calculate instantaneous torque from one cylinder
double calculateCylinderTorque(double cylinderPressure,  // Pa
                               double crankcasePressure, // Pa
                               double pistonArea,         // m²
                               double pistonMass,         // kg
                               double crankAngle,         // rad
                               double crankRadius,        // m
                               double rodLength,          // m
                               double rpm) {
    // Calculate kinematics
    auto kinematics = calculateKinematics(crankAngle, crankRadius, rodLength, rpm);

    // Gas force (positive downward)
    const double F_gas = (cylinderPressure - crankcasePressure) * pistonArea;

    // Inertia force (opposes acceleration)
    const double F_inertia = -pistonMass * kinematics.acceleration;

    // Net piston force
    const double F_piston = F_gas + F_inertia;

    // Rod force (divide by cos β)
    const double cosBeta = std::cos(kinematics.rodAngle);
    const double F_rod = F_piston / cosBeta;

    // Torque = F_rod × r × sin(θ + β)
    const double torque = F_rod * crankRadius *
                         std::sin(crankAngle + kinematics.rodAngle);

    return torque;  // N⋅m
}
```

---

## Implementation Considerations

### Cylinder Volume Calculation

Instantaneous cylinder volume is critical for thermodynamic calculations:

```
V(θ) = V_clearance + A_piston × x(θ)

Where:
- V_clearance = minimum volume at TDC (m³)
- A_piston = piston area = π(B/2)² (m²)
- x(θ) = piston position from TDC (m)
```

**Compression ratio** relates to clearance volume:
```
CR = (V_clearance + V_displacement) / V_clearance

Solving for V_clearance:
V_clearance = V_displacement / (CR - 1)
```

### Deck Height and Stack Height

In real engines, additional geometry must be considered:

**Stack height**:
```
H_stack = H_deck + l_rod + H_compression
```

Where:
- H_deck = block deck height (mm)
- l_rod = connecting rod length (mm)
- H_compression = compressed gasket + piston compression height (mm)

**Piston at TDC** can be:
- **Above deck**: Negative deck clearance (piston protrudes, increases squish)
- **Below deck**: Positive deck clearance (piston recessed, decreases squish)
- **Zero deck**: Piston flush with deck

### Piston Pin Offset

Some engines use **offset piston pins** to reduce side loading:

```
x(θ) = r(1 - cos θ) + l[1 - √(1 - ((r sin θ + e) / l)²)] - e

Where:
- e = offset distance (typically 0-2 mm)
- Positive e offsets pin toward thrust side
```

**Effect**: Reduces side force during power stroke (θ = 0° to 180°), but increases it during compression.

**Recommendation**: For initial implementation, assume e = 0 (symmetric). Add offset as refinement later.

---

## Numerical Stability

### Potential Numerical Issues

#### 1. Square Root of Negative Number

**Problem**: If |sin θ / λ| > 1 due to floating point error, √(1 - ...) is undefined.

**Solution**: Clamp before square root:
```cpp
const double sinBeta = std::sin(theta) / lambda;
const double clampedSin = std::clamp(sinBeta, -1.0, 1.0);
const double cosBeta = std::sqrt(1.0 - clampedSin * clampedSin);
```

#### 2. Division by Zero

**Problem**: cos β can approach zero at extreme rod angles (not possible in real engines, but possible with bad input).

**Solution**: Validate rod ratio at configuration time:
```cpp
if (rodRatio < 1.0) {
    throw std::invalid_argument(
        "Invalid rod ratio " + std::to_string(rodRatio) +
        ". Must be > 1.0 (physically impossible otherwise)."
    );
}
```

#### 3. Trigonometric Function Precision

**Problem**: For θ near 0° or 360°, sin θ ≈ 0 and floating point errors magnify.

**Solution**: Use double precision (64-bit) for all calculations. Single precision (32-bit float) is **not sufficient** for <7% target accuracy.

### Recommended Data Types

```cpp
// Use double for all kinematic calculations
using Angle = double;       // radians
using Length = double;      // meters
using Velocity = double;    // m/s
using Acceleration = double; // m/s²
using Force = double;       // N
using Torque = double;      // N⋅m
```

**Do NOT use**:
- `float` (insufficient precision)
- Integer types for angles (causes rounding errors)

---

## Performance Optimizations

### 1. Lookup Tables for Sin/Cos

For **per-degree simulation** (720 calculations per cycle), precompute trig functions:

```cpp
class TrigLookupTable {
public:
    TrigLookupTable() {
        // Precompute for 0° to 720° in 1° increments
        for (int i = 0; i <= 720; ++i) {
            double rad = i * piston::utils::math::PI / 180.0;
            sinTable_[i] = std::sin(rad);
            cosTable_[i] = std::cos(rad);
        }
    }

    double sin(double degrees) const {
        // Normalize to [0, 720)
        degrees = std::fmod(degrees, 720.0);
        if (degrees < 0) degrees += 720.0;

        // Linear interpolation
        const int i0 = static_cast<int>(degrees);
        const int i1 = (i0 + 1) % 721;
        const double frac = degrees - i0;

        return sinTable_[i0] * (1.0 - frac) + sinTable_[i1] * frac;
    }

    double cos(double degrees) const {
        // Similar implementation
        degrees = std::fmod(degrees, 720.0);
        if (degrees < 0) degrees += 720.0;

        const int i0 = static_cast<int>(degrees);
        const int i1 = (i0 + 1) % 721;
        const double frac = degrees - i0;

        return cosTable_[i0] * (1.0 - frac) + cosTable_[i1] * frac;
    }

private:
    std::array<double, 721> sinTable_;  // 0° to 720°
    std::array<double, 721> cosTable_;
};
```

**Performance gain**: ~3-5x speedup for kinematic calculations.

**Trade-off**: 11.3 KB memory (721 × 2 × 8 bytes).

**Accuracy**: Linear interpolation introduces <0.001% error (negligible).

### 2. Inline Functions

Mark hot-path functions as inline:

```cpp
inline double calculatePistonPosition(double crankAngle,
                                     double crankRadius,
                                     double rodLength) {
    // Implementation
}
```

### 3. Pre-compute Constants

At engine initialization, compute and cache invariant values:

```cpp
struct KinematicConstants {
    double crankRadius;       // r
    double rodLength;         // l
    double rodRatio;          // λ = l/r
    double pistonArea;        // A = π(B/2)²
    double pistonMass;        // m_piston + m_pin + 1/3 m_rod (reciprocating mass)
    double strokeLength;      // S = 2r
    double clearanceVolume;   // V_clearance
};

// Initialize once per engine configuration
KinematicConstants initKinematics(const EngineConfig& config) {
    KinematicConstants k;
    k.crankRadius = config.stroke / 2.0;
    k.rodLength = config.rodLength;
    k.rodRatio = k.rodLength / k.crankRadius;
    k.pistonArea = piston::utils::math::PI *
                   (config.bore / 2.0) * (config.bore / 2.0);
    k.pistonMass = config.pistonMass + config.pinMass +
                   config.rodMass / 3.0;  // Approximate reciprocating mass
    k.strokeLength = config.stroke;
    k.clearanceVolume = config.displacement / (config.compressionRatio - 1.0);

    return k;
}
```

### 4. Avoid Repeated Calculations

In simulation loop, compute once per degree and reuse:

```cpp
// Bad: Recalculate kinematics multiple times
double position = calculatePistonPosition(theta, r, l);
double velocity = calculatePistonVelocity(theta, r, l, rpm);
double accel = calculatePistonAccel(theta, r, l, rpm);  // Repeats sin/cos

// Good: Calculate once, return all results
auto kinematics = calculateKinematics(theta, r, l, rpm);
// kinematics.position, .velocity, .acceleration
```

### Performance Target

**Per-degree simulation** (720 steps per engine cycle):
- **Target**: <100 µs per degree for mechanical simulation
- **Budget breakdown**:
  - Kinematics: 10 µs
  - Force calculations: 20 µs
  - Torque calculation: 10 µs
  - Other: 60 µs

**Measurement**: Use a profiler (gprof with the MinGW toolchain, or perf) to verify.

---

## Validation and Testing

### Unit Tests

Test kinematic calculations against known solutions:

```cpp
TEST_CASE("Piston position at TDC is zero", "[kinematics]") {
    const double r = 46.0e-3;  // 92 mm stroke / 2 = 46 mm = 0.046 m
    const double l = 158.0e-3; // 158 mm rod
    const double theta = 0.0;  // TDC

    double x = calculatePistonPosition(theta, r, l);

    REQUIRE(x == Approx(0.0).margin(1e-9));
}

TEST_CASE("Piston position at BDC equals stroke", "[kinematics]") {
    const double r = 46.0e-3;
    const double l = 158.0e-3;
    const double theta = piston::utils::math::PI;  // BDC = 180°

    double x = calculatePistonPosition(theta, r, l);
    double stroke = 2.0 * r;

    // At BDC, position should equal stroke (within tolerance)
    REQUIRE(x == Approx(stroke).epsilon(0.001));  // 0.1% tolerance
}

TEST_CASE("Piston velocity at TDC and BDC is zero", "[kinematics]") {
    const double r = 46.0e-3;
    const double l = 158.0e-3;
    const double rpm = 6000.0;

    // At TDC
    auto kinematics_tdc = calculateKinematics(0.0, r, l, rpm);
    REQUIRE(kinematics_tdc.velocity == Approx(0.0).margin(1e-6));

    // At BDC
    auto kinematics_bdc = calculateKinematics(piston::utils::math::PI, r, l, rpm);
    REQUIRE(kinematics_bdc.velocity == Approx(0.0).margin(1e-6));
}

TEST_CASE("Mean piston speed calculation", "[kinematics]") {
    const double stroke = 0.092;  // 92 mm = 0.092 m
    const double rpm = 6000.0;

    // Mean piston speed = 2 × stroke × RPM / 60
    double meanSpeed = 2.0 * stroke * rpm / 60.0;

    REQUIRE(meanSpeed == Approx(18.4).epsilon(0.01));  // 18.4 m/s
}

TEST_CASE("Rod angle stays within physical limits", "[kinematics]") {
    const double r = 46.0e-3;
    const double l = 158.0e-3;  // Rod ratio = 3.43

    // Check rod angle for full rotation
    for (double theta = 0.0; theta <= 2.0 * piston::utils::math::PI; theta += 0.1) {
        double beta = calculateRodAngle(theta, l / r);

        // For rod ratio 3.43, max rod angle ≈ 16.9° = 0.295 rad
        REQUIRE(std::abs(beta) < 0.3);  // Should never exceed 17.2°
    }
}
```

### Integration Tests

Test against textbook examples:

**Example from Heywood (1988), p. 51**:
- Engine: 4-stroke, 4-cylinder
- Bore: 80 mm
- Stroke: 88 mm
- Rod length: 160 mm
- RPM: 3000

**Expected results** (from textbook):
- Mean piston speed: 8.8 m/s
- Max piston velocity: ~12.5 m/s (at ~75° ATDC)
- Max piston acceleration: ~7000 m/s² (at TDC)

### Validation Against FEA/CAD

For critical engine builds, validate kinematics against:
1. **SolidWorks Motion Study**: Animate crank-slider mechanism
2. **ANSYS/Abaqus**: FEA of connecting rod stresses
3. **MATLAB/Simulink**: Independent implementation of equations

---

## References

### Primary References (Engine-Specific)

1. **Heywood, J. B. (1988)**. *Internal Combustion Engine Fundamentals*. McGraw-Hill.
   - Chapter 2: Engine Design and Operating Parameters
   - Equations 2.7-2.12 (kinematics)
   - Section 2.4 (mean piston speed)

2. **Stone, R. (2012)**. *Introduction to Internal Combustion Engines* (4th ed.). Palgrave Macmillan.
   - Chapter 1: Introduction
   - Section 1.2.2 (piston motion)

3. **Ferguson, C. R., & Kirkpatrick, A. T. (2015)**. *Internal Combustion Engines: Applied Thermosciences* (3rd ed.). Wiley.
   - Chapter 2: Engine Design and Performance
   - Section 2.2 (slider-crank kinematics)

### Secondary References (Mechanical Design)

4. **Norton, R. L. (2011)**. *Design of Machinery* (5th ed.). McGraw-Hill.
   - Chapter 4: Linkage Analysis (general slider-crank theory)

5. **Shigley, J. E., & Uicker, J. J. (1995)**. *Theory of Machines and Mechanisms* (2nd ed.). McGraw-Hill.
   - Chapter 5: Velocity and Acceleration Analysis

### Online Resources

6. **SAE International**. *SAE J1349* - Engine Power Test Code - Spark Ignition and Compression Ignition
   - Standard for dyno correction factors

7. **MIT OpenCourseWare**. *2.61 Internal Combustion Engines*
   - Professor Wai K. Cheng's lecture notes

### Implementation References

8. **GT-POWER** (Gamma Technologies). Engine simulation software documentation.
   - Industry-standard commercial software (validation benchmark)

9. **Ricardo WAVE**. 1D engine simulation software.
   - Another industry standard

---

## Appendix A: Nomenclature

| Symbol | Description | Units | Notes |
|--------|-------------|-------|-------|
| `θ` | Crank angle from TDC | rad or deg | 0° at TDC, increases with rotation |
| `β` | Connecting rod angle from vertical | rad or deg | Positive on exhaust side |
| `r` | Crank radius (throw) | m or mm | r = Stroke / 2 |
| `l` | Connecting rod length | m or mm | Center-to-center distance |
| `λ` | Rod ratio | dimensionless | λ = l / r, typically 1.5-4.0 |
| `S` | Stroke | m or mm | Piston travel TDC to BDC |
| `B` | Bore | m or mm | Cylinder diameter |
| `x(θ)` | Piston position from TDC | m or mm | Zero at TDC, positive downward |
| `v(θ)` | Piston velocity | m/s | Positive downward (expansion) |
| `a(θ)` | Piston acceleration | m/s² | Positive downward |
| `ω` | Crankshaft angular velocity | rad/s | ω = 2πN/60 |
| `N` | Engine speed | RPM | Revolutions per minute |
| `S̄_p` | Mean piston speed | m/s | S̄_p = 2SN/60 |
| `V(θ)` | Cylinder volume | m³ | V(θ) = V_clearance + A_piston × x(θ) |
| `P` | Cylinder pressure | Pa | Gauge pressure |
| `F` | Force | N | Newton |
| `τ` | Torque | N⋅m | Newton-meter |

---

## Appendix B: Quick Reference Formulas

### Exact Formulas (Use These)

```
Piston Position:
x(θ) = r[(1 - cos θ) + λ(1 - √(1 - sin²θ/λ²))]

Rod Angle:
β(θ) = arcsin(sin θ / λ)

Piston Velocity:
v(θ) = rω sin θ [1 + cos θ / (λ cos β)]

Piston Acceleration:
a(θ) = rω² [cos θ + (λ cos 2θ) / (1 - sin²θ/λ²)^(3/2)]

Cylinder Volume:
V(θ) = V_clearance + A_piston × x(θ)

Instantaneous Torque:
τ(θ) = F_rod × r × sin(θ + β)
```

### Key Relationships

```
Crank radius: r = Stroke / 2
Rod ratio: λ = l / r
Angular velocity: ω = 2πN / 60 (rad/s)
Mean piston speed: S̄_p = 2 × Stroke × N / 60 (m/s)
Piston area: A = π(B/2)²
Compression ratio: CR = V_max / V_min = (V_clearance + V_displacement) / V_clearance
```

---

## Appendix C: Typical Engine Parameters

### Automotive Engines

| Parameter | Small Block Chevy | LS3 | Honda B18C | F1 V10 |
|-----------|-------------------|-----|------------|--------|
| Displacement | 5.7 L | 6.2 L | 1.8 L | 3.0 L |
| Cylinders | V8 | V8 | I4 | V10 |
| Bore | 101.6 mm | 103.25 mm | 81.0 mm | 98.0 mm |
| Stroke | 88.4 mm | 92.0 mm | 87.2 mm | 39.7 mm |
| Rod Length | 165.1 mm | 158.0 mm | 137.9 mm | 102.0 mm |
| Rod Ratio (λ) | 3.74 | 3.43 | 3.16 | 5.14 |
| Compression Ratio | 9.0:1 | 10.7:1 | 11.0:1 | 17.5:1 |
| Max RPM | 6000 | 6600 | 8400 | 19000 |
| Mean Piston Speed @ Max | 17.7 m/s | 20.3 m/s | 24.4 m/s | 25.1 m/s |

---

**Document Status**: Complete and ready for implementation
**Next Steps**: Implement `KinematicCalculator` class in `src/core/engine/mechanical/Kinematics.h/cpp`
