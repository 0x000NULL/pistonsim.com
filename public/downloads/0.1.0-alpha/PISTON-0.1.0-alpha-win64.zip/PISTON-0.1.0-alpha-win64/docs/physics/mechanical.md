# PISTON Mechanical Models — Reference

This page is the developer-oriented entry point to PISTON's mechanical-simulation stack: geometry, mass distribution, slider-crank kinematics, force chain, cranktrain dynamics, friction, oil system, and accessory loads. It maps each implemented model to its governing equations and to the source headers under `src/core/engine/mechanical/`, then points at the existing companion docs rather than re-deriving content already covered there.

## Scope and how to read this page

PISTON ships several layers of mechanical simulation, and only a subset is on the validated baseline path:

- The **validated baseline mechanical stack** is `SliderCrankKinematics` → `ForceAnalysis` → `ChenFlynnFrictionModel` (with default coefficients), implemented in `src/core/engine/mechanical/SliderCrankKinematics.h`, `ForceAnalysis.h`, and `ChenFlynnFrictionModel.h`. This is what `piston simulate` runs by default and what the published Phase 1 accuracy bands cover. The geometry and mass inputs come from `GeometryConfig` and `MassProperties`.
- The **available-but-not-default** mechanical layers — the enhanced `FrictionModel` (Vogel viscosity, oil thermal feedback, crank-angle-resolved ring/skirt friction, FMEP component breakdown), `CranktrainDynamics`, `OilPumpModel`, `AccessoryLoadModel`, `OilGradeLibrary`, and `OilCoolerThermostat` — are implemented in the same source tree but each is gated behind a default-OFF master switch (`FrictionConfig::useDetailedFriction`, `CranktrainDynamicsConfig::enabled`, `OilSystemConfig::enabled`, `AccessoryConfig::enabled`). Switching any of them on changes which simplifications still apply, as documented in [`limitations.md`](limitations.md).

This document is a reference, not a tutorial. For derivations, error tables, and validation of the slider-crank chain, see [`crank_slider_kinematics.md`](crank_slider_kinematics.md). For the bearing-load decomposition and the full force-analysis discussion, see [`force_analysis.md`](force_analysis.md). For the Chen–Flynn coefficient catalog and component-percentage breakdowns, see [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md). For the user-facing view (which knobs are exposed in the JSON), see [`../user_guide/physics_models.md`](../user_guide/physics_models.md). For textbook citations, see [`references.md`](references.md).

ASCII math is used throughout (`λ`, `θ`, `φ`, `ω`, `^`, `·`) to match the style already used in the sibling physics docs. C++ code is not inlined here — `crank_slider_kinematics.md` and `force_analysis.md` already carry illustrative implementation snippets; this page points at the source headers by name and defers code to the companion docs.

---

## 1. Geometry and mass properties

### `GeometryConfig`

`GeometryConfig` (in `GeometryConfig.h`) is a value type that holds the four primary geometric inputs and the three derived quantities that downstream models consume. All dimensions are SI (meters).

| Member | Meaning | Notes |
| --- | --- | --- |
| `bore` | Cylinder bore diameter `B` [m] | Must be positive |
| `stroke` | Crankshaft stroke length [m] | TDC-to-BDC piston travel; must be positive |
| `rodLength` | Connecting-rod length `l` (center-to-center) [m] | Must be positive |
| `pinOffset` | Wrist-pin offset from piston centerline [m] | Default 0; positive toward the thrust side |
| `crankRadius` | `r = stroke / 2` [m] | Derived |
| `rodRatio` | `λ = l / r` [-] | Derived |
| `pistonArea` | `A_piston = π · (B / 2)²` [m²] | Derived |

The constructor enforces:

- `bore > 0`, `stroke > 0`, `rodLength > 0` (each throws `std::invalid_argument` otherwise).
- `0.5 ≤ λ ≤ 10.0` — a hard validation bound on the rod ratio. The typical engineering range, exposed by `isRodRatioTypical()`, is `1.5 ≤ λ ≤ 5.0`.

`getBoreStrokeRatio()` returns `B / stroke`, classifying the engine as oversquare (>1), square (≈1), or undersquare (<1).

### `MassProperties`

`MassProperties` (in `MassProperties.h`) holds the reciprocating- vs. rotating-mass split for inertia-force calculations. Reference: Heywood (1988) §2.3.3, "Inertia Forces."

| Member | Meaning | Default / formula |
| --- | --- | --- |
| `pistonMass` | Piston, rings, wrist pin, retainers [kg] | Typical 0.3–0.8 kg automotive |
| `rodMass` | Total connecting-rod mass [kg] | Typical 0.4–1.0 kg automotive |
| `reciprocatingFraction` | Fraction of `rodMass` treated as reciprocating [-] | Default `2/3 ≈ 0.6667` |
| `reciprocatingMass` | `pistonMass + rodMass · reciprocatingFraction` [kg] | Used for primary and secondary inertia forces |
| `rotatingMass` | `rodMass · (1 − reciprocatingFraction)` [kg] | Rotates with the crankshaft |

The standard 2/3-reciprocating, 1/3-rotating split is the widely used lumped-mass approximation; the exact value depends on rod design and CG location.

The constructor validates:

- `pistonMass > 0` and `rodMass > 0`,
- `0 ≤ reciprocatingFraction ≤ 1`.

Both `getPrimaryInertiaMass()` and `getSecondaryInertiaMass()` return `reciprocatingMass`; `areMassesTypical()` checks the typical automotive ranges (piston 0.2–1.0 kg, rod 0.3–1.2 kg, reciprocating 0.5–1.5 kg).

---

## 2. Slider-crank kinematics

`SliderCrankKinematics` (in `SliderCrankKinematics.h`) computes piston position, velocity, acceleration, rod angle, and rod angular velocity from the crank angle `θ` and angular velocity `ω`, using exact (non–small-angle) slider-crank formulas. The exposed `KinematicState` struct bundles all five quantities for a single `calculateState(crankAngle, ω)` call.

Coordinate system: `θ = 0` at TDC, positive in the direction of rotation. All angles are radians. Reference: Heywood (1988) §2.3, Eqs. 2.7–2.12.

### Governing equations

Piston position from TDC:

```
s(θ) = r · [(1 − cos θ) + λ · (1 − √(1 − sin²θ / λ²))]
```

Piston velocity (positive away from TDC):

```
v(θ, ω) = r · ω · sin θ · [1 + cos θ / (λ · cos φ)]
```

Piston acceleration:

```
a(θ, ω) = r · ω² · [cos θ + λ · cos 2θ / (1 − sin²θ / λ²)^(3/2)]
```

Connecting-rod angle from vertical:

```
φ(θ) = arcsin(sin θ / λ)
```

Connecting-rod angular velocity (chain rule):

```
dφ/dt = (cos θ / (λ · cos φ)) · ω
```

Mean piston speed (used downstream by Chen–Flynn, §5):

```
S_p = 2 · stroke · (RPM / 60)
```

### Numerical stability

`SliderCrankKinematics::clampSinValue` clamps `sin θ / λ` to `[−1, 1]` before the `arcsin` evaluation in `calculateRodAngle`, guarding the inverse-trig path against floating-point round-off when `λ` is close to 1.

### Pin offset

The constructor accepts a `pinOffset` argument (default 0, also exposed via `getPinOffset()`). Non-zero offsets are parsed and stored, but the active formulas above are the centerline forms; offset pistons "complicate kinematics" per the source comment but are not corrected for in the current closed-form expressions.

### Where to go for more

This is the summary. For the full derivation, the small-`1/λ²` series error analysis, peak-velocity-and-acceleration tables, end-stop checks at TDC/BDC, and validation against published curves, see [`crank_slider_kinematics.md`](crank_slider_kinematics.md).

---

## 3. Force analysis

`ForceAnalysis` (in `ForceAnalysis.h`) converts cylinder pressure plus a `KinematicState` into a force-and-torque chain at a single crank angle. It is constructed from two scalars: the piston diameter (used to compute `A_piston`) and the reciprocating mass. Reference: Heywood (1988) §2.4.

### Core force chain

```
F_gas    = P · A_piston                             // calculateGasForce
F_inertia = −m_recip · a                            // calculateInertiaForce
F_piston = F_gas + F_inertia                        // (assembled in calculateForces)
F_rod    = F_piston / cos φ                         // calculateRodForce
τ        = F_rod · r · sin(θ + φ)                   // calculateCrankTorque
F_side   = F_rod · sin φ                            // calculateSideForces
```

The minus sign on `F_inertia` reflects that inertia opposes acceleration. The `1 / cos φ` factor in `F_rod` is the rod-angularity amplification; it grows toward `1 / cos φ_max = 1 / cos(arcsin(1/λ))` near the mid-stroke.

### Result structs

`calculateForces` returns a `ForceState { gasForce, inertiaForce, netPistonForce, rodForce, crankTorque }`. The companion methods produce:

- `BearingLoads` — radial / tangential decomposition at the main bearing and rod big end, plus the wrist-pin (small-end) force, with combined magnitudes.
- `SideForces` — `pistonSideForce`, `pistonSideForceAngle`, and a `majorThrustSide` flag (true on the side opposite crankpin rotation during the power stroke).
- `PowerState` — instantaneous `P = τ · ω`, plus the `indicatedPower = F_gas · v_piston` and `inertiaPower = F_inertia · v_piston` decomposition (so `P_instant = P_indicated + P_inertia` at the per-cylinder level).
- `ForceComponents` — radial/tangential components at the crank pin and engine-fixed X–Y components, with a `totalForceMagnitude` for verification.

### Multi-cylinder helpers

Two `static` helpers operate on multi-cylinder traces:

- `sumCylinderTorques(cylinderTorques)` — returns the total instantaneous engine torque at one crank angle. Cylinders fire at different times based on firing order (e.g., 1-8-7-2-6-5-4-3 for an LS3 V8); each is at a different point in its cycle when summed.
- `analyzeTorqueVariation(torqueHistory)` — returns a `TorqueVariation { peakToPeakVariation, meanTorque, variationPercent }` over a complete cycle.

### Where to go for more

For the bearing-load derivation, the major-vs-minor thrust-side discussion, the instantaneous power-balance worked example, and validation traces, see [`force_analysis.md`](force_analysis.md).

---

## 4. Cranktrain dynamics

`CranktrainDynamics` (in `CranktrainDynamics.h`) is the orchestrator that produces crank-angle-resolved instantaneous torque, instantaneous RPM, and harmonic content for a multi-cylinder engine. The header is explicit that this class **does not reimplement physics** — it composes `SliderCrankKinematics` and `ForceAnalysis` over the cylinder set, applies analytical flywheel dynamics for RPM fluctuation, and runs a simplified DFT for harmonic analysis.

### Default OFF — bit-exact baseline

`CranktrainDynamicsConfig::enabled` defaults to `false`. When disabled, the analyzer is bypassed and the simulation produces the same results as the cycle-averaged baseline. The minimal config is:

| Field | Default | Notes |
| --- | --- | --- |
| `enabled` | `false` | Master switch. False ⇒ zero behavior change vs. baseline. |
| `total_rotating_inertia_kgm2` | `−1.0` | `−1` = auto-estimate from engine config; otherwise must be in `[−1, 2]` kg·m². |
| `angular_resolution_deg` | `1.0` | Analysis resolution; validated to `(0, 10]` deg. |

### Rotating-inertia torque enhancement

When enabled, the analyzer adds the rotating-inertia reaction torque on top of the gas + reciprocating-inertia torque chain produced by `ForceAnalysis`:

```
τ_inertia,rot = −I_rot · dω/dt
```

This is the crank-angle-resolved contribution from the rotating mass (the `1/3` rod mass plus crankshaft / flywheel inertia), which the cycle-averaged `ForceAnalysis` path does not see.

### Result struct

`CranktrainResults` exposes per-angle traces and cycle-level statistics:

| Field | Meaning |
| --- | --- |
| `crank_angles_deg`, `instant_torque_Nm`, `instant_rpm` | Per-angle traces (~720 points at 1° resolution) |
| `mean_torque_Nm`, `peak_torque_Nm`, `min_torque_Nm` | Torque statistics over the cycle |
| `torque_cov_percent` | Coefficient of variation of torque [%] |
| `mean_rpm`, `peak_rpm`, `min_rpm` | RPM statistics over the cycle |
| `rpm_fluctuation_rpm` | Peak-to-peak RPM swing |
| `rpm_fluctuation_percent` | `(peak − min) / mean × 100` [%] |
| `degree_of_irregularity` | `δ = (ω_max − ω_min) / ω_mean` [-] |
| `harmonic_orders`, `harmonic_amplitudes_Nm` | Per-order harmonic spectrum (orders 0.5, 1.0, 1.5, …) |
| `dominant_harmonic_order`, `dominant_harmonic_amplitude_Nm` | Order and amplitude of the largest peak |
| `mean_torque_error_percent`, `energy_conservation_error_J` | Validation metrics vs. cycle-averaged reference |
| `actual_rotating_inertia_kgm2`, `used_estimated_inertia` | MOI value used; flag if auto-estimated |

The class is not part of the validated Phase 1 stack and should not be assumed to be active unless `CranktrainDynamicsConfig::enabled` is explicitly set true.

---

## 5. Friction — Chen–Flynn baseline

`ChenFlynnFrictionModel` (in `ChenFlynnFrictionModel.h`) is the validated friction baseline. It implements the empirical Chen–Flynn correlation for friction mean effective pressure (Chen & Flynn, 1965, SAE 650733):

```
FMEP = A + B · Pmax + C · Cm + D · Cm²
```

| Symbol | Meaning | Units |
| --- | --- | --- |
| `A` | Constant term (auxiliary losses) | Pa |
| `B` | Pressure coefficient (load-dependent friction) | — |
| `C` | Linear speed coefficient (viscous friction) | Pa·s/m |
| `D` | Quadratic speed coefficient (inertial / windage) | Pa·s²/m² |
| `Pmax` | Maximum cylinder pressure | Pa |
| `Cm` | Mean piston speed | m/s |

### Default coefficients

`ChenFlynnFrictionModel::Coefficients` (default constructor) hard-wires:

| Symbol | Value | Published range |
| --- | --- | --- |
| `A` | 35 000 Pa (0.35 bar) | 0.30–0.50 bar |
| `B` | 0.005 | 0.003–0.006 |
| `C` | 10 000 Pa·s/m (0.10 bar·s/m) | 0.08–0.15 bar·s/m |
| `D` | 100 Pa·s²/m² (0.001 bar·s²/m²) | 0.0005–0.002 bar·s²/m² |

`getTypicalCoefficients(engineType)` returns alternative sets per engine class; `validateCoefficients()` checks physical reasonableness.

### Mean piston speed and downstream conversions

```
Cm   = 2 · stroke · RPM / 60                        // calculateMeanPistonSpeed
T_f  = FMEP · V_d / (4π)                            // convertFMEPToTorque (4-stroke)
P_f  = T_f · ω = T_f · 2π · RPM / 60                // calculateFrictionPower
η_m  = 1 − FMEP / IMEP                              // calculateMechanicalEfficiency
```

The `4π` denominator in the FMEP-to-torque conversion is the 4-stroke factor (one combustion event every two revolutions).

### Component contributions in `FrictionResults`

`FrictionResults` exposes the per-term contributions for diagnostics:

| Field | Term |
| --- | --- |
| `auxiliaryLosses` | `A` |
| `loadDependentLosses` | `B · Pmax` |
| `viscousLosses` | `C · Cm` |
| `inertialLosses` | `D · Cm²` |
| `FMEP`, `frictionTorque`, `frictionPower`, `mechanicalEfficiency`, `meanPistonSpeed` | Aggregate outputs |

These are the four additive Chen–Flynn terms, not a per-component (rings / bearings / valvetrain / auxiliaries) tribological breakdown. Per `limitations.md`, the per-component breakdown discussed in [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) §4 is descriptive, not computed, on this baseline path.

For the full discussion (per-component percentages, calibration ranges, coefficient tables per engine type, and §10.6 known limitations) see [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md).

---

## 6. Friction — enhanced `FrictionModel`

`FrictionModel` (in `FrictionModel.h`) wraps `ChenFlynnFrictionModel` with four optional phases. Each is gated behind a `FrictionConfig` flag, all default-OFF for bit-exact compatibility with the baseline. When `FrictionConfig::useDetailedFriction = false` (the default), `FrictionModel::calculateFriction` delegates entirely to Chen–Flynn and produces identical numerics.

### Phase 1 — Vogel viscosity + selective `κ^α` correction

`OilProperties` (default = SAE 10W-40, reference 363.15 K = 90 °C) parameterizes the Vogel viscosity equation:

```
μ(T) = A_v · exp(B_v / (T − C_v))
```

| Default | Value |
| --- | --- |
| `A_v` | 3.41 × 10⁻⁵ Pa·s |
| `B_v` | 1157.0 K |
| `C_v` | 161.0 K |
| `T_ref` | 363.15 K (90 °C) |

The viscosity ratio `κ = μ(T_oil) / μ(T_ref)` is applied selectively to the speed-dependent terms only:

```
FMEP = A + B · Pmax + κ^α · (C · Cm + D · Cm²)
```

with `α = FrictionConfig::viscosityExponent` (default `0.5`). The `A` and `B` terms are unchanged because they capture auxiliary and load-dependent losses that are not viscosity-driven in the same sense.

### Phase 2 — Oil thermal feedback

When `FrictionConfig::useOilThermalFeedback = true`, an `OilThermalState` tracks oil-sump temperature across cycles via the energy balance:

```
m · cp · dT/dt = Q_friction_in − Q_coolant_out − Q_cooler_out
```

| Field | Default | Meaning |
| --- | --- | --- |
| `oilMass_kg` | 4.0 kg | Sump mass |
| `oilSpecificHeat` | 2000 J/(kg·K) | Oil cp |
| `coolantTemp_K` | 363.15 K (90 °C) | Coolant sink temperature |
| `oilCoolantHTC` | 50 W/K | Oil-to-coolant heat-transfer coefficient |
| `oilCoolerHTC` | 0 W/K | Oil-cooler HTC (0 ⇒ no cooler) |
| `frictionHeatFraction` | 0.5 | Fraction of friction power heating the oil |

`FrictionModel::simulateWarmup(inputs, IMEP, T0, maxCycles, tol)` runs the warmup loop from a cold-start temperature to steady state, defaulting to `maxCycles = 5000` and `convergenceTol_K = 0.1` K. The two `updateOilTemperature` overloads accept either the configured `coolantTemp_K` or an explicit override (for coupled-warmup scenarios).

### Phase 3 — Crank-angle-resolved ring + skirt friction

When `FrictionConfig::useCrankAngleResolved = true`, `calculateCrankAngleFriction(bore, stroke, rodLength, rpm, peakP, T_oil, angleStep_deg)` returns a `std::vector<CrankAngleFriction>` over the full cycle (default 1° step). Each entry carries the Stribeck duty parameter (Hersey number `μN/P`) and a `lubricationRegime` integer:

| `lubricationRegime` | Regime |
| --- | --- |
| 0 | Hydrodynamic |
| 1 | Mixed |
| 2 | Boundary |

The piston / ring / skirt parameters that drive this calculation are config defaults:

| Field | Default | Meaning |
| --- | --- | --- |
| `numRings` | 3 | Number of piston rings |
| `ringPackWidth` | 0.004 m | Total ring-pack axial width |
| `ringTension` | 20.0 N/m | Ring tension per unit circumference |
| `skirtLength` | 0.030 m | Piston-skirt length |
| `skirtClearance` | 30 × 10⁻⁶ m | Skirt-to-bore clearance |
| `surfaceRoughness` | 0.4 × 10⁻⁶ m | Composite surface roughness |
| `boundaryFrictionCoeff` | 0.12 | Boundary lubrication friction coefficient |

`integratePistonFMEP(angleData, bore, stroke)` integrates the per-angle data into a piston FMEP scalar.

### Phase 4 — Component-level FMEP breakdown

`calculateFMEPBreakdown` produces an `FMEPBreakdown` decomposing total FMEP into:

| Component | Source |
| --- | --- |
| `pistonRings_Pa` | Phase 3 ring-pack integration |
| `pistonSkirt_Pa` | Phase 3 skirt integration |
| `bearings_Pa` | Chen–Flynn residual |
| `valvetrain_Pa` | Chen–Flynn residual |
| `auxiliaries_Pa` | Chen–Flynn `A` term |
| `totalFMEP_Pa` | Sum |

This is the only path that produces a *computed* per-component breakdown; the baseline `ChenFlynnFrictionModel` only carries the four additive Chen–Flynn terms.

---

## 7. Oil system

The oil-system models live in `OilPumpModel.h`, `OilGradeLibrary.h`, `OilCoolerThermostat.h`, and the `OilSystemConfig` struct in `FrictionModel.h`. The aggregate is gated by `OilSystemConfig::enabled` (default `false` ⇒ legacy `0.30 · rpm`-style path, bit-exact). Per [`limitations.md`](limitations.md), none of these are coupled back into FMEP on the validated baseline.

### `OilPumpModel`

A positive-displacement pump with a relief-valve bypass. The header configures:

| Field | Default | Meaning |
| --- | --- | --- |
| `displacement_cc` | 12.0 cc/rev | Pump volumetric displacement |
| `driveRatio` | 0.5 | `pump_rpm / engine_rpm` |
| `mechanicalEfficiency` | 0.85 | η_mech |
| `volEfficiency0` | 0.92 | Base volumetric efficiency at zero pressure |
| `leakageCoeff` | 2.5 × 10⁻⁹ m³/(Pa·s) | `k_leak` in the leakage correction |
| `reliefCrackPressure_Pa` | 414 000 Pa (~60 psi) | Relief-valve crack point |
| `reliefFullOpenPressure_Pa` | 552 000 Pa (~80 psi) | Relief fully open |
| `reliefMaxFlow_m3s` | 5 × 10⁻⁴ m³/s | Maximum bypass flow |
| `systemResistance` | 1.5 × 10⁹ Pa/(m³/s) | Hydraulic resistance R |

Volumetric efficiency falls off with pressure rise and rises with viscosity:

```
η_vol = η_0 − k_leak · ΔP / μ
```

The relief valve linearly opens between `reliefCrackPressure` and `reliefFullOpenPressure`; the returned `OilPumpState` flags `reliefValveOpen`.

Windage (sump churning loss) is a cubic-in-`ω` term carried in `OilSystemConfig`:

```
P_w = windageCoeff · ω³                              // default coeff = 2.3 × 10⁻⁹ W·s³/rad³
```

`SumpType::WET` and `SumpType::DRY` select the sump configuration.

### `OilGradeLibrary`

`OilGradeLibrary` is a static lookup of Vogel coefficients for ten SAE grades:

```
0W-16, 0W-20, 5W-20, 5W-30, 5W-40, 10W-30, 10W-40, 15W-40, 15W-50, 20W-50
```

`lookup(grade)` returns `std::optional<OilProperties>` with case-insensitive, whitespace-trimmed, hyphen-optional name normalization. `lookupOrDefault(grade)` falls back to the default `OilProperties` (SAE 10W-40) on miss. All entries are referenced to `T_ref = 363.15 K` (90 °C).

### `OilCoolerThermostat`

`OilCoolerThermostat::effectiveHTC(T_oil, cfg)` returns the effective oil-cooler heat-transfer coefficient as a linear ramp:

```
HTC(T) = 0                                    if T ≤ openTemp_K
HTC(T) = (T − openTemp_K) / (fullOpenTemp_K − openTemp_K) · maxHTC
                                              if openTemp_K < T < fullOpenTemp_K
HTC(T) = maxHTC                               if T ≥ fullOpenTemp_K
```

| Default | Value |
| --- | --- |
| `openTemp_K` | 383.15 K (110 °C) |
| `fullOpenTemp_K` | 393.15 K (120 °C) |
| `maxHTC` | 100 W/K |
| `enabled` | `false` |

When `cfg.enabled = false`, the function returns `0`.

---

## 8. Accessory loads

`AccessoryLoadModel` (in `AccessoryLoadModel.h`) models per-component parasitic accessory power for the alternator, water pump, power steering, A/C compressor, and cooling fan. The aggregate is gated by `AccessoryConfig::enabled` (default `false` ⇒ legacy hardcoded path, bit-exact). The model does *not* include oil-pump or windage losses (those are handled by `OilPumpModel` / `OilSystemConfig`, §7).

### Per-component configs

| Component | Config struct | Default behavior |
| --- | --- | --- |
| Alternator | `AlternatorConfig` | `basePower_W = 300`, `rpmCoefficient = 0.05 W/rpm`, `electricalLoad_W = 500`, `efficiency = 0.60`, `driveRatio = 2.5` |
| Water pump | `WaterPumpConfig` | Cubic in pump RPM: `P = coefficient · N_pump³`, `coefficient = 2.0 × 10⁻¹⁰`, `driveRatio = 1.0` |
| Power steering | `PowerSteeringConfig` | `enabled = true`, `basePower_W = 300`, optional `rpmCoefficient`, `type ∈ {hydraulic, electric, none}` |
| A/C compressor | `ACCompressorConfig` | `enabled = false`, `power_W = 3000` at `referenceRPM = 3000` (compressor shaft), scales as `(N / N_ref)^rpmExponent` with `rpmExponent = 0.7`, `driveRatio = 1.5` |
| Cooling fan | `CoolingFanConfig` | `type ∈ {electric, mechanical}`. Electric: constant `power_W`. Mechanical: cubic, `P = coefficient · RPM³`, `coefficient = 1.0 × 10⁻¹¹` |

The alternator splits mechanical drag (`basePower_W` + linear `rpmCoefficient · N_alt`) from electrical-to-mechanical conversion at efficiency `η_alt`, so the total alternator load combines a friction term outside `η` with an `electricalLoad_W / η_alt` conversion term.

### Override curves

Each component carries a `std::vector<PowerCurvePoint> overrideCurve`. The `interpolateCurve(curve, rpm)` static helper performs linear interpolation on the sorted curve, clamping outside the range. With `<2` points, it returns a sentinel < 0 that signals "use the physics formula instead." Two-or-more-point curves replace the physics calculation with measured-data interpolation.

### Output

`AccessoryLoadState` returns per-component powers (alternator, water pump, power steering, A/C, cooling fan) plus the whole-engine total. `calculateTotalPower(rpm)` is the convenience scalar.

---

## 9. Cross-references and further reading

- [`crank_slider_kinematics.md`](crank_slider_kinematics.md) — full slider-crank derivation, error tables, and validation traces; the canonical place for the §2 content here.
- [`force_analysis.md`](force_analysis.md) — bearing-load decomposition, side-force major/minor thrust geometry, instantaneous power balance, and force-analysis validation; the canonical place for the §3 content here.
- [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) — Chen–Flynn coefficient catalog by engine type, descriptive per-component breakdown percentages, calibration ranges, and §10.6 known limitations; the canonical place for the §5 content here.
- [`limitations.md`](limitations.md) — the cross-cutting "Mechanical-loss simplifications" section is the canonical place to check whether a given enhancement (Vogel viscosity, oil-grade library, accessory loads, cranktrain dynamics) is on the validated path.
- [`references.md`](references.md) — Heywood (1988) Chapters 2.3–2.4 (slider-crank kinematics and force analysis) and Chapter 13 (friction and lubrication); Stone (2012); Ferguson & Kirkpatrick (2015); Chen & Flynn SAE 650733; and the rest of the citation list.
- [`../user_guide/physics_models.md`](../user_guide/physics_models.md) — user-facing rather than developer-facing view of which mechanical models PISTON runs and how to select them.
