# Force Analysis - Physics Documentation

**Date:** 2025-01-29
**Component:** `src/core/engine/mechanical/ForceAnalysis.h/cpp`
**References:** Heywood (1988) Chapter 2.4, Ferguson & Kirkpatrick (2015)

---

## Table of Contents

1. [Overview](#overview)
2. [Theoretical Background](#theoretical-background)
3. [Core Force Analysis Chain](#core-force-analysis-chain)
4. [Extended Analyses](#extended-analyses)
5. [Multi-Cylinder Analysis](#multi-cylinder-analysis)
6. [Validation and Accuracy](#validation-and-accuracy)
7. [References](#references)

---

## Overview

The `ForceAnalysis` class implements the complete force analysis chain for piston engine mechanics, converting cylinder pressure and kinematic state into forces, torques, bearing loads, and power. This module is critical for:

- **Performance Prediction**: Torque curves, power output, RPM limits
- **Bearing Design**: Load distribution, bearing selection, lubrication requirements
- **Structural Analysis**: Piston side thrust, connecting rod stresses
- **Efficiency Analysis**: Friction losses, mechanical efficiency
- **Vibration Analysis**: Force balance, torque variation

### Key Features

✅ **Core Force Analysis**
- Gas force from cylinder pressure
- Inertia force from reciprocating mass
- Rod force from piston force and geometry
- Crank torque from rod force and lever arm

✅ **Extended Analyses**
- Bearing loads (radial/tangential decomposition)
- Piston side forces (thrust loading)
- Instantaneous power (indicated, inertia, total)
- Force component decomposition (multiple reference frames)

✅ **Multi-Cylinder Support**
- Torque summation across cylinders
- Torque variation analysis (smoothness metrics)

---

## Theoretical Background

### Slider-Crank Mechanism

The piston engine uses a **slider-crank mechanism** to convert linear piston motion into rotary crankshaft motion. The key components are:

```
        Cylinder Centerline
              ↓
        ┌─────┴─────┐
        │   Piston  │  ← Gas Pressure Acts Here
        └─────┬─────┘
              │ Wrist Pin (Small End)
        ╔═════╧═════╗
        ║ Connecting ║
        ║    Rod     ║  ← Rod Angle φ from vertical
        ╚═════╤═════╝
              │ Crank Pin (Big End)
          ┌───┴───┐
          │ Crank │  ← Crank Angle θ from TDC
          └───┬───┘
              │ (Crankshaft Axis)
```

**Geometry Parameters:**
- **r** = Crank radius (stroke/2)
- **l** = Connecting rod length
- **λ** = Rod ratio = l/r (typically 1.5 to 4.0)
- **θ** = Crank angle from TDC (0° = TDC, 180° = BDC)
- **φ** = Rod angle from cylinder centerline

**Sign Conventions:**
- Positive θ: Clockwise rotation (viewed from front)
- Positive φ: Rod tilted in direction of crank rotation
- Positive forces: Acting away from TDC
- Positive torque: Producing clockwise rotation (engine power output)

---

## Core Force Analysis Chain

### 1. Gas Force

**Physics:** Cylinder pressure acts on the piston crown, creating a net force that drives the piston.

**Formula:**
```
F_gas = P × A_piston = P × π(d/2)²
```

**Where:**
- **P** = Cylinder pressure [Pa] (absolute or gauge, depending on reference)
- **d** = Piston diameter (bore) [m]
- **A_piston** = Piston crown area [m²]

**Implementation:** `ForceAnalysis.cpp:63-78`

**Notes:**
- Atmospheric pressure acts on both sides of the piston, so net force comes from gauge pressure
- For simplicity, we use absolute pressure and handle atmospheric reference in thermodynamics
- Piston area is calculated once in constructor for efficiency

**Typical Values (LS3 6.2L V8):**
- Bore: 103.25 mm → A = 8,373 mm²
- Peak pressure: 60 bar (6 MPa)
- **Peak gas force: 50,240 N (~11,295 lbf)**

---

### 2. Inertia Force

**Physics:** Reciprocating mass (piston + rings + pin + 1/3 rod mass) resists acceleration, creating an inertia force that opposes piston motion.

**Formula:**
```
F_inertia = -m_recip × a_piston
```

**Where:**
- **m_recip** = Reciprocating mass [kg]
  - m_recip = m_piston + m_rings + m_pin + (m_rod / 3)
- **a_piston** = Piston acceleration [m/s²] (from kinematics)

**Implementation:** `ForceAnalysis.cpp:80-99`

**Sign Convention:**
- Negative sign: Inertia force **opposes** acceleration
- When piston accelerates away from TDC (a < 0): F_inertia > 0 (resists motion)
- When piston decelerates toward TDC (a > 0): F_inertia < 0 (assists motion)

**Typical Values (LS3 6.2L V8 at 6000 RPM):**
- m_recip ≈ 0.81 kg
- Peak acceleration at TDC ≈ -35,000 m/s²
- **Peak inertia force: 28,350 N (~6,373 lbf)**

**Physical Insight:**
At high RPM, inertia forces can exceed gas forces, especially during:
- **Intake stroke** (low pressure, high deceleration)
- **Exhaust stroke** (low pressure, high acceleration)
- **Overrun** (throttle closed, minimal cylinder pressure)

---

### 3. Net Piston Force

**Physics:** The net force acting on the piston is the sum of gas force and inertia force.

**Formula:**
```
F_piston = F_gas + F_inertia
```

**Implementation:** `ForceAnalysis.cpp:49`

**Notes:**
- Gas force is always positive (pressure pushes piston down)
- Inertia force alternates sign throughout the cycle
- Net force can be negative (piston pulled by rod during high-RPM intake/exhaust)

---

### 4. Connecting Rod Force

**Physics:** The connecting rod transmits piston force to the crankshaft. Due to rod angularity (φ), the rod force is greater than the piston force.

**Formula:**
```
F_rod = F_piston / cos(φ)
```

**Where:**
- **φ** = Rod angle from vertical [rad] (from kinematics)

**Implementation:** `ForceAnalysis.cpp:101-127`

**Derivation:**
```
Free body diagram of piston:
  F_piston (vertical) = F_rod × cos(φ) (vertical component)

Solving for F_rod:
  F_rod = F_piston / cos(φ)
```

**Numerical Stability:**
- Guard against division by zero when |cos(φ)| < 10⁻⁶
- For typical rod ratios (λ > 1.5), φ_max ≈ 20°, so cos(φ) > 0.94
- Rod force is at most 6% greater than piston force for λ = 1.5

**Typical Values:**
- Rod ratio λ = 3.4 → φ_max ≈ 17°
- cos(17°) ≈ 0.956
- **F_rod ≈ 1.05 × F_piston** (5% increase)

---

### 5. Crankshaft Torque

**Physics:** The rod force creates torque on the crankshaft through a moment arm that varies with crank angle.

**Formula:**
```
τ = F_rod × r × sin(θ + φ)
```

**Where:**
- **r** = Crank radius [m]
- **θ** = Crank angle from TDC [rad]
- **φ** = Rod angle from vertical [rad]

**Implementation:** `ForceAnalysis.cpp:129-157`

**Derivation:**
```
Moment arm (perpendicular distance from rod line of action to crank center):
  d = r × sin(θ + φ)

Torque:
  τ = F_rod × d = F_rod × r × sin(θ + φ)
```

**Key Observations:**
1. **At TDC (θ=0, φ=0):** sin(0) = 0 → **τ = 0** (no torque at TDC!)
2. **At BDC (θ=π, φ=0):** sin(π) = 0 → **τ = 0** (no torque at BDC!)
3. **Maximum torque:** Occurs near **θ ≈ 70-80° ATDC** when sin(θ+φ) ≈ 1

**Physical Insight:**
- Even with maximum cylinder pressure at TDC, torque is zero (bad leverage)
- Peak torque lags peak pressure by 70-80° (geometric effect)
- This is why engines need flywheels to smooth torque delivery

**Typical Values (LS3 6.2L V8, single cylinder):**
- F_rod ≈ 50,000 N
- r = 46 mm
- sin(θ+φ) ≈ 0.98 at peak
- **Peak torque per cylinder: 2,254 N·m (1,662 lb-ft)**
- **V8 total (4 cylinders firing):** ~900 N·m (664 lb-ft) actual measured

---

## Extended Analyses

### 6. Bearing Loads

**Purpose:** Decompose rod force into radial and tangential components for bearing selection and lubrication analysis.

**Formulas:**
```
Main Bearing (Crank Pin):
  F_radial = F_rod × cos(φ)
  F_tangential = F_rod × sin(φ)
  |F_total| = F_rod  (Pythagorean theorem)

Big End (Connecting Rod):
  Same as main bearing (simplified model)

Wrist Pin (Small End):
  F_wrist_pin = F_piston
```

**Implementation:** `ForceAnalysis.cpp:159-211`

**Reference Frame:**
- **Radial:** Along crank radius (from crank center to crank pin)
- **Tangential:** Perpendicular to radial (direction of rotation)

**Applications:**
- **Bearing Selection:** Peak radial load determines bearing size
- **Lubrication:** Tangential load affects oil film pressure
- **Wear Patterns:** Radial/tangential distribution predicts bearing wear

**Typical Values (LS3 at peak torque):**
- F_rod = 50,000 N
- φ ≈ 16°
- F_radial ≈ 48,100 N (96%)
- F_tangential ≈ 13,800 N (28%)

---

### 7. Piston Side Forces

**Purpose:** Calculate lateral force on cylinder wall (piston thrust) from rod angularity.

**Formula:**
```
F_side = F_rod × sin(φ)
```

**Where:**
- **φ** = Rod angle from vertical [rad]

**Implementation:** `ForceAnalysis.cpp:213-254`

**Thrust Sides:**
- **Major Thrust Side:** 180° - 360° (power/intake strokes)
  - High side force, oil film develops here
  - Side opposite to crank rotation direction
- **Minor Thrust Side:** 0° - 180° (compression/exhaust strokes)
  - Lower side force, less oil film
  - Same side as crank rotation direction

**Applications:**
- **Piston Skirt Design:** Determines wear pattern and required skirt length
- **Friction Modeling:** Side force contributes to piston friction
- **Noise/Vibration:** Piston slap occurs when side force reverses

**Typical Values:**
- Peak side force ≈ 15% of rod force (at maximum rod angle)
- LS3: ~7,500 N on major thrust side during power stroke

---

### 8. Instantaneous Power

**Purpose:** Calculate power contributions from gas pressure and inertia at any crank angle.

**Formulas:**
```
Instantaneous Power (Total):
  P_instant = τ × ω

Indicated Power (Gas Only):
  P_indicated = F_gas × v_piston

Inertia Power (Inertia Only):
  P_inertia = F_inertia × v_piston
```

**Where:**
- **τ** = Crankshaft torque [N·m]
- **ω** = Angular velocity [rad/s] = (RPM × 2π) / 60
- **v_piston** = Piston velocity [m/s] (from kinematics)

**Implementation:** `ForceAnalysis.cpp:256-286`

**Power Balance:**
```
P_instant = P_indicated + P_inertia

Proof:
  P_instant = τ × ω = (F_piston × lever_arm) × ω
  P_indicated + P_inertia = (F_gas + F_inertia) × v_piston = F_piston × v_piston

These are equivalent through geometry (lever_arm and velocity relationship).
```

**Applications:**
- **Indicated Power:** Power from combustion (IMEP calculation)
- **Inertia Power:** Power absorbed/released by reciprocating mass
- **Cycle Analysis:** Integrate over cycle to get indicated work

**Physical Insight:**
- During power stroke: P_indicated > 0 (gas delivers power)
- During compression: P_indicated < 0 (compressing gas absorbs power)
- P_inertia alternates sign: negative during acceleration, positive during deceleration

---

### 9. Force Component Decomposition

**Purpose:** Express forces in multiple reference frames for different analyses.

**Reference Frames:**

1. **Radial/Tangential (Crank Pin Frame):**
   ```
   F_radial = F_rod × cos(φ)
   F_tangential = F_rod × sin(φ)
   ```

2. **Engine-Fixed X-Y Frame:**
   ```
   F_x = F_rod × sin(θ + φ)  (horizontal)
   F_y = F_rod × cos(θ + φ)  (vertical)
   ```

**Implementation:** `ForceAnalysis.cpp:288-325`

**Applications:**
- **Radial/Tangential:** Bearing analysis, torque calculation
- **X-Y Components:** Engine mount forces, vibration analysis, crankshaft bending

**Verification:**
```
Total Force Magnitude (all frames):
  |F| = sqrt(F_x² + F_y²) = sqrt(F_radial² + F_tangential²) = F_rod
```

---

## Multi-Cylinder Analysis

### 10. Torque Summation

**Purpose:** Calculate total engine torque from individual cylinder contributions.

**Formula:**
```
τ_total = Σ τ_i  (i = 1 to N_cylinders)
```

**Implementation:** `ForceAnalysis.cpp:327-340`

**Notes:**
- In a 4-stroke engine, each cylinder is at a different crank angle based on firing order
- At any instant, typically only 1-2 cylinders are producing significant torque
- Example firing order (LS3 V8): 1-8-7-2-6-5-4-3

**Example (V8 at steady state):**
```
Cylinder offsets for V8 (90° V-angle, cross-plane crank):
  Cyl 1: 0°
  Cyl 2: 270°
  Cyl 3: 180°
  Cyl 4: 450° = 90°
  ... (continues based on firing order)
```

---

### 11. Torque Variation Analysis

**Purpose:** Quantify torque smoothness over an engine cycle.

**Metrics:**
```
Peak-to-Peak Variation:
  ΔT = T_max - T_min

Mean Torque:
  T_mean = (1/N) × Σ T_i

Variation Percentage:
  V% = (ΔT / T_mean) × 100
```

**Implementation:** `ForceAnalysis.cpp:342-378`

**Interpretation:**
- **Low variation (<10%):** Smooth running (inline-6, V12)
- **Medium variation (10-30%):** Acceptable (V8, inline-4 with balance shafts)
- **High variation (>30%):** Rough running (single-cylinder, parallel twin)

**Applications:**
- **NVH Analysis:** Torque variation correlates with vibration amplitude
- **Flywheel Sizing:** Higher variation requires larger flywheel
- **Engine Smoothness:** Key metric for refinement and driveability

**Typical Values:**
- **V8:** 15-25% (relatively smooth)
- **Inline-4:** 30-50% (requires balance shafts)
- **Single-cylinder:** 100%+ (very rough)

---

## Validation and Accuracy

### Validation Against Real Data

The ForceAnalysis formulas have been validated against:

1. **Heywood (1988) Reference Equations** ✅
   - All formulas match exactly (Chapter 2.4)
   - Sign conventions verified
   - Geometric relationships confirmed

2. **LS3 6.2L V8 Dyno Data** ✅
   - Bore: 103.25 mm, Stroke: 92 mm
   - Peak torque: 424 lb-ft @ 4,600 RPM
   - Order-of-magnitude agreement when combined with thermodynamics

3. **Physical Consistency Checks** ✅
   - Force balance verified at all crank angles
   - Power balance (P_instant = P_indicated + P_inertia) holds
   - Pythagorean theorem verified for force decompositions

### Accuracy Notes

**What This Module Does:**
- ✅ Converts pressure → force → torque **exactly** (geometric relationships)
- ✅ Accounts for inertia effects **accurately**
- ✅ Handles bearing loads and side forces **correctly**

**What Requires External Models:**
- ❌ Cylinder pressure vs. crank angle (requires thermodynamics)
- ❌ Friction losses (requires Chen-Flynn model)
- ❌ Pumping losses (requires gas exchange model)

**Expected Accuracy (when integrated with full engine model):**
- **Phase 1:** <20% error (proof of concept)
- **Phase 2:** <15% error (enhanced prototype)
- **Phase 3:** <10% error (MVP release)
- **Final:** <7% error (professional-grade)

---

## References

### Primary References

1. **Heywood, J. B. (1988).** *Internal Combustion Engine Fundamentals*
   Chapter 2.4: Engine Dynamics and Vibration
   - Gas force, inertia force, rod force, crank torque formulas
   - Sign conventions and reference frames
   - Multi-cylinder torque summation

2. **Ferguson, C. R., & Kirkpatrick, A. T. (2015).** *Internal Combustion Engines: Applied Thermosciences*
   Chapter 3: Engine Dynamics
   - Bearing load decomposition
   - Piston side forces and thrust loading
   - Power calculations

3. **Stone, R. (2012).** *Introduction to Internal Combustion Engines* (4th ed.)
   Chapter 2: Engine Mechanics
   - Slider-crank geometry
   - Force analysis examples
   - Practical design considerations

### Additional Reading

- **Taylor, C. F. (1985).** *The Internal Combustion Engine in Theory and Practice* (Vol. 2)
- **Blair, G. P. (1999).** *Design and Simulation of Four-Stroke Engines*
- **Pulkrabek, W. W. (2003).** *Engineering Fundamentals of the Internal Combustion Engine*

### Online Resources

- **x-engineer.org** - Crank slider mechanism kinematics and dynamics
- **engineersedge.com** - Piston engine force calculations
- **codecogs.com** - Interactive equation editor and verification

---

## Appendix: Quick Reference

### Key Formulas

| Quantity | Formula | Units |
|----------|---------|-------|
| Gas Force | F_gas = P × π(d/2)² | N |
| Inertia Force | F_inertia = -m × a | N |
| Rod Force | F_rod = F_piston / cos(φ) | N |
| Crank Torque | τ = F_rod × r × sin(θ+φ) | N·m |
| Side Force | F_side = F_rod × sin(φ) | N |
| Power | P = τ × ω | W |

### Typical Parameter Ranges

| Parameter | Small Engine | Automotive | Racing |
|-----------|--------------|------------|--------|
| Bore (mm) | 50-70 | 80-105 | 85-100 |
| Stroke (mm) | 50-70 | 75-105 | 75-90 |
| Rod Ratio λ | 1.5-2.0 | 1.5-2.0 | 1.8-2.5 |
| Recip. Mass (kg) | 0.1-0.3 | 0.5-1.0 | 0.4-0.7 |
| Peak Pressure (bar) | 40-50 | 50-80 | 80-120 |
| Peak RPM | 5000-8000 | 6000-7500 | 8000-12000 |

---

**Document Version:** 1.0
**Last Updated:** 2025-01-29
**Author:** PISTON Development Team
**Status:** ✅ Production-Ready
