# PISTON Known Limitations

This document is the **single index of modeling assumptions, simplifications, and unsupported configurations** for the PISTON engine simulation. It does not re-derive physics — it points readers at the deeper documents that already cover each topic and adds the cross-cutting summary they lack.

## Scope of this document

- The **production simulation path is the detailed cycle** — crank-angle-resolved 720° integration with Wiebe (or predictive) combustion, Woschni heat transfer, temperature-dependent γ, and a Livengood–Wu knock integral driving a knock-limited-spark-advance search. `DynoEngineAdapter`'s constructor requires the caller to name its cycle — there is no default, so omitting it is a compile error. The analytical Otto path (`false`) is a deterministic baseline for unit tests only (ULTRAPLAN P2-1 / D3).
- **This document carries no accuracy numbers of its own.** For measured accuracy, use [`../validation/accuracy.generated.md`](../validation/accuracy.generated.md), which is produced by `tools/validate_all.cpp` rather than written by hand. Read its scope header before quoting it: it compares **peak** power/torque against published spec-sheet figures at WOT, and says nothing about curve shape.
- For friction-model detail see [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) §10.6; for the thermodynamic derivations see [`otto_cycle_assumptions.md`](otto_cycle_assumptions.md). Where those documents describe the *analytical Otto baseline*, they are describing the test-only path, not what ships.

If a simplification listed below stops being true, update the deeper document first and amend the cross-reference here.

---

## Thermodynamic simplifications

These apply to the detailed cycle as it actually runs (`DetailedCycleSimulation.cpp`).

- **Gas exchange is not simulated.** The intake stroke is held at constant manifold pressure and constant ambient temperature; the exhaust stroke is held at constant ambient pressure with a fixed +400 K offset. The 720° cycle is therefore a ~360° closed-volume simulation between two prescribed legs. There is **no valve flow, no blowdown, and no in-cycle ram or inertia effect**. Production callers leave the manifold-pressure argument at zero, so both prescribed legs run at the same pressure and **the P—V pumping loop integrates to exactly zero** — all pumping work enters as a PMEP term subtracted afterwards. Turbine back-pressure does reach that term (`OttoCycle::calculatePMEP`), but it never reaches the cylinder P—V trace, and superchargers contribute no back-pressure at all.
- **Volumetric efficiency enters at IVC**, as the pressure the cylinder is left at when the intake valve closes, so trapped mass, fuel mass, the pressure trace, peak pressure, peak temperature and the knock integral that selects ignition timing are all evaluated for the charge the engine actually traps. It was previously applied as a multiplier on the finished cycle's net work, which meant every one of those was evaluated at VE = 1.0. The intake leg itself is still held at manifold pressure, so the restriction does no pumping work in the P—V trace — see the gas-exchange entry above.
- **The VE model is a calibrated correlation, not gas dynamics.** `VVTAwareVEStrategy` evaluates a Gaussian in RPM whose peak, width and minimum come from hand-tuned functions of valve area, cam duration and valve count. A 1-D intake model runs alongside it but contributes only a relative deviation about a fixed mean, weighted 0.20 by default (0.25–0.45 for the six configs carrying an `ecu` block). That 1-D model is **scoped to shape, by decision**: its absolute level sits well below real volumetric efficiency, it has no runner-momentum term, and only the normalised shape reaches the answer — the measured attribution of the level, and the momentum work, are recorded in the backlog. Since VE linearly scales torque, the correlation is the dominant driver of every reported number. Its coefficients, the range over which it saturates, and what it does not model are documented in [`volumetric_efficiency.md`](volumetric_efficiency.md).
- **Ideal gas throughout, with a linear γ(T) fit** — `γ = 1.4 − 5e-5·(T − 300)`, clamped to [1.2, 1.4]; the two-zone burned zone uses that minus a fixed 0.05 offset, clamped to [1.15, 1.35]. No dissociation, no real-gas effects, no species-resolved properties. Separately, the unburned-gas temperature driving the knock integral uses a **hard-coded γ = 1.35** rather than the variable fit, and that path is live at every operating point. Provenance and validity range are in [`thermodynamics.md`](thermodynamics.md#specific-heat-ratio).

- **Knock: the Livengood–Wu integral accumulates over the end gas only** (it stops at burn-out — knock is autoignition of unburned charge, and integrating past its consumption is what used to saturate the model at low RPM). The knock-limited-spark search runs on both timing authorities: anchored at the config's base timing on engines without an ECU map, and **under** the map value on ECU-mapped engines, capped by the config's `knock_retard` budget — the map may never be advanced past, only retarded from. Two honest caveats. First, the end-gas temperature starts from ambient at IVC, so the charge is some tens of kelvin colder than a warm engine's and the knock onset is correspondingly optimistic. Residual enthalpy mixing that closes that gap is now implemented and tested (`setResidualGasTemperatureCalculator`), and is deliberately **not** installed on the production path: with it, the corrected charge temperature drives every octane from RON 60 to RON 110 into the model's 15-degree retard cap, so the model stops distinguishing them. The charge temperature is right and the cap is what cannot yet absorb it — both are filed and open, with the measured figures in the backlog. Second, non-ECU engines run one flat base timing over the whole range, so their knock-limited low-RPM retard is systematically larger than a real mapped ECU would command; the rich WOT mixture's longer autoignition delay (`exp(1.5·(φ−1))`) is modeled and partially offsets this.
- **Single-zone by default.** A two-zone solver exists (`TwoZoneSolver.h`, `useTwoZone`) but is **off by default** and is not the path any shipped configuration exercises.
- **Residual gas is a mass scaler on the production path.** The residual fraction reduces trapped fresh charge and, as shipped, does not raise charge temperature — see the knock entry above for the mixing model that exists, what it measures, and why it is not switched on. Cycle-to-cycle state is not carried over in either case: every cycle restarts from the same charge state rather than inheriting the last one's.
- **Constant combustion efficiency** (`η_combustion`, default 0.94) with an equivalence-ratio correction. No dependence on charge dilution or residual fraction beyond that.

---

## Mechanical-loss simplifications

The default friction stack is the Chen–Flynn FMEP correlation (`ChenFlynnFrictionModel.h`). See [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) for the full discussion.

- **Empirical Chen–Flynn FMEP correlation only — no per-bearing tribology.** Friction is a single number `FMEP = A + B·Pmax + C·Cm + D·Cm²`; the per-component breakdown (piston rings, main bearings, rod bearings, valvetrain) discussed in `chen_flynn_friction_model.md` §4 is **descriptive, not computed**.
- **Oil-temperature-dependent viscosity exists but is off.** `FrictionModel` implements a Vogel viscosity equation and oil thermal feedback, gated behind `mechanical.detailed_friction.enabled`. That flag defaults to `false` and **no shipped engine configuration sets it**, so the default path runs coefficients that implicitly assume oil at ~100 °C. The capability is therefore untested in practice.
- **`mechanical.fmep_coefficient` is a blunt multiplier on the whole friction correlation.** It scales `FMEP` directly rather than adjusting any of the four Chen–Flynn terms individually, so it cannot distinguish, say, ring drag from valvetrain drag. Configs that do not set it take a default of 0.97.
- **PMEP is MAP-derived but assumes fixed exhaust pressure.** `PMEP = (P_exhaust − MAP) + 500·(rpm/1000)²` with `P_exhaust` hard-coded at atmospheric + 5 kPa, so exhaust-system geometry never affects pumping work.
- **Part throttle is modelled, but unvalidated and incomplete.** Manifold pressure now falls with load, and trapped mass, fuelling and the PMEP term follow it; brake torque is continuous and monotone in load. Two caveats. First, the load-to-MAP relation is an analytical stand-in, not a measured throttle characteristic — `ThrottleMap` exists and is not wired to this path. Second, the intake and exhaust legs of the P—V trace still sit at the same pressure, so the restriction does no pumping work in the cycle itself and enters only through the separate PMEP term. **Nothing on the part-load path is measured against anything**, so treat its output as untested. WOT is bit-for-bit unaffected, which is why the published accuracy figure is unchanged by any of this.
- **Forced-induction models are only partly coupled to the cycle.** The turbo and supercharger size their air flow from the VE the cycle traps its charge with (PIS-0083); they used a flat 0.85 and a separate parabola. The turbine still runs on an exhaust temperature linear in RPM rather than the cycle's own. The cycle does compute that temperature (after blowdown, PIS-0076), but feeding it to the turbine exposed a defect in the turbine model: it prescribes shaft speed from the compressor pressure ratio instead of balancing it, so cooler exhaust produced *more* boost, and one diesel exceeded its cylinder-pressure limit. The coupling waits on that fix. The PMEP and exhaust-tuning paths still use their own placeholder flow.
- **No accessory-drive transient loads.** `AccessoryLoadModel.h` carries oil/water-pump baseline draw; alternator, A/C compressor, power steering, and cooling fan are excluded by design.
- **Rigid-body crank-slider — no elastic deformation, no torsional vibration.** The kinematic and force chain in `crank_slider_kinematics.md` and `force_analysis.md` is exact-geometry but treats the crankshaft, connecting rod, and block as infinitely stiff. No flex-induced timing error, no torsional resonance, no main-bearing oil-film compliance. `geometry.pin_offset_mm` is honoured as exact desaxe geometry (position, rod angle, velocity and acceleration), but every shipped configuration sets it to `0.0`, so no published result exercises it.
- **Steady-state friction only** — the Chen–Flynn correlation is curve-fit to motoring tests; transient friction during throttle steps is not modeled. See `chen_flynn_friction_model.md` §10.6, Limitation 2.

---

## Missing systems

This section catalogs subsystems that are either absent or partially implemented (spec/data only, no transient or closed-loop model). For partials, the language "**partial — spec-data only, no transient model**" means the configuration parses and the steady-state numbers are produced, but no time-domain dynamics are simulated.

### Forced induction

- **Turbocharger maps** — `Turbocharger.h` + `CompressorMap.h` + `TurbineModel.h` implement a physics-based steady-state model (analytical turbine, compressor map interpolation, Newton's-2nd-law shaft dynamics). **Map coverage is the gap**: the bundled compressor map catalog is sparse, so out-of-map operating points fall back to extrapolation with degraded accuracy. **No transient lag / wastegate dynamics in the validated path** — the model has a wastegate PID and shaft inertia, but turbo lag is not validated against transient dyno traces.
- **Supercharger maps** — `Supercharger.h` covers Roots, twin-screw, and centrifugal types as steady-state PD/centrifugal models. Recent seed data (`data/superchargers_data.sql` and `turbochargers_extended.sql`) added basic-spec coverage (~15 superchargers, ~34 turbos) **but most entries carry no compressor-map JSON**, so they fall back to spec-derived defaults. Treat as **partial — spec-data only, no compressor map**.
- **Intercooler effectiveness vs. flow** — `Intercooler.h` uses a configured constant effectiveness with a flow-dependent ΔP. **Effectiveness is not a function of mass flow** (real cores droop at high flow). Treat as **constant-effectiveness approximation**.
- **Wastegate dynamics** — `WastegateController.h` implements mechanical-spring and electronic-PID modes for steady-state position; **valve-actuator response, hysteresis, and creep are not modeled**.

### Valvetrain

- **Lift, lobe profile and head flow are configurable but synthesised by default.** The
  optional `valvetrain.intake_valve_lift_mm` / `*_lift_profile` / `head_flow` keys (see
  [`volumetric_efficiency.md`](volumetric_efficiency.md) § Measured valvetrain data) feed
  measured data into the VE model; **no shipped config sets them**, so every bundled engine
  runs on lift synthesised as `0.28 ×` valve diameter and a head-type flow archetype.
- **Spring rate, valve mass, float and surge have no keys and no model.** A cam that would
  float its valves simulates the same as one that would not.

### Variable valve timing

- VVT is **partial — config-driven phasing only**. `VVTConfig.h` and `VVTAwareVEStrategy.h` apply per-channel intake/exhaust phase shifts to VE via an RPM schedule. **There is no cam-actuator dynamics model, no oil-pressure-dependent ramp rate, and no closed-loop cam-position feedback.** Continuous-vs-switched is a config string, not a dynamic distinction.

### Direct injection

- DI is **partial — charge-cooling ΔT only**. `DIConfig.h` implements an air-mass-independent charge-cooling temperature drop and a small thermal-efficiency bonus. **Spray, mixture stratification, multi-pulse injection timing, and high-pressure rail dynamics are not modeled.** The injection event is treated as instantaneous and homogeneous from the cycle's point of view.

### Other partials and unsupported items

- **EGR** — only the rate is simulated, and only partly. `egr.fixed_rate` (clamped to 0.30, and to `egr.max_rate`) reaches the knock integral, the predictive-combustion strategy's dilution term when that strategy is selected, and the diesel ignition delay. It does **not** displace fresh charge from the trapped mass and does **not** heat the charge: recirculated gas carries no temperature in the spark-ignition cycle, so `egr.cooled` and `egr.cooler_efficiency` have no effect and are recorded-only keys. Giving EGR a temperature is the same charge-heating chain as residual-gas mixing, which is built but deliberately switched off (see the knock entry above). `EgrConfig.h`, which carries a rate schedule and a cooler outlet temperature, is used by no simulation path, and the emissions calculator's EGR corrections are fed no EGR rate by any production path. There is no EGR valve controller.
- **Water/methanol injection** — **not modeled.** No charge-cooling, no octane uplift, no flow controller.
- **Electronic boost control beyond a single PID** — `BoostController.h` exists, but multi-mode strategies (overboost, scramble, transient open-loop assist) and N₂O fogger/wet kits are not modeled.
- **Knock-reactive ignition retard / cylinder-by-cylinder trim** — global ignition timing is mapped (`IgnitionMap.h`); **per-cylinder knock retard is not modeled** even though `CylinderBalanceModel.h` exists for balance trims.
- **Rotary (Wankel) engines — unsupported.** The Otto / Wiebe / two-zone cycles assume reciprocating crank-slider geometry. Rotary-specific port timing, eccentric-shaft kinematics, and seal leakage are not implemented.
- **Diesel (compression-ignition) engines — partial, and not validated.** Diesel configs run `DieselCombustionStrategy`: Hardenberg–Hase ignition delay (SAE 790493) driven by the fuel's cetane number, and a Watson dual-Wiebe burn (SAE 800029). The spark-ignition knock model is switched off for diesel cycles. No spray or mixing model exists, and none of the three shipped diesels (`bmw_n47d20`, `cummins_6bt_59`, `vw_19_tdi_alh`) is in the accuracy harness, so no diesel figure is measured against anything. Two defects that made diesel results worse still were fixed together (PIS-0128, PIS-0169): the three configs declared their turbo under a key nothing read and simulated naturally aspirated, and the ignition delay added the correlation's temperature and pressure terms where the published form multiplies them (about 2.4× too long a delay at typical conditions). Even so, the simulated torque curves peak well above the published peak-torque speed and the two small diesels still fall well short of their published power. Treat any diesel output as indicative only.

---

## Accuracy expectations

There is no per-engine-class error table here any more. The previous one quoted a single validated row (`+17.0%` peak, `10.2%` RMSE for an LS3) sourced "verbatim" from `../validation/phase1_validation_results.md` — a document since emptied of all numbers and marked **Superseded**. Those figures had no live source, and the harness measured that engine at a materially different error. Every other row in that table was an unvalidated estimate presented in the same shape as the one validated row.

Use the generated report instead:

```
docs/validation/accuracy.generated.md      # 22 engines, per-engine peak error, regenerated by tools/validate_all
piston validate-dyno --engine <cfg> --validation <entry>   # single engine against a stored reference
```

When reading either, hold on to four things:

1. **Peak only.** The fleet harness compares peak power and torque against published spec-sheet figures. It does not validate curve shape, and simulated peak *location* is frequently off by several hundred RPM.
2. **WOT only.** WOT is also the only throttle position the model resolves (see above), so part-throttle output carries no information. Coverage does exist in `tests/core/engine/test_ThrottleControl.cpp`, but every case there runs the analytical Otto baseline rather than the production detailed cycle, and none pins a value.
3. **References are published figures, not measured sweeps.** No entry in `data/validation/` is a logged dyno run; see that directory's `DYNO_DATA_SUMMARY.md`.
4. **Nothing here is certified**, by SAE or anyone else.

For any engine class you have not personally benchmarked, produce a sweep and compare it against a published dyno before quoting the simulation as authoritative.
