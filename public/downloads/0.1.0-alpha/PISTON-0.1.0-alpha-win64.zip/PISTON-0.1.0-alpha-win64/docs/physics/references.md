# PISTON Physics References — Citation Index

This page is the developer-oriented citation index for everything PISTON's physics implementation cites: textbooks, SAE papers, standards, and the empirical correlations that show up by name in source-header comments and in the sibling pages under `docs/physics/`. It is a *citation index*, not a tutorial — equations live in the companion docs, and each reference entry below points at the section in those docs (and the source header) where the citation is consumed.

## Scope and how to read this page

- For governing equations, defaults, and the in-cylinder model walkthrough, see [`thermodynamics.md`](thermodynamics.md). For the geometry / mass / slider-crank / force-chain / friction / oil / accessory walkthrough, see [`mechanical.md`](mechanical.md). For the Otto-baseline assumption list, see [`otto_cycle_assumptions.md`](otto_cycle_assumptions.md). For cross-cutting modeling caveats, see [`limitations.md`](limitations.md). For the slider-crank derivation, the bearing-load decomposition, and the Chen–Flynn coefficient catalog, see [`crank_slider_kinematics.md`](crank_slider_kinematics.md), [`force_analysis.md`](force_analysis.md), and [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) respectively.
- This page **does not re-derive equations** that already live in those docs. Each reference entry below is annotated with the source header that consumes it and the section in the sibling docs that carries the equation.
- Stable identifiers (ISBN, SAE paper number, year) are used in place of URLs. SAE paper numbers and ISBNs are sufficient for retrieval through any institutional library.
- ASCII math (`γ`, `θ`, `Δθ`, `^`, `·`) is used for inline equation snippets, matching the style already used in the sibling physics docs.

---

## 1. Primary textbooks

### Heywood, J.B. (1988)
*Internal Combustion Engine Fundamentals*. McGraw-Hill. ISBN 978-0070286375.

The most-cited reference in PISTON. Chapters consumed:

- **Chapter 2** — Engine design and operating parameters; §2.3 Eqs. 2.7–2.12 are the slider-crank equations implemented in `SliderCrankKinematics.h` (see [`mechanical.md`](mechanical.md) §2 and [`crank_slider_kinematics.md`](crank_slider_kinematics.md)). §2.3.3 is the inertia-force / reciprocating-mass split that `MassProperties.h` implements ([`mechanical.md`](mechanical.md) §1). §2.4 is the force-analysis chain that `ForceAnalysis.h` implements ([`mechanical.md`](mechanical.md) §3, [`force_analysis.md`](force_analysis.md)).
- **Chapter 4** — Thermodynamic properties of working fluids; the constant-`γ` and NASA-polynomial paths in `OttoCycle.h`, `NASAPolynomials.h`, and `MixtureProperties.h` ([`thermodynamics.md`](thermodynamics.md) §1, §5).
- **Chapter 5** — Ideal models of engine cycles; the analytical Otto-cycle baseline in `OttoCycle.h` ([`thermodynamics.md`](thermodynamics.md) §1).
- **Chapter 9** — Combustion in spark-ignition engines; §9.2.3 is the two-zone framing implemented in `TwoZoneSolver.h` / `TwoZoneState.h` / `TwoZoneCalculator.h` / `TwoZoneThermo.h` ([`thermodynamics.md`](thermodynamics.md) §3). Chapter 9 is also the source for the Wiebe defaults discussed in [`thermodynamics.md`](thermodynamics.md) §2 and for the heuristic CR/octane knock framing of [`limitations.md`](limitations.md).
- **Chapter 12** — Heat transfer in engines; framing for Woschni / Hohenberg / Annand, implemented in `HeatTransfer.h` and `EnhancedHeatTransfer.h` ([`thermodynamics.md`](thermodynamics.md) §4).
- **Chapter 13** — Friction and lubrication; the per-component friction breakdown that informs the descriptive percentages in [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) §4.
- **Chapter 14** — Intake and exhaust flow; volumetric-efficiency framing for `VolumetricEfficiency.h` and the gas-exchange caveats in [`limitations.md`](limitations.md).

### Stone, R. (2012)
*Introduction to Internal Combustion Engines* (4th ed.). Palgrave Macmillan. ISBN 978-0230576636.

A more accessible companion to Heywood. Chapters consumed:

- **Chapter 2** — Thermodynamic principles; cross-checked against the Otto-cycle derivation in [`thermodynamics.md`](thermodynamics.md) §1.
- **Chapter 3** — Combustion and fuels; LHV, AFR, and Wiebe-parameter defaults used in [`thermodynamics.md`](thermodynamics.md) §2 and §3.
- **Chapter 10** — Computer modeling; the framing for the detailed-cycle path in `DetailedCycleSimulation.h` ([`thermodynamics.md`](thermodynamics.md) §6).

### Ferguson, C.R. & Kirkpatrick, A.T. (2015)
*Internal Combustion Engines: Applied Thermosciences* (3rd ed.). Wiley. ISBN 978-1118533314.

- **Chapter 8** — Wiebe-function detail and two-zone modeling; primary reference for `WiebeFunction.h` / `WiebeBurnRate.h` (integrated in `DetailedCycleSimulation.h`) ([`thermodynamics.md`](thermodynamics.md) §2) and `TwoZoneSolver.h` / `TwoZoneState.h` / `TwoZoneCalculator.h` / `TwoZoneThermo.h` ([`thermodynamics.md`](thermodynamics.md) §3).

### Norton, R.L. (2011)
*Design of Machinery* (5th ed.). McGraw-Hill. ISBN 978-0077421717.

Alternate slider-crank derivation. Cited from [`crank_slider_kinematics.md`](crank_slider_kinematics.md) and [`mechanical.md`](mechanical.md) §2 as a cross-check on the Heywood §2.3 forms used by `SliderCrankKinematics.h`.

### Watson, N. & Janota, M.S. (1982)
*Turbocharging the Internal Combustion Engine*. Macmillan. ISBN 978-0333242902.

Turbocharger map and shaft-dynamics reference. Cited from [`limitations.md`](limitations.md) under the forced-induction partial-implementation caveats.

---

## 2. Combustion models — papers

### Wiebe, I. (1956)
*Halbempirische Formel für die Verbrennungsgeschwindigkeit* [Semi-empirical formula for combustion rate]. Verlag der Akademie der Wissenschaften der UdSSR, Moscow.

The original Wiebe-function monograph. No DOI; published as a German-language Soviet-era monograph. An accessible English summary is in Heywood §9. Consumed by `WiebeFunction.h` and `WiebeBurnRate.h` (integrated in `DetailedCycleSimulation.h`); the form `x_b(θ) = 1 − exp(−a · ((θ − θ_s) / Δθ)^(m + 1))` and the default parameters (`a = 5`, `m = 2`, `Δθ = 55°` for gasoline) are documented in [`thermodynamics.md`](thermodynamics.md) §2.

---

## 3. Heat-transfer correlations — papers

The three correlations exposed by `HeatTransfer.h` and `EnhancedHeatTransfer.h` are Woschni, Hohenberg, and Annand. The validated Otto baseline is **adiabatic** — none of these are invoked on it; they are only active when `DetailedCycleSimulation` or `TwoZoneSolver` is selected ([`thermodynamics.md`](thermodynamics.md) §4, [`limitations.md`](limitations.md)).

### Woschni, G. (1967)
"A Universally Applicable Equation for the Instantaneous Heat Transfer Coefficient in the Internal Combustion Engine." *SAE Technical Paper* 670931.

The `h = C1 · B^(−0.2) · P^0.8 · T^(−0.55) · w^0.8` form implemented in `HeatTransfer.h`. Note that PISTON's calibration constant `C1 = 70` deviates from Woschni's published `130`; the source comment in `HeatTransfer.h` documents this as an empirical match to peak-pressure / work targets ([`thermodynamics.md`](thermodynamics.md) §4).

### Hohenberg, G. (1979)
"Advanced Approaches for Heat Transfer Calculations." *SAE Technical Paper* 790825.

Alternative HTC correlation implemented as the free function `hohenbergHTC` in `EnhancedHeatTransfer.h`. Documented in the source-header comment block.

### Annand, W.J.D. (1963)
"Heat Transfer in the Cylinders of Reciprocating Internal Combustion Engines." *Proceedings of the Institution of Mechanical Engineers* 177(1), 973–996.

Convective + radiation heat-flux correlation implemented as `annandHeatFlux` in `EnhancedHeatTransfer.h`. Returns flux rather than HTC, with a guarded radiation term to prevent double-counting.

---

## 4. Knock prediction — papers

The two integrals composed in `KnockModel.h` and `KnockPredictor.h`. These are *only* on the available-but-not-default path: the validated Otto baseline does not feed them, so downstream consumers that rely on the baseline see a heuristic CR + octane knock margin rather than a predictive integral ([`limitations.md`](limitations.md), [`thermodynamics.md`](thermodynamics.md) §3).

### Livengood, J.C. & Wu, P.C. (1955)
"Correlation of Autoignition Phenomena in Internal Combustion Engines and Rapid Compression Machines." *Symposium (International) on Combustion* 5(1), 347–356.

The autoignition integral `∫(1/τ) dθ → 1` evaluated against unburned-zone history. Implemented in `KnockModel.h` and in the diesel autoignition path (`DieselCombustionStrategy.cpp` source comment).

### Douaud, A.M. & Eyzat, P. (1978)
"Four-Octane-Number Method for Predicting the Anti-Knock Behavior of Fuels and Engines." *SAE Technical Paper* 780080.

The induction-time correlation `τ = A · (ON/100)^B · (P/P_ref)^n · exp(Ea/(R·T))`. Implemented as `DouaudEyzatDelay` in `KnockModel.h` and reproduced (so the lightweight predictor is dependency-free) in `KnockPredictor.cpp`.

---

## 5. Slider-crank kinematics & force analysis — papers

No additional SAE entries. The slider-crank chain in `SliderCrankKinematics.h` and `ForceAnalysis.h` cites Heywood (1988) §2.3 (Eqs. 2.7–2.12) and §2.4 — see §1 above — with Norton (2011) as a cross-check. The full derivation, error tables, and validation traces live in [`crank_slider_kinematics.md`](crank_slider_kinematics.md) and [`force_analysis.md`](force_analysis.md); the summary form is in [`mechanical.md`](mechanical.md) §2 and §3.

---

## 6. Friction — papers

The validated friction baseline is Chen–Flynn (`ChenFlynnFrictionModel.h`); the enhanced `FrictionModel.h` adds Vogel viscosity, oil thermal feedback, and crank-angle-resolved ring/skirt friction on top. The papers below are catalogued so the four-term Chen–Flynn baseline and the Phase 3 ring/skirt and valvetrain submodels each have a citation entry.

### Chen, S.K. & Flynn, P.F. (1965)
"Development of a Single Cylinder Compression Ignition Research Engine." *SAE Technical Paper* 650733.

The `FMEP = A + B · Pmax + C · Cm + D · Cm²` correlation implemented in `ChenFlynnFrictionModel.h`. Default coefficients and engine-class variations are catalogued in [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) and summarized in [`mechanical.md`](mechanical.md) §5.

### Patton, K.J., Nitschke, R.G. & Heywood, J.B. (1989)
"Development and Evaluation of a Friction Model for Spark-Ignition Engines." *SAE Technical Paper* 890836.

Patton–Nitschke–Heywood (PNH) component-level friction model. Referenced from [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) §7.1 as a comparison alternative — not implemented in PISTON.

### Sandoval, D. & Heywood, J.B. (2003)
"An Improved Friction Model for Spark-Ignition Engines." *SAE Technical Paper* 2003-01-0725.

A more-accurate-than-Chen–Flynn alternative SI friction model. Referenced from [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) as an upgrade path; not implemented in PISTON.

### Tian, T. (2002)
"Dynamic Behaviors of Piston Rings and Their Practical Impact." *SAE Technical Paper* 2002-01-0483.

Piston-ring dynamics. Informs the Phase 3 ring/skirt sub-model in `FrictionModel.h` ([`mechanical.md`](mechanical.md) §6).

### Ma, M.T. et al. (1997)
"Analysis of Lubrication and Friction for a Complete Piston-Ring Pack with an Improved Oil Availability Model." *SAE Technical Paper* 970836.

Piston-ring lubrication. Same Phase 3 ring/skirt source as Tian (2002).

### Teodorescu, M. et al. (2002)
"Experimental Investigation of Engine Valve Train Friction." *SAE Technical Paper* 2002-01-0484.

Valvetrain-friction reference for the descriptive valvetrain percentage in [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) §4.

### Pipitone, E. et al. (2009)
"A New Simple Friction Model for S. I. Engine." *SAE Technical Paper* 2009-01-1984.

Comparison of Chen–Flynn / Rezeka–Henein / Bishop friction models. Referenced from [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md).

### Taraza, D. et al. (2000)
"Friction Losses in Multi-Cylinder Diesel Engines." *SAE Technical Paper* 2000-01-0921.

Multi-cylinder diesel-engine friction. Referenced from [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) for the diesel coefficient ranges.

### Vogel viscosity equation
Empirical relation `μ(T) = A_v · exp(B_v / (T − C_v))`. Consumed by `OilProperties` (default SAE 10W-40) and by the `OilGradeLibrary.h` static lookup of Vogel coefficients for ten SAE grades ([`mechanical.md`](mechanical.md) §6, §7). Treated as a standard textbook correlation; no single primary citation — Heywood (1988) Chapter 13 and Stone (2012) Chapter 9 both reproduce it.

---

## 7. Validation standards

### SAE J1349
"Engine Power Test Code — Spark Ignition and Compression Ignition — As Installed Net Power Rating." Latest revision SAE J1349_201208.

The dyno-correction standard implemented in `EnvironmentalCorrection.h`. Standard reference conditions (25 °C, 99 kPa dry) and the correction factor used in PISTON's dyno-correction module. Selectable via `setCorrectionStandard("SAE J1349")` in `ValidationHarness` and `DynoConfig`.

### DIN 70020
The German alternate dyno-correction standard. Selectable via `setCorrectionStandard("DIN 70020")` (see `ValidationHarness.cpp` and `ValidationDataLoader.cpp`). Standard reference conditions (20 °C, 101.325 kPa dry) — distinct from SAE J1349, with measurable shifts in reported peak power as documented in [`limitations.md`](limitations.md).

### SAE J2723
"Engine Power Test Code — Engine Power and Torque Certification." The certification standard the LS3 6.2L dyno data was said to have been produced under, when `phase1_validation_results.md` quoted it as the validated NA pushrod V8 baseline; that document has since been emptied of its figures and marked superseded. Cited from [`limitations.md`](limitations.md).

---

## 8. How citations map to source files

The following table is the lookup developers want when answering "which paper does `<header>.h` cite?":

| Source header | Primary citation | Section in sibling docs |
| --- | --- | --- |
| `OttoCycle.h` | Heywood (1988) Ch. 5; Stone (2012) Ch. 2 | [`thermodynamics.md`](thermodynamics.md) §1, [`otto_cycle_assumptions.md`](otto_cycle_assumptions.md) |
| `WiebeFunction.h`, `WiebeBurnRate.h` (integrated in `DetailedCycleSimulation.h`) | Wiebe (1956); Heywood (1988) §9; Ferguson & Kirkpatrick (2015) Ch. 8 | [`thermodynamics.md`](thermodynamics.md) §2 |
| `TwoZoneSolver.h`, `TwoZoneState.h`, `TwoZoneCalculator.h`, `TwoZoneThermo.h` | Heywood (1988) §9.2.3; Ferguson & Kirkpatrick (2015) Ch. 8 | [`thermodynamics.md`](thermodynamics.md) §3 |
| `HeatTransfer.h` | Woschni (1967) SAE 670931; Heywood (1988) Ch. 12 | [`thermodynamics.md`](thermodynamics.md) §4 |
| `EnhancedHeatTransfer.h` | Woschni (1967) SAE 670931; Hohenberg (1979) SAE 790825; Annand (1963) Proc. IMechE 177(1) | [`thermodynamics.md`](thermodynamics.md) §4 |
| `KnockModel.h`, `KnockPredictor.h` | Livengood & Wu (1955); Douaud & Eyzat (1978) SAE 780080; Heywood (1988) Ch. 9 | [`thermodynamics.md`](thermodynamics.md) §3, [`limitations.md`](limitations.md) |
| `SliderCrankKinematics.h` | Heywood (1988) §2.3 Eqs. 2.7–2.12; Norton (2011) | [`mechanical.md`](mechanical.md) §2, [`crank_slider_kinematics.md`](crank_slider_kinematics.md) |
| `ForceAnalysis.h` | Heywood (1988) §2.3.3, §2.4 | [`mechanical.md`](mechanical.md) §3, [`force_analysis.md`](force_analysis.md) |
| `ChenFlynnFrictionModel.h` | Chen & Flynn (1965) SAE 650733 | [`mechanical.md`](mechanical.md) §5, [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) |
| `FrictionModel.h` (Phase 1–4) | Vogel viscosity (Heywood Ch. 13); Tian (2002) SAE 2002-01-0483; Ma et al. (1997) SAE 970836; Teodorescu et al. (2002) SAE 2002-01-0484 | [`mechanical.md`](mechanical.md) §6 |
| `OilGradeLibrary.h`, `OilProperties` | Vogel viscosity equation; SAE J300 grade definitions (industry-standard) | [`mechanical.md`](mechanical.md) §6, §7 |
| `Turbocharger.h`, `CompressorMap.h` | Watson & Janota (1982) | [`limitations.md`](limitations.md) (forced-induction partials) |
| `EnvironmentalCorrection.h` (`src/dyno/`) | SAE J1349; DIN 70020 | §7 above |

---

## 9. Cross-references and further reading

- [`otto_cycle_assumptions.md`](otto_cycle_assumptions.md) — the assumption list for the validated Otto baseline.
- [`limitations.md`](limitations.md) — cross-cutting modeling caveats; the canonical place to check whether a given correlation is on the validated path.
- [`thermodynamics.md`](thermodynamics.md) — developer-oriented entry point to the in-cylinder thermodynamic stack.
- [`mechanical.md`](mechanical.md) — developer-oriented entry point to the mechanical-simulation stack.
- [`crank_slider_kinematics.md`](crank_slider_kinematics.md) — full slider-crank derivation, error tables, validation traces.
- [`force_analysis.md`](force_analysis.md) — bearing-load decomposition, side-force major/minor thrust geometry, instantaneous power balance.
- [`chen_flynn_friction_model.md`](chen_flynn_friction_model.md) — Chen–Flynn coefficient catalog, descriptive per-component breakdown percentages, calibration ranges, §10.6 known limitations.
- [`../user_guide/physics_models.md`](../user_guide/physics_models.md) — user-facing rather than developer-facing view of which models PISTON runs and how to select them.

For institutional access to the SAE papers cited above, see the SAE International digital library; for the NIST thermochemical data referenced by `MixtureProperties.h`, see the NIST Chemistry WebBook.
