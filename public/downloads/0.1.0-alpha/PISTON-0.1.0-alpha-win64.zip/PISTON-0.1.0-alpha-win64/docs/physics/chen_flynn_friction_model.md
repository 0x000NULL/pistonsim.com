# Chen-Flynn Friction Model for Internal Combustion Engines

**Document Version:** 1.0
**Date:** October 29, 2025
**Author:** PISTON Development Team

---

## Table of Contents

1. [Overview](#overview)
2. [Physics Background](#physics-background)
3. [Mathematical Formulation](#mathematical-formulation)
4. [Friction Components](#friction-components)
5. [FMEP Calculation](#fmep-calculation)
6. [Temperature and Viscosity Effects](#temperature-and-viscosity-effects)
7. [Reference Sources](#reference-sources)
8. [Implementation Guide](#implementation-guide)
9. [Typical Coefficient Values](#typical-coefficient-values)
10. [Validation Approach](#validation-approach)

---

## 1. Overview

The **Chen-Flynn friction model** is an empirical correlation developed by Chen and Flynn in 1965 (SAE Paper 650733) to predict Friction Mean Effective Pressure (FMEP) in internal combustion engines. The model remains widely used in engine simulation due to its simplicity and reasonable accuracy (typically within 10% when properly calibrated).

### Key Characteristics

- **Empirical model** based on experimental motoring test data
- **Speed-dependent** through quadratic relationship with mean piston speed
- **Load-dependent** through linear relationship with peak cylinder pressure
- **Engine-specific coefficients** requiring calibration for different designs
- **Suitable for enthusiast-level simulation** when targeting <10% accuracy

### Scope of Application

- **Best for:** Steady-state engine performance prediction
- **Applicable to:** Gasoline and diesel engines (with different coefficients)
- **Limitations:**
  - Does not account for modern fuel injection strategies (GDI, common rail)
  - Does not model transient friction behavior
  - Requires experimental calibration for high accuracy
  - Limited accuracy for advanced variable valve timing systems

---

## 2. Physics Background

### 2.1 Friction Mean Effective Pressure (FMEP)

FMEP represents the mean effective pressure "lost" to friction and other parasitic losses in the engine. It is the difference between indicated and brake performance:

```
BMEP = IMEP - FMEP
```

Where:
- **BMEP** = Brake Mean Effective Pressure (actual output at crankshaft)
- **IMEP** = Indicated Mean Effective Pressure (work from combustion)
- **FMEP** = Friction Mean Effective Pressure (all losses)

### 2.2 Components of FMEP

FMEP encompasses several loss mechanisms:

1. **Mechanical rubbing friction** (60-70% of total):
   - Piston assembly (rings, skirt, pin)
   - Crankshaft bearings (main and rod)
   - Valve train (cam followers, valve springs)

2. **Pumping losses** (15-25% of total):
   - Intake and exhaust flow resistance
   - Throttling losses (SI engines)

3. **Auxiliary losses** (10-20% of total):
   - Oil pump
   - Water pump
   - Fuel pump
   - Alternator (if included)

### 2.3 Friction Distribution by Component

Based on experimental studies (Heywood, 1988; Sandoval & Heywood, 2003):

| Component | Percentage of Total FMEP |
|-----------|---------------------------|
| Piston assembly | 45-50% |
| Crankshaft system (main bearings) | 15-20% |
| Connecting rod system (rod bearings) | 15-18% |
| Valve train system | 15-20% |
| Auxiliary devices | 5-10% |

**Note:** Piston assembly is the dominant friction source, with piston rings alone accounting for ~35% of total engine friction.

---

## 3. Mathematical Formulation

### 3.1 Chen-Flynn Base Equation

The Chen-Flynn correlation expresses FMEP as a function of peak cylinder pressure and mean piston speed:

```
FMEP = A + B·Pmax + C·Cm + D·Cm²
```

**Where:**
- `FMEP` = Friction Mean Effective Pressure [bar or kPa]
- `A` = Constant term [bar] - accounts for auxiliary losses and invariant friction
- `B` = Pressure coefficient [-] - accounts for load-dependent friction
- `C` = Linear speed coefficient [bar·s/m] - accounts for viscous friction
- `D` = Quadratic speed coefficient [bar·s²/m²] - accounts for inertial effects
- `Pmax` = Maximum cylinder pressure [bar]
- `Cm` = Mean piston speed [m/s]

### 3.2 Alternative Formulation (Speed Factor)

Some implementations use a "speed factor" formulation:

```
FMEP = A + B·Pmax + C·Sf + D·Sf²
```

**Where:**
- `Sf = (ω·S)/2` = Speed factor [rad·m/s]
- `ω` = Engine angular velocity [rad/s] = `2π·RPM/60`
- `S` = Piston stroke [m]

**Relationship:** `Sf = π·Cm` (since `Cm = 2·S·N/60 = (ω·S)/π`)

### 3.3 Mean Piston Speed Calculation

Mean piston speed is the average velocity of the piston:

```
Cm = 2·S·N / 60
```

**Where:**
- `Cm` = Mean piston speed [m/s]
- `S` = Stroke length [m]
- `N` = Engine speed [RPM]

**Example:** For a 90mm stroke at 3000 RPM:
```
Cm = 2 × 0.090 × 3000 / 60 = 9.0 m/s
```

### 3.4 Mechanical Efficiency

Mechanical efficiency relates directly to FMEP:

```
ηm = 1 - (FMEP / IMEP)
```

Or equivalently:

```
ηm = BMEP / IMEP
```

**Typical values:**
- Modern gasoline engines: ηm = 0.85-0.92 (FMEP ≈ 0.8-1.5 bar)
- Diesel engines: ηm = 0.80-0.88 (FMEP ≈ 1.0-2.0 bar)

---

## 4. Friction Components

### 4.1 Piston Assembly Friction (45-50% of total)

The piston assembly includes rings, skirt, and pin. Friction varies dramatically through the engine cycle.

#### 4.1.1 Piston Ring Friction

**Three lubrication regimes** occur during the engine cycle:

1. **Hydrodynamic (mid-stroke):**
   - Oil film thickness: 2-10 μm
   - Friction coefficient: μ = 0.001-0.002
   - Viscous shear dominates
   - Friction ∝ √(viscosity)

2. **Mixed (approaching stroke ends):**
   - Oil film thickness: 0.5-2 μm
   - Friction coefficient: μ = 0.02-0.08
   - Both viscous and asperity contact
   - Transition zone on Stribeck curve

3. **Boundary (TDC/BDC):**
   - Oil film thickness: <0.5 μm
   - Friction coefficient: μ = 0.08-0.12
   - Metal-to-metal contact (with boundary additives)
   - Highest friction zone

**Ring-specific contributions:**
- Top compression ring: ~50% of ring pack friction
- Second compression ring: ~30% of ring pack friction
- Oil control ring: ~20% of ring pack friction

#### 4.1.2 Piston Skirt Friction

The piston experiences lateral forces (thrust/anti-thrust) causing skirt contact:

- **Major thrust side:** Load up to 12,000 N (high-performance engines)
- **Minor thrust side:** Load ~3,000 N (10× less than major thrust)
- **Friction regime:** Primarily mixed lubrication
- **Design impact:** Asymmetric skirts reduce friction by ~5-10%

**Lateral force calculation:**
```
Flateral = Fgas·tan(β)
```

Where `β` is the connecting rod angle from vertical.

#### 4.1.3 Piston Pin (Wrist Pin) Friction

- **Lubrication:** Hydrodynamic (oscillating bearing)
- **Contribution:** ~5% of piston assembly friction
- **Typical coefficient:** μ = 0.002-0.005

### 4.2 Crankshaft Bearing Friction (15-20% of total)

#### 4.2.1 Main Bearings

Journal bearings operating in hydrodynamic regime:

**Petroff's equation (approximation for light loads):**
```
Ff = 2π²·μ·N·R³·L / c
```

Where:
- `Ff` = Friction force [N]
- `μ` = Dynamic viscosity [Pa·s]
- `N` = Rotational speed [rev/s]
- `R` = Journal radius [m]
- `L` = Bearing length [m]
- `c` = Radial clearance [m]

**More accurate:** Solve Reynolds equation numerically for pressure distribution.

**Temperature effects:**
- Bearing temperatures: 80-120°C typical
- Oil viscosity decreases exponentially with temperature
- Heat transfer critical for prediction

#### 4.2.2 Connecting Rod Bearings

Similar to main bearings but with:
- **Oscillating loads** (not pure rotation)
- **Higher peak pressures** (up to 80-100 MPa)
- **More severe lubrication challenges** near TDC firing

**Load distribution:**
- Maximum load occurs ~10-15° ATDC (firing stroke)
- Load reversal occurs during intake/exhaust
- Minimum film thickness: 1-3 μm (typical)

### 4.3 Valve Train Friction (15-20% of total)

#### 4.3.1 Cam-Follower Contact

**80% of valve train friction** occurs at cam-follower interface:

- **Sliding friction** at cam nose (highest point)
- **Lubrication regime:** Mixed/boundary
- **Peak contact pressure:** 0.5-2.0 GPa
- **Hertzian contact stress** calculations required

**Types of followers:**
- **Flat tappet:** Higher friction (sliding contact)
- **Roller follower:** Lower friction (rolling contact, reduces by ~30%)
- **Bucket follower:** Intermediate

#### 4.3.2 Valve Spring Force Effects

Spring force increases friction at cam nose:

```
Fcam = Fspring + Finertia
```

Where:
- `Fspring` = Spring preload + compression force
- `Finertia` = m·a (valve mass × acceleration)

**High-performance implications:**
- Stiffer springs required for high RPM
- Increases friction at low RPM (where inertia is low)
- Trade-off between valve control and friction

#### 4.3.3 Valve Guide and Seal Friction

- **Contribution:** ~10% of valve train friction
- **Temperature sensitive:** Clearances change with thermal expansion
- **Oil consumption:** Related to seal friction/quality

**Typical FMEP from valve train:** 0.1-0.3 bar (at low RPM, higher percentage)

### 4.4 Auxiliary Losses (5-10% of total)

#### 4.4.1 Oil Pump

- **Mechanical pump:** Crankshaft-driven (always on)
- **Power consumption:** 1-5 HP (depends on pressure and flow)
- **Speed-dependent:** Linear with RPM

**Simplified model:**
```
Poil_pump = Δp·Q / ηpump
```

Where:
- `Δp` = Pressure rise [Pa]
- `Q` = Flow rate [m³/s]
- `ηpump` = Pump efficiency (0.7-0.85)

#### 4.4.2 Water Pump

- **Power consumption:** 0.5-3 HP
- **Speed-dependent:** Cubic relationship (centrifugal pump)

**Centrifugal pump power:**
```
Pwater = ρ·g·Q·H / ηpump
```

Where `H` is head [m], typically 5-15 m for automotive.

#### 4.4.3 Other Accessories

**Often NOT included in FMEP:**
- Alternator (electrical load varies)
- Power steering pump (load varies)
- Air conditioning compressor (on/off)
- Cooling fan (speed varies)

**Modeling decision for PISTON:** Include oil and water pumps only; exclude variable electrical loads.

---

## 5. FMEP Calculation

### 5.1 Total FMEP Calculation

**Method 1: Chen-Flynn empirical correlation**
```
FMEP_total = A + B·Pmax + C·Cm + D·Cm²
```

**Method 2: Component summation** (more detailed but complex)
```
FMEP_total = FMEP_piston + FMEP_bearings + FMEP_valvetrain + FMEP_aux
```

### 5.2 Relationship to BMEP

Brake Mean Effective Pressure is the actual power output:

```
BMEP = IMEP - FMEP
```

And brake power:

```
Pb = BMEP · Vd · N / (2·nR·60)
```

Where:
- `Pb` = Brake power [W]
- `Vd` = Displacement [m³]
- `N` = Engine speed [RPM]
- `nR` = Number of crank revolutions per power stroke (2 for 4-stroke)

### 5.3 Converting FMEP to Friction Torque

Friction torque can be calculated from FMEP:

```
Tf = FMEP · Vd / (4·π)
```

For a 4-stroke engine. Units: [Nm] if FMEP in [Pa] and Vd in [m³].

**Example:** 2.0L engine, FMEP = 1.0 bar = 100 kPa:
```
Tf = 100000 × 0.002 / (4π) = 15.9 Nm
```

### 5.4 Friction Power Loss

Total friction power:

```
Pf = Tf · ω = FMEP · Vd · N / (2·60)
```

**Example:** Same engine at 3000 RPM:
```
Pf = 15.9 × (2π × 3000/60) = 4990 W ≈ 6.7 HP
```

---

## 6. Temperature and Viscosity Effects

### 6.1 Oil Viscosity-Temperature Relationship

Oil viscosity decreases exponentially with temperature, following the **Vogel equation**:

```
μ(T) = A · exp(B / (T - C))
```

Or the simpler **Walther equation** (ASTM D341):

```
log₁₀(log₁₀(ν + 0.7)) = A - B·log₁₀(T)
```

Where:
- `ν` = Kinematic viscosity [cSt]
- `T` = Temperature [K]
- `A, B, C` = Oil-specific constants

### 6.2 Typical Viscosity Values

**SAE 10W-30 motor oil:**

| Temperature | Kinematic Viscosity | Dynamic Viscosity |
|-------------|---------------------|-------------------|
| 40°C | 60-70 cSt | ~54 mPa·s |
| 100°C | 10-12 cSt | ~9 mPa·s |
| 150°C | 3-4 cSt | ~2.5 mPa·s |

**SAE 5W-20 motor oil:**

| Temperature | Kinematic Viscosity | Dynamic Viscosity |
|-------------|---------------------|-------------------|
| 40°C | 45-50 cSt | ~40 mPa·s |
| 100°C | 8-9 cSt | ~7 mPa·s |
| 150°C | 2.5-3 cSt | ~2 mPa·s |

**Relationship:** `μ = ν · ρ` (dynamic = kinematic × density)

Oil density: ~850-900 kg/m³ (decreases with temperature)

### 6.3 Temperature Distribution in Engine

**Typical operating temperatures:**

| Location | Temperature Range |
|----------|-------------------|
| Piston crown | 250-350°C |
| Piston rings | 150-250°C |
| Cylinder wall (top) | 180-220°C |
| Cylinder wall (mid) | 100-140°C |
| Main bearings | 80-120°C |
| Oil sump | 90-110°C |
| Coolant | 85-95°C |

**Friction impact:**
- **Cold start:** High viscosity → High hydrodynamic friction (2-3× normal)
- **Warm operation:** Optimal viscosity balance
- **Hot operation:** Low viscosity → Risk of boundary lubrication

### 6.4 Viscosity Effect on Friction

**Hydrodynamic friction** (mid-stroke piston, bearings):
```
Ff ∝ √μ  (approximately)
```

More precisely from lubrication theory:
```
Ff = η·U·A / h
```

Where:
- `η` = Dynamic viscosity
- `U` = Sliding velocity
- `A` = Contact area
- `h` = Film thickness

**Boundary friction** (TDC/BDC):
- **Independent of viscosity** (metal-to-metal contact)
- Depends on surface finish, coatings, additives

**Design trade-off:**
- Lower viscosity → Lower hydrodynamic friction → Better fuel economy
- Lower viscosity → Risk of boundary contact → Increased wear
- Modern trend: 0W-20, 5W-20 oils for fuel economy

### 6.5 Simplified Temperature Correction

For quick estimation without full thermal model:

```
FMEP(T) = FMEP(T_ref) · [μ(T) / μ(T_ref)]^0.5
```

Where the exponent 0.5 represents the square-root dependency for hydrodynamic friction.

**Note:** This is approximate and only valid for hydrodynamic-dominated conditions.

---

## 7. Reference Sources

### 7.1 Primary References

1. **Chen, S. K., and Flynn, P. F.** (1965). *"Development of a Single Cylinder Compression Ignition Research Engine."* SAE Technical Paper 650733.
   - **Original Chen-Flynn model** formulation

2. **Heywood, J. B.** (1988). *Internal Combustion Engine Fundamentals.* McGraw-Hill, New York.
   - **Chapter 13:** Friction and Lubrication (pages 721-760)
   - Comprehensive friction component breakdown
   - Experimental friction data and correlations

3. **Patton, K. J., Nitschke, R. G., and Heywood, J. B.** (1989). *"Development and Evaluation of a Friction Model for Spark-Ignition Engines."* SAE Technical Paper 890836.
   - **Patton-Nitschke-Heywood (PNH) model**
   - Component-based approach
   - Includes auxiliary losses

4. **Sandoval, D., and Heywood, J. B.** (2003). *"An Improved Friction Model for Spark-Ignition Engines."* SAE Technical Paper 2003-01-0725.
   - **Updated PNH model** for modern engines
   - Accounts for improved oils and surface finishes
   - More accurate than Chen-Flynn for modern SI engines

5. **Ferguson, C. R., and Kirkpatrick, A. T.** (2015). *Internal Combustion Engines: Applied Thermosciences.* 3rd Edition, Wiley.
   - **Chapter 10:** Friction and Lubrication
   - Design-oriented friction analysis

6. **Stone, R.** (2012). *Introduction to Internal Combustion Engines.* 4th Edition, Palgrave Macmillan.
   - **Section 11.4:** Mechanical Losses
   - Practical friction data

### 7.2 Component-Specific References

**Piston Ring Friction:**
- Tian, T. (2002). *"Dynamic Behaviors of Piston Rings and Their Practical Impact."* SAE 2002-01-0483.
- Ma, M. T., et al. (1997). *"Analysis of Lubrication and Friction for a Complete Piston-Ring Pack with an Improved Oil Availability Model."* SAE 970836.

**Bearing Friction:**
- Booker, J. F. (1965). *"Dynamically Loaded Journal Bearings: Mobility Method of Solution."* ASME Journal of Basic Engineering.
- Stachowiak, G. W., and Batchelor, A. W. (2014). *Engineering Tribology.* 4th Edition, Butterworth-Heinemann.

**Valve Train Friction:**
- Teodorescu, M., et al. (2002). *"Experimental Investigation of Engine Valve Train Friction."* SAE 2002-01-0484.
- Dyson, A. (1980). *"Kinematics and Wear Patterns of Cam and Finger Follower Automotive Valve Gear."* Tribology International.

### 7.3 Friction Model Comparisons

- **Pipitone, E., et al.** (2009). *"A New Simple Friction Model for S. I. Engine."* SAE 2009-01-1984.
  - Compares Chen-Flynn, Rezeka-Henein, and Bishop models
  - Proposes improved correlation

- **Taraza, D., et al.** (2000). *"Friction Losses in Multi-Cylinder Diesel Engines."* SAE 2000-01-0921.
  - Diesel-specific friction analysis
  - Component breakdown

### 7.4 Online Resources

- **x-engineer.org:** [Mechanical Efficiency and FMEP](https://x-engineer.org/mechanical-efficiency-friction-mean-effective-pressure-fmep/)
  - Excellent visual explanations and examples

- **HPWizard.com:** [FMEP Calculator](https://hpwizard.com/fmep.html)
  - Interactive friction calculations

### 7.5 Academic Theses

- **Livanos, G. A.** (2002). *"A Friction Prediction Model for Small SI Engines."* Master's Thesis, Missouri University of Science and Technology.
  - Detailed implementation of friction models
  - Experimental validation

---

## 8. Implementation Guide

### 8.1 Recommended Implementation Strategy for PISTON

**Phase 1: Simple Chen-Flynn Model**
- Use empirical Chen-Flynn correlation
- Single set of coefficients (calibrated to typical gasoline engine)
- Constant oil temperature assumption (100°C)
- **Target accuracy:** 15-20%

**Phase 2: Component-Based Model**
- Separate calculations for piston, bearings, valve train
- Temperature-dependent viscosity
- Oil temperature from thermal model
- **Target accuracy:** 10-15%

**Phase 3: Advanced Model**
- Instantaneous friction (per crank angle)
- Lubrication regime transitions (Stribeck curve)
- Thermal network for component temperatures
- **Target accuracy:** <10%

### 8.2 Phase 1 Implementation (Recommended for MVP)

**Input Parameters:**
```cpp
struct FrictionInputs {
    double Pmax;           // Maximum cylinder pressure [Pa]
    double rpm;            // Engine speed [RPM]
    double stroke;         // Piston stroke [m]
    double displacement;   // Engine displacement [m³]
};
```

**Chen-Flynn Coefficients:**
```cpp
struct ChenFlynnCoefficients {
    double A;  // Constant term [Pa]
    double B;  // Pressure coefficient [-]
    double C;  // Linear speed coefficient [Pa·s/m]
    double D;  // Quadratic speed coefficient [Pa·s²/m²]
};
```

**Calculation Function:**
```cpp
double calculateFMEP(const FrictionInputs& inputs,
                     const ChenFlynnCoefficients& coeffs) {
    // Calculate mean piston speed [m/s]
    double Cm = 2.0 * inputs.stroke * inputs.rpm / 60.0;

    // Chen-Flynn correlation [Pa]
    double FMEP = coeffs.A
                + coeffs.B * inputs.Pmax
                + coeffs.C * Cm
                + coeffs.D * Cm * Cm;

    return FMEP;
}

double calculateFrictionTorque(double FMEP, double displacement) {
    // Convert FMEP to friction torque [Nm]
    return FMEP * displacement / (4.0 * M_PI);
}

double calculateFrictionPower(double frictionTorque, double rpm) {
    // Calculate friction power [W]
    double omega = 2.0 * M_PI * rpm / 60.0;  // [rad/s]
    return frictionTorque * omega;
}
```

### 8.3 Coefficient Calibration Strategy

**Option 1: Literature Values (Quick Start)**
- Use typical coefficients from published studies
- Accept 15-20% error
- Good for initial development

**Option 2: Scaling from Similar Engine**
- Find published coefficients for similar engine
- Scale based on displacement, stroke, bore
- Moderate effort, 10-15% error

**Option 3: Experimental Calibration (Best Accuracy)**
- Motoring test data required (engine motored without combustion)
- Measure torque vs. RPM at various throttle positions
- Regression analysis to determine A, B, C, D
- Labor-intensive but <10% error achievable

### 8.4 Unit Conversions

**Pressure units:**
```cpp
// Chen-Flynn equation expects consistent units
// If using bar (common in literature):
const double BAR_TO_PA = 1e5;

// Example coefficient conversion
ChenFlynnCoefficients coeffs_bar = {0.30, 0.006, 0.05, 8.5e-5};
ChenFlynnCoefficients coeffs_Pa = {
    coeffs_bar.A * BAR_TO_PA,              // 30000 Pa
    coeffs_bar.B,                          // 0.006 (dimensionless)
    coeffs_bar.C * BAR_TO_PA,              // 5000 Pa·s/m
    coeffs_bar.D * BAR_TO_PA               // 8.5 Pa·s²/m²
};
```

### 8.5 Validation Approach

**Level 1: Sanity Checks**
```cpp
// FMEP should be positive and reasonable
assert(FMEP > 0);
assert(FMEP < 5e5);  // < 5 bar (extremely high friction)

// Mechanical efficiency should be reasonable
double mech_eff = 1.0 - (FMEP / IMEP);
assert(mech_eff > 0.7 && mech_eff < 0.95);

// Friction torque proportional to displacement
double Tf_per_liter = frictionTorque / (displacement * 1000);
assert(Tf_per_liter > 5.0 && Tf_per_liter < 15.0);  // [Nm/L]
```

**Level 2: Comparison to Published Data**
- Compare FMEP vs. RPM curve to literature
- Check FMEP vs. BMEP trends
- Verify mechanical efficiency values

**Level 3: Dyno Validation**
- Compare predicted brake power to actual dyno results
- Iterate coefficients to minimize error
- Target: <10% error across RPM range

### 8.6 Edge Cases and Numerical Stability

**Low-speed behavior:**
```cpp
// At very low RPM, quadratic term can be neglected
if (rpm < 500) {
    // Use simplified model or limit extrapolation
    FMEP = coeffs.A + coeffs.B * Pmax;
}
```

**High-speed behavior:**
```cpp
// At high RPM, friction increases rapidly
// Ensure coefficients don't predict negative BMEP
if (FMEP > 0.5 * IMEP) {
    // Warning: friction consumes >50% of indicated work
    logWarning("Excessive friction predicted");
}
```

**Zero or negative Pmax:**
```cpp
// During motoring or deceleration
if (Pmax <= 0) {
    // Use speed-dependent terms only
    FMEP = coeffs.A + coeffs.C * Cm + coeffs.D * Cm * Cm;
}
```

---

## 9. Typical Coefficient Values

### 9.1 Chen-Flynn Coefficients for Gasoline Engines

Two kinds of set exist in the code, and they are labeled honestly:

**The legacy tuned default** (`gasoline_performance`, used by every config that sets no
`mechanical.friction_class`): `A = 35,000 Pa, B = 0.005, C = 10,000 Pa·s/m, D = 140
Pa·s²/m²`. This set is **not literature-derived**: its speed terms carry roughly twice the
Sandoval-Heywood rubbing-plus-auxiliary friction at high speed, which compensates
overprediction elsewhere in the model. Swapping the cited sets below in fleet-wide
nearly doubled the measured fleet power error (the exact before/after figures live in the
landing commit's message and the generated report) -- the decompensation is recorded in the
open backlog item, and the default stays until the compensated defects land.

**Cited per-class sets**, derived from the Sandoval-Heywood component FMEP correlations
(D. Sandoval, *An Improved Friction Model for Spark Ignition Engines*, MIT M.S. thesis,
2002; published as Sandoval & Heywood, SAE 2003-01-0725) evaluated at class-representative
fleet geometry, rubbing + auxiliaries only (PISTON subtracts pumping separately), then
least-squares fitted to the Chen-Flynn form. The derivation -- component equations 7.b,
8.b/9.b, 10.b (valvetrain constants from the thesis's Table 4.2), 11; assumptions;
anchor points; fit residuals under 0.3 kPa -- is committed as
`tools/derive_friction_classes.py`; run it to reproduce this table:

| `mechanical.friction_class` | Representative | A [Pa] | B [-] | C [Pa·s/m] | D [Pa·s²/m²] |
|---|---|--:|--:|--:|--:|
| `gasoline_pushrod_2v` | LS3-class OHV V8 | 53,925 | 0.00200 | 2,762 | 78.0 |
| `gasoline_dohc_4v` | modern DOHC 16v+ | 57,267 | 0.00192 | 3,720 | 79.3 |
| `gasoline_sohc_2v` | L28E-class SOHC | 59,957 | 0.00259 | 4,187 | 100.3 |
| `side_valve` | flathead (geometry only; era effects stay in `fmep_coefficient`) | 52,480 | 0.00344 | 2,843 | 117.5 |

The B coefficient is derived from the correlation's ring gas-loading term mapped from
intake to peak pressure (the mapping is an estimate and the script states it); bearing
dimensions are not in engine configs and use stated proportional estimates, which enter
linearly and move the totals by a few percent -- inside the correlation's own 15-20%
literature-calibration band (section 8.3).

### 9.2 Chen-Flynn Coefficients for Diesel Engines

Diesel engines typically have **higher friction** due to:
- Higher compression ratios → Higher Pmax
- Heavier construction (higher reciprocating mass)
- Higher injection pressures

#### Typical Light-Duty Diesel
```
A = 0.40 bar = 40,000 Pa
B = 0.004 [-]
C = 0.08 bar·s/m = 8,000 Pa·s/m
D = 1.0e-4 bar·s²/m² = 10.0 Pa·s²/m²
```

**Typical FMEP range:** 1.5-2.5 bar

#### Heavy-Duty Diesel (Large Displacement)
```
A = 0.50 bar = 50,000 Pa
B = 0.003 [-]
C = 0.10 bar·s/m = 10,000 Pa·s/m
D = 1.2e-4 bar·s²/m² = 12.0 Pa·s²/m²
```

### 9.3 Coefficient Physical Interpretation

**A (Constant Term):**
- Represents **auxiliary losses** and invariant friction
- Includes oil pump, water pump baseline
- Typical range: 0.15-0.50 bar
- **Lower values:** Efficient accessories, variable displacement pumps
- **Higher values:** Fixed-displacement pumps, older designs

**B (Pressure Coefficient):**
- Represents **load-dependent friction** (ring/bearing pressure)
- Higher combustion pressure increases ring-liner contact load
- Typical range: 0.003-0.008
- **Lower values:** Low-tension rings, good lubrication
- **Higher values:** High ring tension, boundary lubrication

**C (Linear Speed Coefficient):**
- Represents **viscous friction** in hydrodynamic regime
- Dominant at moderate speeds
- Typical range: 0.03-0.10 bar·s/m
- **Lower values:** Low-viscosity oil, good surface finish
- **Higher values:** High-viscosity oil, rough surfaces

**D (Quadratic Speed Coefficient):**
- Represents **inertial and turbulent effects** at high speed
- Becomes important above ~4000 RPM
- Range depends on how the fit splits speed dependence between C and D: literature
  quotes with most speed dependence in C carry D near 5e-5 to 1.5e-4 bar·s²/m²,
  while the fitted sets in this codebase (section 9.1) carry 78-150 Pa·s²/m² --
  the code's validator bounds follow the fitted convention
- **Lower values:** Lightweight reciprocating components
- **Higher values:** Heavy components, high piston speeds

### 9.4 Example Calculations

**Example Engine Specifications:**
- Displacement: 2.0 L = 0.002 m³
- Bore: 86 mm
- Stroke: 86 mm
- Compression ratio: 10.5:1
- Peak cylinder pressure: 80 bar = 8 MPa (typical for SI)

**Operating Point:** 3000 RPM, WOT

**Step 1: Calculate mean piston speed**
```
Cm = 2 × 0.086 × 3000 / 60 = 8.6 m/s
```

**Step 2: Apply Chen-Flynn correlation (typical SI coefficients)**
```
FMEP = 0.30 + 0.006×80 + 0.05×8.6 + 8.5e-5×8.6²
     = 0.30 + 0.48 + 0.43 + 0.0063
     = 1.22 bar = 122 kPa
```

**Step 3: Calculate friction torque**
```
Tf = FMEP × Vd / (4π)
   = 122000 × 0.002 / (4π)
   = 19.4 Nm
```

**Step 4: Calculate friction power loss**
```
Pf = Tf × ω
   = 19.4 × (2π × 3000/60)
   = 6100 W = 8.2 HP
```

**Step 5: Check mechanical efficiency**
```
Assume IMEP = 12 bar (typical for WOT)
ηm = 1 - (1.22 / 12) = 0.899 = 89.9%
```

This is reasonable for a modern gasoline engine. (The D term previously read 0.063 bar -- a factor-of-ten arithmetic slip; 8.5e-5 x 8.6^2 = 0.0063 bar, and the totals above now follow.)

---

## 10. Validation Approach

### 10.1 Data Sources for Validation

**Level 1: Published Literature Data**
- Heywood (1988): Chapter 13, Figures 13.2-13.8
- Sandoval & Heywood (2003): Updated friction data
- SAE papers with motoring test results
- **Advantage:** Free, readily available
- **Disadvantage:** Generic engines, limited detail

**Level 2: Manufacturer Technical Data**
- OEM workshop manuals (friction torque specs)
- Technical bulletins
- **Advantage:** Specific to production engines
- **Disadvantage:** Limited availability, incomplete

**Level 3: Dyno Testing Data**
- Chassis dyno (measures wheel HP)
- Engine dyno (measures crank HP directly)
- **Advantage:** Real-world validation
- **Disadvantage:** Requires access to dyno, expensive

**Level 4: Motoring Test Data (Gold Standard)**
- Engine motored (no combustion) across RPM range
- Direct measurement of friction
- **Advantage:** Most accurate for coefficient calibration
- **Disadvantage:** Requires disassembly, specialized equipment

### 10.2 Validation Metrics

**Primary Metric: FMEP vs. RPM**
```
Compare predicted FMEP curve to measured/published data
Acceptable error: ±10-15% across RPM range
```

**Secondary Metric: Mechanical Efficiency**
```
ηm = BMEP / IMEP
Typical range: 85-92% for modern SI engines
```

**Tertiary Metric: Friction Breakdown**
```
Validate piston/bearing/valvetrain percentages against literature
```

### 10.3 Validation Test Cases

#### Test Case 1: Idle (800 RPM)
```
Expected FMEP: 0.5-0.8 bar
Dominated by auxiliary losses (A term)
Low Pmax (throttled)
```

#### Test Case 2: Cruise (2500 RPM, Part Throttle)
```
Expected FMEP: 0.9-1.2 bar
Moderate Pmax (~5-7 bar)
Viscous friction significant
```

#### Test Case 3: WOT Mid-Range (4000 RPM)
```
Expected FMEP: 1.3-1.8 bar
High Pmax (~80 bar)
High Cm (piston speed)
All terms contribute
```

#### Test Case 4: Redline (6500 RPM)
```
Expected FMEP: 2.0-2.8 bar
Maximum Cm
Quadratic term (D) becomes important
Risk of friction limiting power
```

### 10.4 Sensitivity Analysis

**Vary each coefficient ±20% and observe effect:**

| Coefficient | ±20% Change Impact | Most Sensitive Condition |
|-------------|-------------------|--------------------------|
| A | ±0.06 bar FMEP | Low RPM, low load |
| B | ±10-15% FMEP | High load (WOT) |
| C | ±8-12% FMEP | Mid-range RPM |
| D | ±5-20% FMEP | High RPM (>5000) |

**Conclusion:**
- **B coefficient** most critical for accuracy at WOT (enthusiast focus)
- **C coefficient** important for part-throttle efficiency
- **D coefficient** critical for high-RPM accuracy

### 10.5 Recommended Validation Workflow for PISTON

**Step 1: Implement with literature coefficients**
```
Use "typical gasoline" values from Section 9.1
```

**Step 2: Smoke test**
```
Verify FMEP is positive and reasonable (0.5-3.0 bar)
Check mechanical efficiency (80-95%)
```

**Step 3: Compare to published curves**
```
Plot FMEP vs. RPM
Overlay with Heywood Figure 13.5 or similar
Adjust coefficients if gross mismatch (>30% error)
```

**Step 4: Dyno validation (if available)**
```
Run actual engine on dyno (brake power)
Compare to simulation (IMEP - FMEP)
Iterate coefficients to minimize RMS error
```

**Step 5: Document and lock coefficients**
```
Save calibrated coefficients in configuration file
Document assumptions and limitations
Note expected accuracy (10-15% typical)
```

### 10.6 Known Limitations and Mitigation

**Limitation 1: Empirical Model (No Physics)**
- Chen-Flynn is curve-fit, not first-principles
- **Mitigation:** Use for trends, not absolute values
- **Mitigation:** Validate against multiple data sources

**Limitation 2: Steady-State Only**
- Does not model transient friction (acceleration)
- **Mitigation:** Acceptable for dyno sweep simulation
- **Future work:** Add transient correction factors

**Limitation 3: Temperature Dependency Not Explicit**
- Coefficients implicitly assume oil temperature ~100°C
- **Mitigation:** Document assumption clearly
- **Phase 2:** Add temperature correction factor

**Limitation 4: Engine-Specific Calibration**
- Coefficients valid only for similar engine designs
- **Mitigation:** Provide multiple coefficient sets
- **User guidance:** How to adapt for custom builds

**Limitation 5: Modern Technology Gap**
- Original model from 1965, predates:
  - Direct injection (GDI)
  - Variable valve timing (VVT)
  - Cylinder deactivation
  - Advanced coatings (DLC, thermal barriers)
- **Mitigation:** Use updated models (Sandoval-Heywood) if needed
- **Acceptable:** For enthusiast builds, older tech often applies

---

## Summary for Implementation

### Quick Reference Card

**Chen-Flynn Equation:**
```
FMEP [Pa] = A + B·Pmax + C·Cm + D·Cm²
```

**Typical Gasoline Engine Coefficients (Modern):**
```
A = 25,000 Pa    (auxiliary losses)
B = 0.005        (load effect)
C = 4,000 Pa·s/m (viscous friction)
D = 7.0 Pa·s²/m² (inertial effects)
```

**Mean Piston Speed:**
```
Cm [m/s] = 2 × Stroke [m] × RPM / 60
```

**Friction Torque:**
```
Tf [Nm] = FMEP [Pa] × Vd [m³] / (4π)
```

**Mechanical Efficiency:**
```
ηm = 1 - (FMEP / IMEP)
```

**Expected Values:**
- FMEP: 0.8-2.0 bar (gasoline), 1.5-2.5 bar (diesel)
- Mechanical efficiency: 85-92% (modern SI engines)
- Piston assembly: 45-50% of total friction
- Bearings: 30-35% of total friction
- Valve train: 15-20% of total friction

### Implementation Priority for PISTON MVP

1. **Phase 1 (Now):** Implement basic Chen-Flynn with constant coefficients
2. **Phase 2 (Later):** Add temperature-dependent viscosity correction
3. **Phase 3 (Future):** Component-based model for detailed analysis

### Success Criteria

- **Functional:** FMEP calculated for all operating points
- **Reasonable:** FMEP between 0.5-3.0 bar for typical engines
- **Accurate:** Within ±15% of published data (if available)
- **Validated:** Mechanical efficiency 80-95%

---

**End of Document**

*This document provides comprehensive reference material for implementing the Chen-Flynn friction model in the PISTON engine simulation system. For questions or clarifications, consult the references listed in Section 7 or review engine thermodynamics textbooks (Heywood, Ferguson, Stone).*
