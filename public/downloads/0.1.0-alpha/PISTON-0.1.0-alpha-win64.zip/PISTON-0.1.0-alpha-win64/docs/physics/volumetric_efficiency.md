# Volumetric Efficiency

This document describes what PISTON's production volumetric-efficiency model **is**, where its
numbers come from, and where it stops being valid. It exists because the model's own
`getName()` used to advertise it as a 1D gas-dynamics system, which it is not.

VE matters more here than almost anything else. It sets the pressure the cylinder is left at
when the intake valve closes, and therefore the trapped mass, the fuel metered against it,
the peak pressure and temperature, and the knock-limited spark timing — so it drives every
torque and power figure the project reports.

## What runs

`VVTAwareVEStrategy` is the **only** strategy any production path installs. The sole non-test
caller of `OttoCycle::setVEStrategy` is `DynoEngineAdapter::initializeIntegratedPhysics`, and it
always constructs this class. Three other implementations of the `VEStrategy` interface exist —
`EmpiricalVEStrategy`, `PhysicsBasedVEStrategy`, `IntakeSystem1DVEStrategy` — and none of them is
reachable outside tests.

`VVTAwareVEStrategy::calculate(rpm)` evaluates, in order:

1. **A Gaussian in RPM** — the base curve, and the dominant term. On an engine whose cam
   switches, there are two of them, one per lobe, and the one for the **active** cam is used
   (see [Switching cams](#switching-cams)).
2. **× the VVT multiplier** from `ValveTrainSystem::getVEMultiplier`, which is exactly `1.0`
   for the 28 of 32 configs that declare no `vvt_type` — and, since PIS-0143, exactly `1.0`
   for VTEC too, in both cam states. Cam phasing and continuous-lift systems still return a
   real factor here.
3. **+ a small deviation from the 1D intake model** (see [The 1D contribution](#the-1d-contribution)).
4. **Clamped to `[0.30, 1.05]`.**

## The Gaussian

```
VE(rpm) = minVE + (peakVE - minVE) * exp(-x^2),   x = (rpm - peakRPM) / rpmRange
```

Its four parameters are computed per cam in `DynoEngineAdapter.cpp`, from valve geometry
and cam duration — once for a fixed valvetrain, twice for a switching one:

```
ivar         = intake valve area / bore area          (area ratio, both per cylinder)
veFromValves = 0.68 + (ivar - 0.15) * (0.95 - 0.68) / (0.30 - 0.15),  clamped [0.55, 0.98]
camFactor    = clamp((intake_cam_duration_deg - 180) / 100, 0, 1)

peakVE   = veFromValves + camFactor*0.02 + (multi-valve ? 0.02 : 0)
           - (exhaust/intake area ratio < 0.70 ? (0.70 - ratio)*0.10 : 0),  clamped [0.55, 0.98]
minVE    = 0.40 + ivar,                                       clamped [0.35, 0.70]
peakRPM  = idle + (redline - idle) * (0.50 + camFactor*0.18 + (multi-valve ? 0.05 : 0))
rpmRange = (redline - idle) * (0.50 + (multi-valve ? 0.10 : 0))
```

### Switching cams

A VTEC engine's `valvetrain` keys state the **high** cam's duration and lift — that is what the
figures in the configs are, and what the model's low lobe is derived *from*, at a fixed
`0.75` of the declared intake lift (`0.78` exhaust) and a duration capped at `230°`. No shipped
config states low-cam figures, so that synthesis is the only description of the low lobe the model
has, and the low-cam Gaussian derived from it inherits exactly that provenance.

The correlations above are therefore evaluated twice for such an engine — once from the declared
(high) figures, once from the synthesised low ones — and `empiricalVE(rpm)` selects between the two
results on the cam the valvetrain system reports as active, via `getEffectiveCamProfile`. That is
the same selector `computeRawVE` already used, so the base and the 1D deviation can never disagree
about which lobe is running, and an ECU-driven engagement speed (`ecu.cam.vtec`) moves both.

Before PIS-0143 there was one Gaussian, derived from the high-cam figures, used at every speed,
with a flat `1.20` multiplied on above the switch. That counted the high lobe's breathing twice
above the switch — once through `camFactor` and `flowGain`, once through the multiplier — and
described the wrong lobe entirely below it. The multiplier also compared against a hardcoded
switch speed rather than the configured one, so on an engine whose ECU engaged elsewhere the two
halves of the model stepped at different speeds.

`minVE` has no cam term (it comes from nominal valve area alone), so it is shared by both sets
rather than derived twice. The inlet-Mach capacity scale likewise stays on the high cam: the
choke onset only bites near the top of the range, where the high lobe is the one running.

### Provenance

**These coefficients are hand-calibrated, not taken from a published correlation.** They were
fitted so the resulting curves put peak torque and peak power in roughly the right places for the
engines in `data/engines/`. No source is claimed for them because there is none to claim. Treat
them as a fleet-shaped interpolation, not as physics.

### Where it saturates

The correlation carries no discriminating signal at the top or the bottom of its range, and a
large fraction of the shipped fleet sits at both limits:

| Parameter | Limit | Configs pinned to it |
|---|---|--:|
| `peakVE` | upper clamp `0.98` | 14 of 32 |
| `minVE` | upper clamp `0.70` | 14 of 32 |

Every modern four-valve engine in the fleet — S54, Coyote, K20A, K24A2, B18C, RB26DETT, D16Y8 and
others — has `ivar > 0.30`, so `veFromValves` clamps and they all receive **the same** peak VE
regardless of how their valve geometry actually differs. Changing intake valve diameter on any of
those engines moves nothing until the change is large enough to drop `ivar` below about 0.30.

The `0.98` cap is bypassable only on the measured-data branch (next section): with a lift
profile, lift key or head-flow curve present, the same correlation runs with `ivar`
scaled by `flowGain` and the cap raised to `1.02` — measured flow can tell good heads
apart, which is exactly what the nominal-valve-area cap cannot. No shipped config carries
those keys, so the fleet numbers in this document are computed entirely on the capped
branch.

### The idle-speed dependence

`peakRPM` and `rpmRange` are fractions of the **`redline_rpm − idle_rpm` span**. Idle speed has no
bearing on how an engine breathes at 6000 RPM, but raising it moves the VE peak up and narrows the
curve. For a 6600 RPM redline, moving idle from 600 to 1000 RPM shifts the VE peak 200 RPM higher
and narrows the width by 200 RPM. This is a modelling artefact, not a physical effect.

## The 1D contribution

`IntakeSystem` is structurally a crank-angle-resolved intake model: plenum dynamics, valve
flow with a lift-dependent discharge coefficient, runner wave correction.

**Its absolute level is not volumetric efficiency, and by decision it is not asked to be.**
Before the one-event fix it was not even a shape: the model swept a `[0,360)`-periodic cam
profile over 0-720 degrees and so ran the intake event **twice** per cycle, and the raw curve
was the residue of a phantom fill fighting a real-event blowback -- pinned on its own `0.1`
clamp over whole rev ranges for four engines, rising monotonically with speed instead of
falling, with a 74% discontinuity at the F20C's VTEC switch. That defect is fixed and pinned
dead by `tests/core/engine/airpath/test_IntakeVEFleet.cpp`.

What remains is a curve with a believable shape and a level well below physical: roughly
0.50-0.58 across the fleet, against a real 0.7-1.05. `PIS-0074` closed by bounding this
model's claim to the shape alone, because that is all that reaches the answer (see the
deviation blend below) -- and because the level was measured before it was explained. The
attribution, per engine and speed, is reproducible from
`piston_tests "[.ve_attribution]"`:

- **Roughly a fifth of the deficit is thermal, not flow.** The model heats its own charge to
  347-398 K by IVC -- it starts from residual at 550 K and adds inflow enthalpy plus a fixed
  wall pickup -- and density goes as `1/T`. The same trapped states evaluated at intake
  temperature give 0.63-0.72. No runner-momentum term recovers any of that, which is why the
  filed diagnosis ("no ram term") was incomplete.
- **The rest is genuinely flow and timing**: a late IVC on long-duration cams traps a cylinder
  that has already risen well off BDC, and with no ram or inertia term the model cannot keep
  filling against it the way a real engine does at speed. That is the part a momentum term
  would address, and it is what `PIS-0149` carries.
- Worth noticing across models: this intake model already believes in charge heating and lands
  in the 330-380 K band a warm engine really runs, while the thermodynamic cycle it feeds still
  starts compression at intake temperature. The two halves disagree about the same charge by
  60-100 K. `PIS-0140` is that disagreement from the cycle's side.

**The 1D model does not choke at high RPM.** It cannot be the source of a breathing limit,
which is why the limit below is a separate term.

It reaches the answer as a **relative deviation about a hard-coded constant**:

```
normalisedRaw = rawVE(rpm) / rawPeakVE           // rawPeakVE scanned over the rev range
deviation     = normalisedRaw - 0.85             // 0.85 is a literal in the source
result        = base + base * deviation * physicsBlendFactor
```

`physicsBlendFactor` defaults to **0.20**. Subtracting a constant discards the 1D model's
absolute level and keeps only its shape; the blend factor then scales what remains down to a
perturbation, bounded at `0.85 × blend` — about 17% at the default.

How much shape there actually is, measured: the narrowest shipped raw curve spans about 0.021
over its whole rev range, and several sit near 0.022-0.026. On a level near 0.55 that is a few
percent of relative variation, weighted at a fifth by the blend -- so for those engines the 1D
model moves the reported VE by well under one percent. `test_IntakeVEFleet.cpp` pins a floor
under that span, so the contribution can be small but cannot silently become nothing. For engines whose raw curve still rises to the top of
the range, `normalisedRaw` approaches 1.0 there and the deviation about 0.85 is **positive**,
so weighting the 1D model more heavily raises high-RPM VE rather than lowering it. The 0.85
is an arbitrary reference and it biases the correction in whichever direction it happens to
sit relative to the normalised curve.

The factor is raised per engine by `ecu.ve_1d_blend`, in the range `[0.0, 0.85]`.

## The breathing limit

After the blend, VE is multiplied by a factor derived from the **Taylor inlet Mach index**:

```
Z   = A_p * mean_piston_speed / (C_i * A_i * a)
phi = 1                for Z <= 0.6
phi = 0.6 / Z          for Z >  0.6
```

where `A_p` is piston area, `A_i` the nominal intake valve area (diameter and count, both
from the config), `a` the speed of sound at charge temperature, and `C_i = 0.35` the mean
inlet flow coefficient.

**What is and is not chosen here.** `Z` is a published dimensionless group with a published
definition, and 0.6 is the commonly quoted onset of its falloff. `C_i = 0.35` is the textbook
typical value for a production head. The `1/Z` exponent is not a fitted shape: above the
onset the inlet is sonic-limited, so choked mass flux is fixed while the valve-open period
shortens as `1/rpm`; trapped mass therefore falls as `1/rpm`, and so does VE. Since `Z` is
itself proportional to `rpm`, that is exactly `1/Z`.

**Nothing here was calibrated against the fleet.** No constant in this section was chosen by
looking at what it did to the accuracy figure, and none should be.

**It is the mildest falloff consistent with the physics.** Treating flow as perfectly capped
at the onset is optimistic; a real port degrades progressively and falls off faster. An
engine still peaking at its rev limiter after this is under-corrected, not over-corrected.

**It is selective, by design.** Engines are generally designed so `Z` approaches its onset
near the power peak, so the limit engages late and only for the engines that need it. A
large-valve pushrod V8 never reaches the onset within its rev range and is bit-for-bit
unaffected — the multiplier is exactly `1.0` below onset.

## Measured valvetrain data (optional keys)

Since PIS-0107 a config may carry measured valvetrain data, and the model consumes it
through one presence-gated mechanism. The keys, all optional, all under `valvetrain.`:

| Key | Shape | Meaning |
|---|---|---|
| `intake_valve_lift_mm` / `exhaust_valve_lift_mm` | scalar | Peak lift, mm **at the valve** (rocker applied). Replaces the `0.28·D` synthesis. |
| `intake_lift_profile` / `exhaust_lift_profile` | `[[angle_deg, lift_mm], …]` | Full lobe, **lobe-relative** angles (0 = peak lift); positioned by `intake_centerline_deg` + VVT phasing. Wins over the scalar. |
| `head_flow` | `{"test_pressure_inH2O": 28.0, "intake": [[lift_mm, cfm], …], "exhaust": […]}` | Flow-bench curve, CFM per cylinder's port(s). Converted to a `Cd(L/D)` model at the bench depression (`ρ = 1.204 kg/m³` assumed); an explicit `cd_table` wins over it. |

Malformed data never fails a load: the adapter validates each table and falls back to the
synthesis with a warning (the same discipline as `cd_table` parsing), because the
integrated-physics initialiser downgrades wholesale on any exception.

**How it enters the model.** All of it reduces to one dimensionless ratio:

```
A_eff_mean = mean over the open event (1° steps) of  Cd(L/D) · π·D·L(θ) · n_valves
flowGain   = A_eff_mean(measured) / A_eff_mean(synthesised)      clamped [0.6, 1.5]
```

Every hand-calibrated coefficient in the Gaussian is a proxy for the engine's mean
effective inlet flow area (Heywood's `C_i·A_i`, the same group inside the Mach index), so
the measured data's whole effect is that one ratio: `ivar` scales by it (peak VE, cap
raised to `1.02` on this branch), the peak-RPM and width fractions scale by it (at constant
breathing state, RPM scales with effective inlet area), and the Mach index divides by it
(the choke onset moves up with a better-flowing head). The baseline of the ratio is exactly
the profile and Cd model the ungated path would have used, so data that merely restates the
synthesis gives `flowGain = 1.0` exactly — this is a measurement entering a correlation,
not a re-calibration of it. Duration cancels in the event-mean and keeps entering only
through `camFactor`, so there is no double-count.

**What is physics and what is a stand-in here:** the event-mean effective area and the
RPM ∝ area scaling are physics; reusing the linear `ivar` correlation line beyond its
calibration range, and scaling the existing Mach index *relatively* rather than re-deriving
it absolutely from `C_i·A_i`, are documented stand-ins — an absolute re-derivation would
move gated and ungated engines against each other for reasons unrelated to the part
swapped. A measured lobe also replaces the synthetic `fromParameters` profile inside the 1D
contribution (rescaled per call to the VVT system's effective lift, so VTEC switching stays
alive).

Configs without any of these keys execute the pre-existing expressions token-for-token —
bit-identical, asserted by tests with exact `==` comparison, not a tolerance.

## What is not modelled

- **No valve-float or valvetrain-dynamics limit.** The inlet-Mach limit above ends the curve
  only for engines that actually choke their inlet inside the rev range. For the rest, the
  Gaussian decays onto `minVE` — 0.68–0.70 for much of the fleet — so torque flattens onto a
  floor instead of collapsing, and simulated power keeps climbing to wherever the sweep
  stops. Those engines are still marked `*` in
  [`../validation/accuracy.generated.md`](../validation/accuracy.generated.md), and the RPM at
  which their simulated peak occurs carries no information. Nothing models spring surge,
  valve float, or port flow degradation with lift.
- **Valvetrain data is optional, and no shipped config carries it yet.** The keys exist
  (previous section), but no shipped config sets them, so every fleet engine still runs on
  lift synthesised as `0.28 × intake valve diameter` (`0.26 ×` for exhaust). Spring rate and
  valve mass have no keys at all — nothing models spring surge or float.
- **The restriction does no pumping work.** VE now reaches the cylinder — it sets the pressure
  at IVC, and trapped mass follows from it — but the intake leg of the P—V trace is still held
  at manifold pressure, so throttling and breathing losses do not appear as pumping work.
  They enter only through the separate PMEP term. See [`limitations.md`](limitations.md).

## Other VE calculations in the tree

Two more independent VE models exist and do not agree with the one above. Neither feeds the cycle:

- `BSFCCalculator::estimateVE` — a parabola, `peakVE × (1 − 0.5·((rpm−peakRPM)/peakRPM)²)` clamped
  to `[0.3, 1.0]`, used for the fuel-flow and BSFC figures in every report. It has a high-RPM
  rolloff the cycle's VE does not.
- `VolumetricEfficiency::evaluateGaussianCurve` — the built-in Gaussian used only when
  `initializeIntegratedPhysics` throws and the adapter falls back. Its parameters come from
  `OttoCycleConfigBuilder`, a near-duplicate of the correlation above that additionally applies a
  diesel override the `DynoEngineAdapter` copy does not. It has now diverged twice: it also has
  neither the measured-lobe `flowGain` branch nor the per-cam split, so a fallback engine gets the
  high-cam correlation at every speed. That is intentional — the fallback has no valvetrain object
  to read a cam state from, and no multiplier that could double-count one — but any change to the
  expressions the two copies still share has to be made in both.

## See also

- [`limitations.md`](limitations.md) — the index of modelling assumptions.
- [`../GAS_DYNAMICS_AND_VE_MODELING.md`](../GAS_DYNAMICS_AND_VE_MODELING.md) — the Helmholtz,
  1D-gas-dynamics and discharge-coefficient models that `IntakeSystem` implements. Read it as a
  description of that component, not of the production VE path, which weights it at 0.20 of a
  deviation.
- [`../validation/accuracy.generated.md`](../validation/accuracy.generated.md) — measured accuracy.
