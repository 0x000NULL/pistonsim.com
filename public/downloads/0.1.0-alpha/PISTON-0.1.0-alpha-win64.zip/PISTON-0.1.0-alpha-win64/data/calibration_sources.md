# Turbo Engine ECU Calibration Sources

## Honda K20C1 (FK8 Civic Type R)

### Ignition Timing
- **Hondata FK8 Tuning Guide** (https://www.hondata.com/tech-tuning-the-k20c-fk8-civic-type-r)
  - Key finding: "A typical CTR will see 0deg at peak torque (~280kPa///AirC>=230) and 9deg at peak HP (~235kPa///AirC>=175)"
  - This confirms extreme timing pull at high boost — near 0° BTDC at peak torque conditions
- **Hondata FlashPro FK8** (https://www.hondata.com/flashpro-fk8-us)
  - FlashPro Manager provides boost, ignition, fuel, cam control editing
  - Stock calibrations available as baseline references
- **HA Motorsports FlashPro** (https://www.hamotorsports.com/products/fp-fk8-us)
  - Confirms boost/ignition/fuel table editing capability for stock ECU characterization

### Applied calibration:
- Ignition at high boost (160 kPa): -2° to 7° BTDC (peak torque to peak HP range)
- Lambda at high boost: 0.78-0.80 (rich for cooling)
- Boost target: 38 kPa peak gauge (~5.5 psi effective in sim)

## Toyota 2JZ-GTE

### Ignition Timing
- **Supra Forums - 2JZ Ignition Timing and Knock Control** (https://www.supraforums.com/threads/2jz-ignition-timing-and-knock-control.1058850/)
  - Stock ECU runs aggressive base map but relies heavily on knock retard
  - Stock sensors detect knock and pull timing from base map
  - At cruise/vacuum: up to 50° advance reported
  - At full boost: 15-20° typical after knock retard
- **Lexus IS Forum - Base Timing Map** (https://www.my.is/threads/base-timing-map.506882/)
  - 2JZs like 18-20° at idle
  - Timing adjusted for idle stability
- **HP Academy - Ignition Timing Recommendation** (https://www.hpacademy.com/forum/practical-dyno-tuning/show/ignition-timing-recomedation/)
  - At 200 kPa boost, start at 2° for high CR + pump gas
  - Conservative approach for turbo applications
- **Link ECU Forums - 2JZ-GTE Tuning** (https://forums.linkecu.com/topic/14502-multiple-questions-2jz-gte-high-fuel-table-ignition-timing-and-knock-sensors-queries/)
  - Community data for 2JZ-GTE with standalone ECU

### Applied calibration:
- Ignition at high boost (170 kPa): -1° to 6° BTDC
- Lambda at high boost: 0.78-0.80
- Boost target: 28 kPa peak gauge (~4 psi effective in sim)

## BMW N54B30

### Ignition Timing
- **BMW Tuning - N54 MHD Flash Tunes** (https://bmwtuning.co/bmw-n54-mhd-flash-tunes-horsepower-gains/)
  - MHD allows monitoring boost, AFRs, ignition timing
  - Stock tune is conservative; flash tunes add timing
- **COBB Tuning - N54 Tuning Guide** (https://cobbtuning.atlassian.net/wiki/spaces/PRS/pages/828637363/BMW+N54+Tuning+Guide)
  - Stage1 calibrations: optimized ignition, boost, and fuel targets
  - Designed for stock hardware
- **Boost Monkey - Interpreting MHD Datalogs** (https://boostmonkey.com/blogs/guides/interpreting-mhd-datalogs-n54-n55-335i-135i-535i)
  - N54 timing corrections ~3° are normal part of ignition control strategy
  - Stock timing is very conservative due to 10.2:1 CR with turbo + DI
- **MHD Tuning** (https://mhdtuning.com/)
  - 50+ engine monitors including individual cylinder ignition timing

### Applied calibration:
- Ignition at high boost (160 kPa): 1° to 7° BTDC
- Lambda at high boost: 0.78-0.80
- Boost target: 22 kPa peak gauge (~3.2 psi effective in sim)
- N54 is notably conservative due to 10.2:1 CR (high for turbo) enabled by DI charge cooling

## General Notes
- All three engines now target λ=0.78-0.80 at WOT/high boost (rich for component protection)
- Part throttle targets remain at λ=1.0 (stoichiometric) for emissions
- Timing maps follow the pattern: aggressive advance at vacuum/low load, severe pull at high boost
- The simulation's boost_kPa values represent gauge pressure targets for the wastegate controller
- Calibrated 2025-02-15
