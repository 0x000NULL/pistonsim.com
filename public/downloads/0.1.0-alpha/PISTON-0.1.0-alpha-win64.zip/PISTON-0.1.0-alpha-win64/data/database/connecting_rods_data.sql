-- ============================================================================
-- PISTON Parts Database - Connecting Rods Data
-- ============================================================================
-- Connecting rods for popular engine builds:
-- - LS rods (stock, aftermarket H-beam, I-beam)
-- - SBC rods (5.7", 6.0", 6.125")
-- - Honda B/K series rods (forged, I-beam, H-beam)
-- - JDM rods (2JZ, 4G63, SR20DET)
--
-- Note: sample_data.sql already contains some rods
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 14 connecting_rods

-- ============================================================================
-- GM LS CONNECTING RODS
-- ============================================================================

-- Eagle LS1 H-Beam Rods (4340 steel, budget performance)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Eagle LS1 H-Beam', 'CRS5700LS1', 155.58, 55.0,
       22.225, 'H', 'ARP 2000', 575.0, mat.id, 7500, 750.0, 580.00, NULL,
       'Eagle H-beam 4340 steel, LS1/LS6 6.098" length, budget street/strip'
FROM manufacturers m, materials mat
WHERE m.name = 'Eagle Specialty Products' AND mat.name = '4340 Steel';

-- Manley LS7 H-Tuff Rods (premium forged)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Manley LS7 H-Tuff', '14023-8', 158.75, 55.0,
       25.4, 'H', 'ARP 2000', 625.0, mat.id, 8500, 900.0, 1200.00, NULL,
       'Manley H-Tuff LS7 rods, 6.25" length, premium forged 4340'
FROM manufacturers m, materials mat
WHERE m.name = 'Manley Performance' AND mat.name = '4340 Steel';

-- Brian Crower LS2/LS3 I-Beam Rods (lightweight)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'BC LS2/LS3 I-Beam', 'BC0800', 155.58, 55.0,
       22.225, 'I', 'ARP 2000', 540.0, mat.id, 8000, 800.0, 720.00, NULL,
       'Brian Crower I-beam, lightweight 4340, 6.098" length'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = '4340 Steel';

-- LS Stock Powdered Metal Rods (OEM replacement)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'LS Stock PM', '12558178', 155.58, 55.0,
       22.225, 'I', 'Factory', 630.0, mat.id, 6500, 500.0, 280.00, 80.00,
       'OEM powdered metal rods, 6.098" length, stock replacement (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Forged Steel';

-- ============================================================================
-- SMALL BLOCK CHEVY RODS
-- ============================================================================

-- Eagle SBC 5.7" I-Beam Rods (350 build)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Eagle SBC 5.7"', 'CRS5700D3D', 144.78, 54.0,
       22.225, 'I', 'ARP 2000', 615.0, mat.id, 7000, 650.0, 450.00, NULL,
       'Eagle I-beam 5.7" for SBC 350, 4340 steel, budget performance'
FROM manufacturers m, materials mat
WHERE m.name = 'Eagle Specialty Products' AND mat.name = '4340 Steel';

-- Manley SBC 6.0" H-Beam Rods (383 stroker)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Manley SBC 6.0"', '14056-8', 152.4, 54.0,
       22.225, 'H', 'ARP 2000', 640.0, mat.id, 7500, 750.0, 980.00, NULL,
       'Manley H-beam 6.0" for 383 stroker, premium 4340 steel'
FROM manufacturers m, materials mat
WHERE m.name = 'Manley Performance' AND mat.name = '4340 Steel';

-- Oliver SBC 6.125" Billet I-Beam (406 stroker, premium)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Oliver SBC 6.125"', 'OLI-PN4340I-625', 155.575, 54.0,
       22.225, 'I', 'ARP 2000', 585.0, mat.id, 8000, 900.0, 1600.00, NULL,
       'Oliver billet I-beam 6.125" for 406 stroker, ultra-premium'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = '4340 Steel';  -- Using GM as placeholder for Oliver

-- ============================================================================
-- HONDA B/K SERIES RODS
-- ============================================================================

-- Brian Crower B16A/B18C I-Beam Rods (lightweight race)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'BC B16/B18 I-Beam', 'BC0050', 134.5, 48.0,
       19.0, 'I', 'ARP 2000', 380.0, mat.id, 9500, 350.0, 680.00, NULL,
       'Brian Crower I-beam for B-series, 5.295" length, 9500+ RPM'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = '4340 Steel';

-- Manley K20A/K24 H-Beam Rods (street/turbo)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Manley K20/K24 H-Beam', '14019-4', 152.0, 50.0,
       21.0, 'H', 'ARP 2000', 525.0, mat.id, 9000, 600.0, 920.00, NULL,
       'Manley H-beam for K-series, 5.984" length, turbo capable'
FROM manufacturers m, materials mat
WHERE m.name = 'Manley Performance' AND mat.name = '4340 Steel';

-- Eagle K20A2 H-Beam Rods (budget K-series)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Eagle K20 H-Beam', 'CRS5984K20', 152.0, 50.0,
       21.0, 'H', 'ARP 2000', 540.0, mat.id, 8500, 500.0, 580.00, NULL,
       'Eagle H-beam for K20/K24, 5.984" length, budget performance'
FROM manufacturers m, materials mat
WHERE m.name = 'Eagle Specialty Products' AND mat.name = '4340 Steel';

-- ============================================================================
-- JDM RODS (2JZ, 4G63, SR20)
-- ============================================================================

-- Manley 2JZ-GTE H-Beam Rods (turbo Supra)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Manley 2JZ H-Beam', '14016-6', 142.0, 54.0,
       23.0, 'H', 'ARP 2000', 625.0, mat.id, 8500, 1200.0, 1100.00, NULL,
       'Manley H-beam for 2JZ-GTE, 5.590" length, 1000+ HP capable'
FROM manufacturers m, materials mat
WHERE m.name = 'Manley Performance' AND mat.name = '4340 Steel';

-- Brian Crower 4G63 Evo I-Beam Rods (rally/drift)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'BC 4G63 I-Beam', 'BC0400', 150.0, 52.0,
       22.0, 'I', 'ARP 2000', 565.0, mat.id, 8500, 700.0, 840.00, NULL,
       'Brian Crower I-beam for 4G63, 5.905" length, Evo VIII/IX'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = '4340 Steel';

-- Eagle SR20DET H-Beam Rods (240SX/Silvia)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Eagle SR20 H-Beam', 'CRS5500SR20', 139.7, 50.0,
       21.0, 'H', 'ARP 2000', 490.0, mat.id, 9000, 550.0, 680.00, NULL,
       'Eagle H-beam for SR20DET, 5.500" length, drift/turbo capable'
FROM manufacturers m, materials mat
WHERE m.name = 'Eagle Specialty Products' AND mat.name = '4340 Steel';

-- Carrillo 2JZ Pro-H Rods (ultimate turbo build)
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter,
                            small_end_diameter, beam_type, rod_bolts, weight, material_id, max_rpm, max_power,
                            price_new, price_used, notes)
SELECT m.id, 'Carrillo 2JZ Pro-H', 'SCR5442-6', 142.0, 54.0,
       23.0, 'H', 'Carrillo', 590.0, mat.id, 9000, 1500.0, 2200.00, NULL,
       'Carrillo Pro-H for 2JZ, 5.590" length, 1500+ HP capable, premium'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = '4340 Steel';  -- Using GM as placeholder for Carrillo

-- ============================================================================
-- ============================================================================
-- LS: (Eagle, Manley, Brian Crower, Stock)
-- SBC: (Eagle 5.7", Manley 6.0", Oliver 6.125")
-- Honda: (BC B16/B18, Manley K20, Eagle K20)
-- JDM: (Manley 2JZ, BC 4G63, Eagle SR20, Carrillo 2JZ)
--
-- ============================================================================
