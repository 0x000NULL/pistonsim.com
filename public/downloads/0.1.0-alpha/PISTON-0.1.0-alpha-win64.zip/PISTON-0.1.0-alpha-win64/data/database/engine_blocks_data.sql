-- ============================================================================
-- PISTON Parts Database - Engine Blocks Data
-- ============================================================================
-- Popular engine blocks covering:
-- - GM LS family (LS1, LS2, LS6, LS7, LS9, LQ4)
-- - Small Block Chevy (350, 383, 406 stroker)
-- - Honda B/K series (B16, B18, K20)
-- - JDM performance (2JZ-GE, 4G63, SR20DET)
-- - Ford Windsor / Cleveland / M-block / Modular
-- - Mopar LA / Magnum / B / RB / Gen II Hemi / Gen III Hemi
--
-- Note: sample_data.sql already contains LS3, Coyote 5.0, 392 Hemi, 2JZ-GTE, K24A2
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 37 engine_blocks

-- ============================================================================
-- GM LS FAMILY
-- ============================================================================

-- GM LS1 5.7L (Gen III - first aluminum LS)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS1', '12551358', 99.0, 92.0, 234.95, 111.76, 8, 'V', 90,
       100.5, 233.5, 5, 60.0, 27.2, 92.0, mat.id, 2000.00, 600.00,
       '5.7L Gen III V8, aluminum, 346 ci, C5 Corvette/Camaro/GTO (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LS2 6.0L (Gen IV - C6 Corvette, GTO)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS2', '12568949', 101.6, 92.0, 234.95, 111.76, 8, 'V', 90,
       103.0, 233.5, 5, 60.0, 27.2, 94.0, mat.id, 2200.00, 700.00,
       '6.0L Gen IV V8, aluminum, 364 ci, C6 Corvette base (2005, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LS6 5.7L (high-performance LS1, C5 Z06)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS6', '12561166', 99.0, 92.0, 234.95, 111.76, 8, 'V', 90,
       100.5, 233.5, 5, 60.0, 27.2, 92.5, mat.id, 2800.00, 1200.00,
       '5.7L Gen III V8, aluminum, 346 ci, higher performance than LS1 (2001, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LS7 7.0L (C6 Z06 - largest production LS)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS7', '12480030', 104.8, 101.6, 237.0, 111.76, 8, 'V', 90,
       105.5, 235.5, 5, 60.0, 27.2, 102.0, mat.id, 9500.00, 6000.00,
       '7.0L Gen IV V8, aluminum, 427 ci, dry sump, titanium rods/valves (2006, new)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LS9 6.2L Supercharged (ZR1)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS9', '12623979', 103.25, 92.0, 234.95, 111.76, 8, 'V', 90,
       104.5, 233.5, 5, 60.0, 27.2, 96.0, mat.id, 8000.00, 4500.00,
       '6.2L Gen IV V8, aluminum, 376 ci, supercharged ZR1, forged internals (2009, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LQ4/LQ9 6.0L (truck/SUV engine, cast iron)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LQ4/LQ9', '88894389', 101.6, 92.0, 234.95, 111.76, 8, 'V', 90,
       103.5, 233.5, 5, 60.0, 27.2, 198.0, mat.id, 1800.00, 500.00,
       '6.0L Gen III V8, cast iron, 364 ci, truck/SUV block, very strong (1999, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Cast Iron';

-- ============================================================================
-- SMALL BLOCK CHEVY (GEN I)
-- ============================================================================

-- Chevy SBC 350 (5.7L - classic small block)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SBC 350', '3970010', 101.6, 88.4, 228.6, 108.0, 8, 'V', 90,
       104.8, 226.6, 5, 57.2, 25.4, 202.0, mat.id, 1500.00, 400.00,
       '5.7L Gen I V8, cast iron, 350 ci, most common SBC, 4-bolt mains (1967, rebuild)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Cast Iron';

-- Chevy SBC 383 Stroker (350 bored/stroked to 383)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SBC 383 Stroker', '3970010-383', 104.8, 92.0, 228.6, 108.0, 8, 'V', 90,
       106.0, 226.6, 5, 57.2, 25.4, 205.0, mat.id, 1800.00, 600.00,
       '6.3L stroker V8, cast iron, 383 ci, 350 block bored 0.030" + 400 crank (1967, rebuild)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Cast Iron';

-- Chevy SBC 406 Stroker (350 block with 406 stroker kit)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SBC 406 Stroker', 'GM-350-406', 106.0, 101.6, 228.6, 108.0, 8, 'V', 90,
       107.0, 226.6, 5, 57.2, 25.4, 210.0, mat.id, 3500.00, 1500.00,
       '6.7L stroker V8, cast iron, 406 ci, 350 block bored 0.060" + stroker crank (1970, rebuild)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Cast Iron';

-- ============================================================================
-- HONDA B/K SERIES
-- ============================================================================

-- Honda B16A 1.6L VTEC (Civic Si, Del Sol VTEC)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B16A', 'B16A2', 81.0, 77.4, 203.9, 84.5, 4, 'inline', NULL,
       82.0, 202.9, 5, 52.0, 21.5, 68.0, mat.id, 2000.00, 800.00,
       '1.6L I4 VTEC, aluminum, 97 ci, 160 hp, lightweight high-revving (1989, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda B18C 1.8L VTEC (Integra Type R)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B18C', 'B18C5', 81.0, 87.2, 211.84, 84.5, 4, 'inline', NULL,
       82.0, 210.84, 5, 52.0, 21.5, 72.0, mat.id, 3500.00, 1500.00,
       '1.8L I4 VTEC, aluminum, 110 ci, 195 hp, Type R high-performance (1995, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda K20A 2.0L i-VTEC (RSX Type S, Civic Si)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K20A', 'K20A2', 86.0, 86.0, 212.0, 90.0, 4, 'inline', NULL,
       87.5, 211.0, 5, 52.0, 21.5, 82.0, mat.id, 2800.00, 1200.00,
       '2.0L I4 i-VTEC, aluminum, 122 ci, 200 hp, K-series square design (2002, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- JDM PERFORMANCE ENGINES
-- ============================================================================

-- Toyota 2JZ-GE 3.0L (naturally aspirated 2JZ, not turbo)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ-GE', '11400-46050', 86.0, 86.0, 243.0, 91.5, 6, 'inline', NULL,
       87.5, 242.0, 7, 60.0, 24.0, 188.0, mat.id, 1800.00, 700.00,
       '3.0L I6 N/A, cast iron, 183 ci, 225 hp, non-turbo 2JZ (1991, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Cast Iron';

-- Mitsubishi 4G63 2.0L Turbo (Evolution)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '4G63', 'MD050310', 85.0, 88.0, 228.6, 88.0, 4, 'inline', NULL,
       87.5, 227.6, 5, 54.0, 22.0, 102.0, mat.id, 2500.00, 900.00,
       '2.0L I4 turbo, cast iron, 122 ci, Evolution VII-IX, legendary rally engine (1988, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Mitsubishi' AND mat.name = 'Cast Iron';

-- Nissan SR20DET 2.0L Turbo (S13/S14/S15)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SR20DET', 'SR20DET', 86.0, 86.0, 223.5, 88.0, 4, 'inline', NULL,
       87.5, 222.5, 5, 54.0, 22.0, 120.0, mat.id, 3000.00, 1200.00,
       '2.0L I4 turbo, aluminum, 122 ci, 240SX/Silvia, drift legend (1989, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Nissan' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- FORD SMALL BLOCK / WINDSOR / CLEVELAND / MODULAR
-- ============================================================================

-- Ford 289 Windsor (1963-1968 small block, K-code Mustang)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '289 Windsor', 'C5OE-6015', 101.6, 72.9, 208.4, 111.25, 8, 'V', 90,
       102.6, 207.0, 5, 63.5, 27.0, 207.0, mat.id, 1500.00, 400.00,
       '4.7L Windsor V8, cast iron, 289 ci, original small-block Ford (1963, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 302 Windsor / 5.0 HO (Mustang, F-150, Bronco)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '302 Windsor', 'E7TE-6015-PA', 101.6, 76.2, 208.4, 111.25, 8, 'V', 90,
       102.6, 207.0, 5, 63.5, 27.0, 209.0, mat.id, 1700.00, 450.00,
       '5.0L Windsor V8, cast iron, 302 ci, Fox-body 5.0 HO (1968, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford Boss 302 (1969-1970, Cleveland-headed Windsor, 4-bolt mains)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'Boss 302', 'DOZE-6015-A', 101.6, 76.2, 208.4, 111.25, 8, 'V', 90,
       102.6, 207.0, 5, 63.5, 27.0, 220.0, mat.id, 4500.00, 2200.00,
       '5.0L Boss V8, cast iron, 302 ci, 4-bolt mains, Cleveland-headed Windsor (1969, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 351 Windsor (5.8L Windsor, F-series, Mustang)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '351 Windsor', 'D2OE-6015-A', 101.6, 88.9, 241.4, 111.25, 8, 'V', 90,
       102.6, 240.0, 5, 63.5, 27.0, 245.0, mat.id, 2000.00, 600.00,
       '5.8L Windsor V8, cast iron, 351 ci, taller-deck small block (1969, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 351 Cleveland (1970-1974, canted-valve heads, Mustang/Torino)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '351 Cleveland', 'D1ZE-6015-A', 101.6, 88.9, 233.7, 111.25, 8, 'V', 90,
       102.6, 232.3, 5, 63.5, 27.0, 250.0, mat.id, 3500.00, 1500.00,
       '5.8L Cleveland V8, cast iron, 351 ci, canted-valve heads (1970, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 351M (1975-1982, M-block tall-deck Cleveland-derived)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '351M', 'D7TE-6015-AA', 101.6, 88.9, 261.5, 111.25, 8, 'V', 90,
       102.6, 260.0, 5, 63.5, 27.0, 260.0, mat.id, 1500.00, 500.00,
       '5.8L M-block V8, cast iron, 351 ci, tall-deck truck variant (1975, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 400M (1971-1982, M-block large-displacement variant)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '400M', 'D5TE-6015-AA', 101.6, 101.6, 261.5, 111.25, 8, 'V', 90,
       102.6, 260.0, 5, 63.5, 27.0, 265.0, mat.id, 1600.00, 550.00,
       '6.6L M-block V8, cast iron, 400 ci, tall-deck truck/wagon (1971, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 460 (385-series Big Block, F-series, Lincoln)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '460', 'D1VE-6015-AA', 109.2, 100.8, 261.6, 124.46, 8, 'V', 90,
       110.5, 260.0, 5, 63.5, 27.0, 290.0, mat.id, 2200.00, 700.00,
       '7.5L 385-series big block V8, cast iron, 460 ci, F-series/Lincoln (1968, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 5.4L Triton (F-150, Expedition, Lightning, GT)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '5.4 Triton', 'XL3E-6015-AA', 90.2, 105.8, 227.0, 100.0, 8, 'V', 90,
       91.5, 226.0, 5, 62.0, 25.0, 195.0, mat.id, 1800.00, 450.00,
       '5.4L Modular Triton V8, cast iron, 330 ci, truck/SUV workhorse (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 5.8L Trinity (Shelby GT500 supercharged, aluminum Modular)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '5.8 Trinity', 'CR3Z-6015-A', 93.5, 105.8, 227.0, 100.0, 8, 'V', 90,
       94.5, 226.0, 5, 62.0, 25.0, 105.0, mat.id, 6500.00, 3500.00,
       '5.8L Trinity DOHC V8, aluminum, 354 ci, supercharged Shelby GT500 (2013, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Aluminum 356';

-- Ford 6.2L Boss (Raptor, Super Duty - Boss SOHC V8)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '6.2 Boss', 'AL3E-6015-BA', 102.0, 95.0, 234.0, 110.0, 8, 'V', 90,
       103.0, 233.0, 5, 62.0, 25.0, 215.0, mat.id, 4000.00, 1800.00,
       '6.2L Boss SOHC V8, cast iron, 379 ci, Raptor/Super Duty (2010, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Ford 6.8L V10 Triton (Super Duty, Excursion, motorhome chassis)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '6.8 V10', 'XC2E-6015-AA', 90.2, 105.8, 227.0, 100.0, 10, 'V', 90,
       91.5, 226.0, 6, 68.0, 27.0, 270.0, mat.id, 2000.00, 650.00,
       '6.8L Triton V10, cast iron, 415 ci, Super Duty/Excursion/motorhome (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- ============================================================================
-- MOPAR SMALL BLOCK / BIG BLOCK / HEMI
-- ============================================================================

-- Mopar LA 273 (1964-1969, original LA small block)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '273 LA', '273-LA', 92.07, 84.07, 241.3, 113.28, 8, 'V', 90,
       93.07, 240.3, 5, 60.45, 25.4, 190.0, mat.id, 1500.00, 400.00,
       '4.5L LA V8, cast iron, 273 ci, original LA small block (1964, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar LA 318 (most common Mopar small block)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '318 LA', '318-LA', 99.31, 84.07, 241.3, 113.28, 8, 'V', 90,
       100.31, 240.3, 5, 60.45, 25.4, 205.0, mat.id, 1500.00, 400.00,
       '5.2L LA V8, cast iron, 318 ci, most common Mopar small block (1967, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar LA 340 (high-perf small block, factory 4-bbl)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '340 LA', '340-LA', 104.65, 84.07, 241.3, 113.28, 8, 'V', 90,
       105.65, 240.3, 5, 60.45, 25.4, 210.0, mat.id, 3500.00, 1500.00,
       '5.6L LA V8, cast iron, 340 ci, high-perf small block, factory 4-bbl (1968, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar LA 360 (externally-balanced small block)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '360 LA', '360-LA', 101.6, 90.93, 241.3, 113.28, 8, 'V', 90,
       102.6, 240.3, 5, 60.45, 25.4, 220.0, mat.id, 1700.00, 500.00,
       '5.9L LA V8, cast iron, 360 ci, externally-balanced small block (1971, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar 5.9 Magnum (roller-cam-ready LA derivative)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '5.9 Magnum', '5.9-Magnum', 101.6, 90.93, 241.3, 113.28, 8, 'V', 90,
       102.6, 240.3, 5, 60.45, 25.4, 225.0, mat.id, 1800.00, 500.00,
       '5.9L Magnum V8, cast iron, 360 ci, roller-cam-ready LA derivative (1992, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar 383 B-block (RB precursor low-deck big block)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '383 B', '383-B', 107.95, 85.85, 253.5, 121.92, 8, 'V', 90,
       109.0, 252.5, 5, 69.85, 27.0, 290.0, mat.id, 2200.00, 700.00,
       '6.3L B-block V8, cast iron, 383 ci, RB precursor low-deck big block (1959, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar 400 B-block (largest-bore low-deck B)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '400 B', '400-B', 110.24, 85.85, 253.5, 121.92, 8, 'V', 90,
       111.24, 252.5, 5, 69.85, 27.0, 295.0, mat.id, 2000.00, 650.00,
       '6.6L B-block V8, cast iron, 400 ci, largest-bore low-deck B (1972, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar 440 RB (raised-deck big block)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '440 RB', '440-RB', 109.73, 95.25, 272.3, 121.92, 8, 'V', 90,
       110.73, 271.3, 5, 69.85, 27.0, 315.0, mat.id, 4500.00, 1800.00,
       '7.2L RB V8, cast iron, 440 ci, raised-deck big block (1965, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar 426 Hemi Gen II (Elephant hemispherical heads)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '426 Hemi', '426-Hemi-G2', 107.95, 95.25, 272.3, 121.92, 8, 'V', 90,
       109.0, 271.3, 5, 69.85, 27.0, 330.0, mat.id, 9500.00, 6000.00,
       '7.0L Gen II Hemi V8, cast iron, 426 ci, Elephant hemispherical heads (1964, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Mopar 5.7 Hemi Gen III Eagle (MDS variant)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '5.7 Hemi', '5.7-Hemi-Eagle', 99.5, 90.9, 226.0, 107.95, 8, 'V', 90,
       100.5, 225.0, 5, 62.5, 24.0, 110.0, mat.id, 3500.00, 1200.00,
       '5.7L Gen III Hemi V8, cast iron, 345 ci, Eagle MDS variant (2003, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- ============================================================================
-- ============================================================================
-- GM LS: LS1, LS2, LS6, LS7, LS9, LQ4
-- SBC Gen I: 350, 383 stroker, 406 stroker
-- Honda: B16A, B18C, K20A
-- JDM: 2JZ-GE, 4G63, SR20DET
-- Ford: 289, 302, Boss 302, 351W, 351C, 351M, 400M, 460, 5.4 Triton, 5.8 Trinity, 6.2 Boss, 6.8 V10
-- Mopar: 273, 318, 340, 360 LA, 5.9 Magnum, 383 B, 400 B, 440 RB, 426 Hemi, 5.7 Hemi
--
-- ============================================================================
