-- ============================================================================
-- PISTON Parts Database - Crankshafts Data
-- ============================================================================
-- Crankshafts for popular engine builds:
-- - LS crankshafts (stock, stroker, billet)
-- - SBC crankshafts (stock 350, 383 stroker, 406 stroker)
-- - Honda B/K series cranks (stock, stroker)
-- - JDM cranks (2JZ, 4G63)
--
-- Note: sample_data.sql already contains some crankshafts
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 12 crankshafts

-- ============================================================================
-- GM LS CRANKSHAFTS
-- ============================================================================

-- LS1 Stock Crankshaft (5.7L, cast steel)
-- Weight corrected: OEM LS1 ductile-iron crank is ~16-17 kg (GM service data / King Engine Bearings ref.)
-- Previous value of 52.0 kg was ~3× real weight — clearly in lbs not kg.
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'LS1 Stock', '12551352', 92.0, 60.0, 52.0,
       8, 5, '1-8-7-2-6-5-4-3', TRUE, FALSE, 16.5, mat.id, 6500, 550.0, 800.00, 250.00,
       'LS1 stock cast crank, 3.622" stroke, internally balanced (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Ductile Iron';

-- LS3 Stock Crankshaft (6.2L, forged steel)
-- Weight corrected: OEM LS3 forged crank is ~17-18 kg (GM casting data; lighter than cast due to forging flash removal)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'LS3 Stock', '12622033', 92.0, 60.0, 52.0,
       8, 5, '1-8-7-2-6-5-4-3', TRUE, FALSE, 17.5, mat.id, 7000, 600.0, 1200.00, 500.00,
       'LS3 forged steel crank, 3.622" stroke, stronger than LS1/LS2 (2008, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Forged Steel';

-- LS7 Stock Crankshaft (7.0L, forged steel)
-- Weight corrected: OEM LS7 forged crank is ~19-21 kg (427 ci displacement, longer stroke than LS3)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'LS7 Stock', '12480036', 101.6, 60.0, 55.0,
       8, 5, '1-8-7-2-6-5-4-3', TRUE, FALSE, 20.5, mat.id, 7500, 700.0, 3500.00, 2200.00,
       'LS7 forged steel crank, 4.000" stroke, titanium connecting rods (2006, new)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Forged Steel';

-- Texas Speed LS 4.125" Stroker Crank (416 ci build)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'TSP LS 4.125"', 'TSP-CRANK-4125', 104.775, 60.0, 52.0,
       8, 5, '1-8-7-2-6-5-4-3', TRUE, FALSE, 20.5, mat.id, 7500, 800.0, 1800.00, NULL,
       'Texas Speed 4.125" stroker for 416 ci LS, 4340 forged steel; weight ~20.5 kg (PDDI-15 fix from erroneous 57.0 kg)'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = '4340 Steel';

-- ============================================================================
-- SMALL BLOCK CHEVY CRANKSHAFTS
-- ============================================================================

-- SBC 350 Stock Cast Crank (budget rebuild)
-- Weight corrected: OEM SBC cast-iron crank is ~13-15 kg (SCAT, Eagle tech docs)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'SBC 350 Cast', '3970010', 88.4, 57.2, 50.8,
       8, 5, '1-8-4-3-6-5-7-2', FALSE, TRUE, 14.0, mat.id, 6000, 450.0, 400.00, 120.00,
       'SBC 350 cast crank, 3.480" stroke, externally balanced, 2-piece seal (1967, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Cast Iron';

-- SBC 383 Stroker Crank (400 crank, 3.750" stroke)
-- Weight corrected: SCAT 383 stroker cast crank is ~15-16 kg (SCAT Enterprises catalog)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'SBC 383 Stroker', 'SCAT-9000', 95.25, 57.2, 54.9,
       8, 5, '1-8-4-3-6-5-7-2', FALSE, TRUE, 15.5, mat.id, 6800, 600.0, 650.00, NULL,
       'SBC 383 stroker crank, 3.750" stroke, cast steel, external balance (SCAT placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Ductile Iron';

-- SBC 406 Stroker Crank (4.000" stroke, forged)
-- Weight corrected: Eagle 406 forged 4340 crank is ~16-18 kg (Eagle Specialty Products spec sheet)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'SBC 406 Stroker', 'EAGLE-440030030000', 101.6, 57.2, 54.9,
       8, 5, '1-8-4-3-6-5-7-2', FALSE, TRUE, 16.5, mat.id, 7200, 750.0, 950.00, NULL,
       'SBC 406 stroker crank, 4.000" stroke, 4340 forged steel, external balance'
FROM manufacturers m, materials mat
WHERE m.name = 'Eagle Specialty Products' AND mat.name = '4340 Steel';

-- ============================================================================
-- HONDA B/K SERIES CRANKSHAFTS
-- ============================================================================

-- Honda B18C Type R Crank (stock, high-revving)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'B18C Type R', '13310-P73-003', 87.2, 52.0, 48.0,
       4, 5, '1-3-4-2', TRUE, FALSE, 11.5, mat.id, 9000, 220.0, 800.00, 400.00,
       'B18C Type R crank, 3.43" stroke, forged steel, 8900 RPM redline (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Forged Steel';

-- Brian Crower B-Series Stroker Crank (95mm stroke)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'BC B-Series Stroker', 'BC0311', 95.0, 52.0, 48.0,
       4, 5, '1-3-4-2', TRUE, FALSE, 12.0, mat.id, 8500, 280.0, 1200.00, NULL,
       'Brian Crower stroker crank for B16/B18, 95mm (3.74") stroke, 2.0L+ displacement'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = '4340 Steel';

-- Honda K24A2 Stock Crank (2.4L)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, 'K24A2 Stock', '13310-RAA-A01', 99.0, 52.0, 50.0,
       4, 5, '1-3-4-2', TRUE, FALSE, 15.0, mat.id, 7500, 220.0, 600.00, 250.00,
       'K24A2 stock crank, 99mm (3.90") stroke, strong for boost (2003, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Forged Steel';

-- ============================================================================
-- JDM CRANKSHAFTS (2JZ, 4G63)
-- ============================================================================

-- Toyota 2JZ-GTE Stock Crank (forged, bulletproof)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, '2JZ-GTE Stock', '13401-46010', 86.0, 60.0, 54.0,
       6, 7, '1-5-3-6-2-4', TRUE, FALSE, 25.0, mat.id, 8000, 1000.0, 1200.00, 500.00,
       '2JZ-GTE forged crank, 86mm (3.39") stroke, legendary for 1000+ HP (1991, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- Mitsubishi 4G63 Evo VIII/IX Crank (forged)
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, rod_journal_diameter,
                        cylinder_count, main_bearing_count, firing_order, internal_balance, external_balance,
                        weight, material_id, max_rpm, max_power, price_new, price_used, notes)
SELECT m.id, '4G63 Evo VIII', 'MD311348', 88.0, 54.0, 50.0,
       4, 5, '1-3-4-2', TRUE, FALSE, 14.5, mat.id, 8500, 600.0, 900.00, 450.00,
       '4G63 Evo VIII/IX forged crank, 88mm (3.46") stroke, rally-proven (2003, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Mitsubishi' AND mat.name = 'Forged Steel';

-- ============================================================================
-- ============================================================================
-- LS: (LS1, LS3, LS7, TSP 4.125" stroker)
-- SBC: (350 cast, 383 stroker, 406 stroker)
-- Honda: (B18C Type R, BC B-series stroker, K24A2)
-- JDM: (2JZ-GTE, 4G63 Evo)
--
-- ============================================================================
