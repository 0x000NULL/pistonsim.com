-- ============================================================================
-- PISTON Parts Database - Cylinder Heads Data
-- ============================================================================
-- Cylinder heads matching engine blocks in the database:
-- - GM LS family heads (LS1, LS2, LS3, LS6, LS7, LS9, 243/799, aftermarket)
-- - Small Block Chevy heads (Vortec, aftermarket performance)
-- - Honda B/K series heads (B16, B18C, K20, K24)
-- - JDM heads (2JZ-GE, 4G63, SR20DET)
-- - Ford Coyote, Chrysler Hemi
--
-- Note: sample_data.sql already contains some heads
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 33 cylinder_heads

-- ============================================================================
-- GM LS FAMILY CYLINDER HEADS
-- ============================================================================

-- GM LS1 243 Casting Heads (5.7L, rectangular port)
-- LS/SBC heads are OHV (pushrod) -- corrected from mislabeled DOHC (P2-15)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS1 243 Casting', '12558062', 'OHV', 2, 67.0, 'cathedral', 51.0, 40.0,
       210.0, 80.0, 14.0, 99.0, 111.76, 22.0, mat.id, 800.00, 300.00,
       'LS1 cathedral port heads, 243 casting, OHV 2V, 2.00"/1.55" valves (1998, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LS(high-flow LS heads)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS6', '12561168', 'OHV', 2, 65.5, 'cathedral', 51.0, 40.0,
       220.0, 82.0, 14.2, 99.0, 111.76, 22.5, mat.id, 1500.00, 600.00,
       'LS6 cathedral port heads, OHV 2V, higher flow than LS1, 2.00"/1.55" valves (2001, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LS3 L92/LS3 Rectangle Port Heads
-- LS3/L92 chamber_type is 'rectangular' (rectangle port, not cathedral); OHV (P2-15)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS3 L92', '12622033', 'OHV', 2, 68.0, 'wedge', 53.0, 42.0,
       260.0, 90.0, 15.0, 103.25, 111.76, 24.0, mat.id, 1800.00, 800.00,
       'LS3/L92 rectangle port heads, OHV 2V, 2.165"/1.59" valves, high flow (2008, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LS(titanium valves, CNC ported)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS7', '12480008', 'OHV', 2, 70.0, 'cathedral', 54.0, 42.0,
       270.0, 92.0, 15.5, 104.8, 111.76, 25.0, mat.id, 4500.00, 2800.00,
       'LS7 CNC ported heads, OHV 2V, titanium intake valves, 2.20"/1.61" valves (2006, new)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM LS9 Supercharged Heads (ZR1)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS9', '12623968', 'OHV', 2, 64.5, 'cathedral', 53.0, 42.0,
       255.0, 88.0, 14.8, 103.25, 111.76, 24.5, mat.id, 3500.00, 2000.00,
       'LS9 supercharged heads, OHV 2V, sodium-filled valves, 2.16"/1.59" valves (2009, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- GM 799/243 Truck Heads (budget LS performance)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '799 Truck Head', '12558060', 'OHV', 2, 64.0, 'cathedral', 51.0, 40.0,
       215.0, 81.0, 14.0, 101.6, 111.76, 22.5, mat.id, 600.00, 200.00,
       '799/243 truck heads, OHV 2V, cathedral port, budget performance, 2.00"/1.55" valves (2005, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- Texas Speed LS3 CNC Ported Heads (aftermarket)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'TSP LS3 CNC', 'TSP-LS3-CNC', 'OHV', 2, 68.0, 'cathedral', 54.0, 42.0,
       280.0, 95.0, 16.0, 103.25, 111.76, 24.0, mat.id, 2800.00, NULL,
       'Texas Speed CNC ported LS3 heads, OHV 2V, 2.20"/1.61" stainless valves, 320+ CFM (2015, new)'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- SMALL BLOCK CHEVY (GEN I) HEADS
-- ============================================================================

-- Chevy Vortec Heads (iron, budget performance)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'Vortec 906', '10239906', 'OHV', 2, 64.0, 'heart', 48.0, 38.0,
       170.0, 70.0, 12.7, 101.6, 108.0, 44.0, mat.id, 600.00, 150.00,
       'Vortec iron heads, heart-shaped chamber, 1.94"/1.50" valves, 200+ CFM (1996, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Cast Iron';

-- Edelbrock Performer RPM SBC Heads (aluminum aftermarket)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'Performer RPM SBC', '60179', 'OHV', 2, 72.0, 'heart', 53.0, 40.0,
       185.0, 75.0, 13.7, 101.6, 108.0, 23.0, mat.id, 1400.00, 700.00,
       'Edelbrock aluminum heads, 2.02"/1.60" valves, 230 CFM intake (2000, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Edelbrock' AND mat.name = 'Aluminum 6061-T6';

-- AFR 227 Race SBC Heads (high-performance aluminum)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'AFR 227 Race', 'AFR-1115', 'OHV', 2, 75.0, 'heart', 55.0, 43.0,
       227.0, 85.0, 14.0, 106.0, 108.0, 25.0, mat.id, 3200.00, 1800.00,
       'AFR race heads, OHV 2V, 2.08"/1.60" stainless valves, 290+ CFM intake (GM placeholder for AFR) (2010, new)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- HONDA B/K SERIES HEADS
-- ============================================================================

-- Honda B16A VTEC Head (high-revving)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B16A VTEC', 'B16A2-HEAD', 'DOHC', 4, 47.5, 'pent_roof', 31.0, 27.0,
       120.0, 55.0, 11.5, 81.0, 84.5, 14.0, mat.id, 800.00, 400.00,
       'B16A VTEC head, 4 valves/cyl, 8500 RPM capable, 1.22"/1.06" valves (1989, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda B18C Type R Head (Integra Type R)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B18C Type R', 'B18C5-HEAD', 'DOHC', 4, 49.2, 'pent_roof', 33.0, 28.0,
       130.0, 58.0, 11.8, 81.0, 84.5, 15.0, mat.id, 1500.00, 800.00,
       'B18C5 Type R head, high-flow VTEC, 8900 RPM, 1.30"/1.10" valves (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda K20A i-VTEC Head (RSX Type S)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K20A i-VTEC', 'K20A2-HEAD', 'DOHC', 4, 51.0, 'pent_roof', 35.0, 30.0,
       145.0, 62.0, 12.0, 86.0, 90.0, 16.5, mat.id, 1200.00, 600.00,
       'K20A2 i-VTEC head, VTC on intake cam, 8200 RPM, 1.38"/1.18" valves (2002, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda K24A2 Head (Accord, TSX)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K24A2', 'K24A2-HEAD', 'DOHC', 4, 62.5, 'pent_roof', 35.0, 30.0,
       150.0, 64.0, 12.2, 87.0, 90.0, 17.0, mat.id, 1000.00, 500.00,
       'K24A2 head, larger chamber than K20, i-VTEC, 1.38"/1.18" valves (2003, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- JDM PERFORMANCE HEADS
-- ============================================================================

-- Toyota 2JZ-GE Head (naturally aspirated)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ-GE Head', '11101-46050', 'DOHC', 4, 58.5, 'pent_roof', 33.5, 29.0,
       155.0, 66.0, 11.5, 86.0, 91.5, 28.0, mat.id, 800.00, 350.00,
       '2JZ-GE head, DOHC 24V, VVT-i, 1.32"/1.14" valves, N/A version (1991, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Aluminum 356';

-- Mitsubishi 4G63 Evo VIII/IX Head (high-flow turbo)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '4G63 Evo VIII', 'MD366969', 'DOHC', 4, 52.0, 'pent_roof', 34.5, 30.0,
       148.0, 63.0, 11.8, 85.0, 88.0, 18.0, mat.id, 1200.00, 600.00,
       '4G63 Evo VIII/IX head, MIVEC, turbo optimized, 1.38"/1.18" valves (2003, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Mitsubishi' AND mat.name = 'Aluminum 356';

-- Nissan SR20DET Head (S13/S14/S15)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SR20DET Head', 'SR20DET-HEAD', 'DOHC', 4, 50.8, 'pent_roof', 33.0, 29.0,
       140.0, 60.0, 11.5, 86.0, 88.0, 16.0, mat.id, 1000.00, 500.00,
       'SR20DET head, DOHC 16V, VVL on later models, 1.30"/1.14" valves (1991, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Nissan' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- FORD & CHRYSLER HEADS
-- ============================================================================

-- Ford Coyote 5.0 Head (DOHC Ti-VCT)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'Coyote 5.0 Head', 'BR3E-6049-BA', 'DOHC', 4, 63.0, 'pent_roof', 37.5, 31.5,
       180.0, 72.0, 12.5, 92.2, 100.0, 20.0, mat.id, 1800.00, 900.00,
       'Coyote DOHC head, Ti-VCT, 4 valves/cyl, 1.59"/1.22" valves (2011, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Aluminum 356';

-- Chrysler 392 Hemi Head (6.4L)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '392 Hemi Head', '53021616AD', 'OHV', 2, 90.5, 'hemi', 52.0, 42.0,
       240.0, 88.0, 13.5, 103.9, 107.8, 26.0, mat.id, 2000.00, 1000.00,
       '392 Hemi head, hemispherical chamber, VVT, 2.09"/1.65" valves (2011, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- JAPANESE IMPORTS (EXTENDED)
-- ============================================================================

-- Honda B16B Head (EK9 Civic Type R, JDM)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B16B', 'B16B-EK9', 'DOHC', 4, 46.5, 'pent_roof', 31.0, 27.0,
       125.0, 56.0, 11.6, 81.0, 84.5, 14.5, mat.id, 1600.00, 900.00,
       'B16B EK9 Civic Type R head, JDM-only, 10.8:1 CR, hand-ported, 8400 RPM (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda B18A1 LS Head (Integra LS, non-VTEC)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B18A1 LS', 'B18A1-DA9', 'DOHC', 4, 50.0, 'pent_roof', 31.0, 26.5,
       115.0, 53.0, 10.8, 81.0, 84.5, 14.0, mat.id, 500.00, 200.00,
       'B18A1 LS head, non-VTEC DOHC, common LS/VTEC swap base, 1.22"/1.04" valves (1990, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda B20 VTEC Head (B20/VTEC swap with B16/B18 head)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B20 VTEC', 'B20VTEC-HEAD', 'DOHC', 4, 51.0, 'pent_roof', 33.0, 28.0,
       132.0, 59.0, 11.8, 84.0, 84.5, 15.0, mat.id, 1100.00, 550.00,
       'B20/VTEC swap head, B-series VTEC head on B20Z block, big-bore N/A combo (used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda K20A Type R PRC Head (EP3/DC5 JDM)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K20A Type R PRC', 'K20A-PRC', 'DOHC', 4, 50.0, 'pent_roof', 35.0, 30.0,
       150.0, 65.0, 12.5, 86.0, 90.0, 16.5, mat.id, 2200.00, 1200.00,
       'K20A Type R PRC head, EP3/DC5 JDM, hand-ported, 11.5:1 CR, 8400 RPM redline (2001, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda K20Z3 Head (FA5/FG2 Civic Si)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K20Z3', 'K20Z3-FA5', 'DOHC', 4, 51.5, 'pent_roof', 35.0, 30.0,
       146.0, 63.0, 12.2, 86.0, 90.0, 16.5, mat.id, 1300.00, 650.00,
       'K20Z3 head, FA5/FG2 Civic Si, i-VTEC with intake VTC, 1.38"/1.18" valves (2006, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Honda K24A4 Head (TSX, Element)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K24A4', 'K24A4-HEAD', 'DOHC', 4, 63.5, 'pent_roof', 34.0, 29.0,
       138.0, 60.0, 11.6, 87.0, 90.0, 17.0, mat.id, 700.00, 300.00,
       'K24A4 head, TSX/Element, low-flow vs K24A2, common K-series swap base, 1.34"/1.14" valves (2003, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- Toyota 2JZ-GTE VVT-i Head (MkIV JDM Supra)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ-GTE VVT-i', '11101-46051-VVTI', 'DOHC', 4, 60.5, 'pent_roof', 33.5, 29.0,
       162.0, 70.0, 11.6, 86.0, 91.5, 28.5, mat.id, 2500.00, 1400.00,
       '2JZ-GTE VVT-i head, MkIV JDM Supra, twin-turbo, recessed deck, 1.32"/1.14" valves (1997, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Aluminum 356';

-- Toyota 2JZ-GTE Non-VVTi Head (export Supra, Aristo)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ-GTE Non-VVTi', '11101-46055', 'DOHC', 4, 58.0, 'pent_roof', 33.5, 29.0,
       160.0, 68.0, 11.5, 86.0, 91.5, 28.0, mat.id, 2200.00, 1200.00,
       '2JZ-GTE non-VVTi head, export MkIV Supra/Aristo, twin-turbo, simpler cam drive (1993, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Aluminum 356';

-- Toyota 1JZ-GTE Head (Aristo, Chaser, Soarer)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '1JZ-GTE', '11101-46050-1JZ', 'DOHC', 4, 56.5, 'pent_roof', 33.0, 28.0,
       148.0, 64.0, 11.4, 86.0, 88.0, 25.5, mat.id, 1500.00, 700.00,
       '1JZ-GTE head, JZX/Aristo/Soarer, 2.5L turbo, VVT-i on later revisions, 1.30"/1.10" valves (1990, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Aluminum 356';

-- Nissan RB26DETT Head (R32/R33/R34 GT-R)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'RB26DETT', 'RB26DETT-N1', 'DOHC', 4, 53.0, 'pent_roof', 34.5, 30.0,
       155.0, 67.0, 11.8, 86.0, 98.0, 27.0, mat.id, 3500.00, 1800.00,
       'RB26DETT head, R32/33/34 Skyline GT-R, twin-turbo, individual throttle bodies, 1.36"/1.18" valves (1989, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Nissan' AND mat.name = 'Aluminum 356';

-- Nissan RB25DET NEO Head (R34 25GT-T)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'RB25DET NEO', 'RB25DET-NEO', 'DOHC', 4, 56.5, 'pent_roof', 33.0, 29.0,
       145.0, 62.0, 11.4, 86.0, 98.0, 26.5, mat.id, 1400.00, 650.00,
       'RB25DET NEO head, R34 25GT-T, NEO solid lifters, NVCS, single-turbo 2.5L (1998, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Nissan' AND mat.name = 'Aluminum 356';

-- Nissan SR20VE NEO VVL Head (P11 Primera)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SR20VE NEO VVL', 'SR20VE-NEO', 'DOHC', 4, 49.5, 'pent_roof', 33.5, 29.0,
       142.0, 61.0, 11.6, 86.0, 88.0, 16.5, mat.id, 1300.00, 600.00,
       'SR20VE NEO head, P11 Primera, NVCS + VVL (Nissan VTEC equivalent), high-rev N/A (1998, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Nissan' AND mat.name = 'Aluminum 356';

-- Mitsubishi 4G63 Evo IV-VI Head (7-bolt)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '4G63 Evo IV-VI', '4G63-EVOVI-7B', 'DOHC', 4, 51.5, 'pent_roof', 33.5, 29.0,
       144.0, 61.0, 11.6, 85.0, 88.0, 17.5, mat.id, 1100.00, 500.00,
       '4G63 Evo IV-VI head, 7-bolt crank era, turbo-optimized, pre-MIVEC, 1.32"/1.14" valves (1996, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Mitsubishi' AND mat.name = 'Aluminum 356';

-- Mitsubishi 4G63 DSM 7-bolt Head (Eclipse/Talon GSX 2G)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, valve_configuration, valves_per_cylinder,
                           combustion_chamber_volume, chamber_type, intake_valve_diameter, exhaust_valve_diameter,
                           intake_port_volume, exhaust_port_volume, max_lift, compatible_bore, compatible_spacing,
                           weight, material_id, price_new, price_used, notes)
SELECT m.id, '4G63 DSM 7-bolt', '4G63-DSM-7BOLT', 'DOHC', 4, 52.5, 'pent_roof', 33.0, 28.5,
       140.0, 60.0, 11.4, 85.0, 88.0, 17.5, mat.id, 900.00, 400.00,
       '4G63 DSM 7-bolt head, 2G Eclipse/Talon GSX, turbo, pre-MIVEC US-spec, 1.30"/1.12" valves (1995, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Mitsubishi' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- ============================================================================
-- GM LS: (LS1, LS6, LS3, LS7, LS9, 799, TSP)
-- SBC Gen I: (Vortec, Edelbrock, AFR)
-- Honda: (B16A, B16B, B18A1, B18C, B20 VTEC, K20A, K20A PRC, K20Z3, K24A2, K24A4)
-- JDM: (2JZ-GE, 2JZ-GTE VVT-i, 2JZ-GTE Non-VVTi, 1JZ-GTE, 4G63 Evo VIII, 4G63 Evo IV-VI,
--                4G63 DSM 7-bolt, SR20DET, SR20VE NEO, RB26DETT, RB25DET NEO)
-- Ford/Chrysler: (Coyote, 392 Hemi)
--
-- Total with sample_data.sql: 39+ cylinder heads
-- ============================================================================
