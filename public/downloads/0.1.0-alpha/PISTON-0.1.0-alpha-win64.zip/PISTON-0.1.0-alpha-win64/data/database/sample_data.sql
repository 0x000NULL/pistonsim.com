-- ============================================================================
-- PISTON Parts Database - Sample Data
-- ============================================================================
-- Populates database with realistic sample data for testing and development
--
-- Contents:
-- 1. Manufacturers
-- 2. Materials
-- 3. Fuels
-- 4. Engine Blocks
-- 5. Cylinder Heads
-- 6. Pistons
-- 7. Connecting Rods
-- 8. Crankshafts
-- 9. Camshafts
-- 10. Turbochargers
-- 11. Intake Manifolds
-- 12. Compatibility Rules
-- 13. Sample Saved Configurations (2 builds)
--
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 10 manufacturers
-- Rows: 10 materials
-- Rows: 6 fuels
-- Rows: 5 engine_blocks
-- Rows: 5 cylinder_heads
-- Rows: 5 pistons
-- Rows: 4 connecting_rods
-- Rows: 5 crankshafts
-- Rows: 5 camshafts
-- Rows: 4 turbochargers
-- Rows: 5 intake_manifolds
-- Rows: 8 compatibility_rules
-- Rows: 2 saved_configurations

-- ============================================================================
-- MANUFACTURERS
-- ============================================================================

INSERT INTO manufacturers (name, country, website, notes) VALUES
('General Motors', 'USA', 'https://www.gm.com', 'LS and LT engine family'),
('Ford Motor Company', 'USA', 'https://www.ford.com', 'Modular, Coyote, and Windsor families'),
('Chrysler', 'USA', 'https://www.stellantis.com', 'Hemi family'),
('Toyota', 'Japan', 'https://www.toyota.com', 'JZ and UZ families'),
('Honda', 'Japan', 'https://www.honda.com', 'K-series and B-series'),
('Comp Cams', 'USA', 'https://www.compcams.com', 'Camshaft manufacturer'),
('Texas Speed & Performance', 'USA', 'https://www.texas-speed.com', 'LS performance specialist'),
('Garrett Motion', 'USA', 'https://www.garrettmotion.com', 'Turbocharger manufacturer'),
('Precision Turbo', 'USA', 'https://www.precisionturbo.net', 'High-performance turbos'),
('Wiseco', 'USA', 'https://www.wiseco.com', 'Forged piston manufacturer');

-- ============================================================================
-- MATERIALS
-- ============================================================================

INSERT INTO materials (name, type, density, tensile_strength, yield_strength, thermal_conductivity, thermal_expansion, notes) VALUES
('Cast Iron', 'metal', 7200, 250, 150, 50, 11.0, 'Traditional block material, good wear resistance'),
('Aluminum 356', 'alloy', 2700, 172, 124, 151, 21.5, 'Common cast aluminum alloy for blocks and heads'),
('Aluminum 6061-T6', 'alloy', 2700, 310, 276, 167, 23.6, 'Strong aluminum alloy for billet parts'),
('Forged Steel', 'metal', 7850, 950, 650, 50, 11.7, 'High-strength steel for connecting rods'),
('4340 Steel', 'alloy', 7850, 1240, 1100, 44, 12.3, 'Premium alloy steel for cranks and rods'),
('Titanium Ti-6Al-4V', 'alloy', 4500, 950, 880, 7, 8.6, 'Aerospace-grade titanium for rods and valves'),
('2618 Aluminum', 'alloy', 2770, 455, 400, 133, 23.4, 'High-strength forged piston material'),
('4032 Aluminum', 'alloy', 2680, 380, 315, 155, 18.9, 'Low-expansion piston material'),
('Ductile Iron', 'metal', 7100, 550, 380, 36, 12.0, 'Strong cast iron for cranks'),
('Nodular Iron', 'metal', 7150, 420, 290, 36, 11.5, 'Ductile cast iron variant');

-- ============================================================================
-- FUELS
-- ============================================================================

-- Octanes, heating value, density and stoichiometric AFR restate the FuelProperties
-- factories, the one authoritative fuel table (PIS-0187); tests/systems/fuel/
-- test_FuelSourceAgreement.cpp holds them equal. These rows used to disagree with it on
-- almost every figure (E85 by 3-5 octane numbers; 'Race Gas 100' was 104 AKI).
INSERT INTO fuels (name, common_name, octane_ron, octane_mon, octane_aki, ethanol_content,
                  lower_heating_value, density, stoichiometric_afr, laminar_flame_speed,
                  autoignition_temp, notes) VALUES
('Gasoline 87', 'Regular Unleaded', 91, 83, 87, 10, 43.4, 0.72, 14.7, 0.37, 530, 'Pump gas, 87 AKI (R+M)/2'),
('Gasoline 91', 'Premium', 95, 87, 91, 10, 43.5, 0.73, 14.7, 0.37, 530, 'Premium, 91 AKI (West Coast)'),
('Gasoline 93', 'Premium Plus', 97, 89, 93, 10, 43.5, 0.74, 14.7, 0.37, 530, 'Premium, 93 AKI (East Coast)'),
('E85', 'Flex Fuel', 108, 100, 105, 85, 27.0, 0.79, 9.8, 0.48, 636, '85% ethanol blend, 105 AKI'),
('Race Gas 100', 'Unleaded Race', 104, 96, 100, 0, 43.5, 0.74, 14.7, 0.40, 530, 'Unleaded race fuel, 100 AKI'),
('Race Gas 110', 'Leaded Race', 117, 103, 110, 0, 43.8, 0.75, 14.7, 0.38, 530, 'Leaded race fuel, 110 AKI (not street legal)');

-- ============================================================================
-- ENGINE BLOCKS
-- ============================================================================

-- GM LS3 6.2L (C6 Corvette, Camaro SS)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS3', '12628927', 103.25, 92.0, 234.95, 111.76, 8, 'V', 90,
       104.8, 233.5, 5, 60.0, 27.2, 95.0, mat.id, 2500.00, 800.00,
       '6.2L Gen IV small-block V8, aluminum, 376 ci displacement'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- Ford Coyote 5.0L (Mustang GT)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'Coyote 5.0', 'BR3E-6015-DA', 92.2, 92.7, 216.0, 100.0, 8, 'V', 90,
       93.5, 214.5, 5, 62.0, 25.0, 97.5, mat.id, 3500.00, 1200.00,
       '5.0L DOHC V8, aluminum, 302 ci, Ti-VCT'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Aluminum 356';

-- Chrysler 392 Hemi (6.4L)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '392 Hemi', '5038925AA', 103.0, 94.6, 226.0, 107.95, 8, 'V', 90,
       104.5, 224.5, 5, 62.5, 24.0, 105.0, mat.id, 4500.00, 1500.00,
       '6.4L Hemi V8, cast iron, 392 ci, modern Gen III Hemi'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Cast Iron';

-- Toyota 2JZ-GTE (Supra)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ-GTE', '11400-46090', 86.0, 86.0, 213.5, 91.5, 6, 'inline', NULL,
       87.5, 212.0, 7, 62.0, 23.0, 100.0, mat.id, NULL, 3500.00,
       '3.0L inline-6, cast iron block, twin-turbo, legendary durability'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Cast Iron';

-- Honda K24 (Civic Si, Accord)
INSERT INTO engine_blocks (manufacturer_id, model, part_number, bore, stroke, deck_height, bore_spacing,
                          cylinder_count, configuration, bank_angle, max_bore, min_deck_height,
                          main_bearing_count, main_bearing_diameter, main_bearing_width,
                          weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K24A2', '10002-RBB-000', 87.0, 99.0, 212.0, 92.0, 4, 'inline', NULL,
       88.0, 210.5, 5, 52.0, 21.0, 68.0, mat.id, NULL, 800.00,
       '2.4L inline-4, aluminum, DOHC i-VTEC, 144 ci'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- CYLINDER HEADS
-- ============================================================================

-- NOTE (PIS-0106 data audit): the flow_data_json curves originally seeded for the
-- LS3, Coyote, 392 Hemi and 2JZ-GTE heads were removed. Their low-lift points
-- converted to discharge coefficients of 1.08-1.41 against the curtain area at the
-- standard 28 inH2O depression -- physically impossible (measured flow cannot
-- exceed ideal curtain flow), consistent with the CFM column being shifted one
-- lift step. Rather than guessing a correction, the curves are NULL until someone
-- re-enters them from a verified flow sheet. The K24A2 curve converts to plausible
-- Cd (0.41-0.93) end-to-end and is kept.
-- GM LS(rectangle port)
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, compatible_spacing, bolt_pattern,
                           combustion_chamber_cc, valve_angle, quench_area_percent,
                           intake_valve_count, intake_valve_diameter, intake_valve_stem_diameter,
                           intake_port_volume, intake_runner_cross_section,
                           exhaust_valve_count, exhaust_valve_diameter, exhaust_valve_stem_diameter,
                           exhaust_port_volume, exhaust_runner_cross_section,
                           flow_data_json, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS3 Heads', '12622169', 111.76, 'LS standard',
       65.0, 15.0, 62.0,
       1, 51.0, 8.0, 265.0, 25.5,
       1, 44.5, 8.0, 85.0, 19.5,
       NULL,
       18.0, mat.id, 2000.00, 600.00, 'Rectangle port heads, 260 cc runners, flows ~297 CFM intake'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- Ford Coyote Heads
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, compatible_spacing, bolt_pattern,
                           combustion_chamber_cc, valve_angle, quench_area_percent,
                           intake_valve_count, intake_valve_diameter, intake_valve_stem_diameter,
                           intake_port_volume, intake_runner_cross_section,
                           exhaust_valve_count, exhaust_valve_diameter, exhaust_valve_stem_diameter,
                           exhaust_port_volume, exhaust_runner_cross_section,
                           flow_data_json, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'Coyote DOHC Heads', 'BR3E-6090-HA', 100.0, 'Modular DOHC',
       58.0, 12.0, 55.0,
       2, 37.0, 6.0, 185.0, 21.0,
       2, 32.5, 6.0, 72.0, 16.5,
       NULL,
       16.5, mat.id, 3000.00, 900.00, 'DOHC 4-valve heads, Ti-VCT variable timing, flows ~306 CFM'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Aluminum 356';

-- Chrysler 392 Hemi Heads
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, compatible_spacing, bolt_pattern,
                           combustion_chamber_cc, valve_angle, quench_area_percent,
                           intake_valve_count, intake_valve_diameter, intake_valve_stem_diameter,
                           intake_port_volume, intake_runner_cross_section,
                           exhaust_valve_count, exhaust_valve_diameter, exhaust_valve_stem_diameter,
                           exhaust_port_volume, exhaust_runner_cross_section,
                           flow_data_json, weight, material_id, price_new, price_used, notes)
SELECT m.id, '392 Hemi Heads', '5038926AB', 107.95, 'Gen III Hemi',
       74.0, 13.5, 58.0,
       1, 54.0, 8.5, 280.0, 27.0,
       1, 44.0, 8.5, 95.0, 20.0,
       NULL,
       22.0, mat.id, 3500.00, 1000.00, 'Modern Hemi heads, variable valve timing, flows ~318 CFM'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Aluminum 356';

-- Toyota 2JZ-GTE Heads
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, compatible_spacing, bolt_pattern,
                           combustion_chamber_cc, valve_angle, quench_area_percent,
                           intake_valve_count, intake_valve_diameter, intake_valve_stem_diameter,
                           intake_port_volume, intake_runner_cross_section,
                           exhaust_valve_count, exhaust_valve_diameter, exhaust_valve_stem_diameter,
                           exhaust_port_volume, exhaust_runner_cross_section,
                           flow_data_json, weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ-GTE Head', '11101-46090', 91.5, '2JZ DOHC',
       52.0, 10.0, 60.0,
       2, 33.5, 6.0, 155.0, 18.5,
       2, 30.0, 6.0, 68.0, 15.0,
       NULL,
       15.0, mat.id, NULL, 1200.00, 'DOHC 4-valve inline-6 head, solid for 1000+ HP'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Aluminum 356';

-- Honda K24 Head
INSERT INTO cylinder_heads (manufacturer_id, model, part_number, compatible_spacing, bolt_pattern,
                           combustion_chamber_cc, valve_angle, quench_area_percent,
                           intake_valve_count, intake_valve_diameter, intake_valve_stem_diameter,
                           intake_port_volume, intake_runner_cross_section,
                           exhaust_valve_count, exhaust_valve_diameter, exhaust_valve_stem_diameter,
                           exhaust_port_volume, exhaust_runner_cross_section,
                           flow_data_json, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K24A2 Head', '12100-RBB-010', 92.0, 'K-series DOHC',
       48.0, 8.0, 65.0,
       2, 35.0, 5.5, 140.0, 17.0,
       2, 30.5, 5.5, 62.0, 14.0,
       '{"intake":[[1.27,58.7],[2.54,118.5],[3.81,165.1],[5.08,198.9],[6.35,223.1],[7.62,239.6],[8.89,250.2],[10.16,256.8],[11.43,260.5],[12.70,262.3]],"exhaust":[[1.27,47.2],[2.54,94.1],[3.81,129.2],[5.08,155.6],[6.35,175.3],[7.62,189.4],[8.89,198.7],[10.16,204.6],[11.43,207.8],[12.70,209.4]]}',
       12.5, mat.id, NULL, 400.00, 'DOHC i-VTEC head, compact and efficient'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- PISTONS
-- ============================================================================

-- Wiseco LS3 Forged Piston
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter, pin_length,
                    dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter,
                    ring_pack, top_ring_thickness, second_ring_thickness, oil_ring_thickness,
                    weight, material_id, coating, skirt_coating, max_rpm, max_boost, price_new, notes)
SELECT m.id, 'K0412X3 LS3 Forged', 'K0412X3', 103.25, 32.13, 22.23, 60.0,
       8.0, NULL, 4.0, 55.0, 3.5, 48.0,
       '1.5/1.5/3.0mm', 1.5, 1.5, 3.0,
       520.0, mat.id, 'ArmorGlide', 'Molybdenum', 8000, 35, 650.00,
       'Forged 2618 alloy, -8cc dish, good for 10.5:1 CR with 65cc heads'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- Wiseco Coyote Forged Piston
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter, pin_length,
                    dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter,
                    ring_pack, top_ring_thickness, second_ring_thickness, oil_ring_thickness,
                    weight, material_id, coating, skirt_coating, max_rpm, max_boost, price_new, notes)
SELECT m.id, 'K0604X Coyote Forged', 'K0604X', 92.7, 31.75, 21.0, 55.0,
       12.0, NULL, 3.5, 40.0, 3.0, 35.0,
       '1.2/1.5/3.0mm', 1.2, 1.5, 3.0,
       480.0, mat.id, 'ArmorGlide', 'Molybdenum', 8500, 30, 700.00,
       'Forged 2618 alloy for Coyote 5.0, -12cc dish'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- Wiseco 2JZ Forged Piston
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter, pin_length,
                    dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter,
                    ring_pack, top_ring_thickness, second_ring_thickness, oil_ring_thickness,
                    weight, material_id, coating, skirt_coating, max_rpm, max_boost, price_new, notes)
SELECT m.id, 'K608M86 2JZ Forged', 'K608M86', 86.5, 34.5, 22.0, 58.0,
       22.0, NULL, 4.0, 38.0, 3.5, 33.0,
       '1.2/1.5/2.8mm', 1.2, 1.5, 2.8,
       510.0, mat.id, 'ArmorGlide', 'Molybdenum', 8500, 50, 750.00,
       'Forged 2618 alloy, -22cc dish, 8.5:1 CR for high boost'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- Wiseco K24 Forged Piston
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter, pin_length,
                    dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter,
                    ring_pack, top_ring_thickness, second_ring_thickness, oil_ring_thickness,
                    weight, material_id, coating, skirt_coating, max_rpm, max_boost, price_new, notes)
SELECT m.id, 'K587M87 K24 Forged', 'K587M87', 87.5, 30.0, 21.0, 50.0,
       10.0, NULL, 3.0, 38.0, 2.5, 33.0,
       '1.2/1.2/2.8mm', 1.2, 1.2, 2.8,
       380.0, mat.id, 'ArmorGlide', 'Molybdenum', 9000, 35, 600.00,
       'Forged 2618 alloy for turbo K24, -10cc dish'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- Wiseco 392 Hemi Forged Piston
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter, pin_length,
                    dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter,
                    ring_pack, top_ring_thickness, second_ring_thickness, oil_ring_thickness,
                    weight, material_id, coating, skirt_coating, max_rpm, max_boost, price_new, notes)
SELECT m.id, 'K0452X Hemi Forged', 'K0452X', 103.5, 33.0, 24.0, 62.0,
       18.0, NULL, 4.5, 58.0, 4.0, 48.0,
       '1.5/1.5/3.0mm', 1.5, 1.5, 3.0,
       540.0, mat.id, 'ArmorGlide', 'Molybdenum', 7500, 30, 720.00,
       'Forged 2618 alloy for Gen III Hemi, -18cc dish'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- ============================================================================
-- CONNECTING RODS
-- ============================================================================

-- Texas Speed LS H-Beam Rod
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter, big_end_width,
                            small_end_diameter, small_end_width, beam_type, beam_width, beam_thickness,
                            bolt_type, bolt_diameter, weight, material_id, max_rpm_rating, max_horsepower_rating,
                            tensile_strength_rating, price_new, notes)
SELECT m.id, 'TSP H-Beam LS Rod', 'TSPLS158H', 158.75, 53.9, 20.6, 22.23, 24.0,
       'H-beam', 18.0, 12.0, 'ARP2000', 10.0, 610.0, mat.id, 8000, 150, 950,
       480.00, 'Forged 4340 steel, ARP2000 bolts, 6.250" C-C'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = '4340 Steel';

-- Ford Coyote H-Beam Rod
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter, big_end_width,
                            small_end_diameter, small_end_width, beam_type, beam_width, beam_thickness,
                            bolt_type, bolt_diameter, weight, material_id, max_rpm_rating, max_horsepower_rating,
                            tensile_strength_rating, price_new, notes)
SELECT m.id, 'Manley H-Beam Coyote', '14015-8', 150.7, 53.0, 19.5, 21.0, 22.0,
       'H-beam', 17.0, 11.5, 'ARP2000', 9.5, 585.0, mat.id, 8500, 140, 950,
       520.00, 'Forged 4340 steel for Coyote 5.0, 5.933" C-C'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = '4340 Steel';

-- Honda K-Series H-Beam Rod
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter, big_end_width,
                            small_end_diameter, small_end_width, beam_type, beam_width, beam_thickness,
                            bolt_type, bolt_diameter, weight, material_id, max_rpm_rating, max_horsepower_rating,
                            tensile_strength_rating, price_new, notes)
SELECT m.id, 'Manley H-Beam K-Series', '14027-4', 152.0, 48.0, 18.5, 21.0, 20.0,
       'H-beam', 16.0, 10.5, 'ARP2000', 9.0, 495.0, mat.id, 9000, 130, 950,
       650.00, 'Forged 4340 steel for K24, 5.984" C-C'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = '4340 Steel';

-- Chrysler Hemi H-Beam Rod
INSERT INTO connecting_rods (manufacturer_id, model, part_number, center_to_center_length, big_end_diameter, big_end_width,
                            small_end_diameter, small_end_width, beam_type, beam_width, beam_thickness,
                            bolt_type, bolt_diameter, weight, material_id, max_rpm_rating, max_horsepower_rating,
                            tensile_strength_rating, price_new, notes)
SELECT m.id, 'Manley H-Beam Hemi', '14220-8', 157.1, 59.0, 21.5, 24.0, 24.5,
       'H-beam', 19.0, 13.0, 'ARP2000', 11.0, 665.0, mat.id, 7500, 160, 950,
       750.00, 'Forged 4340 steel for Gen III Hemi, 6.185" C-C'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = '4340 Steel';

-- ============================================================================
-- CRANKSHAFTS
-- ============================================================================

-- GM LS3 Forged Crankshaft
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, main_journal_width,
                        rod_journal_diameter, rod_journal_width, cylinder_count, main_bearing_count, firing_order,
                        counterweight_config, balance_factor, internal_balance, external_balance, bobweight,
                        weight, material_id, heat_treatment, max_rpm_rating, max_horsepower_rating,
                        price_new, price_used, notes)
SELECT m.id, 'LS3 Forged Crank', '12620474', 92.0, 60.0, 27.2, 53.8, 20.6, 8, 5, '1-8-7-2-6-5-4-3',
       'Full counterweights', 50, 1, 0, NULL, 28.5, mat.id, 'Nitrided', 7000, 650,
       1200.00, 400.00, '3.622" stroke forged steel crank, internal balance'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Forged Steel';

-- Ford Coyote Forged Crankshaft
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, main_journal_width,
                        rod_journal_diameter, rod_journal_width, cylinder_count, main_bearing_count, firing_order,
                        counterweight_config, balance_factor, internal_balance, external_balance, bobweight,
                        weight, material_id, heat_treatment, max_rpm_rating, max_horsepower_rating,
                        price_new, price_used, notes)
SELECT m.id, 'Coyote Forged Crank', 'BR3E-6303-EA', 92.7, 62.0, 25.0, 52.3, 19.5, 8, 5, '1-5-4-8-6-3-7-2',
       'Full counterweights', 50, 1, 0, NULL, 17.5, mat.id, 'Nitrided', 7500, 550,
       1500.00, 550.00, '3.65" stroke forged steel, cross-plane design; weight corrected to ~17.5 kg (PDDI-15)'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Forged Steel';

-- Toyota 2JZ Forged Crankshaft
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, main_journal_width,
                        rod_journal_diameter, rod_journal_width, cylinder_count, main_bearing_count, firing_order,
                        counterweight_config, balance_factor, internal_balance, external_balance, bobweight,
                        weight, material_id, heat_treatment, max_rpm_rating, max_horsepower_rating,
                        price_new, price_used, notes)
SELECT m.id, '2JZ-GTE Forged Crank', '13401-46040', 86.0, 62.0, 23.0, 52.0, 21.0, 6, 7, '1-5-3-6-2-4',
       'Full counterweights', 50, 1, 0, NULL, 26.0, mat.id, 'Nitrided', 8000, 1000,
       NULL, 800.00, '3.39" stroke, 7-main bearing design, legendary strength'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- Honda K24 Forged Crankshaft
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, main_journal_width,
                        rod_journal_diameter, rod_journal_width, cylinder_count, main_bearing_count, firing_order,
                        counterweight_config, balance_factor, internal_balance, external_balance, bobweight,
                        weight, material_id, heat_treatment, max_rpm_rating, max_horsepower_rating,
                        price_new, price_used, notes)
SELECT m.id, 'K24A2 Forged Crank', '13310-RBB-000', 99.0, 52.0, 21.0, 48.0, 18.5, 4, 5, '1-3-4-2',
       'Full counterweights', 50, 1, 0, NULL, 18.0, mat.id, 'Nitrided', 9000, 400,
       NULL, 300.00, '3.90" stroke, long-stroke design for torque'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Forged Steel';

-- Chrysler 392 Hemi Cast Crankshaft
INSERT INTO crankshafts (manufacturer_id, model, part_number, stroke, main_journal_diameter, main_journal_width,
                        rod_journal_diameter, rod_journal_width, cylinder_count, main_bearing_count, firing_order,
                        counterweight_config, balance_factor, internal_balance, external_balance, bobweight,
                        weight, material_id, heat_treatment, max_rpm_rating, max_horsepower_rating,
                        price_new, price_used, notes)
SELECT m.id, '392 Hemi Cast Crank', '5038927AA', 94.6, 62.5, 24.0, 59.0, 21.5, 8, 5, '1-8-4-3-6-5-7-2',
       'Full counterweights', 50, 0, 1, 1150.0, 22.0, mat.id, 'Nitrided', 6500, 500,
       800.00, 250.00, '3.72" stroke cast steel, external balance; weight corrected to ~22.0 kg (PDDI-15)'
FROM manufacturers m, materials mat
WHERE m.name = 'Chrysler' AND mat.name = 'Ductile Iron';

-- ============================================================================
-- CAMSHAFTS
-- ============================================================================

-- Comp Cams LS3 Mild Street Cam
INSERT INTO camshafts (manufacturer_id, model, part_number, intake_duration_050, exhaust_duration_050,
                      intake_duration_seat, exhaust_duration_seat, intake_lift, exhaust_lift,
                      intake_lobe_lift, exhaust_lobe_lift, lsa, intake_centerline, exhaust_centerline,
                      overlap, advance_built_in, profile_type, base_circle_diameter, lobe_taper,
                      lift_curve_data_json, rocker_ratio, valve_spring_requirement, max_rpm_safe, price_new, notes)
SELECT m.id, 'Xtreme Energy 224/224', '11-442-8', 224, 224, 275, 275, 14.0, 14.0, 8.75, 8.75,
       113, 109, 117, 24, 4, 'hydraulic_roller', 42.0, 0.5, NULL, 1.7,
       'Requires upgraded springs, 130 lb seat, 320 lb open', 6800, 380.00,
       'Mild street cam, excellent idle, 1500-6500 RPM powerband'
FROM manufacturers m WHERE m.name = 'Comp Cams';

-- Comp Cams LS3 Aggressive Street Cam
INSERT INTO camshafts (manufacturer_id, model, part_number, intake_duration_050, exhaust_duration_050,
                      intake_duration_seat, exhaust_duration_seat, intake_lift, exhaust_lift,
                      intake_lobe_lift, exhaust_lobe_lift, lsa, intake_centerline, exhaust_centerline,
                      overlap, advance_built_in, profile_type, base_circle_diameter, lobe_taper,
                      lift_curve_data_json, rocker_ratio, valve_spring_requirement, max_rpm_safe, price_new, notes)
SELECT m.id, 'Xtreme Energy 230/236', '11-600-8', 230, 236, 282, 288, 15.0, 15.2, 8.82, 8.94,
       115, 107, 123, 33, 4, 'hydraulic_roller', 42.0, 0.5, NULL, 1.7,
       'Requires upgraded springs, 140 lb seat, 360 lb open', 7000, 420.00,
       'Aggressive street, lopey idle, 2000-6800 RPM powerband'
FROM manufacturers m WHERE m.name = 'Comp Cams';

-- Texas Speed Stage 3 Turbo Cam (LS)
INSERT INTO camshafts (manufacturer_id, model, part_number, intake_duration_050, exhaust_duration_050,
                      intake_duration_seat, exhaust_duration_seat, intake_lift, exhaust_lift,
                      intake_lobe_lift, exhaust_lobe_lift, lsa, intake_centerline, exhaust_centerline,
                      overlap, advance_built_in, profile_type, base_circle_diameter, lobe_taper,
                      lift_curve_data_json, rocker_ratio, valve_spring_requirement, max_rpm_safe, price_new, notes)
SELECT m.id, 'TSP Stage 3 Turbo', 'TSPSTG3TC', 220, 228, 272, 280, 14.5, 14.5, 8.53, 8.53,
       117, 109, 125, 11, 4, 'hydraulic_roller', 42.0, 0.5, NULL, 1.7,
       'Requires upgraded springs, 135 lb seat, 340 lb open', 7200, 450.00,
       'Optimized for turbo, wide LSA for boost, 2500-7500 RPM'
FROM manufacturers m WHERE m.name = 'Texas Speed & Performance';

-- Comp Cams Coyote Stage 1 Cam
INSERT INTO camshafts (manufacturer_id, model, part_number, intake_duration_050, exhaust_duration_050,
                      intake_duration_seat, exhaust_duration_seat, intake_lift, exhaust_lift,
                      intake_lobe_lift, exhaust_lobe_lift, lsa, intake_centerline, exhaust_centerline,
                      overlap, advance_built_in, profile_type, base_circle_diameter, lobe_taper,
                      lift_curve_data_json, rocker_ratio, valve_spring_requirement, max_rpm_safe, price_new, notes)
SELECT m.id, 'Coyote Stage 1', '32-602-8', 214, 220, 265, 271, 13.2, 13.5, 11.0, 11.25,
       114, 107, 121, 20, 0, 'hydraulic_roller', 38.0, 0.4, NULL, 1.2,
       'Stock springs adequate', 7500, 550.00,
       'Mild DOHC cam for Coyote, compatible with stock valvetrain'
FROM manufacturers m WHERE m.name = 'Comp Cams';

-- Comp Cams 2JZ Turbo Cam
INSERT INTO camshafts (manufacturer_id, model, part_number, intake_duration_050, exhaust_duration_050,
                      intake_duration_seat, exhaust_duration_seat, intake_lift, exhaust_lift,
                      intake_lobe_lift, exhaust_lobe_lift, lsa, intake_centerline, exhaust_centerline,
                      overlap, advance_built_in, profile_type, base_circle_diameter, lobe_taper,
                      lift_curve_data_json, rocker_ratio, valve_spring_requirement, max_rpm_safe, price_new, notes)
SELECT m.id, '2JZ Turbo Cam', '32-2JZ-TC', 264, 272, 314, 322, 11.2, 11.5, 11.2, 11.5,
       118, 110, 126, 28, 0, 'mechanical_flat', 35.0, 0.3, NULL, 1.0,
       'Requires upgraded springs and shimming', 8500, 680.00,
       'Large turbo cam for 2JZ, boost-friendly LSA, 3000-8500 RPM'
FROM manufacturers m WHERE m.name = 'Comp Cams';

-- ============================================================================
-- TURBOCHARGERS
-- ============================================================================

-- Garrett GTX3582R Gen II
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          compressor_trim, compressor_housing_ar, turbine_inducer, turbine_exducer,
                          turbine_trim, turbine_housing_ar, compressor_map_data_json, turbine_map_data_json,
                          bearing_type, oil_cooled, water_cooled, max_rpm, max_boost, max_flow, weight, price_new, notes)
SELECT m.id, 'GTX3582R Gen II', '856801-5021S', 55.0, 82.0, 67, 0.70, 68.0, 62.0, 84, 0.83,
       NULL, NULL, 'ball_bearing', 1, 1, 230000, 45, 65, 9.5, 2200.00,
       'Dual ball bearing, 650-850 HP, excellent spool and top-end'
FROM manufacturers m WHERE m.name = 'Garrett Motion';

-- Garrett G42-1200
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          compressor_trim, compressor_housing_ar, turbine_inducer, turbine_exducer,
                          turbine_trim, turbine_housing_ar, compressor_map_data_json, turbine_map_data_json,
                          bearing_type, oil_cooled, water_cooled, max_rpm, max_boost, max_flow, weight, price_new, notes)
SELECT m.id, 'G42-1200', '880704-5002S', 67.0, 93.0, 65, 0.90, 84.0, 76.0, 83, 1.05,
       NULL, NULL, 'ball_bearing', 1, 1, 210000, 50, 120, 14.5, 2800.00,
       'Dual ball bearing, 1000-1200 HP capable, large frame'
FROM manufacturers m WHERE m.name = 'Garrett Motion';

-- Precision Turbo 6266 CEA
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          compressor_trim, compressor_housing_ar, turbine_inducer, turbine_exducer,
                          turbine_trim, turbine_housing_ar, compressor_map_data_json, turbine_map_data_json,
                          bearing_type, oil_cooled, water_cooled, max_rpm, max_boost, max_flow, weight, price_new, notes)
SELECT m.id, 'PT6266 CEA', 'PT6266', 62.0, 66.0, 68, 0.85, 68.0, 60.0, 84, 0.96,
       NULL, NULL, 'ceramic_ball', 1, 0, 250000, 50, 80, 10.0, 1900.00,
       'Ceramic ball bearing, 700-900 HP, great response and efficiency'
FROM manufacturers m WHERE m.name = 'Precision Turbo';

-- Precision Turbo 7675 Gen 2 (big power)
-- Wheel geometry from Full-Race's PT7675 CEA listing, full-race.com/76mm-precision-pt7675-cea-turbo
-- (accessed 2026-09-23): compressor inducer 76.71 mm, exducer 102.36 mm; turbine major diameter
-- 82 mm, exducer 75.08 mm; "rated for 1200hp depending on the application". A RESELLER figure:
-- precisionturbo.com could not be retrieved (it serves an automated-client challenge), so no
-- manufacturer sheet was read. Retail listings of the "Gen2 PT7675" name the same 76.71 mm
-- compressor and 75.08 mm turbine exducer. The row previously had a 75 mm compressor exducer
-- smaller than its 76 mm inducer, which the ORM rejects, and turbine and compressor housing A/Rs
-- (1.15, 1.06) matching none of the listed housings, so both A/Rs are now unstated (PIS-0195).
-- Trims follow from the diameters: (76.71/102.36)^2 = 56, (75.08/82)^2 = 84.
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          compressor_trim, compressor_housing_ar, turbine_inducer, turbine_exducer,
                          turbine_trim, turbine_housing_ar, compressor_map_data_json, turbine_map_data_json,
                          bearing_type, oil_cooled, water_cooled, max_rpm, max_boost, max_flow, weight, price_new, notes)
SELECT m.id, 'PT7675 Gen 2', 'PT7675-2', 76.71, 102.36, 56, NULL, 82.0, 75.08, 84, NULL,
       NULL, NULL, 'ceramic_ball', 1, 0, 220000, 55, 150, 16.5, 2500.00,
       'Ceramic ball bearing, rated 1,200 HP depending on application (reseller figure)'
FROM manufacturers m WHERE m.name = 'Precision Turbo';

-- ============================================================================
-- INTAKE MANIFOLDS
-- ============================================================================

-- GM LS3 Stock Intake
INSERT INTO intake_manifolds (manufacturer_id, model, part_number, configuration, runner_length, runner_diameter,
                             runner_cross_section, runner_taper, plenum_volume, plenum_shape,
                             throttle_body_size, throttle_body_count, injector_bung_size, injector_location,
                             weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS3 OEM Manifold', '12625346', 'single_plane', 190.0, 55.0, 23.8, 'tapered',
       5.5, 'rectangular', 90.0, 1, '14mm x 1.5', 'port', 8.5, mat.id, 450.00, 150.00,
       'Stock LS3 composite manifold, good to 6500 RPM'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 356';

-- Fast 102mm LS Manifold
INSERT INTO intake_manifolds (manufacturer_id, model, part_number, configuration, runner_length, runner_diameter,
                             runner_cross_section, runner_taper, plenum_volume, plenum_shape,
                             throttle_body_size, throttle_body_count, injector_bung_size, injector_location,
                             weight, material_id, price_new, price_used, notes)
SELECT m.id, 'FAST 102/102 LSX', '146302B', 'single_plane', 200.0, 58.0, 26.4, 'straight',
       6.2, 'rectangular', 102.0, 1, '14mm x 1.5', 'port', 10.2, mat.id, 850.00, 450.00,
       'High-flow aluminum manifold, 102mm TB, good to 7500 RPM, +25 HP vs stock'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Aluminum 6061-T6';

-- Ford Coyote Boss 302 Manifold
INSERT INTO intake_manifolds (manufacturer_id, model, part_number, configuration, runner_length, runner_diameter,
                             runner_cross_section, runner_taper, plenum_volume, plenum_shape,
                             throttle_body_size, throttle_body_count, injector_bung_size, injector_location,
                             weight, material_id, price_new, price_used, notes)
SELECT m.id, 'Boss 302 Intake', 'M-9424-M50B', 'dual_plane', 210.0, 48.0, 18.1, 'tapered',
       4.8, 'split plenum', 80.0, 1, '14mm x 1.5', 'port', 9.8, mat.id, 1200.00, 600.00,
       'Composite DOHC manifold, dual-plane design for low-end torque'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Aluminum 356';

-- 2JZ Single Turbo Manifold
INSERT INTO intake_manifolds (manufacturer_id, model, part_number, configuration, runner_length, runner_diameter,
                             runner_cross_section, runner_taper, plenum_volume, plenum_shape,
                             throttle_body_size, throttle_body_count, injector_bung_size, injector_location,
                             weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ Single Turbo Intake', 'TSP-2JZ-STI', 'single_plane', 180.0, 52.0, 21.2, 'straight',
       5.0, 'cylindrical', 90.0, 1, '14mm x 1.5', 'port', 7.5, mat.id, 650.00, NULL,
       'Sheet metal intake for single turbo 2JZ, short runners for response'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = 'Aluminum 6061-T6';

-- Honda K-Series RBC Manifold
INSERT INTO intake_manifolds (manufacturer_id, model, part_number, configuration, runner_length, runner_diameter,
                             runner_cross_section, runner_taper, plenum_volume, plenum_shape,
                             throttle_body_size, throttle_body_count, injector_bung_size, injector_location,
                             weight, material_id, price_new, price_used, notes)
SELECT m.id, 'RBC K-Series Intake', '17100-RBC-000', 'single_plane', 185.0, 42.0, 13.9, 'tapered',
       3.2, 'rectangular', 70.0, 1, '11mm x 1.5', 'port', 5.5, mat.id, NULL, 350.00,
       'OEM performance manifold from Civic Si, optimal runner length for K24'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Aluminum 356';

-- ============================================================================
-- COMPATIBILITY RULES
-- ============================================================================

INSERT INTO compatibility_rules (rule_name, rule_type, description, validation_sql, severity, recommendation, active) VALUES
('Bore Spacing Match', 'bore_spacing',
 'Engine block and cylinder head bore spacing must match within 0.1mm',
 'ABS(block.bore_spacing - head.compatible_spacing) < 0.1',
 'error',
 'Select a cylinder head designed for this block family (e.g., LS heads for LS block)',
 1);

INSERT INTO compatibility_rules (rule_name, rule_type, description, validation_sql, severity, recommendation, active) VALUES
('Minimum Valve Clearance', 'valve_clearance',
 'Valve to piston clearance must be at least 2.0mm (0.080") for safety',
 'piston.valve_relief_intake_depth >= 2.0 AND piston.valve_relief_exhaust_depth >= 2.0',
 'error',
 'Use pistons with deeper valve reliefs, or select a less aggressive camshaft',
 1);

INSERT INTO compatibility_rules (rule_name, rule_type, description, validation_sql, severity, recommendation, active) VALUES
('Optimal Rod Ratio', 'rod_ratio',
 'Rod ratio (rod length / stroke) should ideally be between 1.5 and 2.2 for balance of side loading and compactness',
 '(rod.center_to_center_length / crank.stroke) BETWEEN 1.5 AND 2.2',
 'warning',
 'Rod ratio outside ideal range may increase side loading or require taller deck height',
 1);

INSERT INTO compatibility_rules (rule_name, rule_type, description, validation_sql, severity, recommendation, active) VALUES
('Quench Clearance', 'quench',
 'Piston-to-head quench clearance should be 0.035" to 0.045" (0.89mm to 1.14mm) for optimal combustion',
 'calculated_quench BETWEEN 0.89 AND 1.14',
 'warning',
 'Adjust piston compression height, head gasket thickness, or deck clearance',
 1);

INSERT INTO compatibility_rules (rule_name, rule_type, description, validation_sql, severity, recommendation, active) VALUES
('Rod Bearing Size Match', 'bearing_size',
 'Connecting rod big end bore must match crankshaft rod journal diameter within 0.05mm',
 'ABS(rod.big_end_diameter - crank.rod_journal_diameter) < 0.05',
 'error',
 'Select connecting rods with correct big end bore for this crankshaft',
 1);

INSERT INTO compatibility_rules (rule_name, rule_type, description, validation_sql, severity, recommendation, active) VALUES
('Piston Pin Bore Match', 'bearing_size',
 'Piston pin diameter must match connecting rod small end bore within 0.01mm',
 'ABS(piston.pin_diameter - rod.small_end_diameter) < 0.01',
 'error',
 'Select pistons and rods with matching wrist pin diameter',
 1);

INSERT INTO compatibility_rules (rule_name, rule_type, description, validation_sql, severity, recommendation, active) VALUES
('Safe Compression Ratio', 'compression_ratio',
 'Compression ratio must be safe for selected fuel octane rating',
 'calculated_cr <= fuel_octane_limit(fuel.octane_aki)',
 'error',
 'Reduce compression ratio (thicker head gasket, dished pistons) or use higher octane fuel',
 1);

INSERT INTO compatibility_rules (rule_name, rule_type, description, validation_sql, severity, recommendation, active) VALUES
('Deck Height Stack', 'deck_height',
 'Block deck height must accommodate piston compression height + stroke/2 + gasket + clearance',
 'block.deck_height >= (crank.stroke / 2 + piston.compression_height + gasket_thickness + 0.5)',
 'error',
 'Select block with taller deck height, shorter stroke crank, or lower compression height pistons',
 1);

-- ============================================================================
-- SAVED CONFIGURATIONS
-- ============================================================================

-- LS3 Turbo Street Build
INSERT INTO saved_configurations (name, description, engine_block_id, cylinder_head_id, piston_id, connecting_rod_id,
                                 crankshaft_id, camshaft_id, turbocharger_id, intake_manifold_id, fuel_id,
                                 custom_params_json)
SELECT
    'LS3 6.2L Turbo Street Build',
    '650 HP street turbo LS3 on pump gas - conservative and reliable',
    (SELECT id FROM engine_blocks WHERE model = 'LS3'),
    (SELECT id FROM cylinder_heads WHERE model = 'LS3 Heads'),
    (SELECT id FROM pistons WHERE model = 'K0412X3 LS3 Forged'),
    (SELECT id FROM connecting_rods WHERE model = 'TSP H-Beam LS Rod'),
    (SELECT id FROM crankshafts WHERE model = 'LS3 Forged Crank'),
    (SELECT id FROM camshafts WHERE model = 'TSP Stage 3 Turbo'),
    (SELECT id FROM turbochargers WHERE model = 'GTX3582R Gen II'),
    (SELECT id FROM intake_manifolds WHERE model = 'FAST 102/102 LSX'),
    (SELECT id FROM fuels WHERE name = 'Gasoline 93'),
    '{"target_power": 650, "target_torque": 600, "max_rpm": 6800, "max_boost": 15, "compression_ratio": 9.8, "estimated_cost": 12500, "build_notes": "Conservative turbo setup for street driving, pump gas friendly"}'
;

-- 2JZ 1000 HP Build
INSERT INTO saved_configurations (name, description, engine_block_id, cylinder_head_id, piston_id, connecting_rod_id,
                                 crankshaft_id, camshaft_id, turbocharger_id, intake_manifold_id, fuel_id,
                                 custom_params_json)
SELECT
    '2JZ-GTE 1000 HP Single Turbo',
    'Legendary 2JZ single turbo build for 1000+ HP on E85',
    (SELECT id FROM engine_blocks WHERE model = '2JZ-GTE'),
    (SELECT id FROM cylinder_heads WHERE model = '2JZ-GTE Head'),
    (SELECT id FROM pistons WHERE model = 'K608M86 2JZ Forged'),
    (SELECT id FROM connecting_rods WHERE model = 'Manley H-Beam 2JZ'),
    (SELECT id FROM crankshafts WHERE model = '2JZ-GTE Forged Crank'),
    (SELECT id FROM camshafts WHERE model = '2JZ Turbo Cam'),
    (SELECT id FROM turbochargers WHERE model = 'G42-1200'),
    (SELECT id FROM intake_manifolds WHERE model = '2JZ Single Turbo Intake'),
    (SELECT id FROM fuels WHERE name = 'E85'),
    '{"target_power": 1000, "target_torque": 750, "max_rpm": 8000, "max_boost": 35, "compression_ratio": 8.5, "estimated_cost": 18000, "build_notes": "Competition-grade build, E85 required, built bottom end mandatory"}'
;

-- ============================================================================
-- END OF SAMPLE DATA
-- ============================================================================

-- Verify data insertion counts
SELECT 'Manufacturers' as table_name, COUNT(*) as row_count FROM manufacturers
UNION ALL SELECT 'Materials', COUNT(*) FROM materials
UNION ALL SELECT 'Fuels', COUNT(*) FROM fuels
UNION ALL SELECT 'Engine Blocks', COUNT(*) FROM engine_blocks
UNION ALL SELECT 'Cylinder Heads', COUNT(*) FROM cylinder_heads
UNION ALL SELECT 'Pistons', COUNT(*) FROM pistons
UNION ALL SELECT 'Connecting Rods', COUNT(*) FROM connecting_rods
UNION ALL SELECT 'Crankshafts', COUNT(*) FROM crankshafts
UNION ALL SELECT 'Camshafts', COUNT(*) FROM camshafts
UNION ALL SELECT 'Turbochargers', COUNT(*) FROM turbochargers
UNION ALL SELECT 'Intake Manifolds', COUNT(*) FROM intake_manifolds
UNION ALL SELECT 'Compatibility Rules', COUNT(*) FROM compatibility_rules
UNION ALL SELECT 'Saved Configurations', COUNT(*) FROM saved_configurations;
