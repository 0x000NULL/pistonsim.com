-- ============================================================================
-- PISTON Parts Database - Camshafts Data
-- ============================================================================
-- Camshafts for popular engine builds:
-- - LS camshafts (mild street, aggressive street, race)
-- - SBC camshafts (RV/towing, street performance, race)
-- - Honda B/K series cams (OEM VTEC, aftermarket performance)
-- - JDM cams (2JZ, 4G63, SR20DET)
--
-- Cam specs measured at 0.050" lift unless noted
-- LSA = Lobe Separation Angle (degrees)
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 72 camshafts

-- ============================================================================
-- GM LS CAMSHAFTS
-- ============================================================================

-- Comp Cams LS3 Thumpr (aggressive idle, mild performance)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS3 Thumpr', '54-454-11', 'hydraulic_roller', 224.0, 230.0,
       14.3, 14.3, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       274.0, 280.0, 6200, 13.0, 6.5, mat.id, 420.00, NULL,
       'Thumpr cam, choppy idle, 224/230 @ 0.050", street/strip'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Texas Speed LS7 TSP Stage 2 (street/strip)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'TSP Stage 2', 'TSP-LS7-S2', 'hydraulic_roller', 233.0, 237.0,
       15.621, 15.621, 112.0, 107.0, 117.0, 'BTDC/ABDC/BBDC/ATDC',
       283.0, 287.0, 6800, 11.5, 6.8, mat.id, 480.00, NULL,
       'TSP Stage 2, 233/237 @ 0.050", street/strip, great torque'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = 'Forged Steel';

-- Comp Cams LS XFI (race, high-RPM)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS XFI Race', '54-600-11', 'solid_roller', 258.0, 268.0,
       17.78, 17.78, 110.0, 105.0, 115.0, 'BTDC/ABDC/BBDC/ATDC',
       308.0, 318.0, 8000, 7.0, 7.5, mat.id, 950.00, NULL,
       'XFI solid roller, 258/268 @ 0.050", race only, 7500+ RPM'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Lunati LS Voodoo (street/strip, good power band)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS Voodoo', '11220701', 'hydraulic_roller', 228.0, 234.0,
       15.113, 15.113, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       278.0, 284.0, 6500, 12.0, 6.6, mat.id, 450.00, NULL,
       'Lunati Voodoo, 228/234 @ 0.050", smooth idle, great mid-range'
FROM manufacturers m, materials mat
WHERE m.name = 'Lunati' AND mat.name = 'Forged Steel';

-- ============================================================================
-- SMALL BLOCK CHEVY CAMSHAFTS
-- ============================================================================

-- Comp Cams Magnum RV (towing, low-end torque)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBC Magnum RV', '12-600-4', 'hydraulic_flat', 194.0, 206.0,
       11.354, 11.684, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       256.0, 268.0, 5500, 16.0, 5.2, mat.id, 180.00, NULL,
       'Magnum RV cam, 194/206 @ 0.050", excellent vacuum, towing'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Cast Iron';

-- Edelbrock Performer Plus (mild street)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBC Performer+', '7121', 'hydraulic_flat', 204.0, 214.0,
       12.116, 12.192, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       266.0, 276.0, 6000, 14.5, 5.4, mat.id, 220.00, NULL,
       'Performer Plus, 204/214 @ 0.050", smooth idle, good torque'
FROM manufacturers m, materials mat
WHERE m.name = 'Edelbrock' AND mat.name = 'Cast Iron';

-- Crane Cams PowerMax (street/strip)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBC PowerMax', 'H-284-2', 'hydraulic_flat', 224.0, 224.0,
       13.208, 13.208, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       284.0, 284.0, 6500, 11.0, 5.6, mat.id, 260.00, NULL,
       'Crane PowerMax, 224/224 @ 0.050", choppy idle, great power'
FROM manufacturers m, materials mat
WHERE m.name = 'Crane Cams' AND mat.name = 'Cast Iron';

-- Comp Cams XE268H (hot street)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBC XE268H', '12-268-4', 'hydraulic_flat', 224.0, 230.0,
       12.116, 12.192, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       268.0, 274.0, 6500, 10.5, 5.5, mat.id, 240.00, NULL,
       'XE268H classic, 224/230 @ 0.050", aggressive idle, strong power'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Cast Iron';

-- ============================================================================
-- HONDA B/K SERIES CAMSHAFTS
-- ============================================================================

-- Honda B16A VTEC Cams (OEM, aggressive profile)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'B16A VTEC', 'OEM-B16A-CAM', 'dohc_vtec', 232.0, 228.0,
       10.795, 10.439, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       272.0, 268.0, 8500, 13.0, 2.2, mat.id, 600.00, 250.00,
       'OEM B16A VTEC cams, 232/228 @ 0.050", 8500 RPM, aggressive (1989, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Forged Steel';

-- Brian Crower Stage 2 B-Series (turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BC Stage 2 B-Series', 'BC0302', 'dohc', 264.0, 264.0,
       11.811, 11.506, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       280.0, 280.0, 9000, 10.0, 2.4, mat.id, 720.00, NULL,
       'Brian Crower Stage 2, 264/264 @ 0.050", turbo optimized'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = 'Forged Steel';

-- Skunk2 Pro Series K20 (street/strip)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Skunk2 Pro K20', '304-05-5050', 'dohc_ivtec', 242.0, 238.0,
       11.989, 11.608, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       290.0, 286.0, 8800, 11.5, 2.6, mat.id, 850.00, NULL,
       'Skunk2 Pro Series, 242/238 @ 0.050", K20 street/strip'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Forged Steel';  -- Using GM as placeholder for Skunk2

-- Comp Cams K24 Stage 3 (race)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Comp K24 Stage 3', 'K24-S3', 'dohc', 268.0, 268.0,
       12.497, 12.395, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       298.0, 298.0, 9500, 8.5, 2.8, mat.id, 980.00, NULL,
       'Comp Cams Stage 3, 268/268 @ 0.050", race build, 9000+ RPM'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- ============================================================================
-- JDM CAMSHAFTS (2JZ, 4G63, SR20)
-- ============================================================================

-- HKS 272° 2JZ-GTE Cams (mild turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'HKS 272° 2JZ', '22002-AT001', 'dohc', 226.0, 226.0,
       10.897, 10.693, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       272.0, 272.0, 8000, 12.0, 3.8, mat.id, 950.00, NULL,
       'HKS 272° cams, 226/226 @ 0.050", mild turbo 2JZ, street driveable'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';  -- Using Toyota as placeholder for HKS

-- Brian Crower 272° 2JZ (street/strip turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BC 272° 2JZ', 'BC0451', 'dohc', 230.0, 228.0,
       11.506, 11.201, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       272.0, 272.0, 8200, 11.0, 3.9, mat.id, 820.00, NULL,
       'Brian Crower 272°, 230/228 @ 0.050", 2JZ turbo street/strip'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = 'Forged Steel';

-- Comp Cams 4G63 Evo (turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Comp 4G63 Evo', '4G63-T', 'dohc_mivec', 248.0, 248.0,
       11.506, 11.405, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       284.0, 284.0, 8500, 10.0, 2.8, mat.id, 880.00, NULL,
       'Comp Cams 4G63, 248/248 @ 0.050", Evo turbo, MIVEC compatible'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- BC Stage 2 SR20DET (drift/turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BC Stage 2 SR20', 'BC0500', 'dohc', 256.0, 256.0,
       11.811, 11.506, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       280.0, 280.0, 8800, 9.5, 2.5, mat.id, 760.00, NULL,
       'Brian Crower Stage 2, 256/256 @ 0.050", SR20DET turbo/drift'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = 'Forged Steel';

-- ============================================================================
-- FORD & CHRYSLER CAMSHAFTS
-- ============================================================================

-- Comp Cams Ford Coyote Stage 2 (street/strip)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Coyote Stage 2', '191700', 'dohc_tivct', 232.0, 238.0,
       14.986, 14.986, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       282.0, 288.0, 7500, 11.5, 7.2, mat.id, 1200.00, NULL,
       'Comp Cams Coyote Stage 2, 232/238 @ 0.050", Ti-VCT compatible'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Comp Cams 392 Hemi (street/strip)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Hemi 392 Street', '5457', 'dohc', 228.0, 234.0,
       14.732, 14.732, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       278.0, 284.0, 6800, 12.0, 8.5, mat.id, 1100.00, NULL,
       'Comp Cams 392 Hemi, 228/234 @ 0.050", VVT compatible, street'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- ============================================================================
-- EXTENDED CAMSHAFT LIBRARY (54 additional profiles)
-- ============================================================================
-- Spans mild RV/towing through full-race solid roller, plus broader JDM and
-- European import coverage. Niche brands not present in the manufacturers
-- table (HKS, Skunk2, Tomei, JWT, Cosworth, Catcams, Schrick) reuse the
-- closest OEM/specialist row and disambiguate inside the notes column,
-- matching the placeholder convention already used at lines 156, 184.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- LS / LT FAMILY (OEM, RV, mild NA, supercharger, full-race)
-- ----------------------------------------------------------------------------

-- GM LS6 OEM (factory C5 Z06)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS6 OEM', '12565308', 'hydraulic_roller', 204.0, 218.0,
       14.097, 13.995, 117.5, 113.5, 121.5, 'BTDC/ABDC/BBDC/ATDC',
       254.0, 268.0, 6500, 15.0, 6.4, mat.id, 320.00, 180.00,
       'OEM C5 Z06 LS6 cam, 204/218 @ 0.050", smooth idle, factory hot rod (used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Forged Steel';

-- GM LS7 OEM (factory C6 Z06)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS7 OEM', '12624115', 'hydraulic_roller', 211.0, 230.0,
       15.011, 15.011, 110.5, 105.5, 115.5, 'BTDC/ABDC/BBDC/ATDC',
       258.0, 277.0, 7000, 14.0, 6.8, mat.id, 380.00, 210.00,
       'OEM C6 Z06 LS7 cam, 211/230 @ 0.050", high lift factory (used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = 'Forged Steel';

-- Comp Cams LS Truck Torque (RV / towing)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS Truck Torque', 'CCA-LS-TQ-260', 'hydraulic_roller', 196.0, 204.0,
       12.7, 12.954, 114.0, 110.0, 118.0, 'BTDC/ABDC/BBDC/ATDC',
       260.0, 268.0, 5500, 16.5, 6.2, mat.id, 380.00, NULL,
       'LS truck/RV cam, 196/204 @ 0.050", maximum low-end torque, towing'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Comp Cams LS1 Magnum Stage 1 (mild NA)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS1 Magnum S1', '54-413-11', 'hydraulic_roller', 212.0, 218.0,
       13.335, 13.513, 113.0, 109.0, 117.0, 'BTDC/ABDC/BBDC/ATDC',
       265.0, 271.0, 6300, 13.5, 6.4, mat.id, 400.00, NULL,
       'LS1 Magnum NA stage 1, 212/218 @ 0.050", smooth daily-drivable'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- TSP LS3 Stage 4 NA (aggressive NA)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'TSP LS3 Stage 4 NA', 'TSP-LS3-S4-235', 'hydraulic_roller', 235.0, 247.0,
       15.85, 15.85, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       285.0, 297.0, 7200, 9.5, 6.9, mat.id, 520.00, NULL,
       'TSP Stage 4 NA, 235/247 @ 0.050", lopey idle, big NA powerband'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = 'Forged Steel';

-- TSP LS1 Stage 1 (entry NA)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'TSP LS1 Stage 1', 'TSP-LS1-S1', 'hydraulic_roller', 215.0, 220.0,
       14.402, 14.605, 113.0, 109.0, 117.0, 'BTDC/ABDC/BBDC/ATDC',
       268.0, 273.0, 6500, 13.0, 6.5, mat.id, 440.00, NULL,
       'TSP entry-level NA, 215/220 @ 0.050", smooth idle, daily-drivable'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = 'Forged Steel';

-- Lunati Voodoo LS Stage 3 (aggressive NA)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS Voodoo Stage 3', '11220702', 'hydraulic_roller', 240.0, 246.0,
       15.875, 15.875, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       290.0, 296.0, 6800, 9.0, 6.8, mat.id, 510.00, NULL,
       'Lunati Voodoo NA stage 3, 240/246 @ 0.050", aggressive idle'
FROM manufacturers m, materials mat
WHERE m.name = 'Lunati' AND mat.name = 'Forged Steel';

-- Comp Cams LSA Supercharger Cam (wide LSA for boost)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LSA Supercharger', '54-475-11', 'hydraulic_roller', 226.0, 240.0,
       14.859, 15.113, 116.0, 112.0, 120.0, 'BTDC/ABDC/BBDC/ATDC',
       276.0, 290.0, 6800, 13.5, 6.7, mat.id, 540.00, NULL,
       'LSA blower cam, 226/240 @ 0.050", wide LSA for positive-displacement boost'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Comp Cams LT4 Supercharger Cam (Gen V wide-LSA)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LT4 Supercharger', '54-485-11', 'hydraulic_roller', 220.0, 231.0,
       14.529, 14.859, 117.0, 113.0, 121.0, 'BTDC/ABDC/BBDC/ATDC',
       270.0, 281.0, 6500, 14.0, 6.7, mat.id, 580.00, NULL,
       'LT4 Gen V blower cam, 220/231 @ 0.050", DOD/AFM-delete, wide LSA'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- TSP LS7 Pro Stock Race (full-tilt solid roller)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'LS7 Pro Stock Race', 'TSP-LS7-PS-RACE', 'solid_roller', 280.0, 288.0,
       19.304, 19.558, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       330.0, 338.0, 9000, 5.5, 7.8, mat.id, 1450.00, NULL,
       'TSP LS7 Pro Stock solid roller, 280/288 @ 0.050", race only'
FROM manufacturers m, materials mat
WHERE m.name = 'Texas Speed & Performance' AND mat.name = '4340 Steel';

-- ----------------------------------------------------------------------------
-- SMALL & BIG BLOCK CHEVY
-- ----------------------------------------------------------------------------

-- Comp Cams SBC XE274H (hot street)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBC XE274H', '12-242-2', 'hydraulic_flat', 230.0, 236.0,
       12.446, 12.446, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       274.0, 280.0, 6500, 9.5, 5.6, mat.id, 250.00, NULL,
       'XE274H hot street, 230/236 @ 0.050", aggressive idle, 350-400hp SBC'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Cast Iron';

-- Lunati Voodoo SBC 60103 (street/strip)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBC Voodoo 60103', '60103LK', 'hydraulic_flat', 219.0, 227.0,
       12.116, 12.192, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       262.0, 270.0, 6200, 12.5, 5.4, mat.id, 230.00, NULL,
       'Lunati Voodoo SBC, 219/227 @ 0.050", broad torque, mild idle'
FROM manufacturers m, materials mat
WHERE m.name = 'Lunati' AND mat.name = 'Cast Iron';

-- Howards Big Mama Rattler BBC (note: brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BBC Big Mama Rattler', 'HOW-BBC-BIGMAMA', 'hydraulic_flat', 248.0, 254.0,
       14.097, 14.097, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       292.0, 298.0, 6500, 8.5, 6.5, mat.id, 320.00, NULL,
       'Howards Cams Big Mama BBC, 248/254 @ 0.050", choppy idle (Comp Cams placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Cast Iron';

-- Crower Solid Roller BBC (note: brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BBC Solid Roller 280', 'CRW-BBC-SR-280', 'solid_roller', 270.0, 278.0,
       18.288, 18.542, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       320.0, 328.0, 8500, 6.0, 7.5, mat.id, 1100.00, NULL,
       'Crower BBC solid roller, 270/278 @ 0.050", race only (Crane Cams placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Crane Cams' AND mat.name = '4340 Steel';

-- Isky BBC Pro Stock (full race, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BBC Pro Stock', 'ISK-BBC-PSTK', 'solid_roller', 295.0, 305.0,
       19.812, 20.066, 106.0, 102.0, 110.0, 'BTDC/ABDC/BBDC/ATDC',
       350.0, 360.0, 9500, 5.0, 8.0, mat.id, 1850.00, NULL,
       'Iskenderian BBC Pro Stock, 295/305 @ 0.050", drag race only (Comp Cams placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = '4340 Steel';

-- Crane Cams BBC Oval Track Solid Roller
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BBC Oval Track SR', 'H-360-2-OVAL', 'solid_roller', 260.0, 268.0,
       17.272, 17.526, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       312.0, 320.0, 8000, 7.5, 7.4, mat.id, 980.00, NULL,
       'Crane Cams BBC oval track solid roller, 260/268 @ 0.050", short-track race'
FROM manufacturers m, materials mat
WHERE m.name = 'Crane Cams' AND mat.name = '4340 Steel';

-- Comp Cams SBC 350 Towing (mild RV/towing flat tappet)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBC 350 Towing', '12-235-2', 'hydraulic_flat', 192.0, 200.0,
       11.049, 11.43, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       248.0, 256.0, 5500, 17.0, 5.2, mat.id, 170.00, NULL,
       'SBC 350 towing/RV cam, 192/200 @ 0.050", maximum low-end vacuum'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Cast Iron';

-- Edelbrock Performer RPM SBC (street/strip flat tappet)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBC Performer RPM', '7102', 'hydraulic_flat', 224.0, 234.0,
       12.395, 12.954, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       268.0, 278.0, 6500, 11.0, 5.5, mat.id, 250.00, NULL,
       'Edelbrock Performer RPM SBC, 224/234 @ 0.050", strong mid-range'
FROM manufacturers m, materials mat
WHERE m.name = 'Edelbrock' AND mat.name = 'Cast Iron';

-- ----------------------------------------------------------------------------
-- FORD SBF / COYOTE / MODULAR / GODZILLA
-- ----------------------------------------------------------------------------

-- Ford Racing B-Cam SBF (classic 5.0 HO upgrade)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'SBF B-Cam', 'M-6250-B303', 'hydraulic_flat', 224.0, 232.0,
       12.192, 12.192, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       266.0, 274.0, 6500, 10.5, 5.6, mat.id, 290.00, NULL,
       'Ford Racing B-Cam for 302/5.0 HO, 224/232 @ 0.050", classic Mustang upgrade'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Cast Iron';

-- Comp Cams Windsor XE282H (hot street SBF)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Windsor XE282H', '35-242-3', 'hydraulic_flat', 232.0, 240.0,
       14.097, 14.351, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       282.0, 290.0, 6800, 9.0, 5.5, mat.id, 280.00, NULL,
       'Comp Cams Windsor XE282H, 232/240 @ 0.050", hot street 351W'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Cast Iron';

-- Comp Cams Coyote Stage 3 (aggressive Ti-VCT)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Coyote Stage 3', '191900', 'dohc_tivct', 245.0, 253.0,
       15.875, 15.875, 111.0, 107.0, 115.0, 'BTDC/ABDC/BBDC/ATDC',
       295.0, 303.0, 7800, 9.0, 7.4, mat.id, 1450.00, NULL,
       'Comp Cams Coyote Stage 3, 245/253 @ 0.050", aggressive Ti-VCT, 800+hp'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Comp Cams 5.4 Triton 3V (truck/Mustang mod motor)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, '5.4 Triton 3V', '5454-3V', 'dohc', 218.0, 226.0,
       12.446, 12.7, 113.0, 109.0, 117.0, 'BTDC/ABDC/BBDC/ATDC',
       262.0, 270.0, 6500, 12.0, 6.5, mat.id, 720.00, NULL,
       'Comp Cams 5.4 Triton 3V mod motor, 218/226 @ 0.050", truck/Mustang upgrade'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Comp Cams 7.3 Godzilla Stage 2 (super duty pushrod)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, '7.3 Godzilla Stage 2', 'GZ-732-S2', 'hydraulic_roller', 224.0, 232.0,
       14.859, 15.113, 113.0, 109.0, 117.0, 'BTDC/ABDC/BBDC/ATDC',
       274.0, 282.0, 6500, 12.5, 7.0, mat.id, 780.00, NULL,
       'Comp Cams 7.3 Godzilla Stage 2, 224/232 @ 0.050", Super Duty/swap'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Comp Cams 4.6 4V Mach 1 (DOHC mod motor)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, '4.6 4V Mach 1', '46-4V-MACH1', 'dohc', 222.0, 228.0,
       12.954, 13.208, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       268.0, 274.0, 7200, 11.5, 5.8, mat.id, 880.00, NULL,
       'Comp Cams 4.6 4V Mach 1 mod motor, 222/228 @ 0.050", DOHC street/strip'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- ----------------------------------------------------------------------------
-- MOPAR LA / MAGNUM / HEMI GEN II / GEN III
-- ----------------------------------------------------------------------------

-- Comp Cams Mopar Magnum 360 (street/strip)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Mopar Magnum 360', '21-242-4', 'hydraulic_flat', 220.0, 230.0,
       12.192, 12.37, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       268.0, 278.0, 6300, 11.5, 5.5, mat.id, 270.00, NULL,
       'Comp Cams Mopar 5.9 Magnum, 220/230 @ 0.050", great mid-range torque'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Cast Iron';

-- Comp Cams 5.7 Hemi Eagle MDS-Delete
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, '5.7 Hemi Eagle', '5701-EAGLE', 'dohc', 213.0, 221.0,
       14.224, 14.376, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       263.0, 271.0, 6500, 13.0, 6.4, mat.id, 880.00, NULL,
       'Comp Cams 5.7 Hemi Eagle MDS-delete, 213/221 @ 0.050", VVT compatible'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Comp Cams Mopar LA 318 Street (mild flat tappet)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Mopar LA 318 Street', '21-218-4', 'hydraulic_flat', 204.0, 214.0,
       11.278, 11.506, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       254.0, 264.0, 5800, 14.0, 5.3, mat.id, 220.00, NULL,
       'Comp Cams Mopar LA 318 street, 204/214 @ 0.050", smooth idle, daily-driver'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Cast Iron';

-- Comp Cams 6.4 Apache (Gen III Hemi 392)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, '6.4 Apache', '6401-APACHE', 'dohc', 232.0, 240.0,
       14.732, 15.113, 113.0, 109.0, 117.0, 'BTDC/ABDC/BBDC/ATDC',
       282.0, 290.0, 6800, 11.5, 6.6, mat.id, 1080.00, NULL,
       'Comp Cams 6.4 Apache (392 Hemi), 232/240 @ 0.050", VVT-compatible street/strip'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Comp Cams 426 Hemi Race Solid Roller (Gen II elephant)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, '426 Hemi Race SR', '21-426-RACE', 'solid_roller', 268.0, 278.0,
       18.034, 18.288, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       320.0, 330.0, 8200, 6.5, 8.0, mat.id, 1280.00, NULL,
       'Comp Cams 426 Hemi Gen II solid roller, 268/278 @ 0.050", drag race elephant'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = '4340 Steel';

-- ----------------------------------------------------------------------------
-- HONDA B / K / F / D SERIES (Skunk2 entries via Honda placeholder)
-- ----------------------------------------------------------------------------

-- Skunk2 Tuner B-Series (mild street, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Skunk2 Tuner B-Series', 'SK2-TUN-BS', 'dohc_vtec', 226.0, 220.0,
       11.278, 10.922, 113.0, 109.0, 117.0, 'BTDC/ABDC/BBDC/ATDC',
       272.0, 266.0, 8200, 14.5, 2.3, mat.id, 540.00, NULL,
       'Skunk2 Tuner Series B16/B18, 226/220 @ 0.050", street-friendly VTEC (Honda placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Forged Steel';

-- Skunk2 Pro1 K20 (mild K-series race, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Skunk2 Pro1 K20', 'SK2-PRO1-K20', 'dohc_ivtec', 234.0, 230.0,
       11.684, 11.379, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       280.0, 276.0, 8500, 13.0, 2.5, mat.id, 750.00, NULL,
       'Skunk2 Pro1 K20, 234/230 @ 0.050", mild K-series race (Honda placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Forged Steel';

-- Skunk2 Pro2 K20 (aggressive K-series)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Skunk2 Pro2 K20', 'SK2-PRO2-K20', 'dohc_ivtec', 248.0, 244.0,
       12.192, 11.811, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       294.0, 290.0, 9000, 11.0, 2.6, mat.id, 880.00, NULL,
       'Skunk2 Pro2 K20, 248/244 @ 0.050", aggressive K-series (Honda placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Forged Steel';

-- Skunk2 Pro3 K20 (full race, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Skunk2 Pro3 K20', 'SK2-PRO3-K20', 'dohc_ivtec', 258.0, 254.0,
       12.776, 12.395, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       304.0, 300.0, 9500, 8.0, 2.7, mat.id, 980.00, NULL,
       'Skunk2 Pro3 K20, 258/254 @ 0.050", full race K-series (Honda placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Honda' AND mat.name = 'Forged Steel';

-- Brian Crower Stage 1 K20 (street/strip)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BC Stage 1 K20', 'BC-K20-S1', 'dohc_ivtec', 240.0, 240.0,
       11.938, 11.684, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       286.0, 286.0, 8800, 12.0, 2.5, mat.id, 660.00, NULL,
       'Brian Crower Stage 1, 240/240 @ 0.050", K20 street/strip NA'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = 'Forged Steel';

-- Brian Crower Stage 3 K-Series (race)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BC Stage 3 K-Series', 'BC-K20-S3', 'dohc_ivtec', 272.0, 272.0,
       12.827, 12.573, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       312.0, 312.0, 9500, 7.5, 2.8, mat.id, 920.00, NULL,
       'Brian Crower Stage 3, 272/272 @ 0.050", race K-series, 9500 RPM'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = 'Forged Steel';

-- ----------------------------------------------------------------------------
-- TOYOTA 2JZ / 1JZ / 4AGE (HKS/Tomei via Toyota placeholder)
-- ----------------------------------------------------------------------------

-- HKS 256° 2JZ-GTE (mild turbo, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'HKS 256° 2JZ', '22002-AT002', 'dohc', 218.0, 218.0,
       10.49, 10.287, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       256.0, 256.0, 7800, 13.5, 3.7, mat.id, 880.00, NULL,
       'HKS 256° 2JZ-GTE, 218/218 @ 0.050", entry-level turbo cam (Toyota placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- HKS 280° 2JZ-GTE (aggressive turbo, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'HKS 280° 2JZ', '22002-AT003', 'dohc', 234.0, 234.0,
       11.506, 11.303, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       280.0, 280.0, 8200, 11.0, 3.9, mat.id, 1020.00, NULL,
       'HKS 280° 2JZ-GTE, 234/234 @ 0.050", aggressive turbo (Toyota placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- HKS 304° 1JZ-GTE Race (drift/race, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'HKS 304° 1JZ', '22002-AT004-1JZ', 'dohc', 256.0, 256.0,
       12.446, 12.192, 106.0, 102.0, 110.0, 'BTDC/ABDC/BBDC/ATDC',
       304.0, 304.0, 8500, 8.0, 3.8, mat.id, 1180.00, NULL,
       'HKS 304° 1JZ-GTE race, 256/256 @ 0.050", drift/circuit (Toyota placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- Brian Crower Stage 3 2JZ (full race turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BC Stage 3 2JZ', 'BC-2JZ-S3', 'dohc', 272.0, 272.0,
       12.7, 12.446, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       320.0, 320.0, 8800, 8.5, 4.0, mat.id, 1080.00, NULL,
       'Brian Crower Stage 3 2JZ, 272/272 @ 0.050", race turbo, 1500+hp'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = 'Forged Steel';

-- Tomei Procam 4AGE 20V (silvertop NA race, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Tomei Procam 4AGE 20V', 'TOM-4AGE-20V-PROC', 'dohc', 264.0, 264.0,
       11.786, 11.582, 106.0, 102.0, 110.0, 'BTDC/ABDC/BBDC/ATDC',
       304.0, 304.0, 9200, 9.0, 2.4, mat.id, 920.00, NULL,
       'Tomei Procam 4AGE 20V silvertop, 264/264 @ 0.050", NA race (Toyota placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- ----------------------------------------------------------------------------
-- NISSAN RB / SR / VQ / VR38 (brand placeholders via Toyota / BC)
-- ----------------------------------------------------------------------------

-- Tomei Poncam RB26DETT (drop-in mild upgrade)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Tomei Poncam RB26', 'TOM-RB26-PON', 'dohc', 232.0, 232.0,
       10.033, 10.033, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       260.0, 260.0, 8000, 13.0, 3.5, mat.id, 920.00, NULL,
       'Tomei Poncam RB26DETT, 232/232 @ 0.050", drop-in upgrade (Toyota placeholder for Nissan)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- Tomei Procam RB26DETT (race)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Tomei Procam RB26', 'TOM-RB26-PROC', 'dohc', 260.0, 260.0,
       11.024, 10.693, 106.0, 102.0, 110.0, 'BTDC/ABDC/BBDC/ATDC',
       300.0, 300.0, 8500, 9.0, 3.7, mat.id, 1280.00, NULL,
       'Tomei Procam RB26DETT, 260/260 @ 0.050", race-spec (Toyota placeholder for Nissan)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- Brian Crower Stage 3 SR20DET (race turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BC Stage 3 SR20', 'BC-SR20-S3', 'dohc', 274.0, 274.0,
       12.7, 12.395, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       314.0, 314.0, 9000, 7.5, 2.6, mat.id, 880.00, NULL,
       'Brian Crower Stage 3 SR20DET, 274/274 @ 0.050", full race turbo'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = 'Forged Steel';

-- JWT VQ35 Stage 1 (NA street/strip, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'JWT VQ35 Stage 1', 'JWT-VQ35-S1', 'dohc', 244.0, 244.0,
       11.684, 11.43, 112.0, 108.0, 116.0, 'BTDC/ABDC/BBDC/ATDC',
       284.0, 284.0, 7500, 12.0, 3.2, mat.id, 980.00, NULL,
       'Jim Wolf VQ35DE Stage 1, 244/244 @ 0.050", NA 350Z (Toyota placeholder for Nissan)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- Cosworth VR38DETT GT-R (R35 race upgrade, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Cosworth VR38 GT-R', 'COS-VR38-GTR', 'dohc', 264.0, 264.0,
       12.065, 11.938, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       306.0, 306.0, 8200, 9.5, 3.8, mat.id, 1480.00, NULL,
       'Cosworth VR38DETT R35 GT-R, 264/264 @ 0.050", twin-turbo race (Toyota placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- ----------------------------------------------------------------------------
-- MITSUBISHI 4G63 / 4B11 (HKS via Toyota placeholder)
-- ----------------------------------------------------------------------------

-- HKS 264° 4G63 Evo (mild turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'HKS 264° 4G63', '22002-DM002', 'dohc_mivec', 224.0, 224.0,
       10.49, 10.287, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       264.0, 264.0, 7800, 13.0, 2.7, mat.id, 820.00, NULL,
       'HKS 264° 4G63 Evo, 224/224 @ 0.050", mild turbo (Toyota placeholder for Mitsubishi)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- HKS 272° 4G63 Evo (aggressive turbo)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'HKS 272° 4G63', '22002-DM003', 'dohc_mivec', 234.0, 234.0,
       11.303, 11.1, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       272.0, 272.0, 8200, 11.5, 2.8, mat.id, 940.00, NULL,
       'HKS 272° 4G63 Evo, 234/234 @ 0.050", aggressive turbo (Toyota placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Toyota' AND mat.name = 'Forged Steel';

-- Brian Crower Stage 2 4B11 Evo X
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'BC Stage 2 4B11', 'BC-4B11-S2', 'dohc_mivec', 256.0, 256.0,
       11.684, 11.379, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       296.0, 296.0, 8500, 9.0, 2.9, mat.id, 880.00, NULL,
       'Brian Crower Stage 2 4B11 Evo X, 256/256 @ 0.050", MIVEC turbo race'
FROM manufacturers m, materials mat
WHERE m.name = 'Brian Crower' AND mat.name = 'Forged Steel';

-- ----------------------------------------------------------------------------
-- EUROPEAN (Catcams/Schrick/Cosworth via Comp Cams or Ford placeholder)
-- ----------------------------------------------------------------------------

-- Cosworth Duratec 2.0 Race (NA)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Cosworth Duratec Race', 'COS-DUR-2L-RACE', 'dohc', 268.0, 268.0,
       12.192, 11.938, 106.0, 102.0, 110.0, 'BTDC/ABDC/BBDC/ATDC',
       310.0, 310.0, 9000, 8.0, 2.6, mat.id, 1180.00, NULL,
       'Cosworth Duratec 2.0 race cams, 268/268 @ 0.050", Formula Atlantic style NA'
FROM manufacturers m, materials mat
WHERE m.name = 'Ford Motor Company' AND mat.name = 'Forged Steel';

-- Catcams BMW S54 (E46 M3, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Catcams S54 272°', 'CAT-S54-272', 'dohc', 268.0, 268.0,
       11.938, 11.684, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       304.0, 304.0, 8500, 9.5, 3.4, mat.id, 1380.00, NULL,
       'Catcams 272° for BMW S54 (E46 M3), 268/268 @ 0.050" (Comp Cams placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Catcams BMW S55 (F80 M3, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Catcams S55 Stage 2', 'CAT-S55-S2', 'dohc', 248.0, 248.0,
       11.303, 10.922, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       284.0, 284.0, 8000, 11.0, 3.5, mat.id, 1480.00, NULL,
       'Catcams Stage 2 for BMW S55 (F80 M3), 248/248 @ 0.050", twin turbo (Comp Cams placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Catcams BMW N54 turbo (335i, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Catcams N54 Turbo', 'CAT-N54-TURB', 'dohc', 256.0, 256.0,
       11.43, 11.176, 110.0, 106.0, 114.0, 'BTDC/ABDC/BBDC/ATDC',
       294.0, 294.0, 7800, 10.0, 3.4, mat.id, 1280.00, NULL,
       'Catcams N54 turbo cams (335i/535i), 256/256 @ 0.050", PWG/STG2 spec (Comp Cams placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Schrick VW VR6 268° (Mk3/Mk4 Golf, brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Schrick VR6 268°', 'SCH-VR6-268', 'dohc', 244.0, 244.0,
       11.557, 11.303, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       268.0, 268.0, 7500, 11.0, 3.3, mat.id, 1080.00, NULL,
       'Schrick 268° VW VR6, 244/244 @ 0.050", Golf/Corrado upgrade (Comp Cams placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- Audi 1.8T 20V Stage 2 (brand placeholder)
INSERT INTO camshafts (manufacturer_id, model, part_number, profile_type, intake_duration_050, exhaust_duration_050,
                      intake_lift, exhaust_lift, lsa, intake_centerline, exhaust_centerline, valve_timing,
                      intake_duration_seat, exhaust_duration_seat, max_rpm, idle_vacuum, weight, material_id,
                      price_new, price_used, notes)
SELECT m.id, 'Audi 1.8T 20V Stage 2', 'AUD-18T-20V-S2', 'dohc', 248.0, 240.0,
       11.684, 11.303, 108.0, 104.0, 112.0, 'BTDC/ABDC/BBDC/ATDC',
       288.0, 280.0, 7800, 10.5, 2.5, mat.id, 920.00, NULL,
       'Audi/VW 1.8T 20V Stage 2 cams, 248/240 @ 0.050", turbo street/strip (Comp Cams placeholder)'
FROM manufacturers m, materials mat
WHERE m.name = 'Comp Cams' AND mat.name = 'Forged Steel';

-- ============================================================================
-- ============================================================================
-- LS / LT: (Thumpr, TSP S2, XFI Race, Voodoo, LS6/LS7 OEM, Truck Torque,
--                   LS1 Magnum S1, TSP LS3 S4 NA, TSP LS1 S1, Voodoo S3,
--                   LSA blower, LT4 blower, LS7 Pro Stock SR)
-- SBC / BBC: (Magnum RV, Performer+, PowerMax, XE268H, XE274H, Voodoo 60103,
--                     BBC Big Mama, BBC Solid Roller, BBC Pro Stock, BBC Oval Track SR,
--                     SBC 350 Towing, SBC Performer RPM)
-- Ford: (Coyote S2, SBF B-Cam, Windsor XE282H, Coyote S3, 5.4 Triton 3V,
--               7.3 Godzilla S2, 4.6 4V Mach 1)
-- Mopar: (Hemi 392 Street, Magnum 360, 5.7 Hemi Eagle, LA 318 Street,
--                6.4 Apache, 426 Hemi Race SR)
-- Honda: (B16A VTEC, BC B-Series, Skunk2 K20 original, Comp K24 S3,
--                 Skunk2 Tuner B, Skunk2 Pro1/Pro2/Pro3 K20, BC K20 S1, BC K20 S3)
-- Toyota: (HKS 272° 2JZ, BC 272° 2JZ, HKS 256°/280° 2JZ,
--                 HKS 304° 1JZ, BC 2JZ S3, Tomei 4AGE Procam)
-- Nissan: (BC SR20 S2 original, Tomei RB26 Pon/Procam, BC SR20 S3,
--                 JWT VQ35 S1, Cosworth VR38)
-- Mitsubishi: (Comp 4G63 Evo, HKS 264°/272° 4G63, BC 4B11 S2)
-- European: (Cosworth Duratec, Catcams S54/S55/N54, Schrick VR6, Audi 1.8T 20V)
-- Profile-type coverage: hydraulic_flat, hydraulic_roller, solid_roller,
--                        dohc, dohc_vtec, dohc_ivtec, dohc_mivec, dohc_tivct
--
-- ============================================================================
