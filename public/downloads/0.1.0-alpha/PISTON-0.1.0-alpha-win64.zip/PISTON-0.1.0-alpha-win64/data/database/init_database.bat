@echo off
REM ============================================================================
REM PISTON Parts Database - Initialization Script (Windows)
REM ============================================================================
REM This script initializes the PISTON parts database by:
REM 1. Creating the database schema (tables, indexes, triggers)
REM 2. Loading sample data (10 manufacturers, 5 blocks, 5 heads, etc.)
REM 3. Loading extended manufacturers (11 additional)
REM 4. Loading extended parts data (~90 parts total)
REM
REM Usage:
REM   init_database.bat [database_path]
REM
REM Example:
REM   init_database.bat piston.db
REM   init_database.bat ..\..\piston.db
REM
REM Requirements:
REM   - sqlite3.exe in PATH or in current directory
REM   - Write permissions to database directory
REM ============================================================================

setlocal enabledelayedexpansion

REM Default database path
if "%~1"=="" (
    set DB_PATH=piston.db
) else (
    set DB_PATH=%~1
)

set SCRIPT_DIR=%~dp0

echo ===============================================
echo PISTON Parts Database Initialization
echo ===============================================
echo.

REM Check if sqlite3.exe exists
where sqlite3.exe >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo ERROR: sqlite3.exe is not in PATH
    echo.
    echo Please install SQLite3:
    echo   1. Download from https://www.sqlite.org/download.html
    echo   2. Extract sqlite-tools-win32-*.zip
    echo   3. Add sqlite3.exe to PATH or current directory
    echo.
    pause
    exit /b 1
)

REM Check if database already exists
if exist "%DB_PATH%" (
    echo WARNING: Database file already exists: %DB_PATH%
    set /p OVERWRITE=Do you want to overwrite it? (yes/no):
    if /i not "!OVERWRITE!"=="yes" (
        echo Aborted.
        pause
        exit /b 0
    )
    del "%DB_PATH%"
    echo Removed existing database
)

REM Function to execute SQL file
call :execute_sql "schema.sql" "schema (tables, indexes, triggers)"
if %ERRORLEVEL% neq 0 exit /b 1

echo.
echo Step 1: Creating database schema - OK
echo.

REM Load sample data
call :execute_sql "sample_data.sql" "sample data"
if %ERRORLEVEL% neq 0 exit /b 1

echo Step 2: Loading sample data - OK
echo.

REM Load extended manufacturers
call :execute_sql "manufacturers_extended.sql" "extended manufacturers"
if %ERRORLEVEL% neq 0 exit /b 1

echo Step 3: Loading extended manufacturers - OK
echo.

REM Load extended parts data
echo Step 4: Loading extended parts data
call :execute_sql "engine_blocks_data.sql" "engine blocks"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Engine blocks OK

call :execute_sql "cylinder_heads_data.sql" "cylinder heads"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Cylinder heads OK

call :execute_sql "pistons_data.sql" "pistons"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Pistons OK

call :execute_sql "connecting_rods_data.sql" "connecting rods"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Connecting rods OK

call :execute_sql "crankshafts_data.sql" "crankshafts"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Crankshafts OK

call :execute_sql "camshafts_data.sql" "camshafts"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Camshafts OK

call :execute_sql "turbochargers_extended.sql" "turbochargers"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Turbochargers OK

call :execute_sql "superchargers_data.sql" "superchargers"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Superchargers OK

call :execute_sql "materials_thermal_update.sql" "material thermal properties"
if %ERRORLEVEL% neq 0 exit /b 1
echo   - Material thermal updates OK

echo.
echo Step 5: Verifying database contents
echo.

REM Get counts from database
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM manufacturers;"') do set MANUFACTURERS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM materials;"') do set MATERIALS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM fuels;"') do set FUELS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM engine_blocks;"') do set ENGINE_BLOCKS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM cylinder_heads;"') do set CYLINDER_HEADS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM pistons;"') do set PISTONS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM connecting_rods;"') do set CONNECTING_RODS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM crankshafts;"') do set CRANKSHAFTS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM camshafts;"') do set CAMSHAFTS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM turbochargers;"') do set TURBOCHARGERS=%%i
for /f %%i in ('sqlite3 "%DB_PATH%" "SELECT COUNT(*) FROM intake_manifolds;"') do set INTAKE_MANIFOLDS=%%i

echo Database Contents:
echo   Manufacturers:     %MANUFACTURERS%
echo   Materials:         %MATERIALS%
echo   Fuels:             %FUELS%
echo   Engine Blocks:     %ENGINE_BLOCKS%
echo   Cylinder Heads:    %CYLINDER_HEADS%
echo   Pistons:           %PISTONS%
echo   Connecting Rods:   %CONNECTING_RODS%
echo   Crankshafts:       %CRANKSHAFTS%
echo   Camshafts:         %CAMSHAFTS%
echo   Turbochargers:     %TURBOCHARGERS%
echo   Intake Manifolds:  %INTAKE_MANIFOLDS%

REM Calculate total parts
set /a TOTAL_PARTS=%ENGINE_BLOCKS% + %CYLINDER_HEADS% + %PISTONS% + %CONNECTING_RODS% + %CRANKSHAFTS% + %CAMSHAFTS% + %TURBOCHARGERS% + %INTAKE_MANIFOLDS%
echo.
echo Total Parts:         %TOTAL_PARTS%

REM Display database file size
for %%A in ("%DB_PATH%") do set DB_SIZE=%%~zA
set /a DB_SIZE_KB=%DB_SIZE% / 1024
echo Database Size:       %DB_SIZE_KB% KB

echo.
echo ===============================================
echo Database initialization complete!
echo Database file: %DB_PATH%
echo ===============================================
echo.

REM Optional: Run VACUUM to optimize database
set /p VACUUM=Do you want to optimize (VACUUM) the database? (y/n):
if /i "%VACUUM%"=="y" (
    echo Optimizing database...
    sqlite3 "%DB_PATH%" "VACUUM;"
    echo Optimization complete
    for %%A in ("%DB_PATH%") do set DB_SIZE=%%~zA
    set /a DB_SIZE_KB=!DB_SIZE! / 1024
    echo Optimized database size: !DB_SIZE_KB! KB
)

echo.
echo You can now use the database with:
echo   sqlite3 %DB_PATH%
echo.
pause
exit /b 0

REM ============================================================================
REM Function to execute SQL file
REM ============================================================================
:execute_sql
set SQL_FILE=%~1
set DESCRIPTION=%~2

if not exist "%SCRIPT_DIR%%SQL_FILE%" (
    echo ERROR: SQL file not found: %SQL_FILE%
    exit /b 1
)

sqlite3 "%DB_PATH%" < "%SCRIPT_DIR%%SQL_FILE%" 2>nul
if %ERRORLEVEL% neq 0 (
    echo ERROR: Failed to execute %SQL_FILE%
    exit /b 1
)
exit /b 0
