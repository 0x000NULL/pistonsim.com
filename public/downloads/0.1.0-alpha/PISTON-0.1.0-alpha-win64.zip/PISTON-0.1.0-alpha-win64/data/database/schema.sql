-- ============================================================================
-- PISTON Parts Database Schema
-- ============================================================================
-- SQLite database schema for engine parts catalog with compatibility checking
--
-- Design Principles:
-- 1. Read-heavy optimization (parts browsing/filtering)
-- 2. Fast compatibility queries via foreign keys and indexes
-- 3. Flexible data storage (JSON for complex data like flow curves)
-- 4. Schema versioning for future migrations
-- 5. Data integrity through constraints and checks
--
-- Author: PISTON Team
-- Version: 1.0.0
-- Last Updated: 2025-10-30
-- ============================================================================

-- Enable foreign key constraints (must be set for each connection in SQLite)
PRAGMA foreign_keys = ON;

-- ============================================================================
-- METADATA AND VERSIONING
-- ============================================================================

CREATE TABLE schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    description TEXT NOT NULL
);

-- One row per schema version. Add a row whenever the schema gains an object the ORM uses,
-- and raise database::kRequiredSchemaVersion (src/database/DatabaseLocator.h) to match:
-- the parts commands and the GUI refuse a database older than that, rather than failing
-- on a missing table or view mid-query (PIS-0197). test_DatabaseLocator.cpp pins that
-- the two agree.
INSERT INTO schema_version (version, description)
VALUES (1, 'Initial schema with core parts tables');
INSERT INTO schema_version (version, description)
VALUES (2, 'Superchargers reachable: v_superchargers_full (PIS-0157)');

-- ============================================================================
-- MANUFACTURERS TABLE
-- ============================================================================
-- Centralized manufacturer data to ensure consistency and enable filtering
-- Separate table reduces redundancy and enables manufacturer-level metadata

CREATE TABLE manufacturers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    country TEXT,
    website TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for manufacturer name lookups
CREATE INDEX idx_manufacturers_name ON manufacturers(name);

-- ============================================================================
-- MATERIALS TABLE
-- ============================================================================
-- Centralized material properties for strength calculations and compatibility

CREATE TABLE materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    type TEXT CHECK(type IN ('metal', 'alloy', 'composite', 'ceramic')),
    density REAL,  -- kg/m³
    tensile_strength REAL,  -- MPa
    yield_strength REAL,  -- MPa
    thermal_conductivity REAL,  -- W/(m·K)
    specific_heat REAL,  -- J/(kg·K)
    thermal_expansion REAL,  -- µm/(m·K)
    melting_point REAL,  -- K
    notes TEXT
);

-- Index for material lookups
CREATE INDEX idx_materials_name ON materials(name);

-- ============================================================================
-- ENGINE BLOCKS TABLE
-- ============================================================================
-- Core engine block specifications
-- Includes geometry, weight, material, and compatibility dimensions

CREATE TABLE engine_blocks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,

    -- Basic geometry
    bore REAL NOT NULL,  -- mm (nominal bore size)
    stroke REAL NOT NULL,  -- mm
    deck_height REAL NOT NULL,  -- mm (from crank centerline to deck surface)
    bore_spacing REAL NOT NULL,  -- mm (center-to-center distance between cylinders)
    cylinder_count INTEGER NOT NULL CHECK(cylinder_count BETWEEN 1 AND 16),
    configuration TEXT CHECK(configuration IN ('inline', 'V', 'flat', 'W', 'rotary')),
    bank_angle REAL,  -- degrees (for V and W engines)

    -- Capacity and limits
    max_bore REAL,  -- mm (maximum safe bore after machining)
    min_deck_height REAL,  -- mm (minimum after decking)

    -- Main bearings
    main_bearing_count INTEGER NOT NULL,
    main_bearing_diameter REAL NOT NULL,  -- mm
    main_bearing_width REAL,  -- mm

    -- Physical properties
    weight REAL,  -- kg
    material_id INTEGER,

    -- Pricing (nullable for parts without known prices)
    price_new REAL CHECK(price_new >= 0),  -- USD
    price_used REAL CHECK(price_used >= 0),  -- USD

    -- Metadata
    notes TEXT,
    data_source TEXT,  -- where the data came from
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Indexes for common queries
CREATE INDEX idx_engine_blocks_manufacturer ON engine_blocks(manufacturer_id);
CREATE INDEX idx_engine_blocks_bore ON engine_blocks(bore);
CREATE INDEX idx_engine_blocks_stroke ON engine_blocks(stroke);
CREATE INDEX idx_engine_blocks_displacement ON engine_blocks(cylinder_count, bore, stroke);
CREATE INDEX idx_engine_blocks_bore_spacing ON engine_blocks(bore_spacing);

-- ============================================================================
-- CYLINDER HEADS TABLE
-- ============================================================================
-- Cylinder head specifications including combustion chamber and port data
-- Flow data stored as JSON for flexibility

CREATE TABLE cylinder_heads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,

    -- Compatibility
    compatible_spacing REAL NOT NULL,  -- mm (must match block bore_spacing)
    bolt_pattern TEXT,  -- description of bolt pattern

    -- Combustion chamber
    combustion_chamber_cc REAL CHECK(combustion_chamber_cc > 0 OR combustion_chamber_cc IS NULL),  -- cc
    valve_angle REAL,  -- degrees (from vertical, 0 = vertical)
    quench_area_percent REAL CHECK(quench_area_percent BETWEEN 0 AND 100),  -- %

    -- Intake valves
    intake_valve_count INTEGER NOT NULL DEFAULT 1,  -- per cylinder
    intake_valve_diameter REAL NOT NULL,  -- mm
    intake_valve_stem_diameter REAL,  -- mm
    intake_port_volume REAL,  -- cc
    intake_runner_cross_section REAL,  -- cm²

    -- Exhaust valves
    exhaust_valve_count INTEGER NOT NULL DEFAULT 1,  -- per cylinder
    exhaust_valve_diameter REAL NOT NULL,  -- mm
    exhaust_valve_stem_diameter REAL,  -- mm
    exhaust_port_volume REAL,  -- cc
    exhaust_runner_cross_section REAL,  -- cm²

    -- Additional descriptive columns
    valve_configuration TEXT,  -- e.g., 'DOHC', 'OHV', 'SOHC'
    valves_per_cylinder INTEGER,  -- total valves per cylinder (e.g., 2, 4)
    chamber_type TEXT,  -- e.g., 'cathedral', 'heart', 'pent_roof', 'hemi', 'wedge'
    combustion_chamber_volume REAL,  -- cc (alternative name for combustion_chamber_cc)
    max_lift REAL,  -- mm (maximum valve lift supported)
    compatible_bore REAL,  -- mm (compatible bore size)

    -- Flow bench data (JSON format)
    -- Structure: {"intake": [[lift_mm, cfm], ...], "exhaust": [[lift_mm, cfm], ...]}
    -- Example: {"intake": [[0.1, 30], [0.2, 85], [0.3, 145], ...], "exhaust": [...]}
    flow_data_json TEXT CHECK(json_valid(flow_data_json) OR flow_data_json IS NULL),

    -- Physical properties
    weight REAL,  -- kg
    material_id INTEGER,

    -- Pricing
    price_new REAL CHECK(price_new >= 0),
    price_used REAL CHECK(price_used >= 0),

    -- Metadata
    notes TEXT,
    data_source TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Indexes for common queries
CREATE INDEX idx_cylinder_heads_manufacturer ON cylinder_heads(manufacturer_id);
CREATE INDEX idx_cylinder_heads_compatible_spacing ON cylinder_heads(compatible_spacing);
CREATE INDEX idx_cylinder_heads_chamber_cc ON cylinder_heads(combustion_chamber_cc);
CREATE INDEX idx_cylinder_heads_intake_valve ON cylinder_heads(intake_valve_diameter);

-- ============================================================================
-- PISTONS TABLE
-- ============================================================================
-- Piston specifications including compression height, dome/dish volume

CREATE TABLE pistons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,

    -- Dimensions
    bore_size REAL NOT NULL,  -- mm (actual piston diameter)
    compression_height REAL NOT NULL,  -- mm (pin centerline to crown)
    pin_diameter REAL NOT NULL,  -- mm (wrist pin diameter)
    pin_length REAL,  -- mm

    -- Volume
    dish_dome_cc REAL NOT NULL DEFAULT 0,  -- cc (positive = dish, negative = dome)
    dome_height REAL,  -- mm (for dome pistons, height above deck)

    -- Valve reliefs
    valve_relief_intake_depth REAL,  -- mm
    valve_relief_intake_diameter REAL,  -- mm
    valve_relief_exhaust_depth REAL,  -- mm
    valve_relief_exhaust_diameter REAL,  -- mm

    -- Ring pack
    ring_pack TEXT,  -- description (e.g., "1/16 1/16 3/16")
    top_ring_thickness REAL,  -- mm
    second_ring_thickness REAL,  -- mm
    oil_ring_thickness REAL,  -- mm

    -- Physical properties
    weight REAL NOT NULL,  -- grams
    material_id INTEGER,
    coating TEXT,  -- coating type (e.g., "ceramic", "DLC", "none")
    skirt_coating TEXT,  -- skirt coating (e.g., "molybdenum")

    -- Ratings
    max_rpm INTEGER,
    max_boost REAL,  -- psi

    -- Pricing
    price_new REAL CHECK(price_new >= 0),
    price_used REAL CHECK(price_used >= 0),

    -- Metadata
    notes TEXT,
    data_source TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Indexes for common queries
CREATE INDEX idx_pistons_manufacturer ON pistons(manufacturer_id);
CREATE INDEX idx_pistons_bore ON pistons(bore_size);
CREATE INDEX idx_pistons_compression_height ON pistons(compression_height);
CREATE INDEX idx_pistons_pin_diameter ON pistons(pin_diameter);

-- ============================================================================
-- CONNECTING RODS TABLE
-- ============================================================================
-- Connecting rod specifications including geometry and strength ratings

CREATE TABLE connecting_rods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,

    -- Dimensions
    center_to_center_length REAL NOT NULL,  -- mm (C-C length)
    big_end_diameter REAL NOT NULL,  -- mm (rod journal bearing diameter)
    big_end_width REAL,  -- mm (bearing width)
    small_end_diameter REAL NOT NULL,  -- mm (wrist pin bearing diameter)
    small_end_width REAL,  -- mm (bushing width)

    -- Design
    beam_type TEXT CHECK(beam_type IN ('I-beam', 'H-beam', 'A-beam', 'billet', 'I', 'H', 'A')),
    beam_width REAL,  -- mm (at narrowest point)
    beam_thickness REAL,  -- mm

    -- Bolts
    bolt_type TEXT,  -- description (e.g., "ARP2000", "ARP L19")
    rod_bolts TEXT,  -- bolt specification (e.g., "ARP 2000", "Carrillo")
    bolt_diameter REAL,  -- mm

    -- Physical properties
    weight REAL NOT NULL,  -- grams
    material_id INTEGER,

    -- Ratings
    max_rpm_rating INTEGER,
    max_rpm INTEGER,  -- Alternative name for max_rpm_rating
    max_horsepower_rating INTEGER,  -- HP per cylinder
    max_power INTEGER,  -- Alternative name for max_horsepower_rating
    tensile_strength_rating REAL,  -- MPa

    -- Pricing
    price_new REAL CHECK(price_new >= 0),
    price_used REAL CHECK(price_used >= 0),

    -- Metadata
    notes TEXT,
    data_source TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Indexes for common queries
CREATE INDEX idx_connecting_rods_manufacturer ON connecting_rods(manufacturer_id);
CREATE INDEX idx_connecting_rods_length ON connecting_rods(center_to_center_length);
CREATE INDEX idx_connecting_rods_big_end ON connecting_rods(big_end_diameter);
CREATE INDEX idx_connecting_rods_small_end ON connecting_rods(small_end_diameter);

-- ============================================================================
-- CRANKSHAFTS TABLE
-- ============================================================================
-- Crankshaft specifications including stroke, journal sizes, and balance

CREATE TABLE crankshafts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,

    -- Dimensions
    stroke REAL NOT NULL,  -- mm
    main_journal_diameter REAL NOT NULL,  -- mm
    main_journal_width REAL,  -- mm
    rod_journal_diameter REAL NOT NULL,  -- mm
    rod_journal_width REAL,  -- mm

    -- Configuration
    cylinder_count INTEGER NOT NULL CHECK(cylinder_count BETWEEN 1 AND 16),
    main_bearing_count INTEGER NOT NULL,
    firing_order TEXT,  -- e.g., "1-8-7-2-6-5-4-3"

    -- Balance
    counterweight_config TEXT,  -- description of counterweight setup
    balance_factor REAL,  -- % (typically 50-100%)
    internal_balance BOOLEAN DEFAULT FALSE,
    external_balance BOOLEAN DEFAULT FALSE,
    bobweight REAL,  -- grams (for external balance)

    -- Physical properties
    weight REAL NOT NULL,  -- kg
    material_id INTEGER,
    heat_treatment TEXT,  -- e.g., "nitrided", "induction hardened"

    -- Ratings
    max_rpm_rating INTEGER,
    max_rpm INTEGER,  -- Alternative name for max_rpm_rating
    max_horsepower_rating INTEGER,
    max_power INTEGER,  -- Alternative name for max_horsepower_rating

    -- Pricing
    price_new REAL CHECK(price_new >= 0),
    price_used REAL CHECK(price_used >= 0),

    -- Metadata
    notes TEXT,
    data_source TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Indexes for common queries
CREATE INDEX idx_crankshafts_manufacturer ON crankshafts(manufacturer_id);
CREATE INDEX idx_crankshafts_stroke ON crankshafts(stroke);
CREATE INDEX idx_crankshafts_main_journal ON crankshafts(main_journal_diameter);
CREATE INDEX idx_crankshafts_rod_journal ON crankshafts(rod_journal_diameter);

-- ============================================================================
-- CAMSHAFTS TABLE
-- ============================================================================
-- Camshaft specifications including duration, lift, and lobe profiles
-- Lift curve data stored as JSON for per-degree lift values

CREATE TABLE camshafts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,

    -- Timing (all at 0.050" lift unless otherwise noted)
    intake_duration_050 REAL NOT NULL,  -- degrees
    exhaust_duration_050 REAL NOT NULL,  -- degrees
    intake_duration_seat REAL,  -- degrees (advertised duration)
    exhaust_duration_seat REAL,  -- degrees

    -- Lift
    intake_lift REAL NOT NULL,  -- mm (at valve, not lobe)
    exhaust_lift REAL NOT NULL,  -- mm
    intake_lobe_lift REAL,  -- mm (at lobe)
    exhaust_lobe_lift REAL,  -- mm

    -- Lobe separation and phasing
    lsa REAL NOT NULL,  -- degrees (lobe separation angle)
    intake_centerline REAL,  -- degrees ATDC
    exhaust_centerline REAL,  -- degrees BTDC
    overlap REAL,  -- degrees
    advance_built_in REAL DEFAULT 0,  -- degrees

    -- Additional specifications
    valve_timing TEXT,  -- timing description (e.g., 'BTDC/ABDC/BBDC/ATDC')
    idle_vacuum REAL,  -- inHg (vacuum at idle)
    weight REAL,  -- kg

    -- Design
    profile_type TEXT CHECK(profile_type IN (
        'hydraulic_flat', 'hydraulic_roller', 'mechanical_flat', 'mechanical_roller',
        'direct_acting', 'overhead_cam', 'solid_roller',
        'dohc', 'dohc_vtec', 'dohc_ivtec', 'dohc_mivec', 'dohc_tivct'
    )),
    base_circle_diameter REAL,  -- mm
    lobe_taper REAL,  -- degrees

    -- Lift curve data (JSON format)
    -- Structure: {
    --   "intake": [[angle_deg, lift_mm], ...],   // -360 to +360 degrees
    --   "exhaust": [[angle_deg, lift_mm], ...]
    -- }
    -- Used for per-degree simulation
    lift_curve_data_json TEXT CHECK(json_valid(lift_curve_data_json) OR lift_curve_data_json IS NULL),

    -- Compatibility
    rocker_ratio REAL,  -- ratio (e.g., 1.5, 1.6, 1.7)
    valve_spring_requirement TEXT,  -- description (e.g., "180 lb seat, 450 lb open")

    -- Physical properties
    material_id INTEGER,  -- Added for compatibility with data files

    -- Ratings
    max_rpm_safe INTEGER,  -- RPM (considering valve train dynamics)
    max_rpm INTEGER,  -- Alternative name for max_rpm_safe

    -- Pricing
    price_new REAL CHECK(price_new >= 0),
    price_used REAL CHECK(price_used >= 0),

    -- Metadata
    notes TEXT,
    data_source TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Indexes for common queries
CREATE INDEX idx_camshafts_manufacturer ON camshafts(manufacturer_id);
CREATE INDEX idx_camshafts_intake_duration ON camshafts(intake_duration_050);
CREATE INDEX idx_camshafts_exhaust_duration ON camshafts(exhaust_duration_050);
CREATE INDEX idx_camshafts_lift ON camshafts(intake_lift, exhaust_lift);
CREATE INDEX idx_camshafts_lsa ON camshafts(lsa);
CREATE INDEX idx_camshafts_profile_type ON camshafts(profile_type);

-- ============================================================================
-- TURBOCHARGERS TABLE
-- ============================================================================
-- Turbocharger specifications including compressor/turbine maps

CREATE TABLE turbochargers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,

    -- Compressor
    compressor_inducer REAL NOT NULL,  -- mm (inlet diameter)
    compressor_exducer REAL NOT NULL,  -- mm (outlet diameter)
    compressor_trim INTEGER,  -- trim (e.g., 60, 62, 67)
    compressor_housing_ar REAL,  -- A/R ratio

    -- Turbine
    turbine_inducer REAL NOT NULL,  -- mm
    turbine_exducer REAL NOT NULL,  -- mm
    turbine_trim INTEGER,
    turbine_housing_ar REAL,  -- A/R ratio

    -- Compressor map data (JSON format)
    -- Structure: {
    --   "corrected_speed_lines": [60000, 80000, 100000, ...],  // RPM
    --   "pressure_ratios": [1.0, 1.5, 2.0, 2.5, 3.0, ...],
    --   "corrected_flow": [0, 5, 10, 15, 20, ...],  // lb/min
    --   "efficiency": [[eta_11, eta_12, ...], [eta_21, eta_22, ...], ...],  // %
    --   "surge_line": [[pr1, flow1], [pr2, flow2], ...],
    --   "choke_line": [[pr1, flow1], [pr2, flow2], ...]
    -- }
    compressor_map_data_json TEXT CHECK(json_valid(compressor_map_data_json) OR compressor_map_data_json IS NULL),

    -- Turbine map data (JSON format)
    -- Structure: {
    --   "expansion_ratios": [1.5, 2.0, 2.5, 3.0, ...],
    --   "corrected_flow": [0, 50, 100, 150, ...],  // lb/min
    --   "efficiency": [[eta_11, ...], ...]  // %
    -- }
    turbine_map_data_json TEXT CHECK(json_valid(turbine_map_data_json) OR turbine_map_data_json IS NULL),

    -- Bearings
    bearing_type TEXT CHECK(bearing_type IN ('journal', 'ball_bearing', 'ceramic_ball', 'ball')),
    oil_cooled BOOLEAN DEFAULT TRUE,
    water_cooled BOOLEAN DEFAULT FALSE,

    -- Performance
    max_rpm INTEGER,
    max_boost REAL,  -- psi
    max_flow REAL,  -- lb/min

    -- Physical
    weight REAL,  -- kg
    material_id INTEGER,  -- Added for compatibility with data files

    -- Pricing
    price_new REAL CHECK(price_new >= 0),
    price_used REAL CHECK(price_used >= 0),

    -- Metadata
    notes TEXT,
    data_source TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Indexes for common queries
CREATE INDEX idx_turbochargers_manufacturer ON turbochargers(manufacturer_id);
CREATE INDEX idx_turbochargers_compressor_size ON turbochargers(compressor_inducer, compressor_exducer);
CREATE INDEX idx_turbochargers_turbine_size ON turbochargers(turbine_inducer, turbine_exducer);
CREATE INDEX idx_turbochargers_max_boost ON turbochargers(max_boost);

-- ============================================================================
-- SUPERCHARGERS TABLE
-- ============================================================================
-- Positive-displacement and centrifugal supercharger specifications

CREATE TABLE IF NOT EXISTS superchargers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,
    type TEXT NOT NULL CHECK(type IN ('roots', 'twin_screw', 'centrifugal')),
    displacement_ci REAL,
    max_cfm_at_10psi REAL,
    pulley_ratio_min REAL,
    pulley_ratio_max REAL,
    parasitic_drag_hp_at_redline REAL,
    weight REAL,  -- kg
    material_id INTEGER,
    price_new REAL,
    simulation_supported BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

CREATE INDEX IF NOT EXISTS idx_superchargers_manufacturer ON superchargers(manufacturer_id);
CREATE INDEX IF NOT EXISTS idx_superchargers_type ON superchargers(type);

-- ============================================================================
-- INTAKE MANIFOLDS TABLE
-- ============================================================================
-- Intake manifold specifications including runner geometry

CREATE TABLE intake_manifolds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer_id INTEGER NOT NULL,
    model TEXT NOT NULL,
    part_number TEXT UNIQUE,

    -- Configuration
    configuration TEXT CHECK(configuration IN (
        'single_plane', 'dual_plane', 'tunnel_ram', 'itb', 'log_style', 'sheet_metal'
    )),

    -- Runner geometry
    runner_length REAL,  -- mm (from plenum to port)
    runner_diameter REAL,  -- mm (average)
    runner_cross_section REAL,  -- cm²
    runner_taper TEXT,  -- description (e.g., "straight", "tapered", "stepped")

    -- Plenum
    plenum_volume REAL,  -- liters
    plenum_shape TEXT,  -- description

    -- Throttle body
    throttle_body_size REAL,  -- mm (diameter or equivalent)
    throttle_body_count INTEGER DEFAULT 1,

    -- Fuel system
    injector_bung_size TEXT,  -- description (e.g., "14mm x 1.5", "-6 AN")
    injector_location TEXT CHECK(injector_location IN ('port', 'throttle_body', 'direct')),

    -- Physical
    weight REAL,  -- kg
    material_id INTEGER,

    -- Pricing
    price_new REAL CHECK(price_new >= 0),
    price_used REAL CHECK(price_used >= 0),

    -- Metadata
    notes TEXT,
    data_source TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

-- Indexes for common queries
CREATE INDEX idx_intake_manifolds_manufacturer ON intake_manifolds(manufacturer_id);
CREATE INDEX idx_intake_manifolds_configuration ON intake_manifolds(configuration);
CREATE INDEX idx_intake_manifolds_runner_length ON intake_manifolds(runner_length);

-- ============================================================================
-- FUEL PROPERTIES TABLE
-- ============================================================================
-- Fuel specifications for combustion modeling

CREATE TABLE fuels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    common_name TEXT,  -- e.g., "pump gas", "E85", "race gas"

    -- Composition
    -- RON/MON range widened to 70-160 to accommodate high-octane race fuels and
    -- non-hydrocarbon fuels such as hydrogen (RON ~130+) and methanol (RON ~130).
    -- Lower bound 70 allows diesel-equivalent fuels (cetane-rated, low octane proxy).
    octane_ron INTEGER CHECK(octane_ron BETWEEN 70 AND 160),  -- Research Octane Number
    octane_mon INTEGER CHECK(octane_mon BETWEEN 70 AND 160),  -- Motor Octane Number
    octane_aki INTEGER CHECK(octane_aki BETWEEN 70 AND 160),  -- Anti-Knock Index (R+M)/2
    ethanol_content REAL CHECK(ethanol_content BETWEEN 0 AND 100),  -- % by volume

    -- Energy content
    lower_heating_value REAL NOT NULL,  -- MJ/kg
    density REAL NOT NULL,  -- kg/L at 15°C

    -- Combustion properties
    stoichiometric_afr REAL NOT NULL,  -- ratio
    laminar_flame_speed REAL,  -- m/s at stoich
    autoignition_temp REAL,  -- K

    -- Temperature sensitivity
    temp_coefficient REAL,  -- octane change per °C

    -- Metadata
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for fuel lookups
CREATE INDEX idx_fuels_name ON fuels(name);
CREATE INDEX idx_fuels_octane ON fuels(octane_aki);

-- ============================================================================
-- COMPATIBILITY RULES TABLE
-- ============================================================================
-- Define compatibility rules for part combinations
-- Used by compatibility checker to validate builds

CREATE TABLE compatibility_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_name TEXT NOT NULL,
    rule_type TEXT CHECK(rule_type IN (
        'bore_spacing', 'valve_clearance', 'rod_ratio', 'quench',
        'bearing_size', 'deck_height', 'compression_ratio', 'custom'
    )),

    -- Rule definition (human readable)
    description TEXT NOT NULL,

    -- Validation SQL expression
    -- Must return TRUE if compatible, FALSE if not
    -- Can reference parts tables
    validation_sql TEXT,

    -- Severity
    severity TEXT CHECK(severity IN ('error', 'warning', 'info')) DEFAULT 'error',

    -- Recommendation when rule fails
    recommendation TEXT,

    -- Active status
    active BOOLEAN DEFAULT TRUE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for active rules
CREATE INDEX idx_compatibility_rules_active ON compatibility_rules(active);
CREATE INDEX idx_compatibility_rules_type ON compatibility_rules(rule_type);

-- ============================================================================
-- SAVED ENGINE CONFIGURATIONS TABLE
-- ============================================================================
-- Store user-created engine configurations for quick recall

CREATE TABLE saved_configurations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,

    -- Part selections
    engine_block_id INTEGER,
    cylinder_head_id INTEGER,
    piston_id INTEGER,
    connecting_rod_id INTEGER,
    crankshaft_id INTEGER,
    camshaft_id INTEGER,
    turbocharger_id INTEGER,
    intake_manifold_id INTEGER,
    fuel_id INTEGER,

    -- Custom parameters (JSON)
    -- Structure: {
    --   "compression_ratio": 10.5,
    --   "target_power": 500,
    --   "max_rpm": 6500,
    --   "forced_induction": {"boost": 15, "wastegate": "external"},
    --   ...
    -- }
    custom_params_json TEXT CHECK(json_valid(custom_params_json) OR custom_params_json IS NULL),

    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (engine_block_id) REFERENCES engine_blocks(id),
    FOREIGN KEY (cylinder_head_id) REFERENCES cylinder_heads(id),
    FOREIGN KEY (piston_id) REFERENCES pistons(id),
    FOREIGN KEY (connecting_rod_id) REFERENCES connecting_rods(id),
    FOREIGN KEY (crankshaft_id) REFERENCES crankshafts(id),
    FOREIGN KEY (camshaft_id) REFERENCES camshafts(id),
    FOREIGN KEY (turbocharger_id) REFERENCES turbochargers(id),
    FOREIGN KEY (intake_manifold_id) REFERENCES intake_manifolds(id),
    FOREIGN KEY (fuel_id) REFERENCES fuels(id)
);

-- Index for configuration lookups
CREATE INDEX idx_saved_configurations_name ON saved_configurations(name);

-- ============================================================================
-- TRIGGERS FOR AUTOMATIC TIMESTAMP UPDATES
-- ============================================================================
-- Update 'updated_at' timestamp whenever a row is modified

CREATE TRIGGER update_manufacturers_timestamp
    AFTER UPDATE ON manufacturers
    FOR EACH ROW
BEGIN
    UPDATE manufacturers SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_engine_blocks_timestamp
    AFTER UPDATE ON engine_blocks
    FOR EACH ROW
BEGIN
    UPDATE engine_blocks SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_cylinder_heads_timestamp
    AFTER UPDATE ON cylinder_heads
    FOR EACH ROW
BEGIN
    UPDATE cylinder_heads SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_pistons_timestamp
    AFTER UPDATE ON pistons
    FOR EACH ROW
BEGIN
    UPDATE pistons SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_connecting_rods_timestamp
    AFTER UPDATE ON connecting_rods
    FOR EACH ROW
BEGIN
    UPDATE connecting_rods SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_crankshafts_timestamp
    AFTER UPDATE ON crankshafts
    FOR EACH ROW
BEGIN
    UPDATE crankshafts SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_camshafts_timestamp
    AFTER UPDATE ON camshafts
    FOR EACH ROW
BEGIN
    UPDATE camshafts SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_turbochargers_timestamp
    AFTER UPDATE ON turbochargers
    FOR EACH ROW
BEGIN
    UPDATE turbochargers SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_intake_manifolds_timestamp
    AFTER UPDATE ON intake_manifolds
    FOR EACH ROW
BEGIN
    UPDATE intake_manifolds SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

CREATE TRIGGER update_saved_configurations_timestamp
    AFTER UPDATE ON saved_configurations
    FOR EACH ROW
BEGIN
    UPDATE saved_configurations SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;

-- ============================================================================
-- VIEWS FOR COMMON QUERIES
-- ============================================================================
-- Pre-defined views to simplify common queries and improve performance

-- Complete engine block information with manufacturer name
CREATE VIEW v_engine_blocks_full AS
SELECT
    eb.*,
    m.name as manufacturer_name,
    mat.name as material_name,
    (eb.bore * eb.bore * eb.stroke * eb.cylinder_count * 0.7854 / 1000000) as displacement_liters
FROM engine_blocks eb
LEFT JOIN manufacturers m ON eb.manufacturer_id = m.id
LEFT JOIN materials mat ON eb.material_id = mat.id;

-- Complete cylinder head information with manufacturer name
CREATE VIEW v_cylinder_heads_full AS
SELECT
    ch.*,
    m.name as manufacturer_name,
    mat.name as material_name
FROM cylinder_heads ch
LEFT JOIN manufacturers m ON ch.manufacturer_id = m.id
LEFT JOIN materials mat ON ch.material_id = mat.id;

-- Complete piston information with manufacturer name
CREATE VIEW v_pistons_full AS
SELECT
    p.*,
    m.name as manufacturer_name,
    mat.name as material_name
FROM pistons p
LEFT JOIN manufacturers m ON p.manufacturer_id = m.id
LEFT JOIN materials mat ON p.material_id = mat.id;

-- Complete connecting rod information with manufacturer name
CREATE VIEW v_connecting_rods_full AS
SELECT
    cr.*,
    m.name as manufacturer_name,
    mat.name as material_name
FROM connecting_rods cr
LEFT JOIN manufacturers m ON cr.manufacturer_id = m.id
LEFT JOIN materials mat ON cr.material_id = mat.id;

-- Complete crankshaft information with manufacturer name
CREATE VIEW v_crankshafts_full AS
SELECT
    c.*,
    m.name as manufacturer_name,
    mat.name as material_name
FROM crankshafts c
LEFT JOIN manufacturers m ON c.manufacturer_id = m.id
LEFT JOIN materials mat ON c.material_id = mat.id;

-- Complete camshaft information with manufacturer name
CREATE VIEW v_camshafts_full AS
SELECT
    cam.*,
    m.name as manufacturer_name
FROM camshafts cam
LEFT JOIN manufacturers m ON cam.manufacturer_id = m.id;

-- Complete turbocharger information with manufacturer name
CREATE VIEW v_turbochargers_full AS
SELECT
    t.*,
    m.name as manufacturer_name
FROM turbochargers t
LEFT JOIN manufacturers m ON t.manufacturer_id = m.id;

-- Complete supercharger information with manufacturer and material names (PIS-0157).
-- The base table has no price_used column; the view supplies it as NULL because the ORM's
-- shared Part::fromRow reads it on every part row.
CREATE VIEW v_superchargers_full AS
SELECT
    s.*,
    NULL as price_used,
    m.name as manufacturer_name,
    mat.name as material_name
FROM superchargers s
LEFT JOIN manufacturers m ON s.manufacturer_id = m.id
LEFT JOIN materials mat ON s.material_id = mat.id;

-- Complete intake manifold information with manufacturer and material names.
-- Added so every part table the ORM reads has a v_*_full view: the ORM resolves
-- manufacturer_name through these views rather than reading a column that does
-- not exist on the base tables (PIS-0134).
CREATE VIEW v_intake_manifolds_full AS
SELECT
    im.*,
    m.name as manufacturer_name,
    mat.name as material_name
FROM intake_manifolds im
LEFT JOIN manufacturers m ON im.manufacturer_id = m.id
LEFT JOIN materials mat ON im.material_id = mat.id;

-- Saved configurations with all part details
CREATE VIEW v_saved_configurations_full AS
SELECT
    sc.id,
    sc.name,
    sc.description,
    eb.model as engine_block,
    ch.model as cylinder_head,
    p.model as piston,
    cr.model as connecting_rod,
    crk.model as crankshaft,
    cam.model as camshaft,
    t.model as turbocharger,
    im.model as intake_manifold,
    f.name as fuel,
    sc.custom_params_json,
    sc.created_at,
    sc.updated_at
FROM saved_configurations sc
LEFT JOIN engine_blocks eb ON sc.engine_block_id = eb.id
LEFT JOIN cylinder_heads ch ON sc.cylinder_head_id = ch.id
LEFT JOIN pistons p ON sc.piston_id = p.id
LEFT JOIN connecting_rods cr ON sc.connecting_rod_id = cr.id
LEFT JOIN crankshafts crk ON sc.crankshaft_id = crk.id
LEFT JOIN camshafts cam ON sc.camshaft_id = cam.id
LEFT JOIN turbochargers t ON sc.turbocharger_id = t.id
LEFT JOIN intake_manifolds im ON sc.intake_manifold_id = im.id
LEFT JOIN fuels f ON sc.fuel_id = f.id;

-- ============================================================================
-- PERFORMANCE OPTIMIZATION NOTES
-- ============================================================================
-- 1. All foreign keys have indexes automatically created by SQLite
-- 2. Additional indexes created on frequently queried columns:
--    - bore, stroke, displacement (engine_blocks)
--    - bore_spacing (engine_blocks, cylinder_heads)
--    - valve diameters (cylinder_heads)
--    - piston bore, compression height, pin diameter
--    - rod length, bearing sizes
--    - camshaft duration, lift, LSA
--
-- 3. JSON validation constraints ensure data integrity for complex data
-- 4. Views provide denormalized data for read-heavy operations
-- 5. Triggers maintain timestamp consistency automatically
--
-- 6. For production use, consider:
--    - Enabling WAL mode: PRAGMA journal_mode = WAL;
--    - Increasing cache size: PRAGMA cache_size = -64000; (64MB)
--    - Using query planner: ANALYZE; (run after bulk inserts)
--
-- 7. Schema versioning via schema_version table enables future migrations
--
-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
