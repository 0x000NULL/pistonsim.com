-- ============================================================================
-- PISTON Parts Database - Superchargers Data
-- ============================================================================
-- First supercharger coverage for the parts catalog. Includes:
-- - Supercharger-specialist manufacturers (Eaton, Magnuson, Whipple, Vortech, ProCharger)
-- - Basic-spec supercharger entries spanning 3 types:
--     * roots:       4 Eaton + 3 Magnuson           = 7
--     * twin_screw:  3 Whipple                      = 3
--     * centrifugal: 2 Vortech + 3 ProCharger       = 5
--
-- Notes:
-- - DDL (CREATE TABLE / CREATE INDEX) for superchargers lives in schema.sql.
-- - Idempotent: re-running the file produces no duplicate manufacturers or rows
--   (INSERT OR IGNORE on manufacturers; part_number UNIQUE constraint guards parts).
-- - simulation_supported defaults FALSE on every row (basic-spec only, no compressor maps).
-- - displacement_ci is populated for positive-displacement units (roots / twin_screw)
--   and NULL for centrifugal units (which lack a fixed displacement-per-rev).
-- - weight column is in kg (PDDI-17).  Original lbs values × 0.453592, rounded to 1 dp.
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 5 manufacturers
-- Rows: 15 superchargers

-- ============================================================================
-- MANUFACTURERS (supercharger specialists)
-- ============================================================================
-- INSERT OR IGNORE so this seed is safe to run after manufacturers_extended.sql
-- without violating the UNIQUE constraint on manufacturers.name.

INSERT OR IGNORE INTO manufacturers (name, country, website, notes) VALUES
('Eaton', 'USA', 'https://www.eaton.com', 'Roots-style positive-displacement superchargers, OEM and aftermarket'),
('Magnuson', 'USA', 'https://www.magnusonsuperchargers.com', 'TVS roots-style supercharger systems for OEM and crate engines'),
('Whipple Superchargers', 'USA', 'https://www.whipplesuperchargers.com', 'Twin-screw superchargers, high-output street and race applications'),
('Vortech', 'USA', 'https://www.vortechsuperchargers.com', 'Centrifugal supercharger systems, V-series'),
('ProCharger (ATI)', 'USA', 'https://www.procharger.com', 'Centrifugal supercharger systems, D/F-series for street and drag');

-- ============================================================================
-- EATON ROOTS-STYLE SUPERCHARGERS
-- ============================================================================

-- Eaton M62 (compact roots, ~62 ci/rev, OEM late-90s/early-2000s applications)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'M62', 'EAT-M62-OEM', 'roots',
       62.0, 380.0, 2.0, 2.6,
       18.0, 12.7, mat.id, 1200.00,
       FALSE,
       'Eaton M62 roots blower, ~62 ci/rev, ~250 HP capable, OEM Buick 3800 / T-Bird SC platform'
FROM manufacturers m, materials mat
WHERE m.name = 'Eaton' AND mat.name = 'Aluminum 6061-T6';

-- Eaton M90 (mid-frame roots, ~90 ci/rev, popular GM 3.8L SC unit)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'M90', 'EAT-M90-OEM', 'roots',
       90.0, 550.0, 2.0, 2.8,
       28.0, 15.9, mat.id, 1500.00,
       FALSE,
       'Eaton M90 roots blower, ~90 ci/rev, ~325 HP capable, GM 3800 Series II/III, common swap unit'
FROM manufacturers m, materials mat
WHERE m.name = 'Eaton' AND mat.name = 'Aluminum 6061-T6';

-- Eaton M112 (larger roots, ~112 ci/rev, Ford Lightning / Mustang Cobra)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'M112', 'EAT-M112-OEM', 'roots',
       112.0, 700.0, 2.0, 3.0,
       38.0, 19.1, mat.id, 1900.00,
       FALSE,
       'Eaton M112 roots blower, ~112 ci/rev, ~400 HP capable, Ford SVT Lightning / Cobra OEM'
FROM manufacturers m, materials mat
WHERE m.name = 'Eaton' AND mat.name = 'Aluminum 6061-T6';

-- Eaton M122 (large roots, ~122 ci/rev, Mercedes / Mustang Saleen)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'M122', 'EAT-M122-OEM', 'roots',
       122.0, 760.0, 2.2, 3.2,
       42.0, 20.9, mat.id, 2100.00,
       FALSE,
       'Eaton M122 roots blower, ~122 ci/rev, ~450 HP capable, Saleen S281 / Mercedes AMG OEM'
FROM manufacturers m, materials mat
WHERE m.name = 'Eaton' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- MAGNUSON ROOTS / TVS SUPERCHARGERS
-- ============================================================================

-- Magnuson MP1900 TVS (1900 cc/rev, ~115 ci, LS / late-model V8)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'MP1900 TVS', 'MAG-MP1900', 'roots',
       115.9, 720.0, 2.2, 3.0,
       40.0, 21.8, mat.id, 6500.00,
       FALSE,
       'Magnuson MP1900 TVS, 1900 cc/rev, ~625 HP capable, LSx / Coyote bolt-on systems'
FROM manufacturers m, materials mat
WHERE m.name = 'Magnuson' AND mat.name = 'Aluminum 6061-T6';

-- Magnuson MP2300 TVS (2300 cc/rev, ~140 ci, LS9-style supplied unit)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'MP2300 TVS', 'MAG-MP2300', 'roots',
       140.4, 880.0, 2.2, 3.1,
       50.0, 24.9, mat.id, 7200.00,
       FALSE,
       'Magnuson MP2300 TVS, 2300 cc/rev, ~750 HP capable, LS9 / ZR1 OEM-style large rotor pack'
FROM manufacturers m, materials mat
WHERE m.name = 'Magnuson' AND mat.name = 'Aluminum 6061-T6';

-- Magnuson MP2650 TVS (2650 cc/rev, ~162 ci, large displacement V8)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'MP2650 TVS', 'MAG-MP2650', 'roots',
       161.7, 1000.0, 2.3, 3.3,
       58.0, 28.1, mat.id, 8200.00,
       FALSE,
       'Magnuson MP2650 TVS, 2650 cc/rev, ~850 HP capable, big-cube V8 (LT4-class, 6.2/6.4 Hemi)'
FROM manufacturers m, materials mat
WHERE m.name = 'Magnuson' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- WHIPPLE TWIN-SCREW SUPERCHARGERS
-- ============================================================================

-- Whipple W140AX (2.3L twin-screw, 140 ci/rev, popular Coyote/LS unit)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'W140AX', 'WHP-W140AX', 'twin_screw',
       140.0, 1050.0, 2.3, 3.4,
       55.0, 27.2, mat.id, 7800.00,
       FALSE,
       'Whipple W140AX 2.3L twin-screw, ~775 HP capable, Coyote / LS / Hemi front-feed kits'
FROM manufacturers m, materials mat
WHERE m.name = 'Whipple Superchargers' AND mat.name = 'Aluminum 6061-T6';

-- Whipple W175AX (2.9L twin-screw, 175 ci/rev, big-power street/strip)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'W175AX', 'WHP-W175AX', 'twin_screw',
       175.0, 1300.0, 2.3, 3.5,
       70.0, 30.8, mat.id, 8800.00,
       FALSE,
       'Whipple W175AX 2.9L twin-screw, ~1000 HP capable, 5.2 Predator / 6.2 Hellcat front-feed'
FROM manufacturers m, materials mat
WHERE m.name = 'Whipple Superchargers' AND mat.name = 'Aluminum 6061-T6';

-- Whipple W210AX (3.4L twin-screw, 210 ci/rev, race-class)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'W210AX', 'WHP-W210AX', 'twin_screw',
       210.0, 1550.0, 2.4, 3.6,
       85.0, 34.0, mat.id, 10500.00,
       FALSE,
       'Whipple W210AX 3.4L twin-screw, ~1200 HP capable, big-cube race / Demon-class builds'
FROM manufacturers m, materials mat
WHERE m.name = 'Whipple Superchargers' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- VORTECH CENTRIFUGAL SUPERCHARGERS
-- ============================================================================
-- Centrifugal SCs do not have a fixed per-rev displacement; displacement_ci = NULL.

-- Vortech V-3 Si-Trim (compact centrifugal, street-class)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'V-3 Si-Trim', 'VOR-V3SI', 'centrifugal',
       NULL, 1100.0, 3.0, 4.5,
       45.0, 8.2, mat.id, 2900.00,
       FALSE,
       'Vortech V-3 Si-Trim, self-contained oiling, ~775 HP capable, SBC/LS/Coyote street kits, ~5.4:1 internal step-up'
FROM manufacturers m, materials mat
WHERE m.name = 'Vortech' AND mat.name = 'Aluminum 6061-T6';

-- Vortech V-7 YSi-Trim (mid-size centrifugal, race-capable)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'V-7 YSi-Trim', 'VOR-V7YSI', 'centrifugal',
       NULL, 1500.0, 3.0, 4.5,
       70.0, 10.9, mat.id, 3800.00,
       FALSE,
       'Vortech V-7 YSi-Trim, race-capable centrifugal, ~1200 HP capable, ~3.6:1 internal step-up, oil-fed'
FROM manufacturers m, materials mat
WHERE m.name = 'Vortech' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- PROCHARGER CENTRIFUGAL SUPERCHARGERS
-- ============================================================================

-- ProCharger D-1SC (street-class centrifugal, self-contained gear case)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'D-1SC', 'PRO-D1SC', 'centrifugal',
       NULL, 1150.0, 3.0, 4.4,
       50.0, 10.0, mat.id, 4200.00,
       FALSE,
       'ProCharger D-1SC, self-contained centrifugal, ~825 HP capable, popular SBC/LS/Coyote street kits'
FROM manufacturers m, materials mat
WHERE m.name = 'ProCharger (ATI)' AND mat.name = 'Aluminum 6061-T6';

-- ProCharger F-1A (race-class centrifugal, oil-fed gear case)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'F-1A', 'PRO-F1A', 'centrifugal',
       NULL, 1500.0, 3.2, 4.8,
       75.0, 14.5, mat.id, 5800.00,
       FALSE,
       'ProCharger F-1A, oil-fed race centrifugal, ~1200 HP capable, big-power V8 street/strip'
FROM manufacturers m, materials mat
WHERE m.name = 'ProCharger (ATI)' AND mat.name = 'Aluminum 6061-T6';

-- ProCharger F-1X (top-tier centrifugal, large-frame race)
INSERT INTO superchargers (manufacturer_id, model, part_number, type,
                          displacement_ci, max_cfm_at_10psi, pulley_ratio_min, pulley_ratio_max,
                          parasitic_drag_hp_at_redline, weight, material_id, price_new,
                          simulation_supported, notes)
SELECT m.id, 'F-1X', 'PRO-F1X', 'centrifugal',
       NULL, 1800.0, 3.2, 5.0,
       95.0, 16.3, mat.id, 7200.00,
       FALSE,
       'ProCharger F-1X, large-frame race centrifugal, ~1525 HP capable, billet impeller, oil-fed'
FROM manufacturers m, materials mat
WHERE m.name = 'ProCharger (ATI)' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- SUMMARY
-- ============================================================================
-- Manufacturers added (INSERT OR IGNORE): 5
--   - Eaton, Magnuson, Whipple Superchargers, Vortech, ProCharger (ATI)
--
-- Superchargers added: 15
--   - roots (7):       Eaton M62, M90, M112, M122; Magnuson MP1900, MP2300, MP2650
--   - twin_screw (3):  Whipple W140AX, W175AX, W210AX
--   - centrifugal (5): Vortech V-3 Si-Trim, V-7 YSi-Trim;
--                      ProCharger D-1SC, F-1A, F-1X
--
-- All rows: simulation_supported = FALSE (basic-spec only, no compressor maps).
-- All weights in kg (PDDI-17 conversion from lbs, original × 0.453592).
-- ============================================================================
