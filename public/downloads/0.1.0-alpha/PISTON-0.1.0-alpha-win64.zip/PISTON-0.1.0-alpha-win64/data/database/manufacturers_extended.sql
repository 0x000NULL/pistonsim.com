-- ============================================================================
-- PISTON Parts Database - Extended Manufacturers
-- ============================================================================
-- Additional manufacturers to complement the base set in sample_data.sql
-- These manufacturers support the extended parts catalog
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 13 manufacturers

INSERT INTO manufacturers (name, country, website, notes) VALUES
-- Piston manufacturers
('JE Pistons', 'USA', 'https://www.jepistons.com', 'High-performance forged pistons'),
('CP Pistons', 'USA', 'https://www.cppistons.com', 'Custom forged pistons and rings'),

-- Connecting rod manufacturers
('Eagle Specialty Products', 'USA', 'https://www.eaglerod.com', 'I-beam and H-beam connecting rods'),
('Manley Performance', 'USA', 'https://www.manleyperformance.com', 'Premium rods, pistons, and valves'),
('Brian Crower', 'USA', 'https://www.briancrower.com', 'Rods, cams, valve springs'),

-- Camshaft manufacturers
('Crane Cams', 'USA', 'https://www.cranecams.com', 'High-performance camshafts and valvetrain'),
('Lunati', 'USA', 'https://www.lunatipower.com', 'Camshafts and valvetrain components'),

-- Turbocharger manufacturers
('BorgWarner', 'USA', 'https://www.borgwarner.com', 'OEM and aftermarket turbochargers'),
('Holset', 'USA/UK', 'https://www.holset.com', 'Cummins turbocharger division'),

-- Intake manifold manufacturers
('Edelbrock', 'USA', 'https://www.edelbrock.com', 'Intake manifolds, carburetors, heads'),
('Holley Performance', 'USA', 'https://www.holley.com', 'Intake manifolds, EFI systems, carbs'),

-- OEM manufacturers (P2-16: needed for correct engine/part attribution)
('Mitsubishi', 'Japan', 'https://www.mitsubishi.com', 'OEM: 4G63, 4B11 engines (Eclipse, Evolution series)'),
('Nissan', 'Japan', 'https://www.nissan.com', 'OEM: SR20DET, RB26DETT, VQ35, VR38 engines');

-- Extended manufacturers complement existing:
-- GM, Ford, Chrysler, Toyota, Honda (OEMs)
-- Comp Cams, Texas Speed, Garrett, Precision, Wiseco (specialists)
--
