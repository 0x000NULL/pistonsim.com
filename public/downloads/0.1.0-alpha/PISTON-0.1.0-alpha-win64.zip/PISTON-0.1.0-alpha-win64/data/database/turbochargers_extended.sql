-- ============================================================================
-- PISTON Parts Database - Extended Turbochargers Data
-- ============================================================================
-- Additional turbochargers complementing those in sample_data.sql:
-- - Garrett turbos (GT series, GTX series)
-- - BorgWarner (EFR series)
-- - Precision (PT series)
-- - Holset (HX series, truck turbos)
--
-- Turbo specs include compressor/turbine inducer/exducer, trim, A/R, bearings
-- Note: sample_data.sql already contains its own turbos (Garrett GTX3076R, etc.)
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 30 turbochargers

-- ============================================================================
-- GARRETT MOTION TURBOCHARGERS
-- ============================================================================

-- Garrett G25-550 (small, responsive, 550 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'G25-550', '877895-5003S', 46.0, 62.0,
       53.0, 46.0, 56, 84,
       0.72, 0.92, 'ball', TRUE, TRUE,
       230000, 35.0, 36.0, 6.2, mat.id, 1350.00, NULL,
       'Garrett G25-550, 550 HP, responsive small turbo, water-cooled CHRA',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett G30-660 (mid-size, 660 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'G30-660', '877895-5007S', 52.0, 67.0,
       60.0, 52.0, 60, 84,
       0.72, 1.01, 'ball', TRUE, TRUE,
       220000, 38.0, 42.0, 7.5, mat.id, 1450.00, NULL,
       'Garrett G30-660, 660 HP, balanced turbo/lag, ball-bearing',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett GTX3582R Gen2 (high-flow, 775 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'GTX3582R Gen2', '856801-5003S', 58.0, 82.0,
       74.0, 62.0, 58, 84,
       0.70, 1.06, 'ball', TRUE, FALSE,
       225000, 40.0, 52.0, 9.8, mat.id, 1900.00, 900.00,
       'Garrett GTX3582R Gen2, 775 HP, larger compressor, ball-bearing',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- BORGWARNER EFR TURBOCHARGERS
-- ============================================================================

-- BorgWarner EFR 6258 (225-450 HP)
-- Geometry, part number (6258-A complete turbo, 0.64 A/R T25 single scroll) and HP rating
-- from BorgWarner's own EFR 6258 data sheet, borgwarner.com/docs/default-source/iam/
-- boosting-technologies/efr-6258-a.pdf (accessed 2026-09-23): compressor wheel inducer 49 mm,
-- outer 62 mm; turbine wheel outer 58 mm, exducer 51 mm. The row previously carried a 40 mm
-- compressor inducer and the two turbine diameters swapped (inducer 50 < exducer 58), which
-- the ORM rejects, and a part number (179391) that is not in BorgWarner's table (PIS-0195).
-- Trims follow from the diameters: (49/62)^2 = 62, (51/58)^2 = 77. BorgWarner publishes no
-- compressor housing A/R for this model, so none is stated.
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'EFR 6258', '179150', 49.0, 62.0,
       58.0, 51.0, 62, 77,
       NULL, 0.64, 'ball', TRUE, TRUE,
       240000, 38.0, 32.0, 6.8, mat.id, 1650.00, NULL,
       'BorgWarner EFR 6258-A, 225-450 HP (BorgWarner rating), T25 0.64 A/R, integrated wastegate',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'BorgWarner' AND mat.name = 'Aluminum 6061-T6';

-- BorgWarner EFR 7670 (375-650 HP)
-- Geometry, part number (7670-C complete turbo, 0.92 A/R T4 twin scroll, wastegated) and HP
-- rating from BorgWarner's own EFR 7670 data sheet, borgwarner.com/docs/default-source/iam/
-- boosting-technologies/efr-7670-c.pdf (accessed 2026-09-23): compressor wheel inducer 57 mm,
-- outer 76 mm; turbine wheel outer 70 mm, exducer 61 mm. The row previously carried a 52 mm
-- compressor inducer, the turbine diameters swapped, a 700 HP rating BorgWarner does not give
-- and a part number (179394) not in BorgWarner's table (PIS-0195). The 7670-D number (179392)
-- could not be used: the EFR 6758 row below already carries it, which BorgWarner's 7670 table
-- contradicts. Trims follow from the diameters: (57/76)^2 = 56, (61/70)^2 = 76. No compressor
-- housing A/R is published.
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'EFR 7670', '179390', 57.0, 76.0,
       70.0, 61.0, 56, 76,
       NULL, 0.92, 'ball', TRUE, TRUE,
       220000, 42.0, 47.0, 10.2, mat.id, 1850.00, NULL,
       'BorgWarner EFR 7670-C, 375-650 HP (BorgWarner rating), T4 twin-scroll 0.92 A/R, Gamma-Ti turbine',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'BorgWarner' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- PRECISION TURBO TURBOCHARGERS
-- ============================================================================

-- Precision 5558 (street/strip, 550 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'Precision 5558', 'PT5558', 55.0, 71.0,
       58.0, 52.0, 58, 82,
       0.72, 0.81, 'ball', TRUE, FALSE,
       215000, 36.0, 38.0, 8.0, mat.id, 1280.00, NULL,
       'Precision 5558, 550 HP, street/strip, CEA compressor wheel',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Precision Turbo' AND mat.name = 'Aluminum 6061-T6';

-- Precision 6466 Gen2 (mid-range, 800 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'Precision 6466 Gen2', 'PT6466-GEN2', 64.0, 88.0,
       66.0, 62.0, 62, 84,
       0.82, 0.96, 'ball', TRUE, FALSE,
       210000, 45.0, 58.0, 11.5, mat.id, 1750.00, 850.00,
       'Precision 6466 Gen2, 800 HP, great mid-range power, CEA compressor',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Precision Turbo' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- HOLSET TURBOCHARGERS (Truck/Diesel)
-- ============================================================================

-- Holset HX40W (diesel truck, robust)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'HX40W', '3538856', 60.0, 88.0,
       74.0, 68.0, 58, 78,
       0.70, 0.96, 'journal', TRUE, FALSE,
       180000, 35.0, 55.0, 14.0, mat.id, 900.00, 300.00,
       'Holset HX40W, diesel truck turbo, journal bearing, very robust',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Holset' AND mat.name = 'Cast Iron';

-- Holset HX35 (smaller diesel, budget turbo)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'HX35', '3536338', 54.0, 82.0,
       68.0, 62.0, 60, 80,
       0.68, 0.88, 'journal', TRUE, FALSE,
       190000, 32.0, 48.0, 12.5, mat.id, 750.00, 200.00,
       'Holset HX35, smaller diesel turbo, budget-friendly, journal bearing',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Holset' AND mat.name = 'Cast Iron';

-- Holset HE351CW (VGT, variable geometry)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'HE351CW VGT', '4043976', 57.0, 85.0,
       71.0, 65.0, 61, 82,
       0.72, NULL, 'journal', TRUE, FALSE,  -- VGT has no fixed A/R
       185000, 38.0, 52.0, 15.5, mat.id, 1200.00, 450.00,
       'Holset HE351CW, VGT (Variable Geometry Turbo), electronic actuator',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Holset' AND mat.name = 'Cast Iron';

-- ============================================================================
-- ADDITIONAL POPULAR STREET/TRACK TURBOS (basic specs)
-- ============================================================================
-- Basic spec rows only -- compressor_map_data_json/turbine_map_data_json left
-- NULL. Performance numbers are conservative manufacturer-spec-sheet values
-- referenced in each notes column.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- GARRETT (additional G-series and GTX/GT frames)
-- ----------------------------------------------------------------------------

-- Garrett G25-660 (small frame, 660 HP street/track)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'G25-660', '871389-5011S', 49.0, 64.0,
       54.0, 47.0, 60, 84,
       0.72, 0.92, 'ball', TRUE, TRUE,
       230000, 38.0, 46.0, 6.4, mat.id, 1500.00, NULL,
       'Garrett G25 family, 660 HP rated, fast-spool small frame, water-cooled CHRA',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett G30-770 (mid-size, 770 HP street/track)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'G30-770', '880698-5005S', 54.0, 71.0,
       60.0, 54.0, 58, 76,
       0.72, 1.01, 'ball', TRUE, TRUE,
       220000, 40.0, 52.0, 8.0, mat.id, 1700.00, NULL,
       'Garrett G30 family, 770 HP rated, popular street/track turbo',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett G30-900 (mid-size, 900 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'G30-900', '880698-5009S', 58.0, 71.0,
       65.0, 55.0, 67, 72,
       0.72, 1.01, 'ball', TRUE, TRUE,
       220000, 42.0, 62.0, 9.0, mat.id, 1850.00, NULL,
       'Garrett G30 family, 900 HP rated, larger comp wheel for top-end power',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett G35-900 (900 HP, 6-cyl street/track)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'G35-900', '880700-5005S', 58.0, 68.0,
       68.0, 61.0, 67, 84,
       0.72, 1.01, 'ball', TRUE, TRUE,
       220000, 42.0, 65.0, 10.0, mat.id, 2000.00, NULL,
       'Garrett G35 family, 900 HP rated, divided turbine housing options',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett G35-1050 (1050 HP, big-power 6-cyl)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'G35-1050', '880700-5009S', 62.0, 68.0,
       68.0, 61.0, 67, 84,
       0.72, 1.06, 'ball', TRUE, TRUE,
       220000, 45.0, 80.0, 10.5, mat.id, 2200.00, NULL,
       'Garrett G35 family, 1050 HP rated, larger comp inducer vs G35-900',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett G40-1150 (1150 HP, large-frame V8)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'G40-1150', '880702-5005S', 67.0, 82.0,
       80.0, 72.0, 65, 83,
       0.85, 1.06, 'ball', TRUE, TRUE,
       215000, 48.0, 115.0, 13.0, mat.id, 2600.00, NULL,
       'Garrett G40 family, 1150 HP rated, large-frame V8 street/track',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett GTX2867R Gen2 (small frame, popular 4-cyl track)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'GTX2867R Gen2', '856800-5008S', 47.0, 67.0,
       53.85, 47.0, 65, 75,
       0.64, 0.86, 'ball', TRUE, FALSE,
       240000, 32.0, 39.0, 6.0, mat.id, 1500.00, NULL,
       'Garrett GTX2867R Gen2, ~450 HP, popular for SR20DET / 4G63 / B-series builds',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett GT2860RS (legacy small-frame "Disco Potato")
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'GT2860RS', '707160-5004', 47.2, 60.1,
       53.8, 47.0, 62, 76,
       0.60, 0.64, 'ball', TRUE, FALSE,
       250000, 28.0, 36.0, 5.5, mat.id, 1400.00, 600.00,
       'Garrett GT2860RS "Disco Potato", classic 350 HP T25 frame for SR/4G/EJ',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- Garrett GT3076R Gen2 (popular T3-flange mid-frame)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'GT3076R Gen2', '836040-5012', 56.0, 76.0,
       60.0, 55.0, 56, 84,
       0.70, 0.82, 'ball', TRUE, FALSE,
       225000, 35.0, 52.0, 9.0, mat.id, 1550.00, 700.00,
       'Garrett GT3076R Gen2, ~525 HP, classic T3 mid-frame street/track turbo',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Garrett Motion' AND mat.name = 'Aluminum 6061-T6';

-- ----------------------------------------------------------------------------
-- BORGWARNER (additional EFR + S-series SX-E)
-- ----------------------------------------------------------------------------

-- BorgWarner EFR 6758 (mid-small EFR, 550 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'EFR 6758', '179392', 47.0, 67.0,
       60.4, 58.0, 63, 76,
       0.64, 0.85, 'ball', TRUE, TRUE,
       235000, 38.0, 45.0, 7.2, mat.id, 1750.00, NULL,
       'BorgWarner EFR 6758, ~550 HP, fast-spool mid-small, Gamma-Ti turbine',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'BorgWarner' AND mat.name = 'Aluminum 6061-T6';

-- BorgWarner EFR 7163 (mid EFR, ~600 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'EFR 7163', '179393', 49.0, 71.0,
       65.0, 63.0, 60, 76,
       0.83, 0.92, 'ball', TRUE, TRUE,
       225000, 40.0, 50.0, 9.0, mat.id, 1900.00, NULL,
       'BorgWarner EFR 7163, ~600 HP, balanced response/efficiency, ball-bearing',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'BorgWarner' AND mat.name = 'Aluminum 6061-T6';

-- BorgWarner EFR 8374 (large EFR, ~825 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'EFR 8374', '179395', 60.0, 83.0,
       75.0, 74.0, 58, 80,
       0.83, 1.05, 'ball', TRUE, TRUE,
       210000, 42.0, 70.0, 13.0, mat.id, 2200.00, NULL,
       'BorgWarner EFR 8374, ~825 HP, T4 housing, Gamma-Ti turbine wheel',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'BorgWarner' AND mat.name = 'Aluminum 6061-T6';

-- BorgWarner EFR 9180 (largest EFR, ~1100 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'EFR 9180', '179396', 64.0, 91.0,
       84.0, 80.0, 56, 78,
       1.00, 1.05, 'ball', TRUE, TRUE,
       200000, 45.0, 85.0, 16.0, mat.id, 2400.00, NULL,
       'BorgWarner EFR 9180, ~1100 HP, big-power T4 frame, ball-bearing',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'BorgWarner' AND mat.name = 'Aluminum 6061-T6';

-- BorgWarner S366 SX-E (66mm comp, billet wheel, 750 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'S366 SX-E', '14009097016', 50.0, 66.0,
       73.0, 65.0, 73, 84,
       0.83, 0.91, 'ball', TRUE, FALSE,
       195000, 42.0, 68.0, 16.0, mat.id, 1300.00, NULL,
       'BorgWarner S366 SX-E, ~750 HP, billet comp wheel, T4 flange',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'BorgWarner' AND mat.name = 'Aluminum 6061-T6';

-- A "BorgWarner S475 SX-E" row stood here and was removed (PIS-0195). It could not be matched
-- to a real product: BorgWarner's SX-E series is the 76 mm S476SX-E with a billet (FMW) wheel,
-- while the 75 mm S475 is the SX / SX3 / SX4 with a cast extended-tip wheel; its part number
-- (14009097023) appears in no BorgWarner or reseller listing found (searched 2026-09-23); and
-- its own figures contradicted each other (a 75 mm "comp" stored as the exducer of a 56 mm
-- inducer, and a turbine trim of 96 against 83/74 mm turbine wheels). A catalogue entry that
-- names a part nobody can buy is worse than none.

-- ----------------------------------------------------------------------------
-- PRECISION TURBO (additional CEA / Gen2 frames)
-- ----------------------------------------------------------------------------

-- Precision 5862 (street, ~625 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'Precision 5862', 'PT5862', 38.0, 58.0,
       62.0, 57.0, 60, 76,
       0.63, 0.81, 'ball', TRUE, FALSE,
       220000, 36.0, 46.0, 8.5, mat.id, 1350.00, NULL,
       'Precision 5862, ~625 HP, street/strip 6-cyl friendly, ball-bearing',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Precision Turbo' AND mat.name = 'Aluminum 6061-T6';

-- Precision 6062 CEA (street/strip, ~675 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'Precision 6062 CEA', 'PT6062-CEA', 42.0, 60.0,
       62.0, 57.0, 60, 76,
       0.70, 0.81, 'ball', TRUE, FALSE,
       215000, 38.0, 50.0, 9.0, mat.id, 1400.00, NULL,
       'Precision 6062 CEA, ~675 HP, billet (CEA) compressor wheel, street/strip',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Precision Turbo' AND mat.name = 'Aluminum 6061-T6';

-- Precision 6766 Gen2 (~900 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'Precision 6766 Gen2', 'PT6766-GEN2', 47.0, 67.0,
       66.0, 62.0, 65, 84,
       0.81, 0.96, 'ball', TRUE, FALSE,
       210000, 42.0, 60.0, 11.0, mat.id, 1750.00, NULL,
       'Precision 6766 Gen2, ~900 HP, CEA compressor, T4 flange',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Precision Turbo' AND mat.name = 'Aluminum 6061-T6';

-- Precision 6870 Gen2 (~1000 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'Precision 6870 Gen2', 'PT6870-GEN2', 48.0, 68.0,
       70.0, 65.0, 62, 84,
       0.81, 1.00, 'ball', TRUE, FALSE,
       210000, 44.0, 70.0, 12.0, mat.id, 1900.00, NULL,
       'Precision 6870 Gen2, ~1000 HP, CEA compressor, V-band/T4 options',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Precision Turbo' AND mat.name = 'Aluminum 6061-T6';

-- Precision 7175 Gen2 (~1150 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'Precision 7175 Gen2', 'PT7175-GEN2', 52.0, 71.0,
       75.0, 67.0, 65, 84,
       0.85, 1.05, 'ball', TRUE, FALSE,
       205000, 48.0, 85.0, 13.5, mat.id, 2150.00, NULL,
       'Precision 7175 Gen2, ~1150 HP, CEA compressor, drag/race-grade',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Precision Turbo' AND mat.name = 'Aluminum 6061-T6';

-- Precision 8085 Gen2 (~1300 HP)
INSERT INTO turbochargers (manufacturer_id, model, part_number, compressor_inducer, compressor_exducer,
                          turbine_inducer, turbine_exducer, compressor_trim, turbine_trim,
                          compressor_housing_ar, turbine_housing_ar, bearing_type, oil_cooled, water_cooled,
                          max_rpm, max_boost, max_flow, weight, material_id, price_new, price_used,
                          notes, compressor_map_data_json, turbine_map_data_json)
SELECT m.id, 'Precision 8085 Gen2', 'PT8085-GEN2', 58.0, 80.0,
       85.0, 75.0, 60, 84,
       1.00, 1.15, 'ball', TRUE, FALSE,
       200000, 50.0, 120.0, 16.5, mat.id, 2500.00, NULL,
       'Precision 8085 Gen2, ~1300 HP, CEA compressor, big-power competition',
       NULL, NULL
FROM manufacturers m, materials mat
WHERE m.name = 'Precision Turbo' AND mat.name = 'Aluminum 6061-T6';

-- ============================================================================
-- ============================================================================
-- Garrett: (G25-550, G25-660, G30-660, G30-770, G30-900,
--                    G35-900, G35-1050, G40-1150, GTX2867R Gen2,
--                    GTX3582R Gen2, GT2860RS, GT3076R Gen2)
-- BorgWarner: (EFR 6258, EFR 6758, EFR 7163, EFR 7670,
--                       EFR 8374, EFR 9180, S366 SX-E)
-- Precision: (5558, 5862, 6062 CEA, 6466 Gen2, 6766 Gen2,
--                      6870 Gen2, 7175 Gen2, 8085 Gen2)
-- Holset: (HX40W, HX35, HE351CW VGT)
--
-- Coverage: 350-1300 HP range, ball-bearing/journal/VGT, modern + legacy frames
-- Note: rows added in this section have compressor_map_data_json and
-- turbine_map_data_json left NULL (basic specs only, no map JSON).
-- ============================================================================
