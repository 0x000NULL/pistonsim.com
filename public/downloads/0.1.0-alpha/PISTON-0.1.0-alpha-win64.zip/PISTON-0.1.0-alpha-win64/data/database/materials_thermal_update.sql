-- ============================================================================
-- Material Thermal Properties Update
-- ============================================================================
-- Updates existing materials table with specific heat and melting point data
-- for heat transfer calculations
--
-- Author: PISTON Project
-- Version: 1.0.0
-- Date: 2025-10-30
-- ============================================================================

-- Add new columns if they don't exist (SQLite doesn't support IF NOT EXISTS for columns)
-- If running on fresh database, these columns will already exist from schema.sql

-- Note: SQLite ALTER TABLE only supports ADD COLUMN, not MODIFY
-- If columns already exist, this will fail (expected)
-- Run this only on databases created before thermal properties were added

-- Try to add columns (will fail if they exist, which is fine)
-- ALTER TABLE materials ADD COLUMN specific_heat REAL;  -- J/(kg·K)
-- ALTER TABLE materials ADD COLUMN melting_point REAL;  -- K

-- ============================================================================
-- Update existing materials with thermal properties
-- ============================================================================

-- Cast Iron
UPDATE materials
SET specific_heat = 460.0,
    melting_point = 1473.0
WHERE name = 'Cast Iron' OR name = 'Gray Cast Iron';

-- Aluminum 356
UPDATE materials
SET specific_heat = 963.0,
    melting_point = 888.0
WHERE name = 'Aluminum 356' OR name = 'Aluminum 356-T6';

-- Aluminum 6061
UPDATE materials
SET specific_heat = 896.0,
    melting_point = 855.0
WHERE name = 'Aluminum 6061-T6' OR name = 'Aluminum 6061';

-- Forged Steel
UPDATE materials
SET specific_heat = 486.0,
    melting_point = 1723.0
WHERE name = 'Forged Steel';

-- 4340 Steel
UPDATE materials
SET specific_heat = 475.0,
    melting_point = 1700.0
WHERE name = '4340 Steel' OR name = 'Steel 4340';

-- Titanium Ti-6Al-4V
UPDATE materials
SET specific_heat = 526.0,
    melting_point = 1878.0
WHERE name LIKE '%Titanium%' OR name LIKE '%Ti-6Al-4V%';

-- ============================================================================
-- Verification query
-- ============================================================================

-- Uncomment to verify updates
-- SELECT
--     name,
--     thermal_conductivity AS k_W_mK,
--     specific_heat AS cp_J_kgK,
--     melting_point AS Tm_K,
--     density AS rho_kg_m3
-- FROM materials
-- ORDER BY name;

-- ============================================================================
-- Material thermal property reference data
-- ============================================================================
--
-- Source: Engineering materials handbooks, Heywood (1988), MatWeb database
--
-- Material                  k (W/m·K)  cp (J/kg·K)  Tm (K)   ρ (kg/m³)
-- -------------------------------------------------------------------------
-- Aluminum 356-T6           151        963          888      2685
-- Aluminum 6061-T6          167        896          855      2700
-- Cast Iron (Gray)          52         460          1473     7200
-- Steel 4340                44.5       475          1700     7850
-- Forged Steel              50         486          1723     7850
-- Titanium Ti-6Al-4V        6.7        526          1878     4430
-- Copper                    400        385          1358     8960
-- Magnesium AZ31            96         1050         883      1770
-- Nodular Cast Iron         36         515          1493     7150
--
-- Thermal diffusivity (α) can be calculated as:
--   α = k / (ρ * cp)  [m²/s]
--
-- Biot number for heat transfer analysis:
--   Bi = h * L / k
-- where h = heat transfer coefficient, L = characteristic length
--
-- For engine applications:
-- - Bi < 0.1: Lumped capacitance model valid (uniform temperature)
-- - Bi > 0.1: Spatial temperature gradients must be considered
--
-- ============================================================================
