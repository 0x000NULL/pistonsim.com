-- ============================================================================
-- PISTON Parts Database - Pistons Data
-- ============================================================================
-- Pistons for popular engine builds:
-- - LS engine pistons (stock and forged)
-- - SBC pistons (hypereutectic, forged, dished/domed)
-- - Honda B/K series (high-compression, low-compression)
-- - JDM pistons (2JZ, 4G63, SR20DET)
--
-- Note: sample_data.sql already contains some pistons
-- ============================================================================
--
-- Rows this file adds, by table. Checked by tests/database/test_SeedRowCounts.cpp
-- (PIS-0189): state counts here and nowhere else in this file.
-- Rows: 16 pistons

-- ============================================================================
-- GM LS PISTONS
-- ============================================================================

-- Wiseco LS1 Forged Pistons (high-compression N/A)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS1 Forged Dome', 'K397X99', 99.0, 28.4, 22.0,
       68.0, -8.5, 6.0, 3.5, 44.0, 3.0, 38.0,
       '1.5mm/1.5mm/3.0mm', 'Dry film lubricant', 7500, NULL, 318.0, mat.id, 850.00, NULL,
       'Forged 2618 alloy, domed for 11.5:1 CR, LS1 build'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- JE Pistons LS2 Dish Turbo Pistons (low-compression turbo)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS2 Turbo Dish', 'JE-359630', 101.6, 28.4, 22.0,
       68.0, 15.0, NULL, 4.0, 45.0, 3.5, 40.0,
       '1.2mm/1.2mm/3.0mm', 'Ceramic crown coating', 8000, 45.0, 335.0, mat.id, 950.00, NULL,
       'Forged 2618, 15cc dish for 8.5:1 CR, turbo build'
FROM manufacturers m, materials mat
WHERE m.name = 'JE Pistons' AND mat.name = '2618 Aluminum';

-- CP Pistons LS3 Street/Strip (mid-compression)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS3 Street/Strip', 'SC7411', 103.25, 28.4, 22.0,
       68.0, 5.5, NULL, 3.8, 50.0, 3.2, 44.0,
       '1.5mm/1.5mm/3.0mm', 'Anodized', 7500, 15.0, 340.0, mat.id, 900.00, NULL,
       'Forged 2618, 5.5cc dish for 10.5:1 CR, street/strip'
FROM manufacturers m, materials mat
WHERE m.name = 'CP Pistons' AND mat.name = '2618 Aluminum';

-- LS7 Stock Hypereutectic Pistons (OEM replacement)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'LS7 Stock', '12499114', 104.8, 27.94, 25.0,
       68.0, 1.0, NULL, 4.2, 54.0, 3.6, 48.0,
       '1.2mm/1.2mm/2.0mm', 'None', 7000, NULL, 410.0, mat.id, 650.00, 200.00,
       'Hypereutectic OEM pistons, flat-top design, 11.0:1 CR (2006, used)'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = '4032 Aluminum';

-- ============================================================================
-- SMALL BLOCK CHEVY PISTONS
-- ============================================================================

-- Wiseco SBC 350 Forged Flat-Top (10:1 compression)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SBC 350 Flat-Top', 'K448X40', 101.6, 38.1, 22.225,
       74.6, 0.0, NULL, 2.8, 44.0, 2.4, 38.0,
       '1.5mm/1.5mm/3.0mm', 'Dry film', 7000, NULL, 460.0, mat.id, 750.00, NULL,
       'Forged flat-top for 10:1 CR, Vortec heads compatible'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- JE Pistons SBC 383 Stroker Domed (street performance)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SBC 383 Domed', 'JE-180958', 104.8, 38.1, 22.225,
       74.6, -12.0, 8.0, 3.2, 46.0, 2.8, 40.0,
       '1.5mm/1.5mm/3.0mm', 'Ceramic', 7200, NULL, 485.0, mat.id, 820.00, NULL,
       'Forged domed pistons for 383 stroker, 11:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'JE Pistons' AND mat.name = '2618 Aluminum';

-- CP Pistons SBC 406 Stroker Dished (turbo)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SBC 406 Turbo', 'SC7466', 106.0, 38.1, 22.225,
       74.6, 20.0, NULL, 4.0, 50.0, 3.5, 44.0,
       '1.2mm/1.2mm/3.0mm', 'Ceramic crown', 7500, 35.0, 510.0, mat.id, 920.00, NULL,
       'Forged dished for turbo 406, 20cc dish for 8.5:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'CP Pistons' AND mat.name = '2618 Aluminum';

-- SBC 350 Hypereutectic (budget rebuild)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SBC 350 Hyper', 'H345CP', 101.6, 38.1, 22.225,
       74.6, 5.0, NULL, 2.5, 42.0, 2.2, 36.0,
       '1.5mm/1.5mm/3.0mm', 'None', 6500, NULL, 520.0, mat.id, 380.00, NULL,
       'Hypereutectic budget pistons, 5cc dish, 9.0:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'General Motors' AND mat.name = '4032 Aluminum';

-- ============================================================================
-- HONDA B/K SERIES PISTONS
-- ============================================================================

-- Wiseco B16A High-Compression Pistons (11.5:1)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B16A High-Comp', 'K586M81', 81.0, 30.0, 19.0,
       50.0, -3.0, 2.5, 1.8, 32.0, 1.5, 28.0,
       '1.2mm/1.2mm/2.8mm', 'ArmorGlide', 9000, NULL, 225.0, mat.id, 720.00, NULL,
       'Forged dome for 11.5:1 CR, race build, 8500+ RPM'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- CP Pistons B18C Type R (10.5:1)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'B18C Type R', 'SC7009', 81.0, 30.0, 21.0,
       50.0, 0.0, NULL, 2.0, 34.0, 1.6, 30.0,
       '1.2mm/1.2mm/2.8mm', 'Anodized', 9000, NULL, 235.0, mat.id, 750.00, NULL,
       'Forged flat-top, Type R spec, 10.5:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'CP Pistons' AND mat.name = '2618 Aluminum';

-- JE Pistons K20A Turbo (low-compression 8.5:1)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K20A Turbo', 'JE-361530', 86.0, 30.0, 21.0,
       50.0, 12.0, NULL, 2.5, 36.0, 2.0, 32.0,
       '1.0mm/1.2mm/2.8mm', 'Ceramic crown', 9000, 40.0, 260.0, mat.id, 820.00, NULL,
       'Forged dished for turbo, 12cc dish, 8.5:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'JE Pistons' AND mat.name = '2618 Aluminum';

-- Wiseco K24A2 Street (10:1 compression)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'K24A2 Street', 'K624M87', 87.0, 30.0, 21.0,
       50.0, 2.0, NULL, 2.2, 36.0, 1.8, 32.0,
       '1.2mm/1.2mm/2.8mm', 'ArmorGlide', 8500, 12.0, 270.0, mat.id, 760.00, NULL,
       'Forged 2cc dish, street/boost capable, 10:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- ============================================================================
-- JDM PISTONS (2JZ, 4G63, SR20)
-- ============================================================================

-- CP Pistons 2JZ-GE High-Compression (N/A build)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ-GE N/A', 'SC7426', 86.0, 31.5, 23.0,
       62.0, -6.0, 4.5, 3.0, 38.0, 2.5, 34.0,
       '1.2mm/1.2mm/2.8mm', 'Anodized', 8000, NULL, 380.0, mat.id, 880.00, NULL,
       'Forged domed for 2JZ N/A, 11.5:1 CR, 6cc dome'
FROM manufacturers m, materials mat
WHERE m.name = 'CP Pistons' AND mat.name = '2618 Aluminum';

-- JE Pistons 2JZ-GTE Turbo (low-compression)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, '2JZ-GTE Turbo', 'JE-338340', 86.5, 31.5, 23.0,
       62.0, 18.0, NULL, 3.5, 40.0, 3.0, 36.0,
       '1.0mm/1.2mm/2.8mm', 'Ceramic crown', 8500, 50.0, 395.0, mat.id, 950.00, NULL,
       'Forged dished for turbo 2JZ, 18cc dish, 8.5:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'JE Pistons' AND mat.name = '2618 Aluminum';

-- Wiseco 4G63 Evo Pistons (turbo)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, '4G63 Evo Turbo', 'K557M85', 85.0, 34.2, 22.0,
       60.0, 14.0, NULL, 2.8, 36.0, 2.4, 32.0,
       '1.2mm/1.2mm/2.8mm', 'ArmorGlide', 8500, 45.0, 320.0, mat.id, 840.00, NULL,
       'Forged dished for Evo turbo, 14cc dish, 8.5:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'Wiseco' AND mat.name = '2618 Aluminum';

-- CP Pistons SR20DET (turbo drift)
INSERT INTO pistons (manufacturer_id, model, part_number, bore_size, compression_height, pin_diameter,
                    pin_length, dish_dome_cc, dome_height, valve_relief_intake_depth, valve_relief_intake_diameter,
                    valve_relief_exhaust_depth, valve_relief_exhaust_diameter, ring_pack, coating,
                    max_rpm, max_boost, weight, material_id, price_new, price_used, notes)
SELECT m.id, 'SR20DET Turbo', 'SC7304', 86.5, 30.0, 21.0,
       55.0, 11.0, NULL, 2.5, 34.0, 2.0, 30.0,
       '1.2mm/1.2mm/2.8mm', 'Ceramic crown', 8500, 40.0, 280.0, mat.id, 800.00, NULL,
       'Forged dished for SR20 turbo, 11cc dish, 8.8:1 CR'
FROM manufacturers m, materials mat
WHERE m.name = 'CP Pistons' AND mat.name = '2618 Aluminum';

-- ============================================================================
-- ============================================================================
-- LS: (LS1, LS2, LS3, LS7)
-- SBC: (350 flat, 383 domed, 406 turbo, 350 hyper)
-- Honda: (B16A, B18C, K20A, K24A2)
-- JDM: (2JZ-GE, 2JZ-GTE, 4G63, SR20DET)
--
-- ============================================================================
