#!/bin/bash
# ============================================================================
# PISTON Parts Database - Initialization Script (Linux/Mac)
# ============================================================================
# This script initializes the PISTON parts database by:
# 1. Creating the database schema (tables, indexes, triggers)
# 2. Loading sample data (10 manufacturers, 5 blocks, 5 heads, etc.)
# 3. Loading extended manufacturers (11 additional)
# 4. Loading extended parts data (~90 parts total)
#
# Usage:
#   ./init_database.sh [database_path]
#
# Example:
#   ./init_database.sh piston.db
#   ./init_database.sh ../../piston.db
#
# Requirements:
#   - sqlite3 command-line tool installed
#   - Write permissions to database directory
# ============================================================================

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'  # No Color

# Default database path
DB_PATH="${1:-piston.db}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${GREEN}===============================================${NC}"
echo -e "${GREEN}PISTON Parts Database Initialization${NC}"
echo -e "${GREEN}===============================================${NC}"
echo ""

# Check if sqlite3 is installed
if ! command -v sqlite3 &> /dev/null; then
    echo -e "${RED}ERROR: sqlite3 is not installed${NC}"
    echo "Please install SQLite3:"
    echo "  Ubuntu/Debian: sudo apt-get install sqlite3"
    echo "  macOS: brew install sqlite3"
    exit 1
fi

# Check if database already exists
if [ -f "$DB_PATH" ]; then
    echo -e "${YELLOW}WARNING: Database file already exists: $DB_PATH${NC}"
    read -p "Do you want to overwrite it? (yes/no): " -n 3 -r
    echo
    if [[ ! $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
        echo "Aborted."
        exit 0
    fi
    rm "$DB_PATH"
    echo -e "${GREEN}Removed existing database${NC}"
fi

# Function to execute SQL file
execute_sql() {
    local sql_file="$1"
    local description="$2"

    if [ ! -f "$SCRIPT_DIR/$sql_file" ]; then
        echo -e "${RED}ERROR: SQL file not found: $sql_file${NC}"
        exit 1
    fi

    echo -ne "${YELLOW}Loading $description...${NC}"
    if sqlite3 "$DB_PATH" < "$SCRIPT_DIR/$sql_file" 2>&1 | grep -q "Error"; then
        echo -e " ${RED}FAILED${NC}"
        exit 1
    fi
    echo -e " ${GREEN}OK${NC}"
}

# Create new database and load schema
echo -e "${GREEN}Step 1: Creating database schema${NC}"
execute_sql "schema.sql" "schema (tables, indexes, triggers)"

# Load sample data
echo -e "${GREEN}Step 2: Loading sample data${NC}"
execute_sql "sample_data.sql" "sample data (manufacturers, materials, fuels, parts)"

# Load extended manufacturers
echo -e "${GREEN}Step 3: Loading extended manufacturers${NC}"
execute_sql "manufacturers_extended.sql" "extended manufacturers (11 additional)"

# Load extended parts data
echo -e "${GREEN}Step 4: Loading extended parts data${NC}"
execute_sql "engine_blocks_data.sql" "engine blocks (15 additional)"
execute_sql "cylinder_heads_data.sql" "cylinder heads (20 additional)"
execute_sql "pistons_data.sql" "pistons (18 additional)"
execute_sql "connecting_rods_data.sql" "connecting rods (15 additional)"
execute_sql "crankshafts_data.sql" "crankshafts (12 additional)"
execute_sql "camshafts_data.sql" "camshafts (20 additional)"
execute_sql "turbochargers_extended.sql" "turbochargers (10 additional)"
execute_sql "superchargers_data.sql" "superchargers"
execute_sql "materials_thermal_update.sql" "material thermal properties (UPDATEs)"

# Verify database contents
echo ""
echo -e "${GREEN}Step 5: Verifying database contents${NC}"
echo ""

# Get counts from database
MANUFACTURERS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM manufacturers;")
MATERIALS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM materials;")
FUELS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM fuels;")
ENGINE_BLOCKS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM engine_blocks;")
CYLINDER_HEADS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM cylinder_heads;")
PISTONS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM pistons;")
CONNECTING_RODS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM connecting_rods;")
CRANKSHAFTS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM crankshafts;")
CAMSHAFTS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM camshafts;")
TURBOCHARGERS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM turbochargers;")
INTAKE_MANIFOLDS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM intake_manifolds;")

echo "Database Contents:"
echo "  Manufacturers:     $MANUFACTURERS"
echo "  Materials:         $MATERIALS"
echo "  Fuels:             $FUELS"
echo "  Engine Blocks:     $ENGINE_BLOCKS"
echo "  Cylinder Heads:    $CYLINDER_HEADS"
echo "  Pistons:           $PISTONS"
echo "  Connecting Rods:   $CONNECTING_RODS"
echo "  Crankshafts:       $CRANKSHAFTS"
echo "  Camshafts:         $CAMSHAFTS"
echo "  Turbochargers:     $TURBOCHARGERS"
echo "  Intake Manifolds:  $INTAKE_MANIFOLDS"

# Calculate total parts
TOTAL_PARTS=$((ENGINE_BLOCKS + CYLINDER_HEADS + PISTONS + CONNECTING_RODS + CRANKSHAFTS + CAMSHAFTS + TURBOCHARGERS + INTAKE_MANIFOLDS))
echo ""
echo -e "${GREEN}Total Parts:         $TOTAL_PARTS${NC}"

# Display database file size
DB_SIZE=$(du -h "$DB_PATH" | cut -f1)
echo -e "${GREEN}Database Size:       $DB_SIZE${NC}"

echo ""
echo -e "${GREEN}===============================================${NC}"
echo -e "${GREEN}Database initialization complete!${NC}"
echo -e "${GREEN}Database file: $DB_PATH${NC}"
echo -e "${GREEN}===============================================${NC}"

# Optional: Run VACUUM to optimize database
echo ""
read -p "Do you want to optimize (VACUUM) the database? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -ne "${YELLOW}Optimizing database...${NC}"
    sqlite3 "$DB_PATH" "VACUUM;"
    echo -e " ${GREEN}OK${NC}"
    DB_SIZE=$(du -h "$DB_PATH" | cut -f1)
    echo -e "${GREEN}Optimized database size: $DB_SIZE${NC}"
fi

echo ""
echo "You can now use the database with:"
echo "  sqlite3 $DB_PATH"
echo ""
