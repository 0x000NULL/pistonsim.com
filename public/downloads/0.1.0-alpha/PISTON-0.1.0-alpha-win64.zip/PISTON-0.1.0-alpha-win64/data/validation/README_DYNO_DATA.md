# PISTON Validation Data - README

## Overview

This directory contains dyno data for validating the PISTON engine simulation against real-world measurements. Accurate validation data is critical for improving the simulation's physics models.

## Quick Start

### For LS3 Stock Validation (Priority)

1. **Start with the quick fill template:**
   ```
   _QUICK_FILL_TEMPLATE.json
   ```

2. **Copy and rename it:**
   ```
   naturally_aspirated/ls3_stock_YOURNAME.json
   ```

3. **Fill in the dyno data** (see instructions below)

4. **Validate the file** by running the validation tests

---

## Where to Find Dyno Data

### Option 1: Online Dyno Databases (Easiest)
- **LS1Tech Forums** - https://ls1tech.com/forums/dyno-results/ (LS-series engines)
- **Corvette Forum** - https://www.corvetteforum.com/forums/c6-general-discussion/
- **LS3 Dyno Results Thread** - Search for "LS3 stock baseline dyno"
- **Motor Trend / Car and Driver** - Published test data from magazine reviews

### Option 2: Contact Dyno Shops
Reach out to performance shops that specialize in GM LS engines:
- Explain this is for open-source research/validation
- Ask for anonymized baseline dyno runs (stock LS3)
- Offer attribution in the project documentation

### Option 3: Academic Research Papers
- Search Google Scholar for: "LS3 dynamometer testing"
- University research often includes detailed dyno data
- Check SAE (Society of Automotive Engineers) technical papers

### Option 4: OEM Data
- GM Engineering documents (may be restricted)
- Service manuals sometimes include power curves
- Factory calibration data (if accessible)

---

## How to Fill Out the Template

### Step 1: Choose Your Template

**_QUICK_FILL_TEMPLATE.json** - For basic dyno data
- Use this if you just have RPM, HP, Torque numbers
- Minimal fields required

**_DYNO_DATA_TEMPLATE.json** - For comprehensive data
- Use this if you have detailed dyno sheets
- Includes cam specs, conditions, uncertainty estimates

### Step 2: Gather Your Data

You need at minimum:
- ✅ RPM values (e.g., 2000, 3000, 4000, 5000, 6000 RPM)
- ✅ Horsepower at each RPM
- ✅ Torque (lb-ft) at each RPM

Nice to have:
- Dyno correction factor (SAE J1349 is standard)
- Ambient conditions (temp, pressure)
- Engine specifications (bore, stroke, compression)

### Step 3: Fill in the JSON File

**Example: You have this dyno printout:**
```
RPM     HP      Torque (lb-ft)
2000    130     341
3000    220     386
4000    315     414
5000    390     410
5900    430     382
6500    420     339
```

**Your JSON curves section should be:**
```json
"curves": {
  "rpm": [2000, 3000, 4000, 5000, 5900, 6500],
  "power_hp": [130, 220, 315, 390, 430, 420],
  "torque_ftlb": [341, 386, 414, 410, 382, 339]
}
```

### Step 4: Verify Your Data

**Critical checks:**
1. All three arrays (rpm, power_hp, torque_ftlb) have **same length**
2. RPM values are in **ascending order**
3. Check the relationship: `Power (HP) = Torque (lb-ft) × RPM / 5252`
   - Example: At 5000 RPM with 410 lb-ft:
   - Expected HP = 410 × 5000 / 5252 = **390 HP** ✓

4. Peak values match the maximum in curves:
   - `peak_power_hp` should be the max value in `power_hp` array
   - `peak_power_rpm` should be the RPM where that max occurs

### Step 5: Save and Test

1. Save your file in the correct directory:
   - Naturally aspirated: `naturally_aspirated/`
   - Turbocharged: `turbocharged/`
   - Supercharged: `supercharged/`

2. Run the validation tests:
   ```bash
   ./build/bin/Debug/piston_tests.exe "[validation]"
   ```

3. Check for errors in the test output

---

## File Naming Convention

Use descriptive names that identify the engine and configuration:

```
ls3_stock_dynojet_2024.json          ✓ Good
ls3_cam_headers_tune_ABC_shop.json   ✓ Good (modified engine)
k20a2_type_r_stock.json              ✓ Good (different engine)
2jzgte_stock_auto_trans.json         ✓ Good (transmission matters)

data.json                            ✗ Bad (not descriptive)
my_dyno_run.json                     ✗ Bad (which engine?)
```

---

## Current Data Status

### Priority Engines (Phase 1):

| Engine | Status | File | Priority |
|--------|--------|------|----------|
| **LS3 6.2L V8 Stock** | Published measured curve | `ls3_stock_measured_published.json` (and the rating-based `ls3_stock_published.json`) | **HIGH** |
| Honda K20A2 Stock | ❌ Missing | - | MEDIUM |
| Toyota 2JZ-GE Stock | ❌ Missing | - | MEDIUM |

### Phase 2 Targets (Future):

- LS3 with camshaft upgrade
- 2JZ-GTE turbocharged
- Coyote 5.0L V8
- EcoBoost 2.3L turbocharged

---

## Data Quality Guidelines

### Excellent Quality (Preferred):
- ✓ Engine dyno (not chassis dyno)
- ✓ SAE J1349 corrected
- ✓ 10+ data points across RPM range
- ✓ Completely stock configuration
- ✓ Known ambient conditions
- ✓ Verifiable source (dyno shop, publication)

### Acceptable Quality:
- ✓ Chassis dyno (with drivetrain loss noted)
- ✓ Any correction factor (as long as specified)
- ✓ 5+ data points
- ✓ Minor modifications documented
- ✓ Reasonable ambient conditions assumed

### Poor Quality (Avoid):
- ✗ Uncorrected dyno data with unknown conditions
- ✗ < 5 data points
- ✗ Unknown modifications
- ✗ Conflicting specifications
- ✗ Data that doesn't follow Power = Torque × RPM / 5252

---

## Validation Targets

### Phase 1: <20% RMSE
- Goal: Prove the simulation framework works
- Engine: LS3 stock (simple NA configuration)
- Acceptable error with simplified Otto cycle model

### Phase 2: <15% RMSE
- Wiebe combustion + Woschni heat transfer
- Multiple engine validation
- Beginning of useful predictive capability

### Phase 3: <10% RMSE (MVP)
- Production-ready simulation
- Multiple engines and configurations
- Publishable accuracy

### Phase 5: <7% RMSE (Professional)
- Industry-grade accuracy
- Commercial viability
- Competitive with GT-POWER, Ricardo WAVE

---

## Contributing Data

If you have dyno data to contribute:

1. **Anonymize sensitive information** (remove VIN, customer names, etc.)
2. **Use the templates** provided
3. **Include source attribution** (dyno shop name or publication)
4. **Create a pull request** or open an issue with the data
5. **We will credit you** in the project documentation

### Data License

All validation data should be:
- Publicly shareable (no proprietary/confidential data)
- Properly attributed to source
- Used for research/validation purposes only

---

## Need Help?

- **Template questions**: See `_DYNO_DATA_TEMPLATE.json` inline comments
- **Can't find data**: Open a GitHub issue - community may help
- **Data format errors**: Run validation tests for specific error messages
- **Other questions**: Check project README or open an issue

---

## Appendix: Unit Conversions

### Power
- 1 HP (SAE) = 745.7 Watts
- 1 kW = 1.341 HP
- 1 PS (metric HP) = 0.9863 HP

### Torque
- 1 lb-ft = 1.356 Nm
- 1 kg-m = 7.233 lb-ft

### Displacement
- 1 liter = 61.024 cubic inches
- 1 cubic inch = 0.0163871 liters

### Pressure
- 1 bar = 14.504 PSI
- 1 atm = 14.696 PSI = 29.92 inHg

### Temperature
- °C = (°F - 32) × 5/9
- K = °C + 273.15

---

**Last Updated**: Phase 1 Development
**Next Review**: After first real dyno data acquisition
