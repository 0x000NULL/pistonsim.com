# Validation data — what is actually in this directory

This directory holds the reference entries `piston validate-dyno` compares against. It is
**not** a corpus of measured dyno runs, and this document exists to say so plainly.

## What these entries are

Twenty entries. Three are digitized manufacturer-published measured sweeps; none is a
first-party logged run:

| `curve_provenance` | Count | Meaning |
|---|--:|---|
| `reconstructed_from_published_peaks` | 17 | Published peak power/torque are real; the 9–14 curve points around them are interpolated or estimated |
| `published_peak_only` | 0 | — |
| `published_measured_curve` | 3 | A real measured engine-dyno sweep **published by a third party** (manufacturer certification/catalog curve or equivalent primary source), digitized — the entry must cite the publication and record the digitization method and read-off uncertainty. Third-party measured data, **not** a blind point. The three entries are the GM LS3 and LT4 crate-engine dyno charts (`tools/digitize_dyno_chart.py`) and the JDM F20C diagram from Honda's own 1999 S2000 factbook (`tools/digitize_factbook_curve.py`); each records its source URL, image SHA-256, exact invocation and read-off uncertainty |
| `measured_dyno_curve` | 0 | A **first-party logged run**. **Nothing here qualifies** |

Every entry declares its own provenance in `dyno_data.curve_provenance`; the loader rejects an
entry that omits it or invents a value. List the current state rather than trusting this table:

```
piston validate-dyno --list
```

Three entries (`ls3_stock_published`, `lsa_stock_published`, `2jzgte_single_turbo_e85_community`) additionally
carry a per-point `curves._data_quality` array distinguishing `verified` points from
`extrapolated` ones, and the three digitized entries label every point
`digitized_from_published_chart`. The other seventeen carry no point-level provenance at all.

## What that means for accuracy figures

`validate-dyno` reports RMSE against these curves. For the seventeen reconstructed entries:

- **Peak error is the meaningful number.** It compares against a published figure.
- **Curve-shape RMSE is soft.** It measures agreement with an interpolation, not with an engine.

For the three `published_measured_curve` entries, curve-shape RMSE measures agreement with
the manufacturer's own published sweep, within the read-off uncertainty each entry records.
(The JDM F20C entry describes the 250 PS JIS-net AP1 variant, so it is a `validate-dyno`
reference only — the fleet row keeps its USDM spec basis; the entry says why.)
- **Nothing here is certified**, by SAE or anyone else, and no third party supplied or endorsed
  these files. Where a magazine, forum, or tuning company appears in a `sources` array, it is a
  citation of something published, not a contributor.

For fleet accuracy across 22 engines against published peaks, use the harness output at
[`../../docs/validation/accuracy.generated.md`](../../docs/validation/accuracy.generated.md),
which is generated rather than hand-written.

## Layout

```
data/validation/
├── schema.json                 canonical entry schema (the C++ loader is the real authority)
├── _DYNO_DATA_TEMPLATE.json     annotated template — every field explained
├── _QUICK_FILL_TEMPLATE.json    minimal template for adding your own measured data
├── fleet_reference.csv         published peaks for the 22-engine accuracy harness
├── naturally_aspirated/        14 entries
├── supercharged/               3 entries
└── turbocharged/               6 entries
```

## Adding real measured data

This is the gap worth closing. If you have a logged sweep you can point at, copy
`_QUICK_FILL_TEMPLATE.json`, fill it in, and set `curve_provenance` to `measured_dyno_curve` —
the only entries entitled to that value are ones backed by an actual run. Field-by-field guidance
is in [`../../docs/validation/validation_data_guide.md`](../../docs/validation/validation_data_guide.md).

Record what you actually know. A missing field is recoverable; an invented one is not.
